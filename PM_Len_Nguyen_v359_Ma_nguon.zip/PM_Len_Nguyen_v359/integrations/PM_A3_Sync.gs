/** @OnlyCurrentDoc */
/** A3 price_tt A/C/D/E/F inputs; calculated columns G:AI are read-only results. */
function PM_A3_KiemTraCauHinh() {
  var p = PropertiesService.getScriptProperties();
  if (!p.getProperty('PM_A3_TOKEN') || !p.getProperty('PM_SITE_ACCESS')) throw new Error('Chưa cấu hình kết nối bảo mật PM. Chưa bật lịch.');
  return p;
}
function PM_A3_CaiDatMoiPhut() {
  PM_A3_KiemTraCauHinh();
  PM_A3_DongBo();
  var existing = ScriptApp.getProjectTriggers().filter(function(t) { return t.getHandlerFunction() === 'PM_A3_DongBo'; });
  if (!existing.length) ScriptApp.newTrigger('PM_A3_DongBo').timeBased().everyMinutes(1).create();
  PropertiesService.getScriptProperties().setProperty('PM_A3_TRIGGER_INSTALLED','true');
  // Do not touch other project triggers.
  console.log('Đã thiết lập đồng bộ A3 hai chiều mỗi phút.');
}
function PM_A3_DongBo() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(1000)) return;
  try {
    var p = PM_A3_KiemTraCauHinh();
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('price_tt');
    if (!sheet || sheet.getLastRow() > 10001) throw new Error('Nguồn thiếu / quá 10.000 dòng, giữ bản PM trước đó.');
    function normalized(r) { return {code:String(r[2] || '').trim().toUpperCase(),date:r[0] instanceof Date?Utilities.formatDate(r[0],'Etc/GMT','yyyy-MM-dd'):String(r[0] || ''),price:Number(r[4]),fbPrice:r[5]===''||r[5]==null?null:Number(r[5])}; }
    function values() { return sheet.getRange(1,1,sheet.getLastRow(),35).getValues().map(function(r,i) { if (r[0] instanceof Date) r[0]=Utilities.formatDate(r[0],'Etc/GMT','yyyy-MM-dd');return r; }); }
    function post(acks) {
      var response=UrlFetchApp.fetch('https://pm.lennguyenstore.com/api/a3-sync',{method:'post',contentType:'application/json',followRedirects:false,muteHttpExceptions:true,headers:{Authorization:'Bearer '+p.getProperty('PM_A3_TOKEN'),'OAI-Sites-Authorization':'Bearer '+p.getProperty('PM_SITE_ACCESS')},payload:JSON.stringify({source:'1Lg1Vq-KTo3xH1cnRs15ilXICoRYV0oA6QM4CK_Lksik',sheet:'price_tt',complete:true,values:values(),acks:acks||[],schedulerInstalled:p.getProperty('PM_A3_TRIGGER_INSTALLED')==='true'})});
      if(response.getResponseCode()!==200) throw new Error('PM chưa nhận dữ liệu, HTTP '+response.getResponseCode());
      var result=JSON.parse(response.getContentText());if(!result.ok) throw new Error('PM chưa xác nhận đồng bộ');return result;
    }
    var result=post(),acks=[];
    (result.outbox||[]).forEach(function(q) {
      try {
        var grid=sheet.getRange(1,1,sheet.getLastRow(),6).getValues(),target=q.target,expected=q.expected,key=expected||target,matches=[];
        grid.slice(1).forEach(function(r,i){var n=normalized(r);if(n.code===key.code&&n.date===key.date)matches.push({row:i+2,value:n});});
        if(matches.length>1) throw new Error('A3 có nhiều dòng cùng mã / ngày; không ghi đè');
        var targetMatches=[];grid.slice(1).forEach(function(r,i){var n=normalized(r);if(n.code===target.code&&n.date===target.date)targetMatches.push({row:i+2,value:n});});
        // Retry after a successful write but lost acknowledgment: no second insert.
        if(targetMatches.length===1&&JSON.stringify(targetMatches[0].value)===JSON.stringify(target)&&(q.targetName===undefined||String(grid[targetMatches[0].row-1][3]||'').trim()===q.targetName)){acks.push({id:q.id,revision:q.revision,ok:true});return;}
        if(expected){if(matches.length!==1||JSON.stringify(matches[0].value)!==JSON.stringify(expected))throw new Error('A3 đã sửa khác với bản PM; cần đối chiếu');if(targetMatches.some(function(x){return x.row!==matches[0].row;}))throw new Error('Mã / ngày mới đã tồn tại');}
        if(expected&&q.expectedName!==undefined&&String(grid[matches[0].row-1][3]||'').trim()!==q.expectedName)throw new Error('Tên sản phẩm A3 đã đổi; cần đối chiếu');
        else if(!expected&&matches.length)throw new Error('A3 đã có mã / ngày, không thêm trùng');
        var lastProduct=1;grid.forEach(function(r,i){if(String(r[2]||'').trim())lastProduct=i+1;});var row=expected?matches[0].row:lastProduct+1;
        if(row>sheet.getMaxRows())throw new Error('Hết dòng mẫu A3; cần mở rộng mẫu trước khi thêm');if(!expected){sheet.getRange(3,1,1,35).copyFormatToRange(sheet,1,35,row,row);sheet.getRange(3,1).copyTo(sheet.getRange(row,1),SpreadsheetApp.CopyPasteType.PASTE_DATA_VALIDATION,false);}
        var cells=[sheet.getRange(row,1),sheet.getRange(row,3),sheet.getRange(row,5),sheet.getRange(row,6)];if(q.targetName!==undefined)cells.push(sheet.getRange(row,4));
        if(cells.some(function(c){return Boolean(c.getFormula());}))throw new Error('Ô đích có công thức; cần đối chiếu trước khi sửa');
        // Recheck immediately before the write; never modify quantity B or G:AI formulas.
        if(expected&&JSON.stringify(normalized(sheet.getRange(row,1,1,6).getValues()[0]))!==JSON.stringify(expected))throw new Error('A3 vừa đổi, hoãn ghi');
        cells[0].setValue(target.date?new Date(target.date+'T12:00:00Z'):'');cells[0].setNumberFormat('dd/MM/yyyy');cells[1].setValue(target.code);cells[2].setValue(target.price);cells[3].setValue(target.fbPrice==null?'':target.fbPrice);if(q.targetName!==undefined)cells[4].setValue(q.targetName?'\''+q.targetName:'');SpreadsheetApp.flush();
        if((q.targetName!==undefined&&String(sheet.getRange(row,4).getValue()||'').trim()!==q.targetName)||JSON.stringify(normalized(sheet.getRange(row,1,1,6).getValues()[0]))!==JSON.stringify(target))throw new Error('Đọc lại A3 chưa khớp');
        acks.push({id:q.id,revision:q.revision,ok:true});
      }catch(e){acks.push({id:q.id,revision:q.revision,ok:false,error:String(e.message||e)});}
    });
    if(acks.length) result=post(acks);
    p.setProperty('PM_A3_LAST_SUCCESS',new Date().toISOString());p.deleteProperty('PM_A3_LAST_ERROR');
    console.log('Đã đồng bộ '+result.rows+' dòng; '+acks.length+' thay đổi PM đã đối chiếu.');
  } catch(e) {PropertiesService.getScriptProperties().setProperty('PM_A3_LAST_ERROR',String(e.message||e));throw e;} finally {lock.releaseLock();}
}
