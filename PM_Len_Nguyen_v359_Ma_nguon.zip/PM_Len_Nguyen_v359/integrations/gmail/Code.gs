const ACCOUNT = 'owner@example.invalid';
const ENDPOINT = 'https://pm.lennguyenstore.com/api/gmail-evidence';
const START = Date.parse('2026-04-01T00:00:00+07:00') / 1000;
const HANDOFF = Date.parse('2026-11-20T00:00:00+07:00') / 1000;
const DAY = 86400;
const RECENT_START = HANDOFF - DAY;

function installGmailSync(){
 if(Gmail.Users.getProfile('me').emailAddress!==ACCOUNT)throw Error('Chọn đúng Gmail của shop');
 if(!PropertiesService.getScriptProperties().getProperty('GMAIL_IMPORT_TOKEN'))throw Error('Thiếu GMAIL_IMPORT_TOKEN');
 if(!ScriptApp.getProjectTriggers().some(t=>t.getHandlerFunction()==='runGmailSync'))ScriptApp.newTrigger('runGmailSync').timeBased().everyMinutes(15).create();
 runGmailSync();
}
function postPM(suffix,options){
 const p=PropertiesService.getScriptProperties();
 if(!p.getProperty('GMAIL_IMPORT_TOKEN'))throw Error('Thiếu GMAIL_IMPORT_TOKEN');
 const headers={Authorization:'Bearer '+p.getProperty('GMAIL_IMPORT_TOKEN')};
 if(p.getProperty('PM_SITE_ACCESS'))headers['OAI-Sites-Authorization']='Bearer '+p.getProperty('PM_SITE_ACCESS');
 const res=UrlFetchApp.fetch(ENDPOINT+suffix,Object.assign({method:'post',headers,followRedirects:false,muteHttpExceptions:true},options));
 if(res.getResponseCode()!==200)throw Error('PM HTTP '+res.getResponseCode());
 const json=JSON.parse(res.getContentText());
 if(json.ok!==true)throw Error('PM chưa xác nhận');
 return json;
}
function runGmailSync(event){runLanes(['recent','catchup'],event);}
function runHistoricalPage(){runLanes(['history']);}
function runLanes(lanes,event){
 const context={execution:event&&event.triggerUid?'clock':'manual',runId:Utilities.getUuid()};
 const lock=LockService.getScriptLock();
 if(!lock.tryLock(1000))return;
 try{
  if(Gmail.Users.getProfile('me').emailAddress!==ACCOUNT)throw Error('Sai tài khoản');
  const errors=[];
  const deadline=Date.now()+240000;
  for(const lane of lanes){
   try{scan(lane,deadline,context);}
   catch(e){
    const msg=String(e).slice(0,240);
    try{progress(lane,'Đang chờ thử lại',msg,context);}catch(ignored){}
    errors.push(lane+' '+msg);
   }
  }
  if(errors.length)throw Error(errors.join(' / '));
 }finally{lock.releaseLock();}
}
function progress(lane,detail,error,proof){
 const label=lane==='catchup'?'Rà soát bổ sung 48 giờ · ':'';
 // v135 exposes recent and history activity streams.
 postPM('?progress=1',{contentType:'application/json',payload:JSON.stringify({reviewed:0,saved:0,newOriginals:[],...proof,lane:lane==='catchup'?'recent':lane,actualLane:lane,detail:label+detail,error})});
}
function fold(value) {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/gi,'d').toLowerCase();
}

function asText(html) {
  return html.replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1>/gi,' ')
    .replace(/<br\s*\/?\s*>|<\/(?:p|div|tr|li|td|h[1-6])\s*>/gi,'\n').replace(/<[^>]+>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&')
    .replace(/&#39;/g,"'").replace(/&quot;/g,'"').replace(/[ \t]+/g,' ').trim();
}

function vnInvoice(xml) {
  if(/<!DOCTYPE|<!ENTITY/i.test(xml)) return null;
  const root=XmlService.parse(xml).getRootElement();
  function children(el,name) {return el ? el.getChildren().filter(node=>node.getName()===name) : [];}
  function one(el,name) {const hits=children(el,name);return hits.length===1?hits[0]:null;}
  function value(el,name) {const node=one(el,name);return node ? node.getText().trim() : '';}
  const doc=root.getName()==='HDon'?root:one(root,'HDon');
  const data=one(doc,'DLHDon'), header=one(data,'TTChung'), detail=one(data,'NDHDon');
  const seller=one(detail,'NBan'), buyer=one(detail,'NMua'), pay=one(detail,'TToan');
  if(!header || !seller || !buyer || !pay) return null;
  const lines=children(one(detail,'DSHHDVu'),'HHDVu');
  return {vendor:value(seller,'Ten'),vendorTaxId:value(seller,'MST'),buyerName:value(buyer,'Ten'),
    buyerTaxId:value(buyer,'MST'),series:value(header,'KHHDon'),number:value(header,'SHDon'),
    date:value(header,'NLap'),currency:value(header,'DVTTe'),total:value(pay,'TgTTTBSo'),
    descriptions:lines.map(line=>value(line,'THHDVu')).filter(Boolean),
    adjusted:!!one(header,'TTHDLQuan')||!!one(header,'TTKThayThe')||
      /dieu chinh|thay the/.test(fold(value(header,'THDon')+' '+lines.map(line=>value(line,'THHDVu')).join(' ')))};
}

function fileDigest(bytes) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,bytes)
    .map(b=>(b&255).toString(16).padStart(2,'0')).join('');
}

function readInvoiceLinks(links,propValue) {
  const hosts=new Set((propValue||'').split(/[,\s]+/).map(value=>value.trim().toLowerCase()).filter(Boolean));
  const fields={};
  let downloaded=0;
  for(const [index,entry] of links.entries()) {
    const match=/^https:\/\/([a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,63})(?:\/|\?|$)/i.exec(entry.url);
    const host=match ? match[1].toLowerCase() : '';
    entry.readIssue='Chưa cấu hình quyền tải từ tên miền này';
    if(!host || !hosts.has(host) || /(?:^|\.)(?:localhost|local|internal|test|invalid)$/.test(host))continue;
    if(downloaded>=3) {entry.readIssue='Vượt số liên kết cho một thư, cần tải bổ sung';continue;}
    try {
      const res=UrlFetchApp.fetch(entry.url,{method:'get',followRedirects:false,validateHttpsCertificates:true,muteHttpExceptions:true});
      if(res.getResponseCode()!==200) {entry.readIssue='Nguồn trả HTTP '+res.getResponseCode();continue;}
      const blob=res.getBlob(), bytes=blob.getBytes(), type=(blob.getContentType()||'').split(';')[0].toLowerCase();
      if(bytes.length===0||bytes.length>4*1024*1024) {entry.readIssue='Tệp rỗng hoặc vượt 4 MB, cần tải bổ sung';continue;}
      const exts={'application/pdf':'pdf','text/xml':'xml','application/xml':'xml','image/png':'png','image/jpeg':'jpg','text/csv':'csv','application/vnd.ms-excel':'xls','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'xlsx'};
      const ext=exts[type];
      if(!ext) {entry.readIssue='Liên kết chưa trả về tệp chứng từ trực tiếp';continue;}
      entry.name='chung-tu-'+(index+1)+'.'+ext;
      entry.originalField='link_'+index;
      entry.mimeType=type;
      entry.size=bytes.length;
      entry.sha256=fileDigest(bytes);
      if(ext==='xml'&&bytes.length<=500000) {
        try {entry.invoice=vnInvoice(blob.getDataAsString('UTF-8'));}catch(e){entry.readIssue='XML không phân tích được';}
      }
      fields[entry.originalField]=blob.setName(entry.name);
      downloaded++;
      if(entry.readIssue==='Chưa cấu hình quyền tải từ tên miền này') delete entry.readIssue;
    } catch(e) {entry.readIssue='Lỗi khi đọc tệp liên kết';}
  }
  return fields;
}

// Read Gmail's documented REST JSON representation. The Advanced Service can
// already have converted a discovery "byte" field when it crosses into Apps Script.
function gmailMessageData(id,format,attachmentId) {
  const messagePath='https://gmail.googleapis.com/gmail/v1/users/me/messages/'+encodeURIComponent(id);
  const url=attachmentId ? messagePath+'/attachments/'+encodeURIComponent(attachmentId)
    : messagePath+'?format='+encodeURIComponent(format);
  const response=UrlFetchApp.fetch(url,{headers:{Authorization:'Bearer '+ScriptApp.getOAuthToken()},
    followRedirects:false,muteHttpExceptions:true});
  if(response.getResponseCode()!==200)throw Error('Gmail '+id+' HTTP '+response.getResponseCode());
  return JSON.parse(response.getContentText());
}

function gmailBytes(data,label) {
  if(data!=null && typeof data!=='string') {
    const value=typeof data.getBytes==='function' ? data.getBytes() : data;
    if(Number.isInteger(value.length) && value.length>=0) {
      const signed=[];
      for(let i=0;i<value.length;i++) {
        const b=value[i];
        if(!Number.isInteger(b)||b < -128||b>255)throw Error(label+' · byte không hợp lệ');
        signed.push(b>127?b-256:b);
      }
      return signed;
    }
  }
  if(typeof data!=='string')throw Error(label+' · thiếu dữ liệu Gmail');
  const normalized=data.replace(/[\r\n\t ]/g,'').replace(/=+$/,'')
    .replace(/-/g,'+').replace(/_/g,'/');
  if(normalized.length%4===1||/[^a-zA-Z0-9+/]/.test(normalized))throw Error(label+' · base64 không hợp lệ');
  try {return Utilities.base64Decode(normalized+'='.repeat((4-normalized.length%4)%4));}
  catch(error) {throw Error(label+' · Gmail trả nội dung không giải mã được');}
}

function originalMail(id) {
  const response=gmailMessageData(id,'raw');
  if(response.id!==id)throw Error('Gmail trả sai mã thư '+id);
  const bytes=gmailBytes(response.raw,'Thư gốc '+id);
  // Validate a header and its boundary without decoding the binary body.
  let prefix='';
  for(let i=0;i<Math.min(bytes.length,262144);i++) {
    prefix+=String.fromCharCode(bytes[i]&255);
    if(prefix.endsWith('\n\n')||prefix.endsWith('\r\n\r\n'))break;
  }
  if(!/^(?:[!-9;-~]+):/m.test(prefix)||!/\r?\n\r?\n/.test(prefix))throw Error('Thư gốc '+id+' thiếu đầu thư MIME');
  return Utilities.newBlob(bytes,'message/rfc822',id+'.eml');
}

function inspectMessage(message) {
  const headers = message.payload.headers || [];
  const field = name => (headers.find(header => header.name.toLowerCase() === name) || {}).value || '';
  const subject = field('subject');
  const from=(field('from').match(/<([^<>]+)>/)||[null,field('from')])[1].trim().toLowerCase();
  if(from==='no-reply@accounts.google.com' && /^(?:security alert|canh bao bao mat|alerte de securite)(?:$|\s)/.test(fold(subject).trim())) {
    return {subject,sender:field('from'),manifest:{version:1,reasons:[],attachments:[],links:[],bodyText:''}};
  }
  const ar=field('authentication-results');
  const auth=ar.split(';',1)[0].trim().toLowerCase()==='mx.google.com'
    && ((ar.match(/\bdmarc=pass\b[^;]*\bheader\.from=([^;\s]+)/i)||[])[1]||'').toLowerCase()===from.split('@')[1];
  const attachments = [], attachmentParts=[], bodies = [], links = [];
  const documentWords = /hoa\s*don|invoice|receipt|bien lai|phieu (thu|chi|nhap|xuat)|doi soat|quyet toan|billing statement|credit note|debit note|tax document|chung tu|发票|收据|账单|对账单|結算單|發票|收據|帳單/;
  const costWords = /cuoc phi|tien dien|tien nuoc|tien thue|phi van chuyen|phi dich vu|phi san|phi hoan|gia han|cong no|nhap hang|vat tu|bang ke|thanh toan|thu ho|payment received|payment confirmation|settlement|shipping fee|subscription renewal|service period|amount paid|amount due|vat amount|采购|运费|付款|货款|服務費/;
  function link(url,label) {
    url = url.replace(/&amp;/gi,'&').replace(/[).,;]+$/,'');
    if (!/^https:\/\/[^/@\s]+(?:\/|$)/i.test(url) || url.length > 3500) return;
    if (documentWords.test(fold(label+' '+url)) && !links.some(item=>item.url===url)) {
      links.push({url,label:substringLabel(label)});
    }
  }
  function substringLabel(label) { return asText(label).slice(0,300); }
  function visit(part) {
    const name = part.filename || '', type = (part.mimeType || '').toLowerCase();
    if (name) {
      attachments.push({name,mimeType:type,size:Number((part.body||{}).size)||0});
      attachmentParts.push(part);
    }
    if (!name && (type==='text/plain' || type==='text/html')) {
      const body=part.body||{};
      let data=body.data;
      if (!data && body.attachmentId) data=gmailMessageData(message.id,null,body.attachmentId).data;
      if (data) {
        const ct=(part.headers||[]).find(h=>h.name.toLowerCase()==='content-type');
        const charset=ct && /charset\s*=\s*["']?([\w.-]+)/i.exec(ct.value);
        const blob=Utilities.newBlob(gmailBytes(data,'Nội dung thư '+message.id));
        let content;
        try {content=blob.getDataAsString(charset ? charset[1] : 'UTF-8');}
        catch(e){content=blob.getDataAsString('UTF-8');}
        if(type==='text/html') {
          for(const a of content.matchAll(/<a\b[^>]*?\bhref\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)) link(a[1],asText(a[2]));
          content=asText(content);
        }
        for(const u of content.matchAll(/https:\/\/[^\s<>"']+/gi)) link(u[0],content.slice(Math.max(0,u.index-60),u.index));
        bodies.push(content);
      }
    }
    for(const child of part.parts||[]) visit(child);
  }
  visit(message.payload);
  const bodyText=bodies.join('\n'), names=attachments.map(a=>a.name).join(' ');
  const signal=fold([subject,names,bodyText].join(' '));
  const reasons=[];
  if(documentWords.test(signal)) reasons.push('Có dấu hiệu hóa đơn hoặc chứng từ đối soát');
  if(costWords.test(signal)) reasons.push('Có thông tin giao dịch hoặc dịch vụ cần đối chiếu');
  if(links.length) reasons.push('Có liên kết chứng từ cần kiểm tra quyền truy cập');
  if(!reasons.length && attachments.some(a=>/\.(pdf|xlsx?|csv|xml|zip|png|jpe?g|webp|tiff?)$/i.test(a.name))
       && /nha cung cap|doanh nghiep|mst\b|ma so thue|supplier|merchant|seller center|len nguyen store|company limited|公司/.test(signal)) {
    reasons.push('Tệp nhà cung cấp cần xác định loại');
  }
  if(!reasons.length && attachments.some(a=>/\.(pdf|xlsx?|csv|xml|zip|png|jpe?g|webp|tiff?)$/i.test(a.name))
     && /@(hq\.jtexpress\.vn|commercial\.tiktok\.com)(?:[>\s]|$)/i.test(field('from'))) {
    reasons.push('Tệp của nhà cung cấp cần rà soát');
  }
  let xmlBytes=0;
  for(let i=0;i<attachments.length;i++) {
    const entry=attachments[i], part=attachmentParts[i], body=part.body||{};
    const xml=/\.xml$/i.test(entry.name)||/^(?:application|text)\/(?:[\w.-]+\+)?xml(?:;|$)/i.test(entry.mimeType);
    if(!xml && !reasons.length) continue;
    if(entry.size>12*1024*1024) {
      entry.readIssue='Tệp quá lớn để tính mã nhận diện trong Apps Script';
      if(xml)entry.xmlTruncated=true;
      continue;
    }
    let encoded=body.data;
    if(!encoded && body.attachmentId)encoded=gmailMessageData(message.id,null,body.attachmentId).data;
    if(!encoded) {entry.readIssue='Thiếu nội dung tệp MIME';continue;}
    const bytes=gmailBytes(encoded,'Tệp đính kèm thư '+message.id);
    if(body.size!=null && Number(body.size)!==bytes.length)throw Error('Sai kích thước tệp trong thư '+message.id);
    entry.sha256=fileDigest(bytes);
    if(auth && /@hq\.jtexpress\.vn(?:[>\s]|$)/i.test(field('from')) && /\.xlsx$/i.test(entry.name)) {
      try {Object.assign(entry,readJtWorkbook(bytes));}
      catch(e) {entry.readIssue='Chưa xác minh được bảng kê J&T: '+String(e.message||e).slice(0,150);}
    }
    if(auth && /@commercial\.tiktok\.com(?:[>\s]|$)/i.test(field('from')) && /\.pdf$/i.test(entry.name)) {
      try {Object.assign(entry,tiktokPdf(bytes));}
      catch(e) {entry.readIssue='Chưa xác minh được mẫu PDF TikTok. Chờ đối chiếu bản gốc và chi tiêu thực chạy';}
    }
    if(xml && bytes.length<=500000 && xmlBytes+bytes.length<=700000) {
      const xmlText=Utilities.newBlob(bytes).getDataAsString('UTF-8');
      try {entry.invoice=vnInvoice(xmlText);} catch(e) {entry.readIssue='XML không phân tích được';}
      xmlBytes+=bytes.length;
      if(!reasons.length && /<(?:[\w-]+:)?(?:HDon|Invoice|CreditNote)(?:\s|>)/i.test(xmlText)) {
        reasons.push('Tệp XML có cấu trúc hóa đơn');
      }
    } else if(xml) entry.xmlTruncated=true;
  }
  const notice=typeof extractGmailNotice==='function'?extractGmailNotice(headers,bodyText):null;
  if(notice&&!reasons.length)reasons.push('Thông báo phát hành hóa đơn có mã chứng từ');
  const quarantine=(message.labelIds||[]).some(v=>v==='SPAM'||v==='TRASH')
    ?'Thư thuộc Spam hoặc Thùng rác; cần chủ shop rà soát nguồn':'';
  return {subject,sender:field('from'),manifest:{version:1,attachments,links,reasons,quarantine,notice,
    bodyText:bodyText.slice(0,60000),bodyTruncated:bodyText.length>60000}};
}

function scan(lane,deadline,context) {
  context=context||{execution:'manual',runId:Utilities.getUuid()};
  const props=PropertiesService.getScriptProperties();
  const key=lane==='history'?'all-sources-v1-history':'all-sources-20261120-'+lane;
  const now=Math.floor(Date.now()/1000);
  let state=JSON.parse(props.getProperty(key)||'null');
  if(lane==='catchup' && (!state || state.nextSweep)) {
    if(state && state.nextSweep>now)return;
    state={start:Math.max(RECENT_START,now-2*DAY),end:now};
  }
  if(!state) state={start:lane==='history'?START:RECENT_START};
  const limit=lane==='history'?Math.min(now,HANDOFF):now;
  if(state.start>=limit)return;
  if(!state.end) state.end=Math.min(limit,state.start+(lane==='history'?7:1)*DAY);
  if(lane==='history' && state.end>HANDOFF)state={start:state.start,end:HANDOFF};
  const save=()=>props.setProperty(key,JSON.stringify(state));
  if(!state.ids) {
    const query={q:'after:'+(state.start-1)+' before:'+state.end+' -in:drafts',maxResults:12,includeSpamTrash:true};
    if(state.token)query.pageToken=state.token;
    const page=Gmail.Users.Messages.list('me',query);
    state.ids=(page.messages||[]).map(m=>m.id);
    state.next=page.nextPageToken||'';
    state.reviewed=0;
    state.saved=0;
    save();
  }
  state.proofs=state.proofs||[];
  let proof=state.proofs.find(p=>p.runId===context.runId);
  if(!proof) {
    proof={...context,reviewed:0,saved:0,newOriginals:[]};
    state.proofs.push(proof);
  }
  while(state.ids.length && (!deadline||Date.now()<deadline)) {
    const id=state.ids[0];
    const msg=gmailMessageData(id,'full');
    const info=inspectMessage(msg);
    if(info.manifest.reasons.length) {
      const original=originalMail(id);
      const linkedOriginals=readInvoiceLinks(info.manifest.links,info.manifest.quarantine?'':props.getProperty('GMAIL_INVOICE_LINK_HOSTS'));
      const ack=postPM('',{payload:{...linkedOriginals,original,id,received:new Date(Number(msg.internalDate)).toISOString(),
        subject:info.subject,sender:info.sender,mailbox:ACCOUNT,manifest:JSON.stringify(info.manifest),
        execution:context.execution,runId:context.runId,actualLane:lane}});
      const originalBytes=original.getBytes(),digest=fileDigest(originalBytes);
      if(ack.id!==id||ack.size!==originalBytes.length||ack.digest!==digest)throw Error('Đọc lại không khớp mã, kích thước hoặc SHA-256 thư '+id);
      if(ack.created===true)proof.newOriginals.push({id,digest});
      proof.saved++;
      state.saved++;
    }
    proof.reviewed++;
    state.reviewed++;
    state.ids.shift();
    save();
  }
  const detail=new Date(state.start*1000).toISOString()+' → '+new Date(state.end*1000).toISOString()
    +' · đã xem '+state.reviewed+' thư · PM xác nhận '+state.saved+' · '+(state.next?'còn trang':'hết trang');
  // Each page can span multiple executions. Only attribute new bytes to the
  // execution that received created=true. Retry failed progress with its original UUID.
  while(state.proofs.length) {
    const batch=state.proofs[0];
    progress(lane,detail+(state.ids.length?' · còn '+state.ids.length+' thư chờ xử lý':''),'',batch);
    state.proofs.shift();
    save();
  }
  if(state.ids.length)return;
  if(state.next) state={start:state.start,end:state.end,token:state.next};
  else state=lane==='catchup'?{nextSweep:now+DAY}:{start:state.end};
  save();
}

function jtDate(d,m,y) {
  const date=new Date(Date.UTC(Number(y),Number(m)-1,Number(d)));
  if(date.getUTCDate()!==Number(d)||date.getUTCMonth()+1!==Number(m)||date.getUTCFullYear()!==Number(y))throw Error('Ngày bảng kê không hợp lệ');
  return date.toISOString().slice(0,10);
}

function jtRows(rows,headerIndex) {
  const simple=v=>String(v==null?'':v).trim().toLowerCase().replace(/\s+/g,' ');
  const before=rows.slice(0,headerIndex);
  function oneRow(label) {
    const result=before.filter(row=>row[0]===label);
    if(result.length!==1)throw Error('Thiếu hoặc trùng '+label);
    return result[0];
  }
  function money(value) {
    if(!Number.isSafeInteger(value))throw Error('Ô tiền không phải số nguyên đồng');
    return value;
  }
  const keys=['số tiền cod','phí thu hộ cod','cước phí pp_pm','phí chuyển hoàn','phí giao 1 phần','tiền điều chỉnh','số tiền thực tế chuyển trả'];
  function headings(row,indices,labels) {
    if(!labels.every((label,i)=>simple(row[indices[i]]).startsWith(label)))throw Error('Tiêu đề tiền đã đổi');
  }
  headings(rows[headerIndex],[5,6,7,8,9,10,11],keys);
  const summaryHead=oneRow('NỘI DUNG'),summaryCols=[3,5,6,7,8,9,10,11];
  headings(summaryHead,summaryCols,keys.slice(0,6).concat(['dư nợ kỳ cũ',keys[6]]));
  const summary=summaryCols.map(j=>money(before[before.indexOf(summaryHead)+1][j]));
  const sub=oneRow('Tổng cộng').slice(5,12).map(money);
  const dates=Array.from(before.map(row=>row.join(' ')).join('\n').matchAll(/Ngày\s+(\d{1,2}) tháng\s+(\d{1,2}) năm\s+(\d{4})/g));
  if(dates.length!==1)throw Error('Thiếu hoặc trùng ngày lập bảng kê');
  const day=jtDate(dates[0][1],dates[0][2],dates[0][3]);
  const period=/^\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\s*-\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\s*$/.exec(String(oneRow('Bảng kê chi tiết như sau:')[3]));
  if(!period)throw Error('Không đọc được kỳ bảng kê');
  const lo=jtDate(...period.slice(1,4)),hi=jtDate(...period.slice(4,7));
  if(lo>hi||hi>day)throw Error('Kỳ bảng kê không hợp lệ');
  const customer=oneRow('Mã khách hàng'),cust=String(customer[3]||'').trim();
  if(!cust)throw Error('Thiếu mã khách hàng');
  const sums=Array(7).fill(0),seen=new Set(),ledger=[];
  for(const row of rows.slice(headerIndex+1)) {
    if(!row.some(v=>v!=null && v!==''))continue;
    const tracking=String(row[2]||'').trim();
    if(row[0]!==ledger.length+1||String(row[1]).trim()!==cust||!tracking||seen.has(tracking))throw Error('Chưa khớp số thứ tự, mã khách hàng hoặc mã vận đơn');
    const amounts=sums.map((_,i)=>money(row[i+5]));
    if(amounts.slice(1,6).reduce((n,v)=>n-v,amounts[0])!==amounts[6])throw Error('Tiền chuyển trả không khớp dòng chi tiết');
    amounts.forEach((n,i)=>sums[i]=money(sums[i]+n));
    seen.add(tracking);
    ledger.push([tracking,...amounts]);
  }
  if(!ledger.length||sums.some((n,i)=>n!==sub[i])||sums.slice(0,6).some((n,i)=>n!==summary[i])||sums[6]+summary[6]!==summary[7])throw Error('Tổng vận đơn không khớp bảng kê');
  const fee=money(sums.slice(1,5).reduce((a,b)=>a+b,0));
  if(fee<0)throw Error('Phí âm cần rà soát');
  ledger.sort((a,b)=>a[0]<b[0]?-1:1);
  const detailHash=fileDigest(Utilities.newBlob(JSON.stringify(ledger)).getBytes());
  const month=lo.slice(0,7)===hi.slice(0,7)?lo.slice(0,7):'';
  return {invoice:{vendor:'J&T Express · Chuyển phát nhanh Thuận Phong',buyerName:String(customer[8]||''),
    date:day,currency:'VND',total:String(fee),descriptions:['Đối soát COD và phí vận chuyển'+(month?' · tháng '+month.slice(5)+'/'+month.slice(0,4):' từ tháng '+lo.slice(5,7)+'/'+lo.slice(0,4)+' đến tháng '+hi.slice(5,7)+'/'+hi.slice(0,4))]},
    readIssue:'Đã đối chiếu '+ledger.length+' vận đơn. Kỳ '+lo+' đến '+hi+'. Phí shop '+fee+'đ. COD '+sums[0]+'đ. Chờ phân shop và đối chiếu từng vận đơn trên PM.',
    verifiedReading:{kind:'jt-statement',month,documentDate:day,fromDate:lo,toDate:hi,customer:cust,detailHash,rows:ledger.length,
      trackingLines:ledger.map(v=>({tracking:v[0],fee:v[2]+v[3]+v[4]+v[5],cod:v[1]})),
      cod:sums[0],collection:sums[1],shipping:sums[2],returns:sums[3],partial:sums[4],adjustments:sums[5],priorDebt:summary[6],remitted:summary[7],total:fee}};
}

// Inspect the ZIP central directory before decompressing vendor workbooks.
function guardWorkbook(bytes) {
  const u16=i=>(bytes[i]&255)+256*(bytes[i+1]&255);
  const u32=i=>u16(i)+65536*u16(i+2);
  let end=bytes.length-22;
  for(;end>=Math.max(0,bytes.length-65557);end--)if(u32(end)===0x06054b50 && end+22+u16(end+20)===bytes.length)break;
  if(end<0||u32(end)!==0x06054b50||u16(end+4)||u16(end+6))throw Error('Không đọc được danh mục ZIP');
  const entries=u16(end+10);
  let pos=u32(end+16),size=0;
  if(!entries||entries>500||pos+u32(end+12)!==end)throw Error('ZIP vượt giới hạn hoặc thiếu danh mục');
  for(let i=0;i<entries;i++) {
    if(pos+46>end||u32(pos)!==0x02014b50||(u16(pos+8)&1))throw Error('Tệp ZIP bị khóa hoặc hỏng');
    size+=u32(pos+24);
    if(size>32*1024*1024)throw Error('Bảng vượt 32 MB sau giải nén');
    pos+=46+u16(pos+28)+u16(pos+30)+u16(pos+32);
  }
  if(pos!==end)throw Error('Kích thước ZIP không khớp');
}

function readJtWorkbook(bytes) {
  guardWorkbook(bytes);
  const parts=new Map();
  for(const blob of Utilities.unzip(Utilities.newBlob(bytes,'application/zip','statement.zip'))) {
    if(parts.has(blob.getName()))throw Error('Trùng tên thành phần XLSX');
    parts.set(blob.getName(),blob);
  }
  function root(name) {
    if(!parts.has(name))throw Error('Thiếu thành phần XLSX');
    const xml=parts.get(name).getDataAsString('UTF-8');
    if(/<!ENTITY|<!DOCTYPE/i.test(xml))throw Error('Cấu trúc XML ngoài mẫu');
    return XmlService.parse(xml).getRootElement();
  }
  function many(el,name) {return el?el.getChildren(name,el.getNamespace()):[];}
  function first(el,name) {return el?el.getChild(name,el.getNamespace()):null;}
  function attr(el,name) {const a=el.getAttribute(name);return a?a.getValue():'';}
  function rich(el) {
    return many(el,'t').map(e=>e.getText()).join('')+many(el,'r').map(r=>many(r,'t').map(t=>t.getText()).join('')).join('');
  }
  const links=new Map(many(root('xl/_rels/workbook.xml.rels'),'Relationship').filter(r=>attr(r,'TargetMode')!=='External'&&attr(r,'Type').endsWith('/worksheet')).map(r=>[attr(r,'Id'),attr(r,'Target')]));
  const shared=parts.has('xl/sharedStrings.xml')?many(root('xl/sharedStrings.xml'),'si').map(rich):[];
  const hits=[];
  for(const sheet of many(first(root('xl/workbook.xml'),'sheets'),'sheet')) {
    const rid=sheet.getAttribute('id',XmlService.getNamespace('http://schemas.openxmlformats.org/officeDocument/2006/relationships'));
    const target=rid&&links.get(rid.getValue());
    if(!target||!/^(?:\/xl\/)?worksheets\/[\w.-]+\.xml$/.test(target))throw Error('Không xác minh được trang tính');
    const rows=[];
    // Exported worksheet dimensions can say A1; physical row/cell coordinates are authoritative.
    for(const r of many(first(root(target.startsWith('/')?target.slice(1):'xl/'+target),'sheetData'),'row')) {
      const row=[];
      for(const c of many(r,'c')) {
        const ref=/^([A-Z]+)\d+$/.exec(attr(c,'r'));
        if(!ref)throw Error('Thiếu tọa độ ô Excel');
        const index=Array.from(ref[1]).reduce((n,ch)=>n*26+ch.charCodeAt(0)-64,0)-1;
        if(index<0||index>=16384)throw Error('Tọa độ ngoài bảng');
        const type=attr(c,'t'),v=first(c,'v'),raw=v?v.getText():'';
        if(type==='inlineStr')row[index]=rich(first(c,'is'));
        else if(type==='s'){
          if(!/^\d+$/.test(raw)||Number(raw)>=shared.length)throw Error('Mã chuỗi dùng chung lỗi');
          row[index]=shared[Number(raw)];
        }
        else if(raw!=='')row[index]=!type||type==='n'?Number(raw):raw;
      }
      rows.push(row);
    }
    rows.forEach((r,i)=>{if(r[0]==='STT'&&String(r[2]).trim().toLowerCase()==='mã vận đơn'&&r.length>16)hits.push({rows,index:i});});
  }
  if(hits.length!==1)throw Error('Không xác minh duy nhất một bảng chi tiết J&T');
  return jtRows(hits[0].rows,hits[0].index);
}
