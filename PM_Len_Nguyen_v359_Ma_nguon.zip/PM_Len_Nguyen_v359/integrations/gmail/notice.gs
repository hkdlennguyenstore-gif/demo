// Structured facts printed in an authenticated supplier notification. The original email remains authoritative.
function extractGmailNotice(headers, body) {
  const field = key => String((headers.find(h => String(h.name).toLowerCase() === key) || {}).value || '');
  const from = field('from');
  const address = from.match(/<([^<>\s]+@[^<>\s]+)>/) || from.match(/([^<>\s]+@[^<>\s]+)/);
  const domain = address ? address[1].toLowerCase().split('@').pop() : '';
  const ar = field('authentication-results'), result = /\bdmarc=pass\b[^;]*\bheader\.from=([^;\s]+)/i.exec(ar);
  if (ar.split(';')[0].trim().toLowerCase() !== 'mx.google.com' || !result || result[1].toLowerCase() !== domain) return null;

  const entities = {nbsp:' ',amp:'&',aacute:'á',agrave:'à',atilde:'ã',acirc:'â',eacute:'é',ecirc:'ê',iacute:'í',oacute:'ó',ocirc:'ô',uacute:'ú',yacute:'ý'};
  const flat = String(body || '').replace(/&(#x[0-9a-f]+|#[0-9]+|[a-z]+);/gi,(token, key) => {
    if (key[0]==='#') {
      const n=key[1].toLowerCase()==='x'?parseInt(key.slice(2),16):Number(key.slice(1));
      return n>0 && n<=0x10ffff?String.fromCodePoint(n):token;
    }
    const c=entities[key.toLowerCase()];
    return c && /^[A-Z]/.test(key)?c.toUpperCase():c || token;
  }).replace(/\s+/g,' ').trim();
  const sub = field('subject');
  const foldText = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').toLowerCase();
  const text = foldText(flat), subject = foldText(sub);
  const match = (s, regex) => { const hit=s.match(regex); return hit ? hit[1].trim() : ''; };
  function day(s) {
    const md=/^(\d{2})\/(\d{2})\/(\d{4})$/.exec(s);
    const iso=md ? md[3]+'-'+md[2]+'-'+md[1] : s;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return '';
    const d=new Date(iso+'T00:00:00Z');
    return Number.isFinite(d.valueOf()) && d.toISOString().slice(0,10)===iso ? iso : '';
  }
  function amount(s) {
    const n=/^(\d{1,3}(?:[,.]\d{3})+|\d+)(?:\s+(?:VND|VNĐ))?$/i.exec(s);
    return n && !(n[1].includes(',') && n[1].includes('.')) ? n[1].replace(/[.,]/g,'') : '';
  }
  let vendor='',buyer='',ref='',series='',date='',vt='',bt='',total='',period='',line='',tax='',printed='',currency='';
  if (domain==='mailer.shopee.com' && subject.includes('hoa don phi dich vu')) {
    vendor='SHOPEE';
    buyer=match(flat,/Tên đơn vị:\s*(.+?)\s*-\s*Mã số thuế:/i);
    bt=match(text,/ma so thue:\s*(\d{10}(?:-\d{3}|\d{2,3})?)\b/);
    ref=match(text,/so hoa don:\s*(\d+)\b/);series=match(text,/ky hieu hoa don:\s*([a-z0-9/.-]+)\b/i).toUpperCase();
    date=day(match(text,/ngay hoa don:\s*(\d{4}-\d{2}-\d{2}|\d{2}\/\d{2}\/\d{4})\b/));
    printed=match(text,/gia tri bao gom thue gtgt\s*\(vnd\):\s*(\d[\d.,]*)(?=\s|$)/);total=amount(printed);currency=total?'VND':'';
    const pm=/thang\s+(\d{1,2})\/(20\d{2})/.exec(subject), shop=match(sub,/_(\d{5,})\s*$/);
    if (pm && +pm[1]>=1 && +pm[1]<=12) period=pm[2]+'-'+pm[1].padStart(2,'0');
    line='Phí nền tảng Shopee'+(shop?' '+shop:'')+(period?' tháng '+pm[1]+'/'+pm[2]:'');
  } else if (domain==='meinvoice.vn' && subject.includes('gui hoa don dien tu so')) {
    vendor=match(sub,/^(.*?)\s+gửi\s+h[oóò]a\s+đơn/i);
    buyer=match(flat,/Kính gửi:\s*Quý khách\s+(.{2,160}?)\s+(?:HỘ KINH DOANH|CÔNG TY)\s+.{2,140}?\s+xin gửi cho/i);
    ref=match(text,/\bso:\s*(\d+)\b/);series=match(text,/ky hieu:\s*([a-z0-9/.-]+)/i).toUpperCase();
    date=day(match(text,/\bngay:\s*(\d{2}\/\d{2}\/\d{4})/));
    if (!ref || !(new RegExp('\\b'+ref+'\\b')).test(sub)) return null;
  } else if (domain==='pancake.vn' && subject.includes('phat hanh hoa don dien tu so')) {
    vendor=match(sub,/việc\s+(.+?)\s+phát hành hóa đơn điện tử/i);
    buyer=match(flat,/Kính gửi:\s*(.+?)\s+Mã số thuế:/i);bt=match(text,/ma so thue:\s*(\d{10}(?:-\d{3}|\d{2,3})?)\b/);
    vt=match(text,/cong ty tnhh pancake viet nam\s*[–-]\s*mst:\s*(\d{10}(?:-\d{3}|\d{2,3})?)\b/);
    ref=match(text,/\bso:\s*(\d+)\b/);series=match(text,/ky hieu:\s*([a-z0-9/.-]+)/i).toUpperCase();
    date=day(match(text,/\bngay:\s*(\d{2}\/\d{2}\/\d{4})/));
  } else if (['softdreams.vn','easyinvoice.vn'].includes(domain) && subject.includes('hoa don dien tu so')) {
    const v=/(?:^|,\s*)((?:HỘ KINH DOANH|CÔNG TY)\s+[^,]{2,125}),\s*Mã số thuế\s*:?\s*(\d{10}(?:-\d{3}|\d{2,3})?)(?!\d)\s+xin trân trọng/i.exec(flat);
    const b=/vừa phát hành hóa đơn điện tử đến Quý khách ([^,]+),\s*Mã số thuế\s*:?\s*(\d{10}(?:-\d{3}|\d{2,3})?)(?!\d)/i.exec(flat);
    if(v){vendor=v[1].trim();vt=v[2];}if(b){buyer=b[1].trim();bt=b[2];}
    ref=match(text,/\bso hoa don:\s*(\d+)\b/);series=match(text,/ky hieu(?: mau so hoa don)?:\s*([a-z0-9/.-]+)/i).toUpperCase();
    date=day(match(text,/ngay hoa don:\s*(\d{2}\/\d{2}\/\d{4})/));
    printed=match(flat,/Tổng tiền thanh toán:\s*(\d[\d,.]*(?:\s+(?:VND|VNĐ))?)(?=\s|$)/i);
    total=amount(printed);if(/VND|VNĐ/i.test(printed))currency='VND';
    tax=amount(match(flat,/Tiền thuế:\s*(\d[\d,.]*(?:\s+(?:VND|VNĐ))?)(?=\s|$)/i));
  } else if (domain==='hq.jtexpress.vn' && subject.startsWith('thuan phong:') && subject.includes('hoa don dien tu')) {
    vendor=match(flat,/(CÔNG TY [^\n]{2,165}?)\s+xin gửi cho/i);
    buyer=match(flat,/Kính gửi\s*\(Dear\)\s*:\s*(.+?)\s+CÔNG TY/i);
    ref=match(flat,/\(Invoice Number\)\s*:\s*(\d+)/i);series=match(flat,/\(Serial Number\)\s*:\s*([A-Z0-9]+)/i);
    line='Phí vận chuyển · thông báo phát hành hóa đơn J&T';
  } else return null;

  if(!vendor || !/^\d{1,22}$/.test(ref) || !/^[A-Za-z0-9/.-]{1,24}$/.test(series)) return null;
  const invoice={vendor,vendorTaxId:vt,buyerName:buyer,buyerTaxId:bt,number:ref,series,date,currency:total?currency:'',descriptions:line?[line]:[]};
  if(total) invoice.total=total;
  return {name:'Thông báo phát hành hóa đơn '+ref,invoice,
    verifiedReading:{kind:'invoice_notice',authenticatedDomain:domain,source:'Nội dung thư phát hành hóa đơn',issuer:vendor,reference:ref,printedDate:date,serviceMonth:period,
      printedTotal:printed||null,printedCurrency:currency||null,printedTax:tax||null,originalDownloaded:false},
    readIssue:'Thông báo phát hành hóa đơn. Cần đối chiếu bản gốc, dòng hàng và khoản đã có trước khi ghi chi phí'+(!total?'; thư chưa nêu tổng tiền':'')};
}
