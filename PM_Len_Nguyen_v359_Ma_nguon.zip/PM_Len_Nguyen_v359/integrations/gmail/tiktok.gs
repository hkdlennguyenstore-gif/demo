
// Dedicated parser for the one-page TikTok commercial invoice template.
// Only matched labels and fully reconciled figures produce payment evidence.
function tiktokPdf(bytes) {
  const fail=()=>{throw Error('Mẫu PDF TikTok cần kiểm tra thủ công');};
  if(bytes.length>500000 || bytes.length<100) fail();
  function latin(data) {
    let s='';
    for(let i=0;i<data.length;i+=4096)s+=String.fromCharCode(...data.subarray(i,i+4096));
    return s;
  }
  const pdfBytes=Uint8Array.from(bytes,b=>b&255),pdf=latin(pdfBytes);
  const end=/startxref\s+(\d+)\s+%%EOF\s*$/.exec(pdf);
  if(!pdf.startsWith('%PDF-1.4') || !end)fail();
  const xref=pdf.slice(Number(end[1])), x=/^xref\s+0 (\d+)\s*\n/.exec(xref);
  if(!x || +x[1]>200 || /\/(Encrypt|Prev|XRefStm)\b/.test(xref))fail();
  const entries=xref.slice(x[0].length).split(/\r?\n/).slice(0,Number(x[1]));
  const objects=new Map(),offsets=[];
  entries.forEach((v,i)=>{const hit=/^(\d{10}) (\d{5}) ([nf])\s*$/.exec(v);if(!hit)fail();
    if(hit[3]==='n'){if(+hit[2]!==0)fail();offsets.push([i,+hit[1]]);}
  });
  offsets.sort((a,b)=>a[1]-b[1]).forEach(([id,offset],i)=>{
    const chunk=pdf.slice(offset,i+1<offsets.length?offsets[i+1][1]:Number(end[1]));
    const pre=id+' 0 obj';
    if(!chunk.startsWith(pre)||!chunk.trimEnd().endsWith('endobj'))fail();
    objects.set(id,chunk.slice(pre.length,chunk.lastIndexOf('endobj')).trimStart());
  });
  function ref(obj,key) {const hit=new RegExp('/'+key+'\\s+(\\d+) 0 R\\b').exec(obj);if(!hit)fail();return objects.get(+hit[1])||fail();}
  function inflated(obj) {
    const sm=/\bstream\r?\n/.exec(obj);if(!sm || !/\/Filter\s*\/FlateDecode\b/.test(obj.slice(0,sm.index)))fail();
    const lm=/\/Length\s+(\d+)(\s+0 R)?\b/.exec(obj.slice(0,sm.index));if(!lm)fail();
    const n=Number(lm[2]?(objects.get(+lm[1])||'').trim():lm[1]);
    const i=sm.index+sm[0].length;
    if(!Number.isInteger(n)||n<6||n>200000||!/^\r?\n?endstream\s*$/.test(obj.slice(i+n)))fail();
    const zipped=Uint8Array.from(obj.slice(i,i+n),c=>c.charCodeAt(0));
    const data=gmailZlib.unzlibSync(zipped,new Uint8Array(262144));
    if(data.length>=262144)fail();
    let a=1,b=0;for(const v of data){a=(a+v)%65521;b=(b+a)%65521;}
    if((b*65536+a)!==(zipped[n-4]*16777216+zipped[n-3]*65536+zipped[n-2]*256+zipped[n-1]))fail();
    return latin(data);
  }
  const pages=[...objects.values()].filter(o=>/^<<\s*\/Type\s*\/Page\b/.test(o));
  if(pages.length!==1)fail();
  const page=pages[0],fonts={},resource=ref(ref(page,'Resources'),'Font');
  for(const m of resource.matchAll(/\/(F\d+)\s+(\d+) 0 R/g)) {
    const f=objects.get(+m[2]),wm=/\/Widths\s*\[([^\]]+)\]/.exec(f),fc=/\/FirstChar\s+(\d+)/.exec(f);
    if(!wm || !fc)fail();
    const cmap=inflated(ref(f,'ToUnicode')),map={};
    if(/beginbfrange/.test(cmap)||!/<00>\s*<FF>/.test(cmap))fail();
    for(const group of cmap.matchAll(/beginbfchar([\s\S]*?)endbfchar/g))for(const v of group[1].matchAll(/<([\da-f]{2})>\s*<((?:[\da-f]{4})+)>/gi))map[parseInt(v[1],16)]=String.fromCharCode(...v[2].match(/.{4}/g).map(code=>parseInt(code,16)));
    fonts[m[1]]={map,widths:wm[1].trim().split(/\s+/).map(Number),first:+fc[1]};
  }
  const glyphs=[];
  for(const t of inflated(ref(page,'Contents')).matchAll(/\bBT\b([\s\S]*?)\bET\b/g)) {
    for (const item of t[1].trim().split(/\n(?=-?[\d.]+(?: -?[\d.]+){5} Tm)/)) {
    const pos=/(-?[\d.]+) (-?[\d.]+) (Tm|Td)\s/.exec(item),font=/\/(F\d+) ([\d.]+) Tf/.exec(item);
    if(!pos||!font||!fonts[font[1]])fail();
    const scale=pos[3]==='Tm'?Number(item.trim().split(/\s+/)[0]):1;
    const size=+font[2],{first,widths,map}=fonts[font[1]];
    let xx=+pos[1],yy=+pos[2];
    const ops=item.slice(font.index+font[0].length);
    if(!/^\s*(?:<[\da-fA-F]+>\s*Tj|\[[\d\s.<>a-fA-F-]+\]\s*TJ)\s*$/.test(ops))fail();
    for(const v of ops.replace(/Tj|TJ/g,'').matchAll(/<([\da-f]+)>|(-?[\d.]+)/gi)) {
      if(v[2]) {xx-=+v[2]*scale*size/1000;continue;}
      if(v[1].length%2)fail();
      for(let i=0;i<v[1].length;i+=2){
        const code=parseInt(v[1].slice(i,i+2),16),ch=map[code],w=widths[code-first];if(!ch||!Number.isFinite(w))fail();
        glyphs.push({x:xx,y:yy,ch});xx+=w*scale*size/1000;
      }
    }
  }
  }
  function textAt(y,lo,hi){return glyphs.filter(g=>Math.abs(g.y-y)<=1.1&&g.x>=lo&&g.x<hi).sort((a,b)=>a.x-b.x).map(g=>g.ch).join('').trim().replace(/\s+/g,' ');}
  const baselines=[];
  for(const g of glyphs){if(!baselines.some(y=>Math.abs(y-g.y)<=1.1))baselines.push(g.y);}
  function label(regex,left,right){const hits=baselines.filter(y=>regex.test(textAt(y,left,right)));if(hits.length!==1)fail();return hits[0];}
  const buyerY=label(/^Invoice No\.$/,370,450),buyer=textAt(buyerY,110,370);
  if(!buyer || textAt(buyerY,25,110)!=='Client Name' || !/^Invoice No\.$/.test(textAt(buyerY,370,450)))fail();
  const number=textAt(buyerY,450,570);
  const dateStr=textAt(label(/^Invoice Date$/,370,450),450,570), m=/^(\d{1,2}), ([A-Za-z]+), (\d{4})$/.exec(dateStr);
  const months='January February March April May June July August September October November December'.split(' ');
  if(!/^VNTT\d+$/.test(number)||!m||!months.includes(m[2]))fail();
  const date=jtDate(m[1],months.indexOf(m[2])+1,m[3]);
  label(/^TIKTOK PTE\. LTD\.$/,25,580);
  const taxY=label(/^Tax Registration Number\s*[：:]\s*\d+$/,25,580);
  const taxId=textAt(taxY,25,580).match(/(\d+)$/)[1];
  label(/^Amount in VND$/,450,560);
  const serviceY=label(/^Advertising Fees$/,160,280),note=textAt(serviceY,280,420);
  if(!/^(Prepayment On Account|Autopay On Account)$/.test(note))fail();
  function amount(y) {const s=textAt(y,430,560);if(!/^(?:\d+|\d{1,3}(?:,\d{3})+)$/.test(s))fail();
    const n=Number(s.replace(/,/g,''));if(!Number.isSafeInteger(n))fail();return n;}
  const net=amount(label(/^Subtotal \(excluding Tax\)$/,280,420));
  const tax=amount(label(/^Total Tax @\d+(?:\.\d+)?%$/,280,420));
  const total=amount(label(/^Total Amount Due$/,280,420));
  if(net+tax!==total||amount(serviceY)!==net)fail();
  const shop=fold(buyer).replace(/\s/g,'')==='hokinhdoanhlennguyenstore';
  return {invoice:{vendor:'TIKTOK PTE. LTD.',vendorTaxId:taxId,buyerName:shop?'HỘ KINH DOANH LÊN NGUYỄN STORE':buyer,
    number,date,currency:'VND',total:String(total),descriptions:['Quảng cáo · '+note],adjusted:false},
    readIssue:shop?'':'Bên mua trên PDF khác tên hộ kinh doanh của shop. Chờ xác minh tài khoản; chỉ lưu đối chứng.',
    verifiedReading:{kind:shop?'tiktok-proof':'tiktok-other-buyer',note,net,tax,total,month:date.slice(0,7)}};
}
