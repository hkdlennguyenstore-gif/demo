# Gmail và chi phí Lên Nguyễn Store

Phạm vi từ ngày 01/04/2026 theo giờ Việt Nam. Chỉ chủ shop được tải thư đã lưu. Bản đang phát triển lưu thư EML có các phần đính kèm gốc vào R2, đối chiếu kích thước và mã băm, rồi mới cho phép dịch vụ gửi tiến sang trang kế tiếp. Bảng gmail_evidence theo dõi thư đã lưu. gmail_activity lưu tình trạng từng luồng. Ngày nhận chỉ dùng để tìm thư.

## Quy tắc đối soát trước khi ghi chi phí

| Căn cứ | Đích trong PM | Điều kiện |
|---|---|---|
| Cước hãng vận chuyển | shipping | Khớp mã vận đơn, loại phí và bên chịu phí. Tiền COD dùng để đối chiếu. |
| Hoàn hàng, đổi size, bảo hành | returns | Có đơn gốc và khoản phí bổ sung. Loại phần đã tính trong cước. |
| Quảng cáo thực chạy | ads | Khớp shop, tài khoản, kỳ dịch vụ và sổ quảng cáo. Liên kết hóa đơn vào khoản đã có. Tiền nạp hoặc số dư chỉ đối chứng. |
| Quyết toán sàn | platform | Khớp shop, mã giao dịch, mã đơn và loại phí. Đối chiếu phí hoàn theo dấu. |
| Thuê mặt bằng, điện, nước, internet | operations | Căn cứ địa điểm và kỳ sử dụng. |
| Phần mềm, tên miền, hosting | software | Xác minh dịch vụ dùng cho shop, kỳ thuê bao, tiền tệ và quy tắc phân bổ. |
| Bao bì, tem, túi | packing | Đối chiếu số lượng, mục đích và dữ liệu vật tư đã hạch toán. |
| Nhập hàng | Nhập hàng | Đối chiếu lô và nhà cung cấp, tránh cộng hóa đơn mua vào giá vốn kỳ. |
| Thiết bị | equipment | Xét tài sản, nguyên giá, thời gian sử dụng trước khi phân bổ. |
| Đặt cọc, chuyển khoản | Đối soát thanh toán | Ghép giao dịch với chứng từ gốc. |
| Điều chỉnh, thay thế | Hồ sơ gốc | Giữ các phiên bản và chỉ tính chênh lệch được xác minh. |
| Dòng gộp nhiều dịch vụ | Chờ rà soát | Cần bảng chi tiết hoặc căn cứ phân bổ. |

Trạng thái thuế cần lưu riêng và chờ duyệt tại tab Thuế. Kiểm tra nhà cung cấp, người mua, ký hiệu, số hóa đơn, nội dung từng dòng, kỳ và tổng trước khi ghi sổ. Hai hóa đơn cùng số nhưng khác người bán hoặc ký hiệu có thể là hai chứng từ độc lập.

## Bàn giao ngày 20/11/2026

Phạm vi lịch sử tính theo giờ Việt Nam, từ 00:00 ngày 01/04 đến trước 00:00 ngày 20/11. Đợt nạp trực tiếp dùng mã Gmail bất biến, ngày nhận nội bộ và nguyên bản MIME. Với mỗi thư, đối chiếu số byte và SHA-256 với phản hồi đọc lại từ PM. Một thư có thể chứa nhiều tài liệu. Một chứng từ có thể xuất hiện trong nhiều thư. Báo cáo truy thu đếm thư theo tháng nhận. Báo cáo kế toán dùng kỳ chứng từ và lưu riêng loại tiền. COD, tiền nạp và tiền chuyển trả cần đối chiếu riêng.

Tác vụ Google Apps Script dùng Gmail chỉ đọc của tài khoản shop, gọi bộ nhận qua HTTPS và dùng khóa riêng trong Script Properties. Không đưa giá trị khóa vào nguồn. Hàm installGmailSync thiết lập một trigger thời gian chạy runGmailSync mỗi 15 phút. Luồng thư mới có một ngày chồng lấn tại mốc bàn giao và rà bổ sung 48 giờ. Hàm chạy lịch sử có điểm dừng ở mốc bàn giao. Điểm tiến độ chỉ dịch chuyển sau khi PM xác nhận thư hoặc sau khi hoàn tất bước kiểm tra thư ngoài phạm vi.

Báo cáo bàn giao đối chiếu danh sách mã thư, thời điểm nhận, dung lượng và SHA-256 của từng tháng trước khi lưu số đã xác minh. Có thể chạy lại từng lô theo cùng mã thư. Khi nội dung thư cùng mã đổi, bộ nhận trả lỗi xung đột. Dữ liệu đọc lại ít chi tiết hơn được giữ ở mức bằng chứng đã xác minh trước đó.

Trang /chi-phi/gmail dành cho chủ shop tra cứu theo kỳ, nguồn, trạng thái và tải thư gốc. Tệp đính kèm nằm trong thư .eml. Bản tải được kiểm tra dung lượng và SHA-256 trước khi chuyển cho trình duyệt. Liên kết hóa đơn chỉ lưu bản tải trực tiếp khi được phép truy cập, chưa tải được ghi lý do xử lý. Báo cáo ngân quỹ và số tiền chứng từ chưa đủ căn cứ không tự tạo phiếu chi hoặc duyệt thuế.
