# Lên Nguyễn Store — cấu trúc mở rộng

Phần mềm chung: Lên Nguyễn Store. Phân hệ đang vận hành: Nhân sự (chấm công, lương, bảo hiểm, hồ sơ). Không tạo dữ liệu hay menu cho tính năng chưa triển khai.

`lib/modules.ts` khai báo phân hệ và vai trò được vào. Khi thêm tính năng, bổ sung định nghĩa tại đây, menu tương ứng và kiểm tra quyền tại từng API, kể cả đọc, xuất tệp và tải chứng từ. Mặc định từ chối nếu phân hệ hoặc quyền chưa khai báo. Không suy ra quyền từ việc được chia sẻ website.

Tài khoản `staff@example.invalid` giữ vai trò terminal: tất cả nhân viên, chỉ giờ hiện tại và lịch sử; API /api/clock trả dữ liệu đã lọc. Không tự cấp thêm phân hệ mới cho tài khoản này.

Mail chính nghiệp vụ `owner@example.invalid` là Chủ shop trong phần mềm. Tài khoản sở hữu triển khai hiện tại giữ quyền để tiếp tục sửa và xuất bản. Chuyển chủ sở hữu nền tảng cần quy trình riêng, không thay email bằng cách sửa dữ liệu nghiệp vụ.

Mở rộng đề xuất khi Chủ shop yêu cầu: đơn hàng, kho, doanh thu, thu chi. Mỗi phân hệ có quyền xem/tạo/sửa/xuất riêng; không dùng quyền chấm công để mở dữ liệu mới. Cần có lịch sử thao tác, chốt kỳ và kiểm tra tệp đính kèm tương tự phần Nhân sự.

Các endpoint nhập dữ liệu tạm thời dựa trên site chỉ chủ sở hữu đã được gỡ trước khi thêm tài khoản nhân viên. Thiết lập tài khoản cố định dùng /api/setup với secret runtime riêng, bị vô hiệu hóa sau khi hoàn thành.

## Nhập hàng & Công nợ

Đường dẫn `/nhap-hang`, API `/api/purchases`, dữ liệu riêng trong `app_state` id `purchasing`. Chỉ owner/admin được đọc/ghi và tải chứng từ. Tài khoản terminal, employee, manager, payroll không tự nhận quyền này. Không đọc hoặc sửa dữ liệu nguồn A5 và không tự đồng bộ tồn kho.

Số dư NCC = số dư đầu kỳ + tổng phiếu đang hiệu lực - các khoản trả đang hiệu lực. Số dư âm thể hiện shop trả trước. Mỗi phiếu có nhiều mã/màu/size, giảm giá và chi phí thêm. Thanh toán theo NCC, chưa phân bổ theo phiếu; hạn trả chỉ là thông tin. Hủy phiếu nhập hủy cả khoản trả ngay gắn cùng phiếu, giữ các khoản thanh toán riêng. Giữ lý do và lịch sử. Khóa phiên bản + mã yêu cầu ngăn ghi trùng, cập nhật đồng thời trả 409.

## Hiệu năng và dữ liệu tăng dần (bản 19)

Nhập hàng chuyển sang bảng `pm_purchase_suppliers`, `pm_purchase_docs`, `pm_purchase_requests`, `pm_purchase_audit`, `pm_purchase_migration`. Mỗi phiếu lưu riêng, có index loại/ngày và NCC/ngày; trigger cộng/trừ tổng nhập và tổng trả nguyên tử với giao dịch. Danh sách mặc định 50 phiếu tóm tắt/trang; chi tiết dòng hàng chỉ đọc khi mở phiếu. Chứng từ vẫn ở R2. Dữ liệu JSON cũ được chuyển một lần, giữ nguyên bản cũ để đối chiếu; không sửa lại blob sau khi chuyển. Mã yêu cầu, số phiên bản và tất cả thao tác ghi chạy trong batch nguyên tử. CSV công nợ lấy tổng NCC toàn bộ, không tính từ trang hiện tại. Giới hạn 500 NCC trước khi cần bổ sung tra cứu NCC theo trang.

Nhân sự truyền dữ liệu tháng đang xem, hiển thị công 50 dòng đầu, SSR truyền dữ liệu ban đầu để tránh đọc API lần hai. Màn hình chấm công dừng polling khi tab ẩn và chỉ tải tháng lịch sử được chọn cùng công hôm nay. Dữ liệu Nhân sự hiện vẫn lưu trong trạng thái JSON cũ; chưa kiểm thử tải đồng thời lớn hoặc nhập nhiều năm. Không diễn giải thử nghiệm SQLite trong bộ nhớ thành cam kết độ trễ production.

Kiểm tra bằng SQLite 10.000 phiếu giả lập: truy vấn 2 trang khoảng 7–8ms trong bộ nhớ; phản hồi trang 1 khoảng 9KB, 50 tóm tắt, tổng công nợ và lũy kế trang 2 khớp. Không ghi dữ liệu thử lên production.

## Nhập kho dành cho nhân viên (bản 20)

Nguồn tham chiếu: `Doanh Số Đơn Hàng` ID `1e5FyG3UP4eLN06wBkVQ_GzcSKDJ5Oxq5_FNPrrdpbvE`, tab `LenNguyen_Store`, AF:AN. Các cột: ngày/giờ nhập, mã đã có, mã mới (có thể là mô tả khi đi cùng mã cũ), màu, nguồn Trang/Mạnh, số lượng, ghi chú, ngày chuẩn hóa tự tính. Đã đọc 109 mã và các màu/danh sách validation; chỉ đưa danh mục tham chiếu vào mã nguồn, không nhập lịch sử giao dịch hoặc ghi ngược Sheet. Tab `ĐÃ NHẬP KHO` hiện chỉ có tiêu đề, không lấy làm nguồn giao dịch.

`/nhap-kho` và `/api/stock` cho owner/admin/manager/employee/terminal, gồm mail dùng chung staff@example.invalid theo vai trò terminal hiện có. Đây là cấp thêm quyền Nhập kho theo yêu cầu Chủ shop; các quyền lương, công nợ và chứng từ tài chính giữ nguyên. Người nhập được sửa/hủy phiếu của tài khoản mình khi chưa đối chiếu, có lý do; owner/admin quản lý mọi phiếu. Dữ liệu kho chỉ truyền trường trắng về hàng hóa, không giá/tiền/thanh toán/liên kết ID tài chính. Mọi API giá và chứng từ vẫn owner/admin, kiểm tra phía server.

Chủ shop chọn Nhập giá riêng để lập phiếu tài chính từ phiếu kho, giữ ngày/mã/màu/số lượng. Liên kết giá và khóa phiếu kho được ghi nguyên tử cùng công nợ. Hủy phiếu giá mở lại phiếu kho. Không ghi giá vào record kho hoặc lịch sử phía nhân viên. Các bảng `pm_stock_receipts`, `pm_stock_actions`, `pm_stock_catalog` lưu riêng và có index ngày/nguồn, khóa phiên bản và request id. Mã mới không sửa danh mục bảng nguồn.

Cột Đã kiểm SL theo từng dòng: mặc định false, chỉ chuyển xanh sau khi lưu dấu tích. Người có quyền Nhập kho được kiểm/bỏ kiểm kể cả phiếu đã đối chiếu; không đổi số lượng hoặc thông tin tài chính. Nếu sửa mã, màu hoặc số lượng, trạng thái kiểm dòng đó tự trở về false. Mỗi thao tác ghi người kiểm và thời gian trong lịch sử.

## Nhập dữ liệu nguồn, giá theo ngày và đối chiếu A5 (bản 22)

Doanh Số Đơn Hàng: 697 dòng đủ mã/ngày/SL, 40.564 SP; 12 dòng nguồn thiếu dữ liệu lưu riêng (1 dòng L25 thiếu SL, 11 dòng chỉ ngày/giờ). A3 price_tt: 344 dòng lịch sử, 216 mã. Quy tắc do Chủ shop xác nhận: chỉ chọn giá có ngày gần nhất <= ngày nhập; không dùng giá tương lai, không ghi đè đơn giá đã lưu trong phiếu cũ. Nếu chưa có giá có ngày thì chỉ dùng giá gốc không ngày duy nhất. 3 dòng B91 ngày 19/05/2026, tổng 34 SP chưa có giá cũ trước 21/05; chỉ nhập kho, chưa tạo phiếu tiền.

A5 NhapLieu cột M Thanh Toán Một Phần là tiền trả NCC (NH Trang/NH Mạnh), nhập 32 khoản với ngày và dòng nguồn. Lấy nợ đầu kỳ tại Tong_Quan U5/U23 vì các công thức công nợ thực sự tham chiếu hai ô này; giữ 24 ảnh chụp số dư tháng để đối chiếu. Không cộng ô Tổng Năm U19/U37 vì là tổng các số dư, không phải số còn nợ. Chênh lệch giữa đơn giá theo ngày và A5 theo tháng/cột F được ghi kind adjustment riêng, hiện rõ cột Đối chiếu A5; không thay đơn giá A3 hoặc ngụy tạo dòng hàng/chi tiền. Chênh lệch còn chờ chứng từ, không tự phê duyệt.

Đợt nhập có khóa nguồn cố định, ID theo tọa độ nguồn, ghi nguyên tử và replay không ghi thêm. Chỉ token dịch vụ riêng mới thực hiện được, không dùng quyền nhân viên; không đưa payload tài chính hoặc token vào mã nguồn. Sau hoàn tất, khóa đợt nhập và gỡ endpoint/secret thực hiện. Dữ liệu nguồn Google không thay đổi. Bảng lịch sử giá và báo cáo nguồn chỉ owner/admin xem.

## Đồng bộ POS các sàn và dọn đối chiếu

TikTok 1 = tài khoản POS 400050288 / shop 7494549204538985115 (Len Nguyen Store); TikTok 2 = 100046473 / 7494924027339376972 (Lên Nguyễn Store.); Shopee = 100047072 / 736225350. Định danh đã kiểm tra với POS còn hiệu lực và Ánh xạ shop trong dữ liệu nguồn. Đọc GET POS bằng kết nối máy chủ hiện có; không truyền khóa về trình duyệt.

`sync_pos_orders` chạy Facebook và các sàn, cursor `marketplaces` độc lập, không reset Facebook. Lần đầu chỉ lấy 30 ngày Việt Nam (hôm nay và 29 ngày trước), sau đó lấy theo thời gian cập nhật với chồng lấn 5 phút và chặn đơn ngoài shop đã xác minh. Cập nhật cùng ID, chống ghi đè bởi dữ liệu cũ. Giữ tên trạng thái POS; chỉ tạo đối chứng nếu hành trình cho thấy chuyển hoàn và chưa có sự kiện giao khách. Không suy đoán mã hoàn HHTT từ mã giao đi. Dữ liệu API hiện kiểm tra chưa có mã trả về HHTT riêng; nhập đối chứng thủ công vẫn dùng được.

`pm_return_archive` giữ dấu vết băm mã đã dọn. Đối chiếu thật: mốc khớp là thời điểm muộn hơn giữa nhập đối chứng và quét. Đối chiếu theo 30 ngày: mốc khớp là ngày nhận + 30 ngày. Chỉ dọn chi tiết sau thêm 30 ngày từ mốc khớp; không dọn đơn chưa về kho. Dọn trong lượt đồng bộ và giữ nhật ký tổng số; không sửa POS/sàn hoặc số tồn kho.
