import ts from 'typescript';import fs from 'node:fs';import assert from 'node:assert/strict';import {DatabaseSync} from 'node:sqlite';
const url=s=>'data:text/javascript;base64,'+Buffer.from(ts.transpileModule(s,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText).toString('base64');const range=url(fs.readFileSync('lib/date-range.ts','utf8')),access=url(fs.readFileSync('lib/a3-access.ts','utf8'));const code=fs.readFileSync('lib/a3-sync.ts','utf8').replace("'./a3-access'",JSON.stringify(access)).replace("'./date-range'",JSON.stringify(range));const {setA3Deleted,parseA3Values,syncA3Snapshot,a3OutboxStatement,prepareA3Sync,a3SyncStatus,A3_SOURCE}=await import(url(code));
const sql=new DatabaseSync(':memory:'),db={prepare(q){return {args:[],bind(...a){this.args=a;return this;},async first(){return sql.prepare(q).get(...this.args)||null;},async all(){return {results:sql.prepare(q).all(...this.args)};},async run(){return {meta:{changes:Number(sql.prepare(q).run(...this.args).changes)}};}};},async batch(ss){sql.exec('BEGIN');try{const out=[];for(const s of ss)out.push(await s.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}}};
await prepareA3Sync(db);const h=['Ngày Nhập ','Số Lượng','MÃ SP','Tên SP','GIÁ NHẬP','GIÁ BÁN FB'],values=[h,['2026-11-01',0,'S90','Jean',110000,130000]],input={source:A3_SOURCE,sheet:'price_tt',complete:true,values};let r=await syncA3Snapshot(db,input);assert.equal(r.changed,1);assert.equal(JSON.parse(sql.prepare('SELECT record FROM pm_price_history').get().record).fbPrice,130000);r=await syncA3Snapshot(db,input);assert.equal(r.changed,0);assert.equal(sql.prepare('SELECT COUNT(*) n FROM pm_price_history').get().n,1);
let old=JSON.parse(sql.prepare('SELECT record FROM pm_price_history').get().record),id=sql.prepare('SELECT id FROM pm_price_history').get().id,value={...old,price:120000};sql.prepare('UPDATE pm_price_history SET record=?,price=120000').run(JSON.stringify(value));await a3OutboxStatement(db,id,'rev1',value,old).run();r=await syncA3Snapshot(db,input);assert.equal(r.outbox.length,1);assert.equal(JSON.parse(sql.prepare('SELECT record FROM pm_price_history').get().record).price,120000);
r=await syncA3Snapshot(db,{...input,values:[h,['2026-11-01',0,'S90','Jean',115000,130000]],acks:[{id,revision:'rev1',ok:false,error:'A3 đã đổi'}]});assert.equal(r.outbox.length,0);assert.equal((await a3SyncStatus(db)).conflicts.length,1);assert.equal(JSON.parse(sql.prepare('SELECT record FROM pm_price_history').get().record).price,120000);
await a3OutboxStatement(db,id,'rev2',value,old).run();r=await syncA3Snapshot(db,{...input,values:[h,['2026-11-01',0,'S90','Jean',120000,130000]],acks:[{id,revision:'rev1',ok:true}]});assert.equal(r.outbox[0].revision,'rev2');r=await syncA3Snapshot(db,{...input,values:[h,['2026-11-01',0,'S90','Jean',120000,130000]],acks:[{id,revision:'rev2',ok:true}]});assert.equal(r.outbox.length,0);assert.equal((await a3SyncStatus(db)).pending,0);
assert.equal(parseA3Values([h,values[1],values[1]]).length,2);const duplicate=await syncA3Snapshot(db,{...input,values:[h,values[1],values[1]]});assert.equal(duplicate.issues.length,1);assert.equal(JSON.parse(sql.prepare('SELECT record FROM pm_price_history').get().record).price,120000);assert.throws(()=>parseA3Values([h,['2026-11-01',0,'S90','Jean',0,130000]]),/giá nhập/);assert.throws(()=>parseA3Values([['bad'],values[1]]));await assert.rejects(()=>syncA3Snapshot(db,{...input,complete:false}));
console.log('PASS A3 sync: schema, positive VND, date keys, replay, pending PM preserved, source conflict blocked, stale ack rejected, successful ack, no duplicate history.');
if(process.env.A3_LIVE_FIXTURE){const live=JSON.parse(fs.readFileSync(process.env.A3_LIVE_FIXTURE,'utf8'));try{console.log('Live source valid rows:',parseA3Values(live.values).length);}catch(e){console.log('LIVE SOURCE ISSUE:',e.message);process.exitCode=1;}}

// Names are part of delivery confirmation even when prices already match.
const current=JSON.parse(sql.prepare('SELECT record FROM pm_price_history').get().record),named={...current,name:'Tên mới PM'};
sql.prepare('UPDATE pm_price_history SET record=?').run(JSON.stringify(named));await a3OutboxStatement(db,id,'name-rev',named,current).run();
r=await syncA3Snapshot(db,{...input,values:[h,['2026-11-01',0,'S90','Jean',120000,130000]],acks:[{id,revision:'name-rev',ok:true}]});assert.equal(r.outbox.length,1);assert.equal(r.outbox[0].targetName,'Tên mới PM');
r=await syncA3Snapshot(db,{...input,values:[h,['2026-11-01',0,'S90','Tên mới PM',120000,130000]],acks:[{id,revision:'name-rev',ok:true}]});assert.equal(r.outbox.length,0);
r=await syncA3Snapshot(db,{...input,values:[h,['2026-11-01',0,'S90','',120000,130000]]});assert.equal(r.outbox.length,1);assert.equal(r.outbox[0].targetName,'Tên mới PM');assert.equal(r.outbox[0].expectedName,'');
console.log('PASS names: queue PM name, reject price-only ack, verify name readback, repair missing source name.');

// Removing a row hides it from future imports while retaining historical cost.
const archivedRecord=sql.prepare('SELECT record FROM pm_price_history WHERE id=?').get(id).record;
await assert.rejects(()=>setA3Deleted(db,id,'stale','delete-stale','Chủ shop'),/đã thay đổi/);
await setA3Deleted(db,id,archivedRecord,'delete-once','Chủ shop');
assert.equal(sql.prepare('SELECT COUNT(*) n FROM pm_a3_deleted').get().n,1);
assert.equal((await a3SyncStatus(db)).pending,0);
assert.equal(sql.prepare('SELECT record FROM pm_price_history WHERE id=?').get(id).record,archivedRecord);
r=await syncA3Snapshot(db,{...input,values:[h,['2026-11-01',321,'S90','',999000,999000]]});
assert.equal(r.outbox.length,0);assert.equal(r.changed,0);assert.equal(sql.prepare('SELECT record FROM pm_price_history WHERE id=?').get(id).record,archivedRecord);
await setA3Deleted(db,id,archivedRecord,'delete-once','Chủ shop');assert.equal(sql.prepare('SELECT COUNT(*) n FROM pm_a3_audit WHERE id=?').get('delete-once').n,1);
await setA3Deleted(db,id,archivedRecord,'restore-once','Chủ shop',true);assert.equal(sql.prepare('SELECT COUNT(*) n FROM pm_a3_deleted').get().n,0);
r=await syncA3Snapshot(db,{...input,values:[h,['2026-11-01',321,'S90','Tên mới PM',120000,130000]]});
assert.equal(JSON.parse(sql.prepare('SELECT record FROM pm_price_history WHERE id=?').get(id).record).quantity,321);
assert.equal(parseA3Values([h,['2026-11-01',0,'S90','Jean',120000,130000]])[0].quantity,0);
assert.equal(parseA3Values([h,['2026-11-01','','S90','Jean',120000,130000]])[0].quantity,null);
console.log('PASS delete/restore: stale writes rejected, history retained, queue cancelled, source replay suppressed, restore resumes sync; quantity B including zero is preserved.');
