import ts from 'typescript';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {unzipSync,strFromU8} from 'fflate';
const moduleURL=code=>'data:text/javascript;base64,'+Buffer.from(ts.transpileModule(code,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX}}).outputText).toString('base64');
let cleanup,notice='',errors=[],downloads=[],blob;
globalThis.__detailHooks={useState:()=>['',value=>{if(value instanceof Error)errors.push(value);notice=value;}],useRef:()=>({current:null}),useEffect:fn=>{cleanup=fn();}};
const hooks=moduleURL('export const {useState,useRef,useEffect}=globalThis.__detailHooks;');
const jsx=moduleURL('export function jsx(type,props){return {type,props}};export const jsxs=jsx;');
const data=moduleURL(fs.readFileSync('lib/data-export.ts','utf8'));
const component=moduleURL(fs.readFileSync('components/finance/detail-downloads.tsx','utf8').replace("'react'",JSON.stringify(hooks)).replace("'../../lib/data-export'",JSON.stringify(data)).replace("'./document-links'",JSON.stringify(moduleURL('export default function DocumentLinks(){return null;}')))).replaceAll('NEVER_MATCH','');
// Resolve the automatic JSX runtime after transpilation.
const decoded=Buffer.from(component.split(',')[1],'base64').toString().replace('"react/jsx-runtime"',JSON.stringify(jsx));
const {default:render,isStoredDocument}=await import('data:text/javascript;base64,'+Buffer.from(decoded).toString('base64'));
function buttons(node){if(!node||typeof node!=='object')return [];return [...(node.type==='button'?[node]:[]),...[node.props?.children].flat(Infinity).flatMap(buttons)];}
const create=URL.createObjectURL,revoke=URL.revokeObjectURL,timeout=globalThis.setTimeout;
URL.createObjectURL=b=>{blob=b;return 'blob:fixture';};URL.revokeObjectURL=()=>{};globalThis.setTimeout=()=>0;
globalThis.document={createElement:()=>({click(){downloads.push(this.download);},remove(){}}),body:{appendChild(){}}};
const saved={label:'Hóa đơn gốc.pdf',url:'/api/purchases/receipt?key=receipts%2Ftest',kind:'file'};
const source={label:'Bảng nguồn',url:'https://docs.google.com/spreadsheets/d/test',kind:'source'};
const mail={label:'Thư gốc',url:'/api/gmail-evidence?id=test',kind:'source'};
const props={title:'Chi phí mua hàng đã thanh toán',scope:'01/11/2026 – 30/11/2026',columns:['Loại','Ngày','Số tiền'],rows:[{values:['Thanh toán A5','2026-11-10',62000000],documents:[saved,source]},{values:['Thanh toán A5','2026-11-13',200000000],documents:[]},{values:['Hóa đơn đối chiếu','2026-11-10',62000000],documents:[saved,mail]}]};
let calls=[];globalThis.fetch=async(url,options)=>{calls.push({url,options});return new Response(url===mail.url?'original email':'original pdf',{headers:{'Content-Type':url===mail.url?'message/rfc822':'application/pdf','Content-Disposition':url===mail.url?'attachment; filename="thu.eml"':"attachment; filename*=UTF-8''hoa-don.pdf"}});};
let tree=render(props);let controls=buttons(tree);assert.equal(controls.length,2);await controls[0].props.onClick();
// Event handlers deliberately discard the promise; settle their async work.
for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));
const csv=await blob.text();assert(csv.includes('262000000')===false);assert(csv.includes('200000000'));assert(csv.includes('Hóa đơn đối chiếu'));assert(csv.includes(source.url));assert.equal(calls.length,0);assert.equal(downloads.length,1);
controls[1].props.onClick();for(let i=0;i<30;i++)await new Promise(resolve=>setImmediate(resolve));
assert.equal(downloads.length,2);assert.equal(calls.length,2);assert(calls.every(c=>c.options.cache==='no-store'&&c.options.signal));
let zip=unzipSync(new Uint8Array(await blob.arrayBuffer()));assert.equal(strFromU8(zip['chung-tu/1_hoa-don.pdf']),'original pdf');assert.equal(strFromU8(zip['chung-tu/2_thu.eml']),'original email');assert(strFromU8(zip['danh-muc-tai-lieu.csv']).includes(source.url));assert(strFromU8(zip['pham-vi.txt']).includes('không cộng chung'));assert.equal(Object.keys(zip).filter(x=>x.startsWith('chung-tu/')).length,2);
assert(!isStoredDocument({url:'//other.test/api/file',kind:'file'}));assert(!isStoredDocument(source));assert(isStoredDocument(mail));
// A failed original prevents a misleading partial archive.
const before=downloads.length;globalThis.fetch=async()=>new Response('missing',{status:404});tree=render(props);buttons(tree)[1].props.onClick();for(let i=0;i<15;i++)await new Promise(resolve=>setImmediate(resolve));assert.equal(downloads.length,before);
// Closing or changing scope cancels in-flight work and never downloads the old selection.
let aborted=false;globalThis.fetch=async(url,{signal})=>new Promise((resolve,reject)=>{signal.addEventListener('abort',()=>{aborted=true;reject(new Error('aborted'));});});tree=render(props);buttons(tree)[1].props.onClick();cleanup();for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));assert(aborted);assert.equal(downloads.length,before);
const empty=buttons(render({...props,rows:[]}));assert(empty.every(b=>b.props.disabled));const noFiles=buttons(render({...props,rows:[{values:['A5','2026-11-13',1],documents:[source]}]}));assert(!noFiles[0].props.disabled);assert(noFiles[1].props.disabled);
assert.equal(props.rows[0].values[2],62000000);URL.createObjectURL=create;URL.revokeObjectURL=revoke;globalThis.setTimeout=timeout;
console.log('PASS: scoped CSV, separate payment/invoice rows, original PDF/EML ZIP, deduplication, external source index, missing-file failure, cancellation and empty state; no write requests.');
