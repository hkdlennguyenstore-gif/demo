// Stock overview and confirmed-baseline regressions share one end-to-end isolated suite.
import './test-stock-baseline.mjs';
