import fs from 'node:fs';
import assert from 'node:assert/strict';
import ts from 'typescript';

const source=fs.readFileSync('app/a4/workbench.tsx','utf8');
const ast=ts.createSourceFile('workbench.tsx',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
let declaration;
function visit(node){if(ts.isFunctionDeclaration(node)&&node.name?.text==='loadProduct')declaration=node;ts.forEachChild(node,visit);}
visit(ast);
assert.ok(declaration);
const compiled=ts.transpileModule(declaration.getText(ast),{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
const create=new Function('state','read',`
 const productSeq=state.sequence;
 const setLoading=value=>state.loading=value;
 const setProduct=value=>state.product=typeof value==='function'?value(state.product):value;
 const setError=value=>state.error=value;
 return code=>{${compiled};return loadProduct;};
`);
const prior={code:'L97',pos:{complete:true,remain:3},price:{display:{listing:379000}}};
const state={sequence:{current:0},loading:false,product:prior,error:''};
let resolve,reject;
const lookup=create(state,()=>new Promise((ok,fail)=>{resolve=ok;reject=fail;}));
const load=lookup('L97');
for(let i=0;i<3;i++){
 const current=state.product,pending=load(false,true);
 assert.equal(state.loading,false,'background refresh must keep total, prices and inputs visible');
 assert.equal(state.product,current);
 const next={...prior,pos:{complete:true,remain:4+i}};
 resolve(next);await pending;assert.equal(state.product,next);
}
state.product={...prior,pos:{remain:1,updatedAt:'2026-11-21T10:00:10Z'}};
const slower=load(false,true);resolve({...prior,pos:{remain:3,updatedAt:'2026-11-21T10:00:05Z'}});await slower;
assert.equal(state.product.pos.remain,1,'a slower full lookup must not restore old POS stock');
const current=state.product,failed=load(false,true);
reject(Error('Mất kết nối'));await failed;
assert.equal(state.product,current,'network failure must retain the last successful data');
assert.equal(state.loading,false);assert.equal(state.error,'Mất kết nối');
const old=load(false,true),oldResolve=resolve;
state.product=null;
const next=lookup('B93')();
assert.equal(state.loading,true,'a new code must show its initial loading state');
oldResolve(prior);await old;
assert.equal(state.product,null,'late response from previous code must be ignored');
assert.equal(state.loading,true,'late response must not end new code loading');
const newProduct={code:'B93',pos:{complete:true,remain:9}};
resolve(newProduct);await next;
assert.equal(state.product,newProduct);assert.equal(state.loading,false);assert.equal(state.error,'');
const refreshEffect=source.slice(source.indexOf('const poll=setInterval'),source.indexOf('async function post'));
assert.equal((refreshEffect.match(/loadProduct\(false,true\)/g)||[]).length,3,'timer, focus and cross-window updates must all refresh silently');
console.log('PASS A4: repeated background refresh, network failure, new code, stale response and all three refresh triggers');
