const vm = require('node:vm');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const properties = new Map();
const crypto=require('node:crypto');
const mailbox = 'owner@example.invalid';
const saved = new Map();
const history = [];
let fail = true;
const entries = [{id:'first-invoice'}, {id:'second-invoice'}, {id:'personal'}];
const queries=[];
const ctx = vm.createContext({
  PropertiesService:{getScriptProperties:()=>({
    getProperty:k=>properties.get(k), setProperty:(k,v)=>properties.set(k,v)
  })},
  Gmail:{Users:{Messages:{
    list:(_,query)=>{queries.push(query.q);return {messages:entries};},
    get:(_,id,opts)=>opts.format==='raw'?{raw:Buffer.from(id).toString('base64')}:
      {internalDate:'1780000000000',payload:{headers:[{name:'Subject',value:id==='personal'?'Birthday party':'Invoice'}]}}
  }}},
  Utilities:{getUuid:()=>crypto.randomUUID(),DigestAlgorithm:{SHA_256:'sha256'},computeDigest:(_,b)=>Array.from(crypto.createHash('sha256').update(Buffer.from(b)).digest()),base64Decode:s=>{assert.equal(s.length%4,0);assert(!/[-_]/.test(s));return Buffer.from(s,'base64');},newBlob:b=>({getBytes:()=>b,getDataAsString:()=>b.toString()})}
});
vm.runInContext(fs.readFileSync('integrations/gmail/Code.gs','utf8'),ctx);
ctx.gmailMessageData=(id,format)=>format==='raw'
  ?{id,raw:Buffer.from('From: vendor@example.com\r\nSubject: Invoice\r\n\r\n'+id).toString('base64url')}
  :ctx.Gmail.Users.Messages.get('me',id,{format:'full'});
ctx.postPM=(suffix,opts)=>{
  if(suffix){history.push(JSON.parse(opts.payload));return {ok:true};}
  const {original,id,mailbox:account}=opts.payload;
  assert.equal(account,mailbox);
  if(fail && id==='second-invoice')throw Error('simulated disconnect');
  const created=!saved.has(id);
  saved.set(id,original.getBytes().toString());
  return {ok:true,id,created,digest:crypto.createHash('sha256').update(original.getBytes()).digest('hex'),size:original.getBytes().length};
};
assert.throws(()=>ctx.scan('history'),/disconnect/);
const checkpoint=JSON.parse(properties.get('all-sources-v1-history'));
assert.equal(new Date(checkpoint.start*1000).toISOString(),'2026-03-31T17:00:00.000Z');
assert.equal(history.length,0);
fail=false;
ctx.scan('history',undefined,{execution:'clock',runId:crypto.randomUUID()});
assert.equal(saved.size,2);
assert.equal(history.length,2);
assert.deepEqual(history.map(p=>[p.execution,p.actualLane,p.reviewed,p.saved,p.newOriginals.map(n=>n.id)]),[['manual','history',1,1,['first-invoice']],['clock','history',2,1,['second-invoice']]]);
assert.equal(JSON.parse(properties.get('all-sources-v1-history')).start,checkpoint.end);
console.log('PASS: VN start date, failed page retained, successful retry advanced checkpoint');

assert(queries.every(q=>!q.includes('from:')&&!q.includes('subject:')));
assert.equal(saved.has('personal'),false);
const msg={id:'abc',payload:{headers:[],mimeType:'multipart/mixed',parts:[
 {mimeType:'text/html',body:{data:Buffer.from('<a href="https://vendor.example/doc/42">Tải hóa đơn</a>').toString('base64url')}},
 {filename:'settlement.csv',mimeType:'text/csv',body:{size:42}}]}};
const info=ctx.inspectMessage(msg).manifest;
assert.equal(info.links.length,1);assert.equal(info.attachments.length,1);
assert(info.reasons.length);assert(ctx.inspectMessage({payload:{headers:[],mimeType:'text/plain',
  body:{data:Buffer.from('发票 2026').toString('base64url')}}}).manifest.reasons.length);
console.log('PASS: sender-independent search, body and attachment inspection, Chinese, invoice link capture and personal-mail exclusion');
ctx.Utilities.computeDigest=(_,bytes)=>Array.from(crypto.createHash('sha256').update(bytes).digest());
ctx.Utilities.DigestAlgorithm={SHA_256:'sha256'};
const fetched=[];
ctx.UrlFetchApp={fetch:(url,options)=>{
  fetched.push(url);
  assert.equal(options.followRedirects,false);
  assert.equal(options.validateHttpsCertificates,true);
  assert.equal(options.headers,undefined);
  return {getResponseCode:()=>200,getBlob:()=>({getContentType:()=>'application/pdf',getBytes:()=>Buffer.from('%PDF-test'),setName:name=>({name})})};
}};
const links=[{url:'https://vendor.example/abc?doc=123'},{url:'https://vendor.example.attacker.test/abc'},
 {url:'https://vendor.example@attacker.com/file'},{url:'http://vendor.example/untrusted'}];
const linked=ctx.readInvoiceLinks(links,'vendor.example');
assert.deepEqual(fetched,['https://vendor.example/abc?doc=123']);
assert.equal(Object.keys(linked).length,1);
assert.equal(links[0].sha256.length,64);
assert(links.slice(1).every(link=>link.readIssue));
console.log('PASS: exact approved host, HTTPS only, no redirect/auth forwarding, SHA256 and linked original field');
const cutoff=Date.parse('2026-11-20T00:00:00+07:00')/1000;
const fixedNow=Date.parse('2026-11-25T09:00:00+07:00');
vm.runInContext('Date.now=()=>'+fixedNow,ctx);
properties.set('all-sources-v1-history', JSON.stringify({start:cutoff-3600}));
ctx.scan('history');
const count=queries.length;
assert.equal(JSON.parse(properties.get('all-sources-v1-history')).start,cutoff);
ctx.scan('history');
assert.equal(queries.length,count);
ctx.scan('recent');
assert.match(queries.at(-1),new RegExp('after:'+(cutoff-86400-1)));
ctx.scan('catchup');
assert.match(queries.at(-1),new RegExp('after:'+(fixedNow/1000-2*86400-1)));
const sweeps=queries.length;
ctx.scan('catchup');assert.equal(queries.length,sweeps);
console.log('PASS: VN handoff, immutable historical end, overlap, once-daily late-arrival sweep');

for(const source of [Buffer.from([0xfb,0xff]),Buffer.from('Đối soát phí vận chuyển'),Buffer.from([1])]) {
  for(const encoding of ['base64','base64url'])assert.deepEqual(Buffer.from(ctx.gmailBytes(source.toString(encoding),'test')),source);
  assert.deepEqual(Buffer.from(ctx.gmailBytes(source,'test')),source);
}
assert.throws(()=>ctx.gmailBytes('a','test'),/không hợp lệ/);
assert.throws(()=>ctx.gmailBytes('ab*c','test'),/không hợp lệ/);
const rawLoader=ctx.gmailMessageData;
ctx.gmailMessageData=id=>({id,raw:Buffer.from('Not a complete email').toString('base64url')});
assert.throws(()=>ctx.originalMail('abc'),/đầu thư MIME/);
ctx.gmailMessageData=rawLoader;
console.log('PASS: padded, unpadded base64url, decoded bytes, Vietnamese text and malformed MIME rejection');
const aKeys=['Số tiền COD','Phí thu hộ COD','Cước phí PP_PM','Phí chuyển hoàn','Phí giao 1 phần','Tiền điều chỉnh','Số tiền thực tế chuyển trả'];
const rr=(cells)=>Object.assign([],cells);
const sampleRows=[
 ['Ngày 18 tháng 11 năm 2026'],rr({0:'Mã khách hàng',3:'SHOP',8:'Lên Nguyễn Store'}),
 rr({0:'Bảng kê chi tiết như sau:',3:'16/11/2026 - 17/11/2026'}),
 rr({0:'NỘI DUNG',3:aKeys[0],5:aKeys[1],6:aKeys[2],7:aKeys[3],8:aKeys[4],9:aKeys[5],10:'Dư nợ kỳ cũ',11:aKeys[6]}),
 rr({3:250000,5:500,6:16500,7:1000,8:0,9:200,10:500,11:232300}),
 ['Tổng cộng',null,null,null,null,250000,500,16500,1000,0,200,231800],
 ['STT','Mã khách hàng','Mã vận đơn',null,null,...aKeys],
 [1,'SHOP','0000123',null,null,250000,500,16500,1000,0,200,231800]
];
ctx.Utilities.newBlob=b=>({getBytes:()=>Buffer.from(b)});
const sampleStatement=ctx.jtRows(sampleRows,6).verifiedReading;
assert.equal(sampleStatement.total,18000);assert.equal(sampleStatement.cod,250000);
assert.equal(sampleStatement.trackingLines[0].tracking,'0000123');
sampleRows[7][5]++;
assert.throws(()=>ctx.jtRows(sampleRows,6),/không khớp/);
console.log('PASS: J&T extracted original tracking ID, costs exclude COD, prior debt and adjustments; inconsistent row rejected');

ctx.Gmail.Users.Messages.list=()=>({messages:[]});
const nodata=crypto.randomUUID();
ctx.scan('recent',undefined,{execution:'clock',runId:nodata});
const ack=history.find(h=>h.runId===nodata);
assert.deepEqual([ack.execution,ack.actualLane,ack.reviewed,ack.saved,ack.newOriginals],['clock','recent',0,0,[]]);
const spam=ctx.inspectMessage({labelIds:['SPAM'],payload:{headers:[{name:'Subject',value:'Invoice'}]}});
assert(spam.manifest.quarantine);
const security=ctx.inspectMessage({payload:{headers:[{name:'From',value:'Google <no-reply@accounts.google.com>'},{name:'Subject',value:'Cảnh báo bảo mật cho tài khoản'}],parts:[{filename:'invoice.pdf'}]}});
assert.equal(security.manifest.reasons.length,0);
console.log('PASS: manual and trigger attribution, empty scheduled pass, quarantine and account-alert exclusion');
