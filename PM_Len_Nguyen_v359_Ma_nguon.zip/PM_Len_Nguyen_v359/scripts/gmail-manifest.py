"""Produce PM intake metadata for an already-authorized supplier .eml. Original input is read-only."""
import argparse
import email.policy
import hashlib
import json
import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
from email.parser import BytesParser
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit


def fold(s):
    return ''.join(ch for ch in unicodedata.normalize('NFD', s.lower()) if unicodedata.category(ch) != 'Mn').replace('đ', 'd')


class Body(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.text, self.links = [], []
        self.href, self.label, self.hidden = '', [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style'):
            self.hidden += 1
        if tag == 'a' and not self.hidden:
            self.href = dict(attrs).get('href') or ''
            self.label = []

    def handle_endtag(self, tag):
        if tag in ('script', 'style'):
            self.hidden = max(0, self.hidden - 1)
        if tag == 'a' and self.href:
            self.links.append((self.href, ' '.join(self.label)))
            self.href = ''

    def handle_data(self, data):
        if not self.hidden and data.strip():
            self.text.append(data.strip())
            if self.href:
                self.label.append(data.strip())


def invoice(raw):
    if len(raw) > 500000 or re.search(br'<!DOCTYPE|<!ENTITY', raw.replace(b'\x00', b''), re.I):
        return None
    node = ET.fromstring(raw)
    for elem in node.iter():
        elem.tag = elem.tag.split('}')[-1]

    def one(parent, key):
        xs = parent.findall(key) if parent is not None else []
        return xs[0] if len(xs) == 1 else None

    def field(parent, key):
        n = one(parent, key)
        return (n.text or '').strip() if n is not None else ''

    doc = node if node.tag == 'HDon' else one(node, 'HDon')
    data = one(doc, 'DLHDon')
    hdr, detail = one(data, 'TTChung'), one(data, 'NDHDon')
    seller, buyer, total = one(detail, 'NBan'), one(detail, 'NMua'), one(detail, 'TToan')
    if any(x is None for x in (hdr, seller, buyer, total)):
        return None
    lines = [field(line, 'THHDVu') for line in detail.findall('DSHHDVu/HHDVu')]
    adjusted = any(n.tag in ('TTHDLQuan', 'TTKThayThe') for n in data.iter()) or bool(re.search('dieu chinh|thay the', fold(field(hdr, 'THDon') + ' ' + ' '.join(lines))))
    return dict(vendor=field(seller, 'Ten'), vendorTaxId=field(seller, 'MST'), buyerName=field(buyer, 'Ten'),
                buyerTaxId=field(buyer, 'MST'), series=field(hdr, 'KHHDon'), number=field(hdr, 'SHDon'),
                date=field(hdr, 'NLap'), currency=field(hdr, 'DVTTe'), total=field(total, 'TgTTTBSo'),
                descriptions=lines, adjusted=adjusted)


def manifest(raw):
    msg = BytesParser(policy=email.policy.default).parsebytes(raw)
    texts, attachments, candidates = [], [], []
    for p in msg.walk():
        name = p.get_filename()
        typ = p.get_content_type()
        if p.is_multipart():
            continue
        b = p.get_payload(decode=True) or b''
        if name or p.get_content_disposition() == 'attachment' or typ not in ('text/plain', 'text/html'):
            a = dict(name=name or typ.replace('/', '.'), mimeType=typ, size=len(b), sha256=hashlib.sha256(b).hexdigest())
            if (name or '').lower().endswith('.xml') or 'xml' in typ:
                if len(b) > 500000:
                    a.update(xmlTruncated=True, readIssue='XML vượt giới hạn đọc')
                else:
                    try:
                        a['invoice'] = invoice(b)
                        if not a['invoice']:
                            a['readIssue'] = 'Chưa nhận diện được cấu trúc hóa đơn XML'
                    except ET.ParseError:
                        a['readIssue'] = 'XML không hợp lệ'
            attachments.append(a)
        else:
            try:
                text = b.decode(p.get_content_charset() or 'utf-8', errors='replace')
            except LookupError:
                text = b.decode('utf-8', errors='replace')
            if typ == 'text/html':
                parser = Body()
                parser.feed(text)
                candidates.extend(parser.links)
                text = '\n'.join(parser.text)
            texts.append(text)
            for m in re.finditer(r'https://[^\s<>"\x27]+', text):
                candidates.append((m.group(), text[max(0,m.start()-80):m.start()]))
    links, seen = [], set()
    for url, label in candidates:
        try:
            parsed = urlsplit(url)
        except ValueError:
            continue
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or url in seen:
            continue
        if re.search(r'invoice|hoa don|tra cuu|chung tu|doi soat|download|receipt|bill|发票|账单', fold(url + ' ' + label)):
            links.append(dict(url=url, label=label[:300], readIssue='Chờ kiểm tra quyền tải hóa đơn từ liên kết nguồn'))
            seen.add(url)
    from gmail_notice import extract_notice
    notice = extract_notice(msg, '\n'.join(texts))
    return dict(version=1, bodyText='\n'.join(texts)[:120000], attachments=attachments, links=links,
                **({'notice': notice} if notice else {}),
                reasons=['Thư gốc trong đợt rà soát chứng từ lịch sử'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('eml', type=Path)
    parser.add_argument('-o', '--output', type=Path)
    args = parser.parse_args()
    if args.output and args.output.resolve() == args.eml.resolve():
        parser.error('Chọn một tệp đầu ra khác thư gốc')
    value = json.dumps(manifest(args.eml.read_bytes()), ensure_ascii=False)
    if args.output:
        args.output.write_text(value, encoding='utf-8')
    else:
        sys.stdout.write(value)
