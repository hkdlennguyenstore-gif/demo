import ts from 'typescript';
import {readFile} from 'node:fs/promises';
import {DatabaseSync} from 'node:sqlite';
import assert from 'node:assert/strict';
const modules={};
for(const name of ['orders','a3-access','return-routing','return-reconciliation','return-retention','return-bulk','return-metrics','return-baseline','return-store']){let code=await readFile(new URL('../lib/'+name+'.ts',import.meta.url),'utf8');code=code.replace(/from '(.+?)'/g,(whole,path)=>path.startsWith('./')&&modules[path.slice(2).replace(/\.ts$/,'')]?"from '"+modules[path.slice(2).replace(/\.ts$/,'')]+"'":whole);modules[name]='data:text/javascript;base64,'+Buffer.from(ts.transpileModule(code,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText).toString('base64');}
const {sourceGroup,classifyReceipt,returnStatus}=await import(modules['return-routing']);const {receiveReturn,importExpected,migrateReturnRules,readReturnBoards}=await import(modules['return-store']);
const sqlite=new DatabaseSync(':memory:');sqlite.exec(`CREATE TABLE pm_orders(id TEXT PRIMARY KEY,channel TEXT,number TEXT,tracking TEXT);CREATE TABLE pm_order_returns(id TEXT PRIMARY KEY,channel TEXT,tracking TEXT,date TEXT,order_id TEXT,active INTEGER,record TEXT,UNIQUE(channel,tracking));CREATE TABLE pm_return_expected(id TEXT PRIMARY KEY,group_key TEXT,tracking TEXT,date TEXT,active INTEGER,record TEXT,UNIQUE(group_key,tracking));`);
const db={prepare(sql){return {args:[],bind(...v){this.args=v;return this;},async all(){return {results:sqlite.prepare(sql).all(...this.args)};},async first(){return sqlite.prepare(sql).get(...this.args)||null;},async run(){const r=sqlite.prepare(sql).run(...this.args);return {meta:{changes:r.changes}};}};},async batch(statements){return Promise.all(statements.map(s=>s.run()));}};
assert.equal(sourceGroup('E','TEST-001').group,'delivery');assert.equal(sourceGroup('E','TEST0001').group,'refund');assert.equal(sourceGroup('G','SPXVNTEST').group,'shopee');
assert.equal(classifyReceipt('12340000',[],[]).group,'unresolved');assert.equal(classifyReceipt('12340000',[{group:'refund'}],[]).group,'refund');assert.equal(classifyReceipt('12340000',[{group:'delivery'},{group:'refund'}],[]).group,'unresolved');
const imported=await importExpected(db,[{tracking:'12340000',sourceColumn:'D'},{tracking:'12340000',sourceColumn:'D'},{tracking:'TEST-001',sourceColumn:'B'},{tracking:'TEST',sourceColumn:'B'}],'owner');assert.equal(imported.unique,3);assert.equal(imported.added,3);
let boards=await readReturnBoards(db,{from:'',to:''},1);assert.equal(boards.stats.received,0);assert.equal(boards.boards.find(b=>b.id==='refund').stats.awaiting,1);
await receiveReturn(db,{tracking:'12340000'},'staff');boards=await readReturnBoards(db,{from:'',to:''},1);assert.equal(boards.boards.find(b=>b.id==='refund').stats.matched,1);assert.equal((await receiveReturn(db,{tracking:'12340000'},'staff')).duplicate,true);assert.equal(sqlite.prepare('SELECT COUNT(*) AS n FROM pm_order_returns').get().n,1);
await receiveReturn(db,{tracking:'TEST-001'},'staff');boards=await readReturnBoards(db,{from:'',to:''},1);assert.equal(boards.boards.find(b=>b.id==='delivery').stats.matched,1);assert.equal(boards.boards.find(b=>b.id==='delivery').stats.awaiting,1);
await receiveReturn(db,{tracking:'UNKNOWN1'},'staff');boards=await readReturnBoards(db,{from:'',to:''},1);assert.equal(boards.stats.unresolved,1);assert.equal(returnStatus(false,true),'received_only');
await importExpected(db,[{tracking:'UNKNOWN1',sourceColumn:'F'}],'owner');await migrateReturnRules(db);boards=await readReturnBoards(db,{from:'',to:''},1);assert.equal(boards.boards.find(b=>b.id==='shopee').stats.matched,1);
const old={tracking:'LEGACY88',channel:'unresolved',sourceColumn:'E',sourceRow:1000,receivedAt:'2026-11-17T01:00:00Z',date:'2026-11-17'};sqlite.prepare('INSERT INTO pm_order_returns VALUES(?,?,?,?,?,1,?)').run('legacy','unresolved','LEGACY88',old.date,null,JSON.stringify(old));await migrateReturnRules(db);const fixed=sqlite.prepare("SELECT * FROM pm_order_returns WHERE id='legacy'").get();assert.equal(fixed.channel,'tiktok');assert.equal(JSON.parse(fixed.record).receivedAt,old.receivedAt);assert.equal(JSON.parse(fixed.record).group,'refund');assert.equal((await migrateReturnRules(db)).corrected,0);
await assert.rejects(()=>receiveReturn(db,{tracking:'FROMREF1',sourceColumn:'D'},'staff'));await assert.rejects(()=>importExpected(db,[{tracking:'FROMREF1',sourceColumn:'E'}],'owner'));
const {reconciliation}=await import(modules['return-reconciliation']);const {parseReturnPaste}=await import(modules['return-bulk']);
const start=Date.parse('2026-11-01T00:00:00Z'),day=86400000;
assert.equal(reconciliation(null,{receivedAt:new Date(start).toISOString()},start+30*day-1).matched,false);
assert.equal(reconciliation(null,{receivedAt:new Date(start).toISOString()},start+30*day).auto30,true);
assert.equal(reconciliation(null,null,start+90*day).matched,false);
assert.equal(reconciliation({},null,start+90*day).status,'awaiting');
assert.equal(reconciliation({}, {receivedAt:new Date(start).toISOString()},start+40*day).status,'matched');
assert.equal(reconciliation(null,{receivedAt:'2026-01-01T00:00:00Z',dateUnknown:true,importedAt:new Date(start).toISOString()},start+29*day).auto30,false);
assert.equal(reconciliation(null,{receivedAt:'invalid'},start+50*day).auto30,false);
assert.equal(reconciliation(null,{receivedAt:new Date(start+day).toISOString()},start).auto30,false);
const parsed=parseReturnPaste('12340000\n12340000\nvtpvn000000;VTPVN000000\tABC-001','refund');assert.equal(parsed.input,5);assert.equal(parsed.unique,3);assert.equal(parsed.duplicates,2);assert.equal(parsed.invalid.length,0);
assert.equal(parseReturnPaste('mã lỗi<>','delivery').invalid.length>0,true);
const repeated=await importExpected(db,[{tracking:'12340000',group:'refund'},{tracking:'12340000',group:'refund'}],'owner');assert.equal(repeated.added,0);assert.equal(repeated.removedDuplicates,2);assert.equal(repeated.existing,1);assert.equal(repeated.duplicateInPaste,1);
const wrongGroup=await importExpected(db,[{tracking:'12340000',group:'shopee'}],'owner');assert.equal(wrongGroup.added,0);assert.equal(wrongGroup.existing,1);
const aged={tracking:'AGED0001',group:'refund',channel:'tiktok',receivedAt:new Date(start).toISOString(),date:'2026-11-01'};sqlite.prepare('INSERT INTO pm_order_returns VALUES(?,?,?,?,?,1,?)').run('aged','tiktok',aged.tracking,aged.date,null,JSON.stringify(aged));
let agedBoards=await readReturnBoards(db,{from:'',to:''},1,'auto30',start+30*day);assert.equal(agedBoards.boards.find(b=>b.id==='refund').stats.autoMatched,1);assert.equal(agedBoards.boards.find(b=>b.id==='refund').rows.some(r=>r.tracking===aged.tracking),true);
const pendingReport=await readReturnBoards(db,{from:'',to:''},1,'awaiting',start+30*day);assert.equal(pendingReport.boards.every(b=>b.rows.every(r=>!r.receipt&&r.expected)),true);assert.equal(pendingReport.stats.awaitingAllTime,1);
await importExpected(db,[{tracking:aged.tracking,group:'refund'}],'owner');agedBoards=await readReturnBoards(db,{from:'',to:''},1,'all',start+31*day);const late=agedBoards.boards.find(b=>b.id==='refund').rows.find(r=>r.tracking===aged.tracking);assert.equal(late.reconciliation.exact,true);assert.equal(late.reconciliation.auto30,false);
console.log('Đạt kiểm tra đối chiếu, dán hàng loạt, trùng trong lô/khác lô/khác nhóm, báo cáo chưa về kho, ngưỡng 30 ngày và đối chứng đến muộn.');
sqlite.exec('CREATE TABLE pm_order_actions(id TEXT PRIMARY KEY,time TEXT,actor TEXT,action TEXT,record TEXT)');
const {receiveReturnBatch}=await import(modules['return-store']);
const bulkRows=Array.from({length:3000},(_,i)=>({tracking:'BULK'+String(i).padStart(8,'0'),sourceRow:i+2,sourceColumn:'C'}));
let selectCalls=0,batchCalls=0;const measured={...db,prepare(q){if(q.startsWith('SELECT'))selectCalls++;return db.prepare(q);},async batch(s){batchCalls++;return db.batch(s);}};
const bulk=await receiveReturnBatch(measured,bulkRows,'owner');assert.equal(bulk.added,3000);assert.equal(bulk.duplicates,0);assert.ok(selectCalls<42);assert.equal(batchCalls,50);assert.equal((await receiveReturnBatch(db,bulkRows,'owner')).added,0);
await importExpected(db,[{tracking:'DUALSOURCE1',group:'refund'}],'owner');const routed=await receiveReturnBatch(db,[{tracking:'DUALSOURCE1',sourceRow:780,sourceColumn:''},{tracking:'DUALSOURCE1',sourceRow:2,sourceColumn:'C'}],'owner');assert.equal(routed.added,1);assert.equal(routed.duplicates,1);assert.equal(JSON.parse(sqlite.prepare("SELECT record FROM pm_order_returns WHERE tracking='DUALSOURCE1'").get().record).group,'refund');
const before=sqlite.prepare("SELECT record FROM pm_order_returns WHERE tracking='12340000'").get().record;assert.equal((await receiveReturnBatch(db,[{tracking:'12340000',sourceRow:2,sourceColumn:'C'}],'owner')).added,0);assert.equal(sqlite.prepare("SELECT record FROM pm_order_returns WHERE tracking='12340000'").get().record,before);
await assert.rejects(()=>receiveReturnBatch(db,[{tracking:'INVALIDCOL1',sourceRow:2,sourceColumn:'D'}],'owner'));assert.equal(sqlite.prepare("SELECT COUNT(*) AS n FROM pm_order_returns WHERE tracking='INVALIDCOL1'").get().n,0);
console.log('PASS bulk history: 3,000 receipts in 50 write batches; <40 reads; replay, cross-column duplicate, auto-routing and existing receipt timestamps preserved.');

const double='BULK00000000',receiptBefore=JSON.parse(sqlite.prepare('SELECT record FROM pm_order_returns WHERE tracking=?').get(double).record);for(const group of ['delivery','refund'])sqlite.prepare('INSERT INTO pm_return_expected VALUES(?,?,?,?,1,?)').run('dup-'+group,group,double,'2026-11-01',JSON.stringify({tracking:double,group,source:'Doanh Số Đơn Hàng · BẮN ĐƠN HOÀN'}));sqlite.prepare('INSERT INTO pm_return_expected VALUES(?,?,?,?,1,?)').run('note-wrong','refund','VIETNAMPICKUPWAREHOUSE','2026-11-01',JSON.stringify({source:'Doanh Số Đơn Hàng · BẮN ĐƠN HOÀN',sourceRow:790}));const cleaned=await receiveReturnBatch(db,[bulkRows[0]],'owner');assert.equal(cleaned.added,0);assert.equal(cleaned.cleanup.duplicateReferences,1);assert.equal(cleaned.cleanup.discardedNotes,1);assert.equal(sqlite.prepare('SELECT COUNT(*) AS n FROM pm_return_expected WHERE tracking=? AND active=1').get(double).n,1);const kept=JSON.parse(sqlite.prepare('SELECT record FROM pm_order_returns WHERE tracking=?').get(double).record);assert.equal(kept.receivedAt,receiptBefore.receivedAt);assert.equal(kept.sourceConflict,true);assert.equal(sqlite.prepare("SELECT COUNT(*) AS n FROM pm_order_actions WHERE action='Rà soát đối chứng theo lịch sử đã nhận'").get().n,1);assert.equal((await receiveReturnBatch(db,[bulkRows[0]],'owner')).cleanup.duplicateReferences,0);console.log('PASS: duplicate source references deactivated reversibly with audit; note excluded; receipt time preserved.');

// Each clickable metric must return exactly the complete list counted in its badge,
// independently of the main table's filter and 50-row page.
const now=Date.now(),range={from:'',to:''};
const snapshot=await readReturnBoards(db,range,1,'awaiting',now);
const metrics=['expected','received','matched','exactMatched','autoMatched','awaiting','receivedOnly'];
for(const board of snapshot.boards){for(const metric of metrics){
 const result=await readReturnBoards(db,range,2,'received_only',now,{group:board.id,metric,allTime:false});
 assert.equal(result.details.total,board.stats[metric],board.id+':'+metric);
 assert.equal(result.details.rows.length,board.stats[metric]);
 assert.ok(result.details.rows.every(r=>r.group===board.id&&Boolean(r.tracking)));
}}
const excluded=await readReturnBoards(db,{from:'2099-01-01',to:'2099-12-31'},1,'all',now,{group:'all',metric:'awaiting',allTime:false});assert.equal(excluded.details.total,0);
const allTime=await readReturnBoards(db,{from:'2099-01-01',to:'2099-12-31'},1,'all',now,{group:'all',metric:'awaiting',allTime:true});assert.equal(allTime.details.total,snapshot.stats.awaitingAllTime);
await assert.rejects(()=>readReturnBoards(db,range,1,'all',now,{group:'delivery',metric:'invalid',allTime:false}));
const many=Array.from({length:63},(_,i)=>({tracking:'DETAIL'+String(i).padStart(5,'0'),group:'delivery'}));await importExpected(db,many,'owner');
const full=await readReturnBoards(db,range,1,'all',now,{group:'delivery',metric:'expected',allTime:false});assert.ok(full.details.rows.length>50);assert.equal(full.details.total,full.boards.find(b=>b.id==='delivery').stats.expected);assert.equal(full.boards.find(b=>b.id==='delivery').rows.length,50);
console.log('Đạt: 21 chỉ tiêu khớp danh sách, dữ liệu quá 50 dòng, bộ lọc ngày, toàn thời gian và từ chối chỉ tiêu không hợp lệ.');

const {applyReturnBaseline,readReturnBaseline,allowPosReturn}=await import(modules['return-baseline']);
const baselineInput=Array.from({length:60},(_,i)=>({tracking:'BASELINE'+String(i).padStart(4,'0'),group:i<41?'delivery':'refund'}));
await applyReturnBaseline(db,baselineInput,'owner');
const baselineReport=await readReturnBoards(db,{from:'',to:''},1);assert.equal(baselineReport.stats.awaitingAllTime,60);
const baseline=await readReturnBaseline(db);assert.equal(await allowPosReturn(db,'DETAIL00000',new Date(Date.now()+60000).toISOString(),baseline),false);assert.equal(await allowPosReturn(db,'NEWPARCEL',new Date(Date.now()+60000).toISOString(),baseline),true);assert.equal(await allowPosReturn(db,'OLDDATE','2026-01-01T00:00:00Z',baseline),false);
assert.equal((await readReturnBoards(db,{from:'',to:''},1)).stats.received,baselineReport.stats.received);await assert.rejects(()=>applyReturnBaseline(db,baselineInput,'owner'));
console.log('PASS baseline: exactly 60 pending, prior references excluded without receiving parcels, POS historical replay blocked, new returns allowed, baseline reset rejected.');
