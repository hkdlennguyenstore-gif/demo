import fs from 'node:fs';
import assert from 'node:assert/strict';
import ts from 'typescript';
import {DatabaseSync} from 'node:sqlite';
const compile=s=>ts.transpileModule(s,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText,uri=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
const display=uri(compile(fs.readFileSync('lib/a4-display.ts','utf8')));
const purchasing=uri(compile(fs.readFileSync('lib/purchasing.ts','utf8'))),a4=uri(compile(fs.readFileSync('lib/a4.ts','utf8').replace("'./purchasing.ts'",JSON.stringify(purchasing)).replace("'./a4-display.ts'",JSON.stringify(display))));
const {a4Prices,a4Size,a4Calculate}=await import(display);
const {validateA4Plan,transitionA4Plan,normalizeA4Variations,validateA4Page}=await import(a4);
const {saveA4Plan,A4Conflict,numberedPlans}=await import(uri(compile(fs.readFileSync('lib/a4-store.ts','utf8').replace("'./a4.ts'",JSON.stringify(a4)))));
const sourceCode=fs.readFileSync('lib/a4-source.ts','utf8').replace("import {posGet} from './orders-store';","const posGet=(...args)=>globalThis.__a4Pos(...args);").replace("'./a4'",JSON.stringify(a4));
const {readA4Product}=await import(uri(compile(sourceCode)));
let count=0;async function test(label,fn){await fn();count++;console.log('PASS',label);}
const input={date:'2026-11-21',lot:'01',supplier:'  Xưởng   Minh ',type:'Jean ôm',code:'D09',due:'',note:'Wash nhẹ',colors:[{color:'Xanh nhạt',qty:[5,5,5,5,5,5,5,5,5]},{color:'Đen',qty:[2,0,0,0,0,0,0,0,0]}]};
const normalized=validateA4Plan(input);
await test('two colors, nine sizes, total 47, supplier normalized, leading-zero code retained',()=>{assert.equal(normalized.qty[0],7);assert.equal(normalized.qty.reduce((a,b)=>a+b),47);assert.equal(normalized.supplier,'Xưởng Minh');assert.equal(normalized.code,'D09');});
await test('reject invalid fields, duplicate color, fractions, blank sizes, bad calendar date and earlier due',()=>{for(const p of [{...input,supplier:' '},{...input,date:'2026-02-30'},{...input,due:'2026-11-20'},{...input,colors:[input.colors[0],{...input.colors[0],color:' xanh nhạt '}]},{...input,colors:[{color:'Đen',qty:[.5,0,0,0,0,0,0,0,0]}]},{...input,colors:[{color:'Đen',qty:Array(9).fill(0)}]}])assert.throws(()=>validateA4Plan(p));});
const variation=(id,code='D09',extra={})=>({id,product:{custom_id:code,name:'Jean thật'},fields:[{name:'Màu',value:'Xanh'},{name:'Size',value:'27'}],remain_quantity:5,variations_warehouses:[{warehouse_id:'kho1',remain_quantity:3,actual_remain_quantity:4},{warehouse_id:'kho2',remain_quantity:2,actual_remain_quantity:6}],...extra});
await test('exact POS product code, authoritative sellable quantity, separate physical quantity and hidden rows excluded',()=>{const p=normalizeA4Variations([variation('one'),variation('two','D9'),variation('hidden','D09',{is_hidden:true})],'D09');assert.equal(p.variants.length,1);assert.equal(p.remain,5);assert.equal(p.actual,10);assert.equal(p.complete,true);});
await test('missing source stays null, explicit zero retained, size not inferred from barcode or physical dimensions',()=>{const p=normalizeA4Variations([variation('one','D09',{remain_quantity:undefined,variations_warehouses:[],fields:[],size:{length:27},custom_id:'D09-XANH-27'})],'D09');assert.equal(p.remain,null);assert.equal(p.complete,false);assert.equal(p.variants[0].size,'Chưa có size');assert.equal(normalizeA4Variations([variation('zero','D09',{remain_quantity:0})],'D09').remain,0);});
await test('select POS size for each SKU even if every attribute repeats the first size',()=>{
 const examples=[['T12','T12_XanhCao_34','34'],['T4','T4_XANH SÒ (NHẠT) 29','29'],['SP0D','SP0D_36','36'],['A1','A1_XanhDam_3XL','3XL'],['S91','S91XAMSIZE34(71-73KG)','34'],['T4','T40_XAM_29','27'],['T4','T4_65K','27']];
 for(const [code,sku,expected] of examples){
  const result=normalizeA4Variations([variation('v',code,{custom_id:sku})],code);
  assert.equal(result.variants[0].size,expected,sku);
  assert.equal(result.variants[0].remain,5);
 }
});
await test('numeric marketplace parent matched by exact shop SKU prefix only',()=>{
 const imported=(id,sku,parent)=>variation(id,parent,{custom_id:sku});
 const p=normalizeA4Variations([imported('a','T4_XÁM 29','1735274532979312283'),imported('b','T40_XÁM 29','1735274532979312283'),imported('c','T4_XÁM 29','T9')],'T4');
 assert.deepEqual(p.variants.map(v=>[v.id,v.code,v.size]),[['a','T4','29']]);
});
await test('duplicate variant and duplicate warehouse rejected',()=>{assert.throws(()=>normalizeA4Variations([variation('one'),variation('one')],'D09'),/trùng/);assert.throws(()=>normalizeA4Variations([variation('one','D09',{variations_warehouses:[{warehouse_id:'1'},{warehouse_id:'1'}]})],'D09'),/trùng/);});
await test('read all POS pages and reject unstable totals or missing pages',async()=>{const cfg={PANCAKE_API_KEY:'fixture',PANCAKE_SHOP_ID:'1'};globalThis.__a4Pos=async(_key,_shop,path,q)=>{assert.equal(path,'products/variations');return {success:true,data:[variation('p'+q.page_number)],total_entries:2,total_pages:2};};assert.equal((await readA4Product(cfg,'D09',true)).variants.length,2);globalThis.__a4Pos=async(_k,_s,_p,q)=>({success:true,data:[variation('p'+q.page_number)],total_entries:q.page_number==='1'?2:3,total_pages:2});await assert.rejects(readA4Product(cfg,'D09',true),/thay đổi/);globalThis.__a4Pos=async()=>({success:true,data:[variation('p1')],total_entries:3,total_pages:1});await assert.rejects(readA4Product(cfg,'D09',true),/đủ biến thể/);assert.throws(()=>validateA4Page({success:true,data:[],total_entries:1}),/phân trang/);});
await test('approved size headings normalize explicit Size prefix without merging arbitrary names',()=>{for(const v of ['27','Size 27','SIZE: 27',' size-27 '])assert.equal(a4Size(v),'27');assert.equal(a4Size('27/28'),'27/28');const p=normalizeA4Variations([variation('size-label','D09',{fields:[{name:'Màu',value:'Xanh'},{name:'Size',value:'Size 27'}]})],'D09');assert.equal(p.variants[0].size,'27');assert.equal(p.remain,5);});
await test('real POS size labels with weight guidance share nine columns and preserve every quantity',()=>{
 const labels=['- Size 27 (43 - 45 kg)','- Size 28 (46 - 49 kg','- Size 29 (50 - 54 kg)','- Size 30 (55 - 57 kg)','- Size 31 (58 - 61 kg)','-Size 32 (62 - 65kg)','- Size 33 (66 - 70kg)','- Size 34 (71 - 73kg)','- Size 35 (74 - 76kg)'];
 labels.forEach((label,i)=>assert.equal(a4Size(label),String(27+i)));
 const p=normalizeA4Variations(labels.map((label,i)=>variation('weighted-'+i,'D09',{fields:[{name:'Màu',value:'Xanh'},{name:'Size',value:label}],remain_quantity:i})).concat(variation('plain','D09',{remain_quantity:4})),'D09');
 assert.equal(new Set(p.variants.map(v=>v.size)).size,9);assert.equal(p.remain,40);assert.equal(p.variants.filter(v=>v.size==='27').reduce((n,v)=>n+v.remain,0),4);assert.equal(p.complete,true);
 for(const label of ['27/28','Size 27 dài','Size 27 (mẫu 28)','Áo 27','Size 270'])assert.equal(a4Size(label),label);
});
await test('approved B4 price mapping separates F/G and listing/sale with QC 3%, never treating missing prices as zero',()=>{const calculated=Array(23).fill(null);calculated[0]=190000;calculated[5]=295000;calculated[11]=379000;calculated[12]=245000;const p=a4Prices({price:130000,fbPrice:130000,calculated});assert.equal(p.facebookBase,130000);assert.equal(p.facebook,190000);assert.equal(p.listing,379000);assert.equal(p.quote,302000);assert.equal(p.readLive,299000);assert.equal(p.qc,229000);assert.equal(p.vc9,238000);assert.equal(p.vc50,279000);const missing=a4Prices({price:130000,fbPrice:null,calculated:[]});assert.equal(missing.facebook,null);assert.equal(missing.listing,null);assert.equal(missing.readLive,null);assert.equal(a4Prices({calculatedPending:true,calculated}).listing,null);});
await test('approved calculator handles Vietnamese grouping, operators and percentages without evaluating code',()=>{assert.equal(a4Calculate('(299.000 × 2) − 20.000'),578000);assert.equal(a4Calculate('222000*103%'),228660);assert.equal(a4Calculate('1.234,5 + 0,5'),1235);assert.throws(()=>a4Calculate('1/0'));assert.throws(()=>a4Calculate('alert(1)'));assert.throws(()=>a4Calculate('2 +'));});
const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync('drizzle/0005_tan_joystick.sql','utf8').replaceAll('--> statement-breakpoint',''));
sql.exec("CREATE TABLE official_stock(quantity INTEGER);INSERT INTO official_stock VALUES(123);CREATE TABLE official_cost(amount INTEGER);INSERT INTO official_cost VALUES(456);");
const db={prepare(query){let args=[];return {bind(...v){args=v;return this;},async first(){return sql.prepare(query).get(...args)||null;},async all(){return {results:sql.prepare(query).all(...args)};},async run(){return {meta:{changes:Number(sql.prepare(query).run(...args).changes)}};},runSync(){return {meta:{changes:Number(sql.prepare(query).run(...args).changes)}};}};},async batch(statements){sql.exec('BEGIN IMMEDIATE');try{const result=statements.map(s=>s.runSync());sql.exec('COMMIT');return result;}catch(e){sql.exec('ROLLBACK');throw e;}}};
const stored=id=>{const r=sql.prepare('SELECT version,record FROM pm_a4_plans WHERE id=?').get(id);return {...JSON.parse(r.record),version:r.version};};let first;
await test('save/read across clients, replay cannot duplicate plan, no test seed in migration',async()=>{first=await saveA4Plan(db,'owner',crypto.randomUUID(),'save',input);const id=crypto.randomUUID(),replayed=await saveA4Plan(db,'owner',id,'save',{...input,lot:'02'});assert.equal((await saveA4Plan(db,'owner',id,'save',{...input,lot:'02'})).id,replayed.id);assert.equal(sql.prepare('SELECT COUNT(*) n FROM pm_a4_plans').get().n,2);assert.equal(stored(first.id).qty.reduce((a,b)=>a+b),47);assert.ok(!fs.readFileSync('drizzle/0005_tan_joystick.sql','utf8').includes('INSERT'));});
await test('stale window rejected; only draft editable; production transition retained',async()=>{await saveA4Plan(db,'owner',crypto.randomUUID(),'save',{...input,id:first.id,version:0,lot:'01A'});await assert.rejects(saveA4Plan(db,'owner',crypto.randomUUID(),'save',{...input,id:first.id,version:0}),A4Conflict);await saveA4Plan(db,'owner',crypto.randomUUID(),'production',{id:first.id,version:1,date:'2026-11-21'});assert.equal(stored(first.id).status,'production');await assert.rejects(saveA4Plan(db,'owner',crypto.randomUUID(),'save',{...input,id:first.id,version:2}),/Chỉ sửa/);});
await test('partial/full return, no over-receipt, immutable source data and audit for every accepted request',async()=>{await saveA4Plan(db,'owner',crypto.randomUUID(),'return',{id:first.id,version:2,date:'2026-11-21',quantity:7});assert.equal(stored(first.id).received,7);assert.equal(stored(first.id).status,'production');await assert.rejects(saveA4Plan(db,'owner',crypto.randomUUID(),'return',{id:first.id,version:3,date:'2026-11-21',quantity:41}),/Số lượng/);await saveA4Plan(db,'owner',crypto.randomUUID(),'return',{id:first.id,version:3,date:'2026-11-21',quantity:40});assert.equal(stored(first.id).status,'returned');assert.equal(stored(first.id).returns.length,2);assert.equal(sql.prepare('SELECT quantity FROM official_stock').get().quantity,123);assert.equal(sql.prepare('SELECT amount FROM official_cost').get().amount,456);assert.equal(sql.prepare('SELECT COUNT(*) n FROM pm_a4_requests').get().n,6);});
await test('navigation has distinct A4 module without widening access to costs',async()=>{const nav=await import(uri(compile(fs.readFileSync('lib/navigation.ts','utf8'))));assert.equal(nav.navigationFor('owner').a4,true);assert.equal(nav.navigationFor('employee').a4,true);assert.equal(nav.navigationFor('payroll').a4,false);assert.equal(nav.navigationFor('employee').a3,false);});
await test('draft deletion can be retried',async()=>{
 const draft=await saveA4Plan(db,'owner',crypto.randomUUID(),'save',{...input,lot:'DELETE-TEST'});
 const req=crypto.randomUUID(),data={id:draft.id,version:draft.version};
 await assert.rejects(saveA4Plan(db,'owner',req,'delete',{...data,version:99}),A4Conflict);
 await saveA4Plan(db,'owner',req,'delete',data);
 assert.equal(sql.prepare('SELECT status FROM pm_a4_plans WHERE id=?').get(draft.id).status,'archived');
 assert.equal((await saveA4Plan(db,'owner',req,'delete',data)).replayed,true);
});
await test('lot number is stable across deletion, editing and out-of-order production',async()=>{
 const view=()=>sql.prepare(numberedPlans+" SELECT id,lot FROM numbered WHERE status='draft' ORDER BY seq").all();
 const create=()=>saveA4Plan(db,'owner',crypto.randomUUID(),'save',{...input,lot:''});
 const a=await create(),b=await create(),c=await create();
 const prior=view().find(x=>x.id===c.id).lot;
 await saveA4Plan(db,'owner',crypto.randomUUID(),'delete',{id:b.id,version:0});
 assert.equal(view().find(x=>x.id===c.id).lot,prior);
 const req=crypto.randomUUID(),payload={id:c.id,version:0,date:input.date};
 const report=await saveA4Plan(db,'owner',req,'production',payload);
 assert.equal(report.lot,prior);assert.equal(stored(c.id).lot,prior);
 assert.equal((await saveA4Plan(db,'owner',req,'production',payload)).lot,prior);
 await saveA4Plan(db,'owner',crypto.randomUUID(),'production',{...payload,id:a.id});
 assert.equal(stored(a.id).lot,a.lot);assert.equal(stored(first.id).lot,'1');
});
await test('deleted reported lots leave the list but keep their official number',async()=>{
 const latest=sql.prepare("SELECT id,version FROM pm_a4_plans WHERE status='production' ORDER BY CAST(lot AS INTEGER) DESC LIMIT 1").get();
 for(const data of [latest,{id:first.id,version:stored(first.id).version}]){
  await saveA4Plan(db,'owner',crypto.randomUUID(),'delete',data);
  assert.equal(sql.prepare(numberedPlans+' SELECT count(*) AS n FROM numbered WHERE id=?').get(data.id).n,0);
 }
 const next=await saveA4Plan(db,'owner',crypto.randomUUID(),'save',input);
 assert.equal((await saveA4Plan(db,'owner',crypto.randomUUID(),'production',{id:next.id,version:0,date:input.date})).lot,'7');
});
console.log('A4:',count,'checks passed; fixtures are in-memory only.');sql.close();
