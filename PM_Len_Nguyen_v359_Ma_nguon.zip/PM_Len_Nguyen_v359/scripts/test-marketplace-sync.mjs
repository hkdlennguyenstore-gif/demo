import ts from 'typescript';
import {readFile} from 'node:fs/promises';
import {DatabaseSync} from 'node:sqlite';
import assert from 'node:assert/strict';
const modules={};
for(const name of ['orders','a3-access','return-routing','return-reconciliation','return-retention','return-bulk','return-store','orders-store','marketplace-orders','marketplace-store']){
 let code=await readFile(new URL('../lib/'+name+'.ts',import.meta.url),'utf8');
 code=code.replace(/from '(.+?)'/g,(whole,path)=>{const key=path.replace(/^\.\//,'').replace(/\.ts$/,'');return modules[key]?"from '"+modules[key]+"'":whole;});
 modules[name]='data:text/javascript;base64,'+Buffer.from(ts.transpileModule(code,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText).toString('base64');
}
const {normalizeMarketplace,recentOrderStart,marketplaceAccounts}=await import(modules['marketplace-orders']);
const {syncMarketplaces,storeMarketplaceRows,marketplaceStatus,syncFacebookExpected}=await import(modules['marketplace-store']);
const {prepareOrders}=await import(modules['orders-store']);
const {archiveMatchedReturns,matchedTime,isArchived}=await import(modules['return-retention']);
const {receiveReturn,importExpected}=await import(modules['return-store']);
const sql=new DatabaseSync(':memory:');
const db={prepare(q){return {args:[],bind(...v){this.args=v;return this;},async all(){return {results:sql.prepare(q).all(...this.args)};},async first(){return sql.prepare(q).get(...this.args)||null;},async run(){return {meta:{changes:sql.prepare(q).run(...this.args).changes}};}};},async batch(statements){sql.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}}};
const now=new Date(),today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
const raw={id:'587174124930237694',shop_id:6111341,account:'100046473',order_sources:'-9',inserted_at:today+'T00:00:00',updated_at:today+'T00:01:00',status:4,total_quantity:2,partner:{extend_code:'862707254224',partner_name:'J&T',extend_update:[{action_code:50101,status:'Your package has been delivered. Recipient: Customer'}]},bill_phone_number:'DO_NOT_IMPORT',shipping_address:{address:'DO_NOT_IMPORT'}};
assert.equal(recentOrderStart(new Date('2026-11-17T04:00:00Z')),'2026-10-19');
let r=normalizeMarketplace(raw,'6111341');assert.equal(r.channel,'tiktok2');assert.equal(r.number,raw.id);assert.equal(r.expectedGroup,null);assert.equal(r.returnNeedsReview,true);assert.ok(!JSON.stringify(r).includes('DO_NOT_IMPORT'));
assert.equal(normalizeMarketplace({...raw,account:'400050288'},'6111341').channel,'tiktok1');assert.equal(normalizeMarketplace({...raw,order_sources:'-3',account:'100047072',id:'261117GRQ8DFSP'},'6111341').channel,'shopee');assert.equal(normalizeMarketplace({...raw,account:'UNKNOWN'},'6111341'),null);assert.throws(()=>normalizeMarketplace({...raw,id:Number(raw.id)},'6111341'));assert.throws(()=>normalizeMarketplace(raw,'123'));
const returning={...raw,id:'587174124930237695',partner:{...raw.partner,extend_code:'RETURN12345',extend_update:[{action_code:80101,status:'Your package has been returned to the seller.'}]}};
r=normalizeMarketplace(returning,'6111341');assert.equal(r.expectedGroup,'delivery');
await prepareOrders(db);await storeMarketplaceRows(db,[r,normalizeMarketplace(raw,'6111341')]);await storeMarketplaceRows(db,[r]);assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM pm_orders').get().n,2);assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM pm_return_expected').get().n,1);assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM pm_order_returns').get().n,0);
// Older replay cannot revoke/overwrite newer data or change derived expected parcels.
await storeMarketplaceRows(db,[normalizeMarketplace({...returning,status:3,updated_at:today+'T00:00:00'},'6111341')]);assert.equal(sql.prepare("SELECT status FROM pm_orders WHERE source_id=?").get(returning.id).status,4);assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM pm_return_expected WHERE active=1').get().n,1);
const originalFetch=globalThis.fetch,urls=[];
globalThis.fetch=async input=>{const u=new URL(String(input));urls.push(u);if(u.pathname.endsWith('order_source'))return Response.json({success:true,data:marketplaceAccounts.map(a=>({id:a.account,parent_id:a.source,custom_id:a.shopId}))});return Response.json({success:true,total_entries:2,total_pages:1,page_size:500,data:[raw,returning]});};
try{
 let s=await syncMarketplaces(db,{PANCAKE_API_KEY:'fixture',PANCAKE_SHOP_ID:'6111341'});assert.equal(s.complete,true);assert.equal(s.scopeDays,30);const first=urls.find(u=>u.pathname.endsWith('/orders'));assert.equal(Number(first.searchParams.get('startDateTime')),Date.parse(recentOrderStart()+'T00:00:00+07:00')/1000);assert.deepEqual(JSON.parse(first.searchParams.get('order_sources[]')),[['-9','400050288'],['-9','100046473'],['-3','100047072']]);
 s=await syncMarketplaces(db,{PANCAKE_API_KEY:'fixture',PANCAKE_SHOP_ID:'6111341'});assert.equal(s.phase,'delta');assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM pm_orders').get().n,2);assert.equal(urls.at(-1).searchParams.get('updateStatus'),'updated_at');
 globalThis.fetch=async()=>{throw Error('temporary failure');};await assert.rejects(()=>syncMarketplaces(db,{PANCAKE_API_KEY:'fixture',PANCAKE_SHOP_ID:'6111341'}));assert.equal((await marketplaceStatus(db)).complete,false);assert.ok((await marketplaceStatus(db)).watermark);assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM pm_order_sync_lock').get().n,0);
}finally{globalThis.fetch=originalFetch;}
const day=86400000,start=Date.parse('2026-09-01T00:00:00Z'),receipt={group:'delivery',tracking:'ARCHIVE123',receivedAt:new Date(start).toISOString(),date:'2026-09-01'},expected={tracking:'ARCHIVE123',group:'delivery',importedAt:new Date(start+day).toISOString()};
sql.prepare('INSERT INTO pm_order_returns VALUES(?,?,?,?,?,1,?)').run('aged','tiktok2',receipt.tracking,receipt.date,null,JSON.stringify(receipt));sql.prepare('INSERT INTO pm_return_expected VALUES(?,?,?,?,1,?)').run('aged-exp','delivery',receipt.tracking,receipt.date,JSON.stringify(expected));
assert.equal(matchedTime(expected,receipt),start+day);assert.equal((await archiveMatchedReturns(db,start+31*day-1)).archived,0);assert.equal((await archiveMatchedReturns(db,start+31*day)).archived,1);assert.equal(await isArchived(db,receipt.tracking),true);assert.equal((await receiveReturn(db,{tracking:receipt.tracking},'staff')).duplicate,true);assert.equal((await importExpected(db,[{tracking:receipt.tracking,group:'delivery'}],'owner')).added,0);
// Auto match at receipt + 30 days, then retain for another 30; expected-only parcel stays.
const auto={...receipt,tracking:'AUTO12345'};sql.prepare('INSERT INTO pm_order_returns VALUES(?,?,?,?,?,1,?)').run('auto','tiktok',auto.tracking,auto.date,null,JSON.stringify(auto));sql.prepare('INSERT INTO pm_return_expected VALUES(?,?,?,?,1,?)').run('awaiting','delivery','UNRECEIVED','2026-01-01',JSON.stringify({tracking:'UNRECEIVED',group:'delivery',importedAt:'2026-01-01T00:00:00Z'}));
assert.equal((await archiveMatchedReturns(db,start+60*day-1)).archived,0);assert.equal((await archiveMatchedReturns(db,start+60*day)).archived,1);assert.equal(sql.prepare("SELECT COUNT(*) AS n FROM pm_return_expected WHERE tracking='UNRECEIVED'").get().n,1);
const fb={id:'pos:6111341:315998',channel:'facebook',number:'315998',date:today,updated:today+'T00:02:00Z',status:4,tracking:'FBRETURN987',quantity:1,staff:'NV'};sql.prepare('INSERT INTO pm_orders VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(fb.id,'facebook','315998',fb.number,fb.date,fb.updated,fb.status,fb.staff,fb.tracking,fb.quantity,JSON.stringify(fb));assert.equal((await syncFacebookExpected(db)).added,1);assert.equal((await syncFacebookExpected(db)).added,0);assert.equal(sql.prepare("SELECT COUNT(*) AS n FROM pm_order_returns WHERE tracking='FBRETURN987'").get().n,0);
console.log('PASS: verified shop/account mapping, string IDs, 30-day initial scope, incremental sync, retry/lock release, conservative return routing, replay, exact/auto30 retention boundaries, archived dedup, awaiting preservation.');
sql.close();
