import {test} from 'node:test';
import assert from 'node:assert/strict';
import {zipSync,strToU8} from 'fflate';
import {readArchive} from '../public/expense-ocr/archive.mjs';
test('K21 ZIP 67 PDF: đủ kết quả, lỗi một PDF không chặn 66 PDF còn lại, giữ bytes lỗi',async()=>{
 const entries=Object.fromEntries(Array.from({length:67},(_,i)=>['invoice-'+i+'.pdf',strToU8('PDF TEST '+i)]));
 const file=new File([zipSync(entries)],'fixture-67.zip');let calls=0,last=[];
 const result=await readArchive(file,async pdf=>{calls++;if(pdf.name==='invoice-31.pdf')throw Error('PDF lỗi được cô lập');return {text:'Invoice No: TEST-'+pdf.name+' Invoice Date: 2026-11-20 Total amount due: 1000'};},rows=>{last=rows;});
 assert.equal(calls,67);assert.equal(result.length,67);assert.equal(last.length,67);assert.equal(result.filter(x=>x.row).length,66);assert.equal(result.filter(x=>x.error).length,1);assert.equal(await result[31].pdf.text(),'PDF TEST 31');
});
test('K22 ZIP không có PDF báo lỗi cụ thể',async()=>{await assert.rejects(readArchive(new File([zipSync({'note.txt':strToU8('test')})],'empty.zip'),()=>{},()=>{}),/không có PDF/);});
test('K23 đọc riêng PDF lỗi để thử lại không cần chạy lại cả ZIP',async()=>{let calls=0;const input=new File([zipSync({'ok.pdf':strToU8('ok'),'bad.pdf':strToU8('bad')})],'retry.zip');const rows=await readArchive(input,async pdf=>{if(pdf.name==='bad.pdf')throw Error('OCR tạm lỗi');return {text:'invoice'};},()=>{});const failed=rows.filter(x=>x.error);assert.equal(failed.length,1);for(const item of failed){calls++;assert.equal(await item.pdf.text(),'bad');}assert.equal(calls,1);});
