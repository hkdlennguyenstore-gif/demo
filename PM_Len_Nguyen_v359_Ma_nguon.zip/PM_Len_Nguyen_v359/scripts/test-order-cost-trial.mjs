import ts from 'typescript';
import fs from 'node:fs';
const moduleURL=code=>'data:text/javascript;base64,'+Buffer.from(ts.transpileModule(code,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText).toString('base64');
const dates=moduleURL(fs.readFileSync('lib/date-range.ts','utf8'));
const calc=moduleURL(fs.readFileSync('lib/order-cost-trial.ts','utf8').replace("'./date-range'",JSON.stringify(dates)));
await import(moduleURL(fs.readFileSync('lib/order-cost-trial.test.ts','utf8').replace("'./order-cost-trial'",JSON.stringify(calc))));
