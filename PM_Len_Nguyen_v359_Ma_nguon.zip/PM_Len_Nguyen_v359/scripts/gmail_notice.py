"""Read facts explicitly printed in supplier notification emails. Never infer a missing total."""
from datetime import datetime
from email.utils import parseaddr
import re
import unicodedata


def _fold(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s.lower()) if not unicodedata.combining(c)).replace('đ','d')


def _dmarc_aligned(msg, sender):
    # Only the top receiver-authentication result may establish provenance.
    results = msg.get_all('Authentication-Results', [])
    if not results:
        return False
    ar = str(results[0])
    match = re.search(r'\bdmarc=pass\b[^;]*\bheader\.from=([^;\s]+)', ar, re.I)
    return ar.split(';', 1)[0].strip().lower() == 'mx.google.com' and bool(match and match[1].lower() == sender)


def _read_line(body, label):
    # Retain spelling of the source value, permit labels and values split across MIME text lines.
    lines = [l.strip() for l in body.splitlines() if l.strip()]
    pattern = re.compile(r'^\s*(?:-\s*)?' + label + r'\s*:\s*(.*)$')
    for i, line in enumerate(lines):
        match = pattern.match(_fold(line))
        if match:
            tail = line.split(':', 1)[1].strip()
            return tail or (lines[i+1] if i+1 < len(lines) else '')
    return ''


def _day(v):
    for pattern in ('%d/%m/%Y','%Y-%m-%d'):
        try:
            return datetime.strptime(v.strip(), pattern).date().isoformat()
        except ValueError:
            continue
    return ''


def _vnd(v, unit_explicit=False):
    s = v.strip()
    m = re.fullmatch(r'(\d{1,3}(?:[,.]\d{3})+|\d+)(?:\s+(VND|VNĐ))?', s, re.I)
    if not m or not (m[2] or unit_explicit) or (',' in m[1] and '.' in m[1]):
        return ''
    return m[1].replace(',','').replace('.','')


def extract_notice(msg, body):
    address = parseaddr(str(msg['From'] or ''))[1].lower()
    domain = address.rpartition('@')[2]
    if not _dmarc_aligned(msg, domain):
        return None
    sub = str(msg.get('Subject', '')); subject = _fold(sub)
    vendor = buyer = ref = series = when = vt = bt = total = period = text = tax = ''
    printed = ''
    currency = ''
    if domain == 'mailer.shopee.com' and 'hoa don phi dich vu' in subject:
        vendor='SHOPEE'; buyer=_read_line(body,'ten don vi'); bt=_read_line(body,'ma so thue')
        ref=_read_line(body,'so hoa don'); series=_read_line(body,'ky hieu hoa don'); when=_day(_read_line(body,'ngay hoa don'))
        printed=_read_line(body,r'gia tri bao gom thue gtgt \(vnd\)');total=_vnd(printed,True);currency='VND'
        pm=re.search(r'thang (\d{1,2})/(20\d\d)',subject)
        if pm and 1<=int(pm[1])<=12: period=f'{pm[2]}-{int(pm[1]):02d}'
        shop=re.search(r'_(\d{5,})\s*$',sub)
        text='Phí nền tảng Shopee'+(' '+shop[1] if shop else '')+(' tháng '+pm[1]+'/'+pm[2] if period else '')
    elif domain == 'meinvoice.vn' and 'gui hoa don dien tu so' in subject:
        rv=re.match(r'^(.*?)\s+gửi\s+h[oóò]a\s+đơn',sub,re.I)
        bv=re.search(r'^Kính gửi:\s*Quý khách\s+([^\r\n]+)',body,re.M|re.I)
        if rv:vendor=rv[1].strip()
        if bv:buyer=bv[1].strip()
        ref=_read_line(body,'so');series=_read_line(body,'ky hieu');when=_day(_read_line(body,'ngay'))
        # Cross-check the number in the subject before treating this as a parsed notice.
        if not ref or not re.search(r'\b'+re.escape(ref)+r'\b',sub):return None
    elif domain == 'pancake.vn' and 'phat hanh hoa don dien tu so' in subject:
        vendor=re.split(r' phát hành hóa đơn điện tử',sub,flags=re.I)[0].split('việc ')[-1].strip()
        buyer=_read_line(body,'kinh gui');bt=_read_line(body,'ma so thue');ref=_read_line(body,'so')
        series=_read_line(body,'ky hieu');when=_day(_read_line(body,'ngay'))
        vat=re.search(re.escape(vendor)+r'\s*[–-]\s*MST:\s*(\d{10}(?:-\d{3}|\d{2,3})?)(?!\d)',body,re.I)
        if vat:vt=vat[1]
    elif domain in ('softdreams.vn','easyinvoice.vn') and 'hoa don dien tu so' in subject:
        v=re.search(r'(?:^|\n)([^\n,]{2,160}),\s*Mã số thuế\s*:?\s*(\d{10}(?:-\d{3}|\d{2,3})?)(?!\d)\s+xin trân trọng',body,re.I)
        b=re.search(r'vừa phát hành hóa đơn điện tử đến Quý khách ([^,\r\n]+),\s*Mã số thuế\s*:?\s*(\d{10}(?:-\d{3}|\d{2,3})?)(?!\d)',body,re.I)
        if v:vendor,vt=v.groups()
        if b:buyer,bt=b.groups()
        ref=_read_line(body,'so hoa don');series=_read_line(body,'ky hieu mau so hoa don') or _read_line(body,'ky hieu')
        when=_day(_read_line(body,'ngay hoa don'));printed=_read_line(body,'tong tien thanh toan')
        if _vnd(printed):currency='VND'
        total=_vnd(printed,True);tax=_vnd(_read_line(body,'tien thue'),True)
    elif domain == 'hq.jtexpress.vn' and subject.startswith('thuan phong:') and 'hoa don dien tu' in subject:
        v=re.search(r'(CÔNG TY [^\r\n]+?)\s+xin gửi cho',body,re.I)
        b=re.search(r'Kính gửi\s*\(Dear\)\s*:\s*([^\r\n]+)',body,re.I)
        if v:vendor=v[1].strip()
        if b:buyer=b[1].strip()
        rn=re.search(r'\(Invoice Number\)\s*:\s*(\d+)',body,re.I)
        sn=re.search(r'\(Serial Number\)\s*:\s*([A-Z0-9]+)',body,re.I)
        if rn:ref=rn[1]
        if sn:series=sn[1]
        text='Phí vận chuyển · thông báo phát hành hóa đơn J&T'
    else:
        return None
    if not vendor or not re.fullmatch(r'[0-9]{1,22}',ref) or not re.fullmatch(r'[A-Za-z0-9/.-]{1,24}',series):
        return None
    result=dict(vendor=vendor,vendorTaxId=vt,buyerName=buyer,buyerTaxId=bt,number=ref,series=series,date=when,
                currency=currency if total else '',descriptions=[text] if text else [])
    if total:result['total']=total
    facts=dict(kind='invoice_notice',authenticatedDomain=domain,source='Nội dung thư phát hành hóa đơn',issuer=vendor,reference=ref,printedDate=when,
               serviceMonth=period,printedTotal=printed or None,printedCurrency=currency or None,printedTax=tax or None,originalDownloaded=False)
    reason='Thông báo phát hành hóa đơn. Cần đối chiếu bản gốc, dòng hàng và khoản đã có trước khi ghi chi phí'
    if not total:reason+='; thư chưa nêu tổng tiền'
    return dict(name='Thông báo phát hành hóa đơn '+ref, invoice=result, verifiedReading=facts, readIssue=reason)
