export function isSunday(value:string){return /^\d{4}-\d{2}-\d{2}$/.test(value)&&new Date(value+'T12:00:00Z').getUTCDay()===0;}
export function displayDate(value:string){if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return value||'—';const day=new Date(value+'T12:00:00Z').getUTCDay();return (day===0?'CN':'Thứ '+(day+1))+' · '+value.split('-').reverse().join('/');}
