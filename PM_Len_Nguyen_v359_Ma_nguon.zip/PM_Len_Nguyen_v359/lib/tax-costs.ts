import {operatingEligible} from './tax-cost-reassessment';
import {digest} from './a3-access';
import {type DateRange} from './date-range';
export async function readOperatingCosts(db:D1Database,range:DateRange){
 const where=["kind='expense'","status='confirmed'"],args:string[]=[];if(range.from){where.push('date>=?');args.push(range.from);}if(range.to){where.push('date<=?');args.push(range.to);}
 const result=await db.prepare('SELECT id,record,version FROM pm_finance_docs WHERE '+where.join(' AND ')+' ORDER BY id LIMIT 5001').bind(...args).all<any>();if(result.results.length>5000)throw Error('Kỳ có quá nhiều phiếu chi; cần đối soát trước khi tổng hợp thuế');
 const allRows=result.results.map(r=>({...JSON.parse(r.record),id:r.id,version:r.version})),rows=allRows.filter(r=>r.category!=='cogs'&&!r.supplierPayment),eligible=operatingEligible,sum=(a:any[])=>a.reduce((n,r)=>n+r.amount,0);return {summary:{separateCogs:sum(allRows.filter(r=>r.category==='cogs'||r.supplierPayment)),total:sum(rows),eligible:sum(rows.filter(eligible)),pending:rows.filter(r=>r.deductibility!=='ineligible'&&!eligible(r)).length,excluded:sum(rows.filter(r=>r.deductibility==='ineligible'))},snapshot:await digest(JSON.stringify(rows.map(r=>[r.id,r.version,r.amount,r.deductibility,Boolean(eligible(r))])))};
}
export function taxResult(r:any){const net=Number(r.gross||0)-Number(r.refunds||0),cost=Number(r.deductible||0),vat=Number(r.vat||0),pit=Number(r.pit||0);return {net,cost,beforeTax:net-cost,tax:vat+pit,afterTax:net-cost-vat-pit};}
