import {test} from 'node:test';
import assert from 'node:assert/strict';
import {trialOrders,orderCostTrial,profitBeforeAds,formatTrialInput,projectTrial} from './order-cost-trial';
const query='from=2026-11-20&to=2026-11-20';
const report=(rows:any[])=>({range:{from:'2026-11-20',to:'2026-11-20'},orderSources:{rows}});
test('100 đơn × 20.000đ = 2.000.000đ; dùng đơn chốt, không dùng tổng đơn hoặc sản phẩm',()=>{const scope=trialOrders(query,report([{id:'facebook',ready:true,orders:400,quantity:999,confirmed:100}]),'facebook');assert.equal(scope?.count,100);assert.deepEqual(orderCostTrial('20.000',scope!.count),{kind:'ready',unit:20000,total:2000000});});
test('để trống không thành số 0',()=>{assert.equal(orderCostTrial('',100).kind,'blank');assert.equal(orderCostTrial('  ',100).kind,'blank');});
test('thiếu count, shop, nguồn chưa sẵn sàng đều chưa đủ dữ liệu',()=>{for(const row of [{id:'facebook',ready:true,confirmed:null},{id:'facebook',ready:false,confirmed:100},{id:'tiktok1',ready:true,confirmed:100}])assert.equal(trialOrders(query,report([row]),'facebook')?.count,null);assert.equal(orderCostTrial('20000',null).kind,'missing');});
test('đổi ngày không dùng bản đọc cũ, không tính cho khoảng nhiều ngày',()=>{assert.equal(trialOrders('from=2026-11-21&to=2026-11-21',report([{id:'facebook',ready:true,confirmed:100}]),'facebook')?.count,null);assert.equal(trialOrders('from=2026-11-01&to=2026-11-30',report([]),'facebook'),null);});
test('TikTok 2 dùng tổng đơn POS, kể cả đơn hủy, trong cả dự tính riêng và tổng',()=>{
 const data=report(['facebook','tiktok1','tiktok2','shopee'].map((id,i)=>({id,ready:true,confirmed:id==='tiktok2'?109:i+1,orders:id==='tiktok2'?122:400})));
 const count=trialOrders(query,data,'tiktok2')?.count;
 assert.equal(count,122);
 assert.equal(orderCostTrial('26.500',count!).total,3233000);
 assert.equal(trialOrders(query,data,'all')?.count,129);
 assert.equal(trialOrders(query,report([{id:'tiktok2',ready:true,confirmed:109}]),'tiktok2')?.count,null);
 data.orderSources.rows.pop();
 assert.equal(trialOrders(query,data,'all')?.count,null);
});
test('0 đơn có căn cứ tính được 0, không nhầm thiếu với 0',()=>{assert.equal(orderCostTrial('20000',trialOrders(query,report([{id:'facebook',ready:true,confirmed:0}]),'facebook')!.count).total,0);assert.equal(orderCostTrial('20000',null).total,undefined);});
test('không sửa số liệu nguồn, Ads, tổng chính thức',()=>{const data=report([{id:'facebook',ready:true,confirmed:100}]) as any;data.costs={facebook:{ads:12345}};const before=JSON.stringify(data);Object.freeze(data.costs.facebook);Object.freeze(data.orderSources.rows[0]);for(const raw of ['20000','30000','','bad'])orderCostTrial(raw,trialOrders(query,data,'facebook')!.count);assert.equal(JSON.stringify(data),before);});
test('tiền âm, sai định dạng và vượt số nguyên an toàn bị chặn',()=>{for(const raw of ['-1','2.5','abc','9e9','9007199254740992'])assert.equal(orderCostTrial(raw,100).kind,'invalid');assert.equal(orderCostTrial('9007199254740991',100).kind,'invalid');});
test('không dùng tổng đơn chưa phân trạng thái làm đơn chốt',()=>{const data={range:{from:'2026-11-20',to:'2026-11-20'},orders:{results:[{channel:'facebook',orders:2,quantity:15}]}};assert.equal(trialOrders(query,data,'facebook')?.count,null);});
test('lãi đã trừ Ads: hoàn lại đúng một lần trước QC tạm',()=>{const before=profitBeforeAds(4000000,1000000);assert.equal(before,5000000);const qc=orderCostTrial('20000',100);assert.equal(before!-qc.total!,3000000);});
test('Ads chưa tách được không suy bằng 0 và không tính lãi sau QC',()=>{for(const ads of [null,undefined,'1000000',NaN])assert.equal(profitBeforeAds(4000000,ads),null);assert.equal(orderCostTrial('20000',100).total,2000000);assert.equal(profitBeforeAds(5000000,0),5000000);});
test('giữ lãi âm và không cộng dồn khi thay số nhập',()=>{const base=profitBeforeAds(4000000,1000000)!;assert.equal(base-orderCostTrial('20000',100).total!,3000000);assert.equal(base-orderCostTrial('60000',100).total!,-1000000);});

test('Ads chưa được trừ khỏi lãi: dùng đúng lãi hiển thị, không gán Ads thiếu thành 0',()=>{const before=profitBeforeAds(3438131,null,false);assert.equal(before,3438131);assert.equal(before!-orderCostTrial('27.500',97).total!,770631);assert.equal(profitBeforeAds(3438131,null,true),null);assert.equal(profitBeforeAds(null,null,false),null);});
test('định dạng tiền nhập có dấu chấm, giữ trống và không làm hợp lệ tiền sai',()=>{assert.equal(formatTrialInput('27500'),'27.500');assert.equal(formatTrialInput('27.500'),'27.500');assert.equal(formatTrialInput('1000000'),'1.000.000');assert.equal(formatTrialInput(''),'');assert.equal(formatTrialInput('-1'),'-1');assert.equal(formatTrialInput('2.7500'),'27.500');});

test('tổng lãi và chi phí khớp từng shop trong ca 6.053.213đ',()=>{
 const rows=[projectTrial('',85,2148557,6191443,4386243),projectTrial('27.500',102,3634451,7906169,null),projectTrial('',0,0,0,null),projectTrial('50.000',5,270205,42705,null)];
 assert.equal(rows.reduce((s,r)=>s+r.profit!,0),2998213);assert.equal(rows.reduce((s,r)=>s+r.expense!,0),17195317);
 assert.equal(rows[1].expense,10711169);assert.equal(rows[1].profit,829451);
});
test('QC tạm thay Ads đã có cho cả chi phí và lãi, không cộng hai lần',()=>{const r=projectTrial('20000',100,4000000,3000000,1000000);assert.equal(r.profit,3000000);assert.equal(r.expense,4000000);assert.equal(r.profit!+r.expense!,7000000);});
test('xóa QC hoàn lại đúng các tổng ban đầu',()=>{const r=projectTrial('',102,3634451,7906169,null);assert.equal(r.active,false);assert.equal(r.profit,3634451);assert.equal(r.expense,7906169);});
test('thiếu số đơn hoặc tiền sai làm dự tính chưa đủ dữ liệu',()=>{for(const [raw,count] of [['20000',null],['bad',100]] as const){const r=projectTrial(raw,count,4000000,3000000,null);assert.equal(r.profit,null);assert.equal(r.expense,null);}assert.equal(projectTrial('20000',100,null,null,null).profit,null);assert.equal(projectTrial('20000',100,null,null,null).expense,null);});
test('0 đơn có căn cứ vẫn khớp, lãi âm không bị ép về 0',()=>{assert.equal(projectTrial('20000',0,0,0,null).profit,0);assert.equal(projectTrial('60000',100,4000000,3000000,1000000).profit,-1000000);});
