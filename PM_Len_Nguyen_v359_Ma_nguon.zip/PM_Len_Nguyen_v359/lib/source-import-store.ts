import {preparePurchasing,insertDoc} from './purchasing-store.ts';
import {prepareStock} from './stock-store.ts';
import type {StockReceipt} from './stock.ts';
import type {Purchase,Payment,Supplier} from './purchasing.ts';
export const SOURCE_RUN='ln-source-import-20261116-v1';
export const SOURCE_IDS={stock:'1e5FyG3UP4eLN06wBkVQ_GzcSKDJ5Oxq5_FNPrrdpbvE',prices:'1Lg1Vq-KTo3xH1cnRs15ilXICoRYV0oA6QM4CK_Lksik',debt:'1Bc-90hlX2onIyb3lmAW7BLA92DY3Ww3cE5OCJ_blaeM'};
const initialized=new WeakMap<object,Promise<void>>();
export async function prepareImport(db:D1Database){let pending=initialized.get(db);if(pending){await pending;return;}pending=prepareImportTables(db);initialized.set(db,pending);pending.catch(()=>initialized.delete(db));await pending;}
async function prepareImportTables(db:D1Database){await preparePurchasing(db);await prepareStock(db);await db.batch([
db.prepare('CREATE TABLE IF NOT EXISTS pm_source_imports(id TEXT PRIMARY KEY,status TEXT NOT NULL,manifest TEXT NOT NULL,report TEXT)'),
db.prepare('CREATE TABLE IF NOT EXISTS pm_source_items(id TEXT PRIMARY KEY,run_id TEXT NOT NULL,kind TEXT NOT NULL,record TEXT NOT NULL)'),
db.prepare('CREATE INDEX IF NOT EXISTS pm_source_items_kind ON pm_source_items(run_id,kind)'),
db.prepare('CREATE TABLE IF NOT EXISTS pm_price_history(id TEXT PRIMARY KEY,sku TEXT NOT NULL,date TEXT NOT NULL,price INTEGER NOT NULL,record TEXT NOT NULL)'),
db.prepare('CREATE INDEX IF NOT EXISTS pm_price_sku_date ON pm_price_history(sku,date)'),
db.prepare('CREATE TABLE IF NOT EXISTS pm_source_debt(id TEXT PRIMARY KEY,supplier TEXT NOT NULL,month TEXT NOT NULL,record TEXT NOT NULL)'),
db.prepare('CREATE TABLE IF NOT EXISTS pm_source_issues(id TEXT PRIMARY KEY,kind TEXT NOT NULL,record TEXT NOT NULL)')]);}
export async function importRecords(db:D1Database,kind:string,rows:any[]){const existing=(await db.prepare('SELECT id FROM pm_source_items WHERE run_id=? AND kind=?').bind(SOURCE_RUN,kind).all<{id:string}>()).results;const seen=new Set(existing.map(r=>r.id));let inserted=0,skipped=0;const statements:D1PreparedStatement[]=[];
for(const row of rows){if(!row.id||seen.has(row.id)){skipped++;continue;}if(kind==='supplier'){const s=row.value as Supplier;const old=await db.prepare('SELECT id,record FROM pm_purchase_suppliers WHERE lower(name)=lower(?)').bind(s.name).first<{id:string,record:string}>();if(old&&old.id!==s.id)throw Error('Nhà cung cấp đã được tạo thủ công; cần nối danh tính trước khi nhập: '+s.name);statements.push(db.prepare('INSERT INTO pm_purchase_suppliers(id,name,opening,record) VALUES(?,?,?,?)').bind(s.id,s.name,s.opening,JSON.stringify(s)));}
else if(kind==='price'){const r=row.value;statements.push(db.prepare('INSERT INTO pm_price_history(id,sku,date,price,record) VALUES(?,?,?,?,?)').bind(row.id,r.code,r.date||'',r.price,JSON.stringify(r)));}
else if(kind==='stock'){const r=row.value as StockReceipt,p=row.purchase as Purchase|null;const quantity=r.lines.reduce((n,l)=>n+l.quantity,0);statements.push(db.prepare('INSERT INTO pm_stock_receipts(id,date,time,source,quantity,version,actor_email,purchase_id,record) VALUES(?,?,?,?,?,0,?,?,?)').bind(r.id,r.date,r.time,r.source,quantity,'source-import',p?.id||null,JSON.stringify(r)));if(p)statements.push(insertDoc(db,p,'purchase',p.lines.reduce((n,l)=>n+l.quantity*l.price,0)-p.discount+p.extra));for(const l of r.lines)statements.push(db.prepare('INSERT OR IGNORE INTO pm_stock_catalog(code) VALUES(?)').bind(l.existingCode||l.newCode.toUpperCase()));}
else if(kind==='payment'){const p=row.value as Payment;statements.push(insertDoc(db,p,'payment',p.amount));}
else if(kind==='adjustment'){const r=row.value;statements.push(db.prepare('INSERT INTO pm_purchase_docs(id,supplier,date,kind,number,total,record) VALUES(?,?,?,\'adjustment\',?,?,?)').bind(row.id,r.supplier,r.date,r.number,r.amount,JSON.stringify(r)));}
else if(kind==='debt'){const r=row.value;statements.push(db.prepare('INSERT INTO pm_source_debt(id,supplier,month,record) VALUES(?,?,?,?)').bind(row.id,r.supplier,r.month,JSON.stringify(r)));}
else if(kind==='issue')statements.push(db.prepare('INSERT INTO pm_source_issues(id,kind,record) VALUES(?,?,?)').bind(row.id,'warehouse',JSON.stringify(row.value)));
else throw Error('Loại dữ liệu không hợp lệ');statements.push(db.prepare('INSERT INTO pm_source_items(id,run_id,kind,record) VALUES(?,?,?,?)').bind(row.id,SOURCE_RUN,kind,JSON.stringify(row)));inserted++;seen.add(row.id);}
if(statements.length)await db.batch(statements);return {inserted,skipped};}
export async function verifyImport(db:D1Database){const counts=(await db.prepare('SELECT kind,COUNT(*) AS n FROM pm_source_items WHERE run_id=? GROUP BY kind').bind(SOURCE_RUN).all<{kind:string,n:number}>()).results;const suppliers=(await db.prepare('SELECT id,name,opening,imported,paid,adjustment,opening+imported+adjustment-paid AS balance FROM pm_purchase_suppliers ORDER BY name').all()).results;const quantities=(await db.prepare('SELECT source,SUM(quantity) AS quantity,COUNT(*) AS rows FROM pm_stock_receipts WHERE actor_email=? GROUP BY source').bind('source-import').all()).results;return {counts,suppliers,quantities};}
