import type {Employee,State} from './payroll.ts';
export const HOLIDAY_START='2026-11-17';
export const holidayToday=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
export function holidayCalendar(year:number){return [{date:year+'-01-01',name:'Tết Dương lịch'},{date:year+'-04-30',name:'Ngày Chiến thắng'},{date:year+'-05-01',name:'Quốc tế Lao động'},{date:year+'-09-02',name:'Quốc khánh · 02/09'},{date:year+'-11-24',name:'Ngày Văn hóa Việt Nam'},...({'2026':'2026-04-26','2027':'2027-04-16'}[String(year)]?[{date:({'2026':'2026-04-26','2027':'2027-04-16'} as Record<string,string>)[String(year)],name:'Giỗ Tổ Hùng Vương'}]:[])].filter(d=>d.date>=HOLIDAY_START).sort((a,b)=>a.date.localeCompare(b.date));}
export function employeeHolidays(s:State,e:Employee,month:string,asOf=holidayToday()){
 const starts=[...(e.rates||[]).filter(r=>r.salary>0).map(r=>r.effectiveMonth+'-01'),...s.clocks.filter(c=>c.employee===e.id).map(c=>c.date),...(e.contracts||[]).map(c=>c.start)].filter(Boolean).sort();
 const start=starts[0];if(!start)return [];
 const clocks=s.clocks.filter(c=>c.employee===e.id).map(c=>c.date).sort(),last=clocks.at(-1)||'';
 const contracts=e.contracts||[];
 return holidayCalendar(Number(month.slice(0,4))).filter(d=>d.date.startsWith(month)&&d.date<=asOf&&d.date>=start&&(e.active||Boolean(last&&d.date<=last))&&(!contracts.length||contracts.some(c=>c.start<=d.date&&(!c.end||c.end>=d.date))));
}
export const HOLIDAY_NOTE='Tự tính từ 17/11/2026, không hồi tố. Không tự cộng Tết Âm lịch. Quốc khánh tự cộng 02/09; ngày liền kề chờ xác nhận. Giỗ Tổ đã xác minh lịch 2026–2027; năm sau cần cập nhật lịch. Nghỉ bù chờ lịch nghỉ hằng tuần của từng nhân viên.';
