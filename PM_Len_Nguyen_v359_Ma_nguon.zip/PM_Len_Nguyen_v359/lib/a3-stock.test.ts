import test from 'node:test';
import assert from 'node:assert/strict';
import {stockTone,a3StockRows} from './a3-stock.ts';
import {calculateStockOverview} from './stock-overview-math.ts';
test('Every stock threshold including 10 has exactly one colour',()=>{
 for(const [n,tone] of [[null,'retired'],[0,'empty'],[1,'low'],[9,'low'],[10,'low'],[11,'medium'],[20,'medium'],[21,'high'],[500,'high']] as const)assert.equal(stockTone(n),tone);
});
test('A3 retains confirmed zeros without changing the stock overview default',()=>{
 const args:any=[[],[],[{id:'sold',product:{custom_id:'D1'},sell_export:-10,return_import:0}],[],{from:'2026-11-12',to:'2026-11-21'},true,{date:'2026-11-11',coverageComplete:true,rows:[{code:'D1',quantity:10}]}];
 const ordinary=calculateStockOverview(...args as Parameters<typeof calculateStockOverview>);assert.equal(ordinary.rows.length,0);
 const all=calculateStockOverview(...[...args,true] as Parameters<typeof calculateStockOverview>);assert.equal(all.rows[0].remaining,0);assert.deepEqual(all.cumulative,ordinary.cumulative);
});
test('Codes without quantity are old and follow live codes and confirmed empty codes',()=>{
 const prices=[{id:'0',code:'ZERO',date:'2026-11-21',quantity:100},{id:'1',code:'UNKNOWN',quantity:0},{id:'2',code:'LIVE',date:'2020-01-01',quantity:0}];
 const result=a3StockRows(prices,{rows:[{code:'ZERO',remaining:0},{code:'LIVE',remaining:10}],provisional:true});assert.deepEqual(result.map(r=>r.code),['LIVE','ZERO','UNKNOWN']);assert.equal(result[2].remaining,null);assert.equal(result[2].stockTone,'retired');assert.ok(a3StockRows(prices,null).every(r=>r.remaining===null));
});
