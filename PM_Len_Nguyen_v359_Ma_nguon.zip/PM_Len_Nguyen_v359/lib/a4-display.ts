// Display rules from the approved A4 design. Never mutate A3 or POS values.
export function a4Size(value:unknown):string {
 const text=String(value??'').normalize('NFC').trim();
 // POS labels may include a bullet and weight guidance, sometimes without
 // the closing parenthesis. Those describe the same size, not extra columns.
 const match=text.match(/^(?:[-–—•]\s*)?(?:size\s*[:.\-]?\s*)?(\d{2})(?:\s*\(\s*\d+(?:[.,]\d+)?\s*[-–—]\s*\d+(?:[.,]\d+)?\s*kg\s*\)?)?$/i);
 return match?match[1]:text;
}
export function a4ReadPrice(value:unknown):number|null {
 const n=typeof value==='number'?value:NaN;
 return Number.isFinite(n)&&n>=0?n:null;
}
export function a4MarketingPrice(value:number|null):number|null {
 if(value===null||value<=0)return null;
 return value<9000?value:Math.round((value+1000)/10000)*10000-1000;
}
export function a4Prices(row:any){
 const calculated=row?.calculatedPending?[]:row?.calculated||[];
 const column=(letter:string)=>a4ReadPrice(calculated[letter.charCodeAt(0)-71]);
 const cost=a4ReadPrice(row?.price),facebookBase=a4ReadPrice(row?.fbPrice);
 const ceil=(n:number)=>Math.ceil((n-1e-8)/1000)*1000;
 const hoa=cost===null?null:cost*1.3+3000,fifty=hoa===null?null:hoa+50000,qc=fifty===null?null:fifty*1.03;
 const quote=column('L')===null?null:column('L')!+7000;
 const facebook=column('G')??(facebookBase===null?null:facebookBase+60000);
 return {facebook,facebookBase,enteredCost:cost,listing:column('R'),quote,readLive:a4MarketingPrice(quote),liveLS:column('S'),hoa:hoa===null?null:ceil(hoa),fifty:fifty===null?null:ceil(fifty),qc:qc===null?null:ceil(qc),
  ...Object.fromEntries([9,20,30,35,40,50].map(n=>['vc'+n,qc===null?null:ceil(qc+n*1000)]))};
}
// A small arithmetic parser, shared with the approved browser-only calculator.
export function a4Calculate(expression:string):number {
 const text=expression.trim().replace(/×|[xX]/g,'*').replace(/÷/g,'/').replace(/[−–]/g,'-');
 if(!text||text.length>200)throw Error('Nhập phép tính');
 const tokens:(number|string)[]=[];let pos=0;
 while(pos<text.length){if(/\s/.test(text[pos])){pos++;continue;}const m=text.slice(pos).match(/^(?:\d{1,3}(?:\.\d{3})+(?:,\d+)?|\d+(?:[.,]\d+)?|[.,]\d+)/);if(m){const raw=m[0],grouped=/^\d{1,3}(?:\.\d{3})+(?:,\d+)?$/.test(raw),n=Number(grouped?raw.replace(/\./g,'').replace(',','.'):raw.replace(',','.'));if(!Number.isFinite(n))throw Error('Số không hợp lệ');tokens.push(n);pos+=raw.length;}else if('+-*/()%'.includes(text[pos]))tokens.push(text[pos++]);else throw Error('Phép tính không hợp lệ');}
 let i=0;
 function primary():number {let result:number;if(tokens[i]==='+'||tokens[i]==='-'){const sign=tokens[i++];result=primary()*(sign==='-'?-1:1);}else if(tokens[i]==='('){i++;result=addition();if(tokens[i++]!==')')throw Error('Kiểm tra dấu ngoặc');}else if(typeof tokens[i]==='number')result=tokens[i++] as number;else throw Error('Phép tính chưa đầy đủ');while(tokens[i]==='%'){i++;result/=100;}return result;}
 function multiply():number {let result=primary();while(tokens[i]==='*'||tokens[i]==='/'){const op=tokens[i++],value=primary();if(op==='/'&&value===0)throw Error('Không chia được cho 0');result=op==='*'?result*value:result/value;}return result;}
 function addition():number {let result=multiply();while(tokens[i]==='+'||tokens[i]==='-'){const op=tokens[i++],value=multiply();result=op==='+'?result+value:result-value;}return result;}
 const result=addition();if(i!==tokens.length||!Number.isFinite(result))throw Error('Phép tính không hợp lệ');return Object.is(result,-0)?0:result;
}
