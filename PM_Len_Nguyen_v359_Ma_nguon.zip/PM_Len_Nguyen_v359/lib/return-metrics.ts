export const returnMetrics = [
 ['expected','Đối chứng'], ['received','Đã về kho'], ['matched','Đã khớp'],
 ['exactMatched','Khớp đối chứng'], ['autoMatched','Khớp sau 30 ngày'],
 ['awaiting','Chưa quét về'], ['receivedOnly','Về kho, chờ đối chứng'],
] as const;
export type ReturnMetric = typeof returnMetrics[number][0];
export function matchesReturnMetric(row:any, metric:string):boolean {
 switch(metric){
  case 'expected':return Boolean(row.expected);
  case 'received':return Boolean(row.receipt);
  case 'matched':return Boolean(row.reconciliation.matched);
  case 'exactMatched':return Boolean(row.reconciliation.exact);
  case 'autoMatched':return Boolean(row.reconciliation.auto30);
  case 'awaiting':return row.reconciliation.status==='awaiting';
  case 'receivedOnly':return row.reconciliation.status==='received_only';
  default:return false;
 }
}
export function summarizeReturnRows(rows:any[]){
 return {...Object.fromEntries(returnMetrics.map(([key])=>[key,rows.filter(r=>matchesReturnMetric(r,key)).length])),total:rows.length,partial:rows.filter(r=>r.tracking.endsWith('-001')).length} as Record<ReturnMetric,number>&{total:number,partial:number};
}
