import type {DateRange} from './date-range';
export function vietnamToday(now=new Date()){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);}
export const periodPresets=[['today','Hôm nay'],['week','7 ngày'],['month','Tháng này'],['previous','Tháng trước'],['quarter','Quý này'],['year','Năm nay']] as const;
export function presetRange(kind:string,day=vietnamToday()):DateRange{
 const [y,m]=day.split('-').map(Number);
 const iso=(date:Date)=>date.toISOString().slice(0,10);
 if(kind==='today')return {from:day,to:day};
 if(kind==='week'){const start=new Date(day+'T12:00:00Z');start.setUTCDate(start.getUTCDate()-6);return {from:iso(start),to:day};}
 if(kind==='month')return {from:iso(new Date(Date.UTC(y,m-1,1))),to:iso(new Date(Date.UTC(y,m,0)))};
 if(kind==='previous')return {from:iso(new Date(Date.UTC(y,m-2,1))),to:iso(new Date(Date.UTC(y,m-1,0)))};
 if(kind==='quarter'){const first=Math.floor((m-1)/3)*3;return {from:iso(new Date(Date.UTC(y,first,1))),to:iso(new Date(Date.UTC(y,first+3,0)))};}
 if(kind==='year')return {from:y+'-01-01',to:y+'-12-31'};
 throw Error('Khoảng thời gian không hợp lệ');
}
