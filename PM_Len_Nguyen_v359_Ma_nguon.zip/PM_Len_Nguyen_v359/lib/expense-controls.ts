export type ExpenseOverride={target?:number;excluded:boolean;reason:string;actor:string;time:string};
export const overridePrefix='expense-line:';
export const sourcePrefix='expense-source:';
export async function settings<T>(db:D1Database,prefix:string):Promise<Record<string,T>>{
 const rows=await db.prepare('SELECT id,value FROM app_state WHERE id LIKE ?').bind(prefix+'%').all<{id:string,value:string}>();
 return Object.fromEntries(rows.results.map(r=>[r.id.slice(prefix.length),JSON.parse(r.value)]));
}
export function adKey(provider:string,date:string,account?:string){return ['ads',provider,date,account||''].join('|');}
export function payrollKey(id:string,part:string){return ['payroll',id,part].join('|');}
export function adjusted(raw:number,v?:ExpenseOverride){return v?.excluded?0:v?.target??raw;}
export function applyAdControls(days:any[],provider:string,controls:Record<string,ExpenseOverride>){
 return days.map(day=>{
  if(day.accounts?.length){
   const accounts=day.accounts.map((a:any)=>{
    const key=adKey(provider,day.date,a.account),control=controls[key];
    return control?{...a,original:a.amount,control,amount:adjusted(a.amount,control)}:a;
   });
   if(accounts.every((a:any)=>!a.control))return day;
   return {...day,accounts,total:accounts.reduce((n:number,a:any)=>n+a.amount,0)};
  }
  const control=controls[adKey(provider,day.date)];
  return control?{...day,original:day.total,control,total:adjusted(day.total,control)}:day;
 });
}
export async function sourceMode(db:D1Database,key:string){
 const row=await db.prepare('SELECT value FROM app_state WHERE id=?').bind(sourcePrefix+key).first<{value:string}>();
 return row?JSON.parse(row.value).mode:'active';
}
export function putSetting(db:D1Database,id:string,value:unknown){
 return db.prepare('INSERT INTO app_state(id,value,version) VALUES(?,?,0) ON CONFLICT(id) DO UPDATE SET value=excluded.value,version=app_state.version+1').bind(id,JSON.stringify(value));
}
