import test from 'node:test';
import assert from 'node:assert/strict';
import {createAttendanceViewEpoch,sameAttendanceEmployee} from './attendance-view-epoch';

test('late A scope is ignored after revocation and B fresh scope can be used',async()=>{
 const gate=createAttendanceViewEpoch(),a=gate.begin();
 let release!:()=>void,shown='';
 const aBody=new Promise<void>(resolve=>{release=resolve;});
 const old=(async()=>{await aBody;if(a.current())shown='SAMPLE-A';})();
 gate.revoke();
 assert.equal(a.signal.aborted,true);
 const b=gate.begin();
 if(b.current())shown='SAMPLE-B';
 release();await old;
 assert.equal(shown,'SAMPLE-B');
 assert.equal(b.signal.aborted,false);
});

test('new month read aborts older read and page departure revokes pending action',()=>{
 const gate=createAttendanceViewEpoch(),old=gate.begin(),fresh=gate.begin();
 assert.equal(old.current(),false);assert.equal(old.signal.aborted,true);
 assert.equal(fresh.current(),true);
 gate.revoke();
 assert.equal(fresh.current(),false);assert.equal(fresh.signal.aborted,true);
});

test('write preflight only matches an authenticated same-employee, non-admin view',()=>{
 assert.equal(sameAttendanceEmployee('SAMPLE-A',{admin:false,me:{id:'SAMPLE-A'}}),true);
 for(const state of [{admin:false,me:{id:'SAMPLE-B'}},{admin:true,me:{id:'SAMPLE-A'}},{admin:false,me:null},{}])
  assert.equal(sameAttendanceEmployee('SAMPLE-A',state),false);
});

test('kiosk employee A delayed response cannot render after terminal chooses B or hides page',async()=>{
 const epoch=createAttendanceViewEpoch();let release!:()=>void;
 const first=epoch.begin(),visible:string[]=[];
 const late=new Promise<void>(r=>{release=r}).then(()=>{if(first.current())visible.push('a');});
 const second=epoch.begin();if(second.current())visible.push('b');
 release();await late;assert.deepEqual(visible,['b']);assert.equal(first.signal.aborted,true);
 epoch.revoke();assert.equal(second.current(),false);
});
