import {availableInvoices} from './payment-invoices';
import {validateFinance} from './finance';
import {digest} from './a3-access';
import {putSetting} from './expense-controls';
import {text,type Payment,type Supplier} from './purchasing';

export async function paymentExpense(db:D1Database,p:Payment,supplier:Supplier,input:any,actor:string,hash:string){
 const invoiceId=text(input.invoiceId,160), invoiceValid=input.invoiceValid==='on', eligible=input.expenseValid==='on';
 const include=input.bookExpense==='on';
 let invoiceNumber=text(input.invoiceNumber,100);
 const allocations:{id:string;number:string;amount:number}[]=[];
 const requested=input.allocations??(invoiceId?[{id:invoiceId,amount:p.amount}]:[]);
 if(!Array.isArray(requested)||requested.length>500)throw Error('Danh sách hóa đơn không hợp lệ.');
 if(requested.length){
  const options=new Map((await availableInvoices(db)).map(i=>[i.id,i]));
  const seen=new Set<string>();
  for(const item of requested){
   const invoice=options.get(item?.id);
   if(!invoice||seen.has(invoice.id))throw Error('Hóa đơn đã thay đổi hoặc bị chọn trùng.');
   seen.add(invoice.id);
   if(invoice.supplier.toLocaleLowerCase('vi')!==supplier.name.toLocaleLowerCase('vi')&&input.confirmSource!=='on')throw Error('Xác nhận tên nhà cung cấp trên hóa đơn.');
   if(!Number.isSafeInteger(item.amount)||item.amount<=0||item.amount>invoice.remaining)throw Error('Số phân bổ vượt số còn lại của HĐ '+invoice.number+'.');
   allocations.push({id:invoice.id,number:invoice.number,amount:item.amount});
  }
  if(allocations.reduce((sum,a)=>sum+a.amount,0)!==p.amount)throw Error('Tổng phân bổ phải bằng số tiền thanh toán.');
  invoiceNumber=allocations.map(a=>a.number).join(', ');
 }
 if(invoiceValid&&!invoiceNumber)throw Error('Chọn hóa đơn hoặc điền số hóa đơn đã kiểm tra.');
 if(eligible&&(!include||!invoiceValid||!p.receipt))throw Error('Chọn ghi chi phí, xác nhận hóa đơn và đính kèm chứng từ trước khi duyệt.');
 Object.assign(p,{allocations,invoiceId,invoiceNumber,invoiceValid,expenseValid:eligible});
 if(!include||!p.receipt)return [];
 const reference=text(input.transaction,120);
 if(!reference)throw Error('Điền mã giao dịch hoặc số phiếu chi để kiểm tra trùng.');
 const fingerprint=await digest('expense:'+supplier.name.toLowerCase()+':'+reference.toLowerCase());
 const existing=await db.prepare("SELECT id FROM pm_finance_docs WHERE kind='expense' AND status<>'void' AND (fingerprint=? OR json_extract(record,'$.documentHash')=? OR (lower(json_extract(record,'$.counterparty'))=lower(?) AND lower(json_extract(record,'$.reference'))=lower(?))) LIMIT 1").bind(fingerprint,hash,supplier.name,reference).first();
 if(existing)throw Error('Giao dịch đã có trong Chi phí. Kiểm tra trước khi lưu thanh toán.');
 const now=new Date().toISOString(),id='supplier-payment-'+p.id;
 const value={...validateFinance('expense',{date:p.date,amount:p.amount,paid:p.amount,channel:'shared',category:'cogs',reference,
  counterparty:supplier.name,description:'Thanh toán công nợ · '+supplier.name,note:p.note,receipt:p.receipt,
  paymentMethod:p.method==='Chuyển khoản'?'bank':'cash',deductibility:eligible?'eligible':'pending',
  deductionBasis:eligible?'Người dùng đã rà soát hóa đơn '+invoiceNumber+' và chứng từ thanh toán '+reference:''}),
  id,status:'confirmed',version:0,actor,createdAt:now,updatedAt:now,confirmedAt:now,supplierPayment:p.id,invoiceValid,allocations,invoiceId,invoiceNumber,documentHash:hash};
 Object.assign(p,{expenseId:id,transaction:reference});
 return [db.prepare('INSERT INTO pm_finance_requests SELECT ?,COUNT(*) FROM pm_finance_requests').bind(id),
  db.prepare('INSERT INTO pm_finance_docs VALUES(?,?,?,?,?,?,?,?,?)').bind(id,'expense',p.date,p.date,'shared','confirmed',JSON.stringify(value),0,fingerprint),
  db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),now,actor,'supplier-payment:expense',JSON.stringify({after:value})),
  putSetting(db,'expense-changed:'+p.date,now)];
}
