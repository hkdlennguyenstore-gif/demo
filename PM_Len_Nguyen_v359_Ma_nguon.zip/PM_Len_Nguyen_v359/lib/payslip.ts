import type {PayrollResult} from './payroll.ts';
export type Payslip={month:string,name:string,basic:number,standardDays:number,row:PayrollResult,closed:boolean,note:string,hidden?:string[]};
export const cash=(n:number)=>new Intl.NumberFormat('vi-VN',{maximumFractionDigits:0}).format(n||0)+' đ';
export function slipFields(s:Payslip){
 const r=s.row;
 return [
  {id:'basic',label:'Lương cơ bản / tháng',value:cash(s.basic)},
  {id:'days',label:'Ngày công / ngày chuẩn',value:r.days+' / '+s.standardDays},
  {id:'overtime',label:'Giờ tăng ca',value:r.overtime+' giờ'},
  {id:'base',label:'Lương theo công thực tế',value:cash(r.base)},
  {id:'otPay',label:'Lương tăng ca',value:cash(r.otPay)},
  ...((r.holidayDays||r.holidayWorkedPay)?[
   {id:'holidayPay',label:'Nghỉ lễ hưởng lương · '+(r.holidayDays||0)+' ngày',value:cash(r.holidayPay||0)},
   {id:'holidayWork',label:'Làm việc ngày lễ',value:cash(r.holidayWorkedPay||0)}]:[]),
  {id:'meal',label:'Tiền cơm',value:cash(r.meal)},
  {id:'attendance',label:'Thưởng chuyên cần',value:cash(r.attendance)},
  {id:'allowance',label:'Phụ cấp + trách nhiệm',value:cash(r.allowance+r.responsibility)},
  {id:'bonus',label:'Thưởng + thưởng đơn hàng',value:cash(r.bonus+r.orderBonus)},
  {id:'insuranceCash',label:'Khoản trả thêm thay BH',value:cash(r.insuranceCash||0)},
  {id:'deduction',label:'Khấu trừ khác',value:cash(r.deduction)},
  {id:'earned',label:'TỔNG LƯƠNG',value:cash(r.earned)},
  {id:'employeeInsurance',label:'Bảo hiểm nhân viên',value:cash(r.employeeInsurance||0)},
  {id:'advance',label:'Đã tạm ứng',value:cash(r.advance)},
  {id:'net',label:'CÒN NHẬN',value:cash(r.net)}
 ];
}
export function slipLines(s:Payslip){return slipFields(s).filter(f=>!s.hidden?.includes(f.id)).map(f=>[f.label,f.value]);}
export function slipNote(s:Payslip){return s.hidden?.includes('note')?'':s.note.trim();}
export function slipWarnings(s:Payslip){
 const r=s.row,show=(key:string)=>!s.hidden?.includes(key);
 return [!s.closed?'BẢN TẠM TÍNH · Tháng chưa chốt':'ĐÃ CHỐT BẢNG LƯƠNG',
  show('days')&&r.missing?r.missing+' dòng công thiếu giờ; chưa tính vào lương.':'',
  show('basic')&&r.salaryMissing?'Chưa có mức lương cơ bản.':'',
  show('employeeInsurance')&&!r.insuranceReady?'Bảo hiểm chưa hoàn tất rà soát; số khấu trừ hiện tại có thể thay đổi.':''].filter(Boolean);
}
export async function createPayslipPDF(s:Payslip,fontBytes:Uint8Array){const {PDFDocument,rgb}=await import('pdf-lib');const {default:fontkit}=await import('@pdf-lib/fontkit');const doc=await PDFDocument.create();doc.registerFontkit(fontkit);const font=await doc.embedFont(fontBytes,{subset:true});const p=doc.addPage([595.28,841.89]);const green=rgb(.15,.30,.23),gray=rgb(.40,.46,.41),light=rgb(.94,.97,.94);const text=(t:string,x:number,y:number,size=10,color=green)=>p.drawText(t.normalize('NFC'),{x,y,size,font,color});const wrap=(t:string,width:number,size:number)=>{const out:string[]=[];for(const raw of t.replace(/[\u0000-\u001f]/g,' ').split(' ')){const word=raw;const last=out.length-1;if(last>=0&&font.widthOfTextAtSize(out[last]+' '+word,size)<=width)out[last]+=' '+word;else if(font.widthOfTextAtSize(word,size)<=width)out.push(word);else{let part='';for(const c of word){if(font.widthOfTextAtSize(part+c,size)>width){out.push(part);part=c;}else part+=c;}out.push(part);}}return out;};
text('LÊN NGUYỄN STORE',40,791,14);text('PHIẾU LƯƠNG',40,756,24);text('THÁNG '+s.month.slice(5)+'/'+s.month.slice(0,4),40,732,11,gray);let y=703;for(const line of wrap('Nhân viên: '+s.name,510,12)){text(line,40,y,12);y-=17;}y-=6;for(const line of slipWarnings(s)){for(const t of wrap(line,510,9)){text(t,40,y,9,gray);y-=14;}}y-=12;for(const [label,value] of slipLines(s)){const emph=['TỔNG LƯƠNG','CÒN NHẬN'].includes(label);if(emph)p.drawRectangle({x:34,y:y-8,width:527,height:27,color:light});text(label,44,y,emph?11:10);text(value,548-font.widthOfTextAtSize(value,emph?12:10),y,emph?12:10);y-=27;}if(slipNote(s)){y-=8;text('Ghi chú:',40,y,10);for(const t of wrap(slipNote(s),510,9).slice(0,5)){y-=14;text(t,40,y,9,gray);}}text('Phiếu dành riêng cho nhân viên có tên trên phiếu.',40,42,8,gray);doc.setTitle('Phiếu lương '+s.name+' '+s.month);doc.setAuthor('Lên Nguyễn Store');return doc.save();}
