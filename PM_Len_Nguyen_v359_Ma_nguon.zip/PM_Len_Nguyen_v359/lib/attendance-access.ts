import {permission, type State} from './payroll';
import {attendanceMonthRange,isAttendanceStart} from './attendance-month';
import {hasLeaveOverlap,storedLeaveEnd} from './attendance-leave-range';

const kioskRoleError = 'Chỉ tài khoản chấm công dùng chung được dùng tại đây.';
export function kioskEmployee(s: State, email: string, employeeId: unknown) {
  if (permission(s,email)?.role !== 'terminal') throw Error(kioskRoleError);
  if (typeof employeeId !== 'string' || !employeeId || employeeId.length > 100) throw Error('Chọn đúng tên nhân viên đang làm việc.');
  const employee = s.employees.find(e => e.id === employeeId && e.active);
  if (!employee) throw Error('Chọn đúng tên nhân viên đang làm việc.');
  return employee;
}

export function kioskWorkWeek(now = new Date()) {
  const local = new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
  const from = new Date(local+'T00:00:00Z');
  from.setUTCDate(from.getUTCDate() - (from.getUTCDay()+6)%7);
  const to = new Date(from);to.setUTCDate(to.getUTCDate()+6);
  return {from:from.toISOString().slice(0,10),to:to.toISOString().slice(0,10)};
}

export async function readKioskSchedule(db: D1Database, s: State, email: string, employeeId: unknown, authValue: string, now = new Date()) {
  const employee = kioskEmployee(s,email,employeeId), week = kioskWorkWeek(now);
  const {results} = await db.prepare(`SELECT w.date, json_extract(w.record,'$.start') AS start, json_extract(w.record,'$.end') AS end, json_extract(w.record,'$.scheduleMode') AS scheduleMode
    FROM app_state s LEFT JOIN pm_order_schedule w ON w.employee=? AND w.date BETWEEN ? AND ?
      AND (CASE WHEN json_valid(w.record) THEN json_extract(w.record,'$.kind') ELSE NULL END)='work'
    WHERE s.id='main' AND s.value=? ORDER BY w.date LIMIT 7`)
    .bind(employee.id,week.from,week.to,authValue).all<{date:string|null;start:unknown;end:unknown;scheduleMode:unknown}>();
  if (!results.length) throw Error('Quyền đã thay đổi. Mở lại lịch làm việc.');
  const hhmm=/^([01]\d|2[0-3]):[0-5]\d$/;
  const rows=results.flatMap((r):{date:string;start:string;end:string;dayOnly?:true}[]=>{
    if(!r.date)return [];
    if(r.scheduleMode==='day')return [{date:r.date,start:isAttendanceStart(r.start)?r.start:'',end:'',dayOnly:true}];
    return typeof r.start==='string'&&typeof r.end==='string'&&hhmm.test(r.start)&&hhmm.test(r.end)&&r.start<r.end?[{date:r.date,start:r.start,end:r.end}]:[];
  });
  return {...week,rows};
}

// Identity comes only from the authenticated server session and persisted membership.
export function attendanceAccess(s: State, email: string) {
  const member = permission(s, email);
  const admin = !!member && ['owner', 'admin'].includes(member.role);
  const employee = member?.role === 'employee'
    ? s.employees.find(e => e.id === member.employee && e.active) : undefined;
  if (!admin && !employee) throw Error('Cần đăng nhập tài khoản cá nhân đã được liên kết nhân viên để xem lịch và xin nghỉ.');
  return {admin, employee};
}
// Scoped monthly read for the two staff calendars. Project only the fields they need.
export async function readAttendanceMonth(db:D1Database,s:State,email:string,month:string,authValue:string){
  const access=attendanceAccess(s,email),{from,to}=attendanceMonthRange(month);
  const scope=access.admin?'':' AND employee=?',args=access.admin?[from,to]:[from,to,access.employee!.id];
  const maxRows=2000;
  const leaveArgs=access.admin?[to,from]:[to,from,access.employee!.id];
  const [guard,work,leave,people]=await db.batch([
    db.prepare("SELECT 1 AS ok FROM app_state WHERE id='main' AND value=?").bind(authValue),
    db.prepare('SELECT id,date,employee,version,record FROM pm_order_schedule WHERE date BETWEEN ? AND ?'+scope+' ORDER BY date,employee LIMIT ?').bind(...args,maxRows+1),
    db.prepare('SELECT id,date,employee,status,record FROM pm_order_leave WHERE date<=? AND '+storedLeaveEnd+'>=?'+scope+' ORDER BY date,employee,id LIMIT ?').bind(...leaveArgs,maxRows+1),
    ...(access.admin?[db.prepare("SELECT id,name FROM pm_order_schedule_people ORDER BY rowid LIMIT 501")]:[])
  ]);
  if(!guard.results.length)throw Error('Quyền đã thay đổi. Mở lại lịch làm việc.');
  if(work.results.length>maxRows||leave.results.length>maxRows)throw Error('Tháng có quá 2.000 dòng lịch hoặc đơn nghỉ. Không hiển thị dữ liệu thiếu; nhờ quản trị viên kiểm tra.');
  const field=(record:Record<string,unknown>,key:string)=>typeof record[key]==='string'?record[key] as string:'';
  const roster=s.employees.filter(e=>e.active).map(e=>({id:e.id,name:e.name}));
  if(people&&people.results.length>500)throw Error('Danh sách xếp lịch vượt giới hạn. Nhờ quản trị viên kiểm tra.');
  const scheduleOnly=people?people.results.map(raw=>{const p=raw as {id:string;name:string};return {id:p.id,name:p.name,scheduleOnly:true as const};}):[];
  const name=(record:Record<string,unknown>,employee:string)=>field(record,'name')||s.employees.find(e=>e.id===employee)?.name||'Chưa rõ tên';
  const rows=work.results.map(raw=>{
    const r=raw as {id:string;date:string;employee:string;version:number;record:string},v=JSON.parse(r.record);
    const kind=field(v,'kind');
    if(!['work','off','leave'].includes(kind))throw Error('Có dòng lịch không hợp lệ; nhờ quản trị viên kiểm tra.');
    return {id:r.id,date:r.date,employee:r.employee,version:r.version,name:name(v,r.employee),kind,start:field(v,'start'),end:field(v,'end'),note:field(v,'note')};
  });
  const leaves=leave.results.map(raw=>{
    const r=raw as {id:string;date:string;employee:string;status:string;record:string},v=JSON.parse(r.record);
    if(!['pending','approved','rejected'].includes(r.status))throw Error('Có trạng thái đơn nghỉ không hợp lệ; nhờ quản trị viên kiểm tra.');
    return {id:r.id,date:r.date,employee:r.employee,status:r.status,name:name(v,r.employee),from:r.date,to:field(v,'to')||r.date,note:field(v,'note'),reviewNote:field(v,'reviewNote'),requireResponse:v.rangeVersion===1,...(access.admin&&['shared-clock','admin-assisted'].includes(field(v,'source'))?{source:field(v,'source')}:{})};
  });
  return {month,rows,leaves,locked:s.locked.includes(month),admin:access.admin,me:access.employee?{id:access.employee.id,name:access.employee.name}:null,employees:access.admin?[...roster,...scheduleOnly]:roster.filter(e=>e.id===access.employee!.id)};
}
export function unlockedSchedule(s: State, date: string, to=date) {
  if (s.locked.some(month=>month>=date.slice(0,7)&&month<=to.slice(0,7))) throw Error('Kỳ lương đã khóa; không thay đổi lịch hoặc đơn nghỉ.');
}
// The assertion is the first statement of the same D1 transaction as all writes.
// A failed assertion aborts the whole batch, including the audit record.
export async function attendanceBatch(db: D1Database, authValue: string, date: string, statements: D1PreparedStatement[], to=date) {
  const guard = db.prepare(`SELECT CASE WHEN EXISTS(
    SELECT 1 FROM app_state WHERE id='main' AND value=?
      AND json_type(value,'$.locked')='array'
      AND NOT EXISTS(SELECT 1 FROM json_each(value,'$.locked') WHERE value>=? AND value<=?)
    ) THEN 1 ELSE json('ATTENDANCE_CONTEXT_CHANGED') END AS allowed`).bind(authValue,date.slice(0,7),to.slice(0,7));
  try { return (await db.batch([guard,...statements])).slice(1); }
  catch (error) {
    if (String(error).includes('malformed JSON')) throw Error('Quyền hoặc kỳ lương đã thay đổi trước khi ghi. Tải lại để kiểm tra; chưa ghi thao tác này.');
    throw error;
  }
}
export async function submitOwnLeave(db: D1Database, s: State, email: string, requestId: string, x: {date:string;employee?:string;note:string}, now: string, authValue: string) {
  const access = attendanceAccess(s, email);
  if (!access.employee || (x.employee && x.employee !== access.employee.id)) throw Error('Chỉ được gửi đơn nghỉ cho chính mình bằng tài khoản cá nhân.');
  const employee = access.employee;
  const prior = await db.prepare('SELECT actor,action,record FROM pm_order_actions WHERE id=?').bind(requestId).first<{actor:string;action:string;record:string}>();
  if (prior) {
    const old = JSON.parse(prior.record);
    if (prior.actor !== email || prior.action !== 'Xin nghỉ' || old.employee !== employee.id || old.date !== x.date || old.note !== x.note) throw Error('Mã yêu cầu đã dùng cho nội dung khác.');
    return {ok:true,replayed:true};
  }
  unlockedSchedule(s, x.date);
  const value = {date:x.date,employee:employee.id,name:employee.name,note:x.note,actor:email,requestedAt:now};
  // D1 batch is transactional. Conditional insertion closes the two-tab pending check race.
  await attendanceBatch(db,authValue,x.date,[
    db.prepare("INSERT INTO pm_order_leave SELECT ?,?,?,'pending',? WHERE NOT EXISTS("+hasLeaveOverlap+") ON CONFLICT(id) DO NOTHING").bind(requestId,x.date,employee.id,JSON.stringify(value),employee.id,x.date,x.date),
    db.prepare("INSERT INTO pm_order_actions SELECT ?,?,?,'Xin nghỉ',? WHERE EXISTS(SELECT 1 FROM pm_order_leave WHERE id=? AND record=?) ON CONFLICT(id) DO NOTHING").bind(requestId,now,email,JSON.stringify(value),requestId,JSON.stringify(value))
  ]);
  const saved = await db.prepare('SELECT actor,action,record FROM pm_order_actions WHERE id=?').bind(requestId).first<{actor:string;action:string;record:string}>();
  if (!saved) throw Error('Đã có đơn nghỉ đang chờ hoặc đã duyệt cho ngày này. Tải lại để kiểm tra.');
  const v = JSON.parse(saved.record);
  if (saved.actor !== email || saved.action !== 'Xin nghỉ' || v.employee !== employee.id || v.date !== x.date || v.note !== x.note) throw Error('Mã yêu cầu đã dùng cho nội dung khác.');
  return {ok:true};
}

// A shared terminal can lodge a request, but name selection never proves identity.
export async function submitKioskLeave(db: D1Database, s: State, email: string, requestId: string, x: {date:string;employee:unknown}, now: string, authValue: string) {
  const employee = kioskEmployee(s,email,x.employee);
  const actor = email.toLowerCase(), action = 'Xin nghỉ từ máy chung';
  const readAudit = () => db.prepare('SELECT actor,action,record FROM pm_order_actions WHERE id=?').bind(requestId).first<{actor:string;action:string;record:string}>();
  const checkReplay = (saved:{actor:string;action:string;record:string}) => {
    const old = JSON.parse(saved.record);
    if (saved.actor !== actor || saved.action !== action || old.employee !== employee.id || old.date !== x.date) throw Error('Mã yêu cầu không hợp lệ.');
  };
  const prior = await readAudit();
  if (prior) { checkReplay(prior); return {ok:true}; }
  unlockedSchedule(s, x.date);
  const value = {date:x.date,employee:employee.id,name:employee.name,note:'',actor,requestedAt:now,source:'shared-clock',identityVerified:false};
  const record = JSON.stringify(value);
  await attendanceBatch(db, authValue, x.date, [
    db.prepare("INSERT INTO pm_order_leave SELECT ?,?,?,'pending',? WHERE NOT EXISTS(SELECT 1 FROM pm_order_actions WHERE id=?) AND NOT EXISTS("+hasLeaveOverlap+") ON CONFLICT(id) DO NOTHING").bind(requestId,x.date,employee.id,record,requestId,employee.id,x.date,x.date),
    db.prepare('INSERT INTO pm_order_actions SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM pm_order_leave WHERE id=? AND record=?) ON CONFLICT(id) DO NOTHING').bind(requestId,now,actor,action,record,requestId,record)
  ]);
  const saved = await readAudit();
  if (saved) checkReplay(saved);
  // A second key for a day already pending/approved gets the identical receipt:
  // the terminal must not learn whether a coworker has a previous request.
  return {ok:true};
}
