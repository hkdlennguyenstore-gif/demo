import {readDateRange} from './date-range';

export const attendanceWeekdays = ['Thứ 2','Thứ 3','Thứ 4','Thứ 5','Thứ 6','Thứ 7','Chủ nhật'] as const;
export const isAttendanceStart = (value: unknown): value is string => typeof value==='string'&&/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
export const isAttendanceMonth = (month: string) => /^20\d{2}-(0[1-9]|1[0-2])$/.test(month);
export function currentAttendanceMonth(now = new Date()) {
  const parts = new Intl.DateTimeFormat('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit'}).formatToParts(now);
  return parts.find(x=>x.type==='year')!.value+'-'+parts.find(x=>x.type==='month')!.value;
}
export function attendanceMonthRange(month: string) {
  if (!isAttendanceMonth(month)) throw Error('Tháng không hợp lệ');
  return readDateRange(new URLSearchParams({month}));
}
export function shiftAttendanceMonth(month: string, delta: -1|1) {
  const {from}=attendanceMonthRange(month);
  const date=new Date(from+'T12:00:00Z');
  date.setUTCMonth(date.getUTCMonth()+delta);
  const next=date.toISOString().slice(0,7);
  return isAttendanceMonth(next)?next:month;
}
export function attendanceMonthWeeks(month: string) {
  const {from,to}=attendanceMonthRange(month), first=new Date(from+'T12:00:00Z');
  const blanks=(first.getUTCDay()+6)%7, length=Number(to.slice(-2));
  const cells=Array.from({length:Math.ceil((blanks+length)/7)*7},(_,i)=>{
    const day=i-blanks+1;
    return day<1||day>length?null:{date:month+'-'+String(day).padStart(2,'0'),day};
  });
  return Array.from({length:cells.length/7},(_,i)=>cells.slice(i*7,i*7+7));
}
export const attendanceMonthLabel=(month:string)=>'Tháng '+Number(month.slice(-2))+'/'+month.slice(0,4);
