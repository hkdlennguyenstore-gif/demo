import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import * as access from './attendance-access';
import * as payroll from './payroll';
import * as purchasing from './purchasing';
import * as dates from './date-range';
import * as orders from './orders';
function fixture(){
 const sql=new DatabaseSync(':memory:');sql.exec('CREATE TABLE app_state(id TEXT PRIMARY KEY,value TEXT)');
 const source=readFileSync(new URL('./orders-store.ts',import.meta.url),'utf8');
 for(const table of ['pm_order_schedule','pm_order_leave','pm_order_actions']){const stmt=source.split('\n').find(line=>line.includes('CREATE TABLE IF NOT EXISTS '+table+'('))?.split("'")[1];assert.ok(stmt);sql.exec(stmt);}
 const employee=(id:string)=>({id,name:'SAMPLE '+id,active:true});
 const state:any={owner:'owner@example.invalid',members:[{email:'a@example.invalid',role:'employee',employee:'a'},{email:'b@example.invalid',role:'employee',employee:'b'},{email:'terminal@example.invalid',role:'terminal',employee:'a'},{email:'admin@example.invalid',role:'admin',employee:''}],employees:[employee('a'),employee('b')],locked:[],clocks:[],adjustments:[]};
 const persist=()=>sql.prepare('INSERT OR REPLACE INTO app_state VALUES(?,?)').run('main',JSON.stringify(state));persist();let actor:string|null='a@example.invalid';let beforeBatch:(()=>void)|null=null,afterBatch:(()=>void)|null=null;
 const DB:any={prepare(q:string){let args:any[]=[];return {bind(...v:any[]){args=v;return this;},async first(){return sql.prepare(q).get(...args)||null;},async all(){return {results:sql.prepare(q).all(...args)};},async run(){return {meta:{changes:Number(sql.prepare(q).run(...args).changes)}};}};},async batch(stmts:any[]){const before=beforeBatch;beforeBatch=null;before?.();sql.exec('BEGIN');try{const results=[];for(const s of stmts)results.push(await s.run());sql.exec('COMMIT');const after=afterBatch;afterBatch=null;after?.();return results;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 const modules:any={'cloudflare:workers':{env:{DB}},'../../chatgpt-auth':{getChatGPTUser:async()=>actor?{email:actor}:null},'../../../lib/payroll':payroll,'../../../lib/purchasing':purchasing,'../../../lib/date-range':dates,'../../../lib/orders':orders,'../../../lib/attendance-access':access,'../../../lib/orders-store':{prepareOrders:async()=>{}}};
 const code=ts.transpileModule(readFileSync(new URL('../app/api/orders/route.ts',import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,exports:any={};
 vm.runInNewContext('(function(require,exports){'+code+'})',{Response,Request,URL,crypto})((id:string)=>modules[id]||{},exports);
 const get=async(query='tab=schedule&month=2026-11')=>{const r=await exports.GET(new Request('https://sample.invalid/api/orders?'+query));return {status:r.status,body:await r.json() as any};};
 const post=async(action:string,data:any,id=crypto.randomUUID(),origin='https://sample.invalid')=>{const r=await exports.POST(new Request('https://sample.invalid/api/orders',{method:'POST',headers:{origin},body:JSON.stringify({action,data,requestId:id})}));return {status:r.status,body:await r.json() as any};};
 const count=()=>Number(sql.prepare('SELECT count(*) n FROM pm_order_leave').get()!.n);
 return {sql,state,persist,get,post,count,beforeBatch:(fn:()=>void)=>{beforeBatch=fn;},afterBatch:(fn:()=>void)=>{afterBatch=fn;},actor:(a:string|null)=>{actor=a;}};
}
test('legacy schedules readable; employee sees only own rows, leave reasons and selector',async()=>{const h=fixture();try{for(const id of ['a','b']){h.sql.prepare('INSERT INTO pm_order_schedule VALUES(?,?,?,0,?)').run(id,'2026-11-26',id,JSON.stringify({employee:id,date:'2026-11-26',start:'08:00',end:'17:00'}));h.sql.prepare("INSERT INTO pm_order_leave VALUES(?,?,?,'pending',?)").run(id,'2026-11-27',id,JSON.stringify({employee:id,note:'private-'+id}));}const r=await h.get();assert.equal(r.status,200);assert.equal(r.body.rows.length,1);assert.equal(r.body.rows[0].employee,'a');assert.equal(r.body.leaves.length,1);assert.equal(r.body.leaves[0].note,'private-a');assert.equal(r.body.employees.length,1);}finally{h.sql.close();}});
test('shared terminal and signed-out session cannot read schedule or submit even with selected ID',async()=>{const h=fixture();try{for(const actor of ['terminal@example.invalid',null]){h.actor(actor);assert.equal((await h.get()).status,403);assert.notEqual((await h.post('leave',{employee:'a',date:'2026-11-26',note:''})).status,200);}assert.equal(h.count(),0);}finally{h.sql.close();}});
test('own leave lost response / exact replay adds only one; changed content or other actor denied',async()=>{const h=fixture();try{const id=crypto.randomUUID(),x={employee:'a',date:'2026-11-26',note:'SAMPLE'};assert.equal((await h.post('leave',x,id)).status,200);assert.equal((await h.post('leave',x,id)).body.replayed,true);assert.notEqual((await h.post('leave',{...x,note:'changed'},id)).status,200);h.actor('b@example.invalid');assert.notEqual((await h.post('leave',x,id)).status,200);assert.equal(h.count(),1);}finally{h.sql.close();}});
test('two pending IDs for same employee/day produce one row',async()=>{const h=fixture();try{const x={employee:'a',date:'2026-11-26',note:'SAMPLE'};assert.equal((await h.post('leave',x)).status,200);assert.notEqual((await h.post('leave',x)).status,200);assert.equal(h.count(),1);}finally{h.sql.close();}});
test('employee cannot submit on behalf, schedule, approve or use foreign origin',async()=>{const h=fixture();try{for(const [action,data] of [['leave',{employee:'b',date:'2026-11-26'}],['schedule',{employee:'a',date:'2026-11-26',start:'08:00',end:'17:00'}],['review-leave',{id:'other',approved:true}]] as const)assert.notEqual((await h.post(action,data)).status,200);assert.equal((await h.post('leave',{date:'2026-11-26'},crypto.randomUUID(),'https://other.invalid')).status,403);assert.equal(h.count(),0);}finally{h.sql.close();}});
test('admin approves own permitted action; review replay does not increment schedule twice; clocks/payroll unchanged',async()=>{const h=fixture();try{const before=h.sql.prepare('SELECT value FROM app_state').get()!.value,id=crypto.randomUUID();assert.equal((await h.post('leave',{date:'2026-11-26',note:'SAMPLE'},id)).status,200);h.actor('admin@example.invalid');const review=crypto.randomUUID();assert.equal((await h.post('review-leave',{id,approved:true},review)).status,200);assert.equal((await h.post('review-leave',{id,approved:true},review)).status,200);assert.equal(h.sql.prepare('SELECT version FROM pm_order_schedule').get()!.version,0);assert.equal(h.sql.prepare('SELECT status FROM pm_order_leave').get()!.status,'approved');assert.equal(h.sql.prepare('SELECT value FROM app_state').get()!.value,before);}finally{h.sql.close();}});
test('locked month denies schedule, new leave and approval',async()=>{const h=fixture();try{const id=crypto.randomUUID();assert.equal((await h.post('leave',{date:'2026-11-26',note:''},id)).status,200);h.state.locked=['2026-11'];h.persist();assert.notEqual((await h.post('leave',{date:'2026-11-28',note:''})).status,200);h.actor('owner@example.invalid');assert.notEqual((await h.post('schedule',{date:'2026-11-28',employee:'a',start:'08:00',end:'17:00'})).status,200);assert.notEqual((await h.post('review-leave',{id,approved:true})).status,200);assert.equal(h.sql.prepare('SELECT status FROM pm_order_leave').get()!.status,'pending');}finally{h.sql.close();}});

const snapshot=(h:ReturnType<typeof fixture>)=>JSON.stringify(['pm_order_schedule','pm_order_leave','pm_order_actions'].map(t=>h.sql.prepare('SELECT * FROM '+t+' ORDER BY id').all()));
async function operation(kind:string){
 const h=fixture(),date='2026-11-26',id=crypto.randomUUID();
 let action='leave',data:any={date,note:'SAMPLE'};
 if(kind==='schedule-new'||kind==='schedule-edit'){
  h.actor('owner@example.invalid');action='schedule';data={date,employee:'a',kind:'work',start:'08:00',end:'17:00'};
  if(kind==='schedule-edit'){assert.equal((await h.post(action,data)).status,200);data={...data,start:'09:00',version:0};}
 }
 if(kind.startsWith('review-')){
  const leaveId=crypto.randomUUID();assert.equal((await h.post('leave',data,leaveId)).status,200);
  h.actor('admin@example.invalid');action='review-leave';data={id:leaveId,approved:kind==='review-approve'};
 }
 return {h,run:()=>h.post(action,data,id),lock:()=>{h.state.locked=['2026-11'];h.persist();}};
}
for(const kind of ['leave','schedule-new','schedule-edit','review-approve','review-reject']){
 test(kind+': lock commits after route read but before write batch; no domain or audit write',async()=>{
  const {h,run,lock}=await operation(kind);try{const before=snapshot(h);h.beforeBatch(lock);const result=await run();assert.notEqual(result.status,200);assert.match(result.body.error,/trước khi ghi/);assert.equal(snapshot(h),before);assert.deepEqual(JSON.parse(String(h.sql.prepare('SELECT value FROM app_state').get()!.value)).locked,['2026-11']);}finally{h.sql.close();}
 });
 test(kind+': write batch commits before lock; readback/replay keeps one mutation and audit',async()=>{
  const {h,run,lock}=await operation(kind);try{const before=snapshot(h);h.afterBatch(lock);assert.equal((await run()).status,200);const after=snapshot(h);assert.notEqual(after,before);assert.equal((await run()).status,200);assert.equal(snapshot(h),after);assert.equal((await h.get()).status,200);assert.deepEqual(JSON.parse(String(h.sql.prepare('SELECT value FROM app_state').get()!.value)).locked,['2026-11']);}finally{h.sql.close();}
 });
}
test('audit failure rolls back leave and receipt together',async()=>{const h=fixture();try{const before=snapshot(h);h.sql.exec("CREATE TRIGGER fail_audit BEFORE INSERT ON pm_order_actions BEGIN SELECT RAISE(ABORT,'SAMPLE_AUDIT_FAILURE'); END");assert.notEqual((await h.post('leave',{date:'2026-11-26',note:'SAMPLE'})).status,200);assert.equal(snapshot(h),before);}finally{h.sql.close();}});
test('missing state or malformed lock shape at commit fails closed',async()=>{for(const mode of ['missing','shape','changed-role']){const h=fixture();try{const before=snapshot(h);h.beforeBatch(()=>{if(mode==='missing')h.sql.exec('DELETE FROM app_state');else {if(mode==='shape')h.state.locked=null;else h.state.members=[];h.persist();}});assert.notEqual((await h.post('leave',{date:'2026-11-26',note:'SAMPLE'})).status,200);assert.equal(snapshot(h),before);}finally{h.sql.close();}}});

test('kiosk permits name selection only, stores unverified pending, and cannot inspect or approve',async()=>{const h=fixture();try{
 const before=h.sql.prepare('SELECT value FROM app_state').get()!.value,id=crypto.randomUUID();h.actor('terminal@example.invalid');
 const x={employee:'b',date:'2026-11-26'};
 const first=await h.post('kiosk-leave',x,id);assert.equal(first.status,200);assert.deepEqual(first.body,{ok:true});
 assert.deepEqual((await h.post('kiosk-leave',x,id)).body,{ok:true});
 assert.deepEqual((await h.post('kiosk-leave',x)).body,{ok:true});
 assert.equal((await h.get()).status,403);
 assert.notEqual((await h.post('review-leave',{id,approved:true})).status,200);
 assert.notEqual((await h.post('schedule',{...x,kind:'leave'})).status,200);
 assert.equal(h.count(),1);
 const row=h.sql.prepare('SELECT employee,status,record FROM pm_order_leave WHERE id=?').get(id)!;
 assert.equal(row.employee,'b');assert.equal(row.status,'pending');const persisted=JSON.parse(String(row.record));
 assert.equal(persisted.source,'shared-clock');assert.equal(persisted.identityVerified,false);assert.equal(persisted.note,'');
 assert.equal(h.sql.prepare('SELECT count(*) n FROM pm_order_actions').get()!.n,1);
 assert.equal(h.sql.prepare('SELECT count(*) n FROM pm_order_schedule').get()!.n,0);
 assert.equal(h.sql.prepare('SELECT value FROM app_state').get()!.value,before);
 h.actor('admin@example.invalid');assert.equal((await h.post('review-leave',{id,approved:true})).status,200);
 assert.equal(h.sql.prepare('SELECT status FROM pm_order_leave').get()!.status,'approved');
 assert.equal(h.sql.prepare('SELECT count(*) n FROM pm_order_schedule').get()!.n,1);
 assert.equal(h.sql.prepare('SELECT value FROM app_state').get()!.value,before);
 h.actor('terminal@example.invalid');assert.deepEqual((await h.post('kiosk-leave',x)).body,{ok:true});assert.equal(h.count(),1);
}finally{h.sql.close();}});

test('kiosk authorization rejects private accounts, unsigned, foreign origin, malformed date, inactive or unknown staff and extra fields',async()=>{const h=fixture();try{
 const x={employee:'a',date:'2026-11-26'};
 for(const actor of ['a@example.invalid','admin@example.invalid','owner@example.invalid',null]){h.actor(actor);assert.notEqual((await h.post('kiosk-leave',x)).status,200);}
 h.actor('terminal@example.invalid');h.state.employees[1].active=false;h.persist();
 for(const data of [{...x,employee:'b'},{...x,employee:'missing'},{...x,date:'2026-02-31'},{...x,note:'private'},{...x,approved:true}])assert.notEqual((await h.post('kiosk-leave',data)).status,200);
 assert.equal((await h.post('kiosk-leave',x,'0'.repeat(36))).status,400);assert.equal((await h.post('kiosk-leave',x,crypto.randomUUID(),'https://other.invalid')).status,403);
 assert.equal(h.count(),0);
}finally{h.sql.close();}});

test('kiosk id cannot replay another payload or collide with another actor action',async()=>{const h=fixture();try{
 const x={employee:'a',date:'2026-11-26'},id=crypto.randomUUID();assert.equal((await h.post('leave',x,id)).status,200);
 h.actor('terminal@example.invalid');assert.notEqual((await h.post('kiosk-leave',x,id)).status,200);
 const second=crypto.randomUUID();assert.equal((await h.post('kiosk-leave',{...x,employee:'b'},second)).status,200);
 for(const y of [x,{...x,employee:'b',date:'2026-11-27'}])assert.notEqual((await h.post('kiosk-leave',y,second)).status,200);
 assert.equal(h.count(),2);
}finally{h.sql.close();}});

test('kiosk rolls back pending and audit if audit fails, if payroll locks, or terminal is revoked before write',async()=>{for(const action of ['failure','lock','revoke']){
 const h=fixture();try{h.actor('terminal@example.invalid');const before=snapshot(h);
 if(action==='failure')h.sql.exec("CREATE TRIGGER fail_kiosk_audit BEFORE INSERT ON pm_order_actions BEGIN SELECT RAISE(ABORT,'SAMPLE_AUDIT_FAILURE'); END");
 else h.beforeBatch(()=>{if(action==='lock')h.state.locked.push('2026-11');else h.state.members=h.state.members.filter((m:any)=>m.role!=='terminal');h.persist();});
 assert.notEqual((await h.post('kiosk-leave',{employee:'a',date:'2026-11-26'})).status,200);assert.equal(snapshot(h),before);
 }finally{h.sql.close();}
}});

test('kiosk sees selected active employee current Vietnam week work shifts only; never leaks leave, reasons, IDs or notes',async()=>{const h=fixture();try{
 const {from,to}=access.kioskWorkWeek(),plus=(d:string,n:number)=>new Date(Date.parse(d+'T00:00:00Z')+86400000*n).toISOString().slice(0,10);
 const insert=(id:string,employee:string,date:string,kind:string,start='08:00',end='17:00')=>h.sql.prepare('INSERT INTO pm_order_schedule VALUES(?,?,?,0,?)').run(id,date,employee,JSON.stringify({employee,date,kind,start,end,note:'PRIVATE-'+id,phone:'0000',salary:9876}));
 insert('a-work','a',plus(from,2),'work');insert('a-leave','a',plus(from,3),'leave');insert('a-off','a',plus(from,4),'off');insert('a-next','a',plus(to,1),'work');insert('a-prior','a',plus(from,-1),'work');insert('a-bad-time','a',plus(from,5),'work','17:00','08:00');insert('b-work','b',from,'work','09:00','17:30');
 h.sql.prepare('INSERT INTO pm_order_schedule VALUES(?,?,?,0,?)').run('a-malformed',to,'a','not JSON');
 h.sql.prepare("INSERT INTO pm_order_leave VALUES(?,?,?,'pending',?)").run('leave-private',from,'a',JSON.stringify({note:'SECRET_REASONS'}));
 const old=snapshot(h),query=(id:string)=>'tab=kiosk-schedule&employee='+id;h.actor('terminal@example.invalid');
 const a=await h.get(query('a'));assert.equal(a.status,200);assert.deepEqual(a.body,{from,to,rows:[{date:plus(from,2),start:'08:00',end:'17:00'}]});
 const b=await h.get(query('b'));assert.equal(b.status,200);assert.deepEqual(b.body,{from,to,rows:[{date:from,start:'09:00',end:'17:30'}]});
 assert.equal((await h.get(query('a')+'&from=2025-01-01')).status,400);
 assert.equal((await h.get(query('a')+'&employee=b')).status,400);
 assert.notEqual((await h.get(query('missing'))).status,200);
 h.state.employees[1].active=false;h.persist();assert.notEqual((await h.get(query('b'))).status,200);
 for(const actor of ['a@example.invalid','admin@example.invalid','owner@example.invalid',null]){h.actor(actor);assert.equal((await h.get(query('a'))).status,403);}
 assert.equal(snapshot(h),old);
}finally{h.sql.close();}});

test('kiosk week uses Vietnam day at UTC Sunday evening and crosses year without extending scope',()=>{
 assert.deepEqual(access.kioskWorkWeek(new Date('2026-11-22T16:59:59Z')),{from:'2026-11-16',to:'2026-11-22'});
 assert.deepEqual(access.kioskWorkWeek(new Date('2026-11-22T17:00:00Z')),{from:'2026-11-23',to:'2026-11-29'});
 assert.deepEqual(access.kioskWorkWeek(new Date('2027-01-01T00:00:00Z')),{from:'2026-12-28',to:'2027-01-03'});
});
