import {digest} from './a3-access';
import {trackingCode,vnDay} from './orders';
export async function readReturnBaseline(db:D1Database){await db.prepare('CREATE TABLE IF NOT EXISTS pm_return_baseline(id TEXT PRIMARY KEY,record TEXT NOT NULL)').run();const row=await db.prepare("SELECT record FROM pm_return_baseline WHERE id='current'").first<any>();return row?JSON.parse(row.record):null;}
export async function allowPosReturn(db:D1Database,tracking:string,updated:string,baseline:any){if(!baseline)return true;return !baseline.suppressed.includes(await digest(tracking))&&Date.parse(updated)>Date.parse(baseline.cutoff);}
export async function applyReturnBaseline(db:D1Database,input:any[],actor:string){
 if(!Array.isArray(input)||input.length!==60)throw Error('Mốc này cần đúng 60 mã từ bảng Doanh Số');
 const rows=input.map(r=>({tracking:trackingCode(r.tracking),group:r.group}));if(rows.some(r=>!['delivery','refund','shopee'].includes(r.group))||new Set(rows.map(r=>r.group+':'+r.tracking)).size!==60)throw Error('Kiểm tra nhóm và mã trùng');
 const previous=await readReturnBaseline(db);if(previous)throw Error('Đã có mốc đối chiếu; không tự đặt lại mốc');
 const old=await db.prepare('SELECT * FROM pm_return_expected').all<any>(),receipts=await db.prepare('SELECT tracking,record FROM pm_order_returns WHERE active=1').all<any>(),received=new Set(receipts.results.map(r=>JSON.parse(r.record).group+':'+r.tracking));
 if(rows.some(r=>received.has(r.group+':'+r.tracking)))throw Error('Một mã đã nhận kho trong đúng nhóm; cần đọc lại bảng nguồn');
 const keys=new Set(rows.map(r=>r.group+':'+r.tracking)),cutoff=new Date().toISOString(),suppressed=[...new Set(await Promise.all(old.results.map(r=>digest(r.tracking))))],before=old.results.filter(r=>r.active&&!received.has(r.group_key+':'+r.tracking)&&!keys.has(r.group_key+':'+r.tracking));
 const baseline={cutoff,suppressed,source:'Doanh Số Đơn Hàng · BẮN ĐƠN HOÀN',pending:rows,total:60,actor};
 const statements:D1PreparedStatement[]=[db.prepare('INSERT INTO pm_order_actions VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),cutoff,actor,'Chốt mốc 60 đơn theo Doanh Số',JSON.stringify({baseline,before})),db.prepare("INSERT INTO pm_return_baseline VALUES('current',?)").bind(JSON.stringify(baseline)),...before.map(r=>db.prepare('UPDATE pm_return_expected SET active=0 WHERE id=?').bind(r.id))];
 for(const r of rows){const value={...r,date:vnDay(),dateUnknown:true,source:baseline.source,importedAt:cutoff,baseline:true,actor};statements.push(db.prepare('INSERT INTO pm_return_expected VALUES(?,?,?,?,1,?) ON CONFLICT(group_key,tracking) DO UPDATE SET active=1,record=excluded.record').bind(await digest('return-expected:'+r.group+':'+r.tracking),r.group,r.tracking,value.date,JSON.stringify(value)));}
 await db.batch(statements);return {total:60,excluded:before.length,cutoff};
}
