import {hours,round,type State,type Clock} from './payroll.ts';
import {holidayCalendar} from './holidays.ts';
export function planAttendance(s:State,employee:string,month:string,days:number){
 if(!/^20\d{2}-(0[1-9]|1[0-2])$/.test(month))throw Error('Tháng không hợp lệ');
 if(s.locked.includes(month))throw Error('Tháng đã chốt; cần mở lại trước khi bổ sung');
 const e=s.employees.find(e=>e.id===employee);if(!e)throw Error('Nhân viên không hợp lệ');
 if(!Number.isFinite(days)||days<=0||days>31)throw Error('Nhập số công lớn hơn 0, không vượt số ngày trong tháng');
 let remaining=Math.round(days*480);if(Math.abs(remaining-days*480)>0.001)throw Error('Số công phải quy đổi được ra phút');
 const holiday=new Set(holidayCalendar(Number(month.slice(0,4))).filter(h=>h.date.startsWith(month)).map(h=>h.date));
 const count=new Date(Number(month.slice(0,4)),Number(month.slice(5)),0).getDate(),rows:{date:string,hours:number}[]=[];
 for(let d=1;d<=count&&remaining>0;d++){const date=month+'-'+String(d).padStart(2,'0');if(holiday.has(date))continue;
 const old=s.clocks.find(c=>c.employee===employee&&c.date===date);const capacity=old?Math.max(0,480-Math.round(hours(old,e).regular*60)):480;
 const minutes=Math.min(remaining,capacity);if(minutes){rows.push({date,hours:minutes/60});remaining-=minutes;}}
 if(remaining)throw Error('Tháng không còn đủ chỗ cho '+days+' công bổ sung; các ngày đã đủ 8 giờ được giữ nguyên');
 return rows;
}
export function addAttendance(s:State,employee:string,month:string,days:number,note:string){const rows=planAttendance(s,employee,month,days);for(const r of rows){let c=s.clocks.find(c=>c.employee===employee&&c.date===r.date);if(!c){c={employee,date:r.date,start:'',end:'',note:''};s.clocks.push(c);}c.manualRegular=(c.manualRegular||0)+r.hours;c.note=[c.note,'Bổ sung '+round(r.hours/8)+' công'+(note?' · '+note:'')].filter(Boolean).join(' | ').slice(0,500);}return rows;}
