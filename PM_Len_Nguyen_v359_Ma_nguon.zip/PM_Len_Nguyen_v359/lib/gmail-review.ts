type Row={id:string;mailId:string;document:string;source:string;reference:string;date:string;currency:string;amount:number|null;reason:string;subject:string;received:string;kind:string|null};
type Bill={vendor:string;number:string;day:string;total:number};

export const reviewSchema='CREATE TABLE IF NOT EXISTS gmail_fintab_bills(vendor TEXT NOT NULL,number TEXT NOT NULL,day TEXT NOT NULL,total INTEGER NOT NULL,PRIMARY KEY(vendor,number,day,total))';
const seller=(s:string)=>s.trim().normalize('NFC').toUpperCase().replace(/^CÔNG TY TNHH SHOPEE$/,'SHOPEE');
const number=(s:string)=>s.replace(/^0+(?=\d)/,'');
export function parseBills(text:string):Bill[]{
 const lines=text.trim().split(/\r?\n/);
 if(lines.length>1000)throw Error('Tối đa 1.000 hóa đơn mỗi lượt');
 return lines.map(line=>{
  const [date,ref,vendor,amount,...extra]=line.split('\t');
  if(extra.length||!/^\d{2}\/\d{2}\/\d{4}$/.test(date)||!/^\d{1,20}$/.test(ref)||!vendor?.trim()||vendor.length>300||!/^\d{1,14}$/.test(amount))throw Error('Kiểm tra bốn cột ngày, số hóa đơn, nhà cung cấp và tổng tiền VND.');
  const day=date.split('/').reverse().join('-');
  if(!Number.isFinite(Date.parse(day))||new Date(day).toISOString().slice(0,10)!==day)throw Error('Ngày hóa đơn không hợp lệ');
  return {day,number:number(ref),vendor:seller(vendor),total:Number(amount)};
 });
}

export function administrativeNotice(r:{source:string;subject:string;document:string;amount:number|null}){
 if(r.amount!=null)return '';
 if(r.source==='invoice@pancake.vn' && r.document==='Tra cứu biên bản điện tử Hilo' && /^Thông báo về việc ký biên bản thay thế hóa đơn số:\s*\d+$/i.test(r.subject))return 'Yêu cầu ký biên bản thay thế. Theo dõi hóa đơn thay thế khi phát hành.';
 if(r.source==='possupport@pancake.vn' && r.subject==='Pancake Einvoice' && r.document.includes('tạo gói cước hóa đơn'))return 'Thông báo đăng ký dịch vụ hóa đơn điện tử. Theo dõi tiền mua và mức sử dụng tại hóa đơn phần mềm.';
 return '';
}
function evidence(r:Row){
 const notice=administrativeNotice(r);if(notice)return notice;

 if(r.kind==='tiktok-other-buyer')return 'PDF TikTok ghi tên bên mua khác shop. Lưu riêng để đối chứng.';
 if(/^coddoisoat[^@]*@hq\.jtexpress\.vn$/i.test(r.source) && /^THÔNG BÁO LỊCH THANH TOÁN COD DỊP LỄ/i.test(r.document) && r.amount===null)return 'Thông báo lịch chuyển tiền COD ngày lễ. Theo dõi cước ở bảng kê vận đơn.';
 if(r.kind==='shipping-contract')return 'Hợp đồng khung vận chuyển. Đối chiếu chi phí theo bảng kê thực tế.';
 if(r.kind==='payment-receipt' && r.source==='Runway AI, Inc.')return 'Biên nhận trả tiền Runway. Theo dõi khoản mua trả trước trên hóa đơn cùng giao dịch.';
 if(r.source==='payment-noreply@email.tiktok.com' && r.document==='Nội dung thư' && r.subject==='Số dư trong tài khoản TikTok Shop của bạn đã được rút')return 'Thông báo rút số dư TikTok Shop. Dùng đối chiếu dòng tiền.';
 if((r.kind==='image-review'||r.source==='no-reply@notifications.tiktok.com') && /4366143-Billing and Payment-Ad credits/i.test(r.subject))return 'Trao đổi hỗ trợ tín dụng quảng cáo TikTok. Theo dõi chi phí bằng báo cáo thực chạy.';
 if(r.source==='no-reply@accounts.google.com' && r.subject==='Cảnh báo bảo mật')return 'Thông báo bảo mật tài khoản Google.';
 if(r.source==='drive-shares-dm-noreply@google.com' && r.subject.startsWith('Thư mục được chia sẻ với bạn:'))return 'Thông báo chia sẻ thư mục. Chứng từ nằm trong thư mục Drive.';
 return '';
}
export async function reviewGmail(db:D1Database,mailId?:string){
 const {results:items}=await db.prepare(`SELECT d.id,d.mailId,d.document,d.source,d.reference,d.date,d.currency,d.amount,d.reason,e.subject,e.received,
 json_extract(f.facts,'$.reading.kind') kind FROM gmail_documents d JOIN gmail_evidence e ON d.mailId=e.id
 LEFT JOIN gmail_document_facts f ON f.itemId=d.id WHERE d.state='pending' AND d.targetId='' AND d.reason NOT LIKE 'Thư cần kiểm tra vị trí%' `+(mailId?'AND d.mailId=?':'')).bind(...(mailId?[mailId]:[])).all<Row>();
 if(!items.length)return {matched:0};
 const {results:bills}=await db.prepare('SELECT vendor,number,day,total FROM gmail_fintab_bills').all<Bill>();
 const notices=new Map<string,Row[]>(),matched=new Set<string>();
 const actions:D1PreparedStatement[]=[];
 for(const r of items.filter(r=>r.kind==='invoice_notice')){
  const group=notices.get(r.mailId)||[];group.push(r);notices.set(r.mailId,group);
  const hits=bills.filter(b=>b.vendor===seller(r.source)&&b.number===number(r.reference)&&(r.date?b.day===r.date:b.day.slice(0,4)===r.received.slice(0,4)));
  if(hits.length!==1 || (r.amount!==null&&r.amount!==hits[0].total)||(r.currency&&r.currency!=='VND'))continue;
  matched.add(r.id);
  const bill=hits[0],note='Fintab · Hóa đơn đầu vào ngày '+bill.day+' · số '+bill.number+' · '+bill.total.toLocaleString('vi-VN')+'đ. Chờ đối chiếu kỳ, shop và khoản chi đã có.';
  actions.push(db.prepare("UPDATE gmail_documents SET amount=?,currency='VND',date=CASE WHEN date='' THEN ? ELSE date END,reason=? WHERE id=? AND state='pending' AND (amount IS NULL OR amount=?) AND (currency='' OR currency='VND')").bind(bill.total,bill.day,note,r.id,bill.total));
 }
 const references=await db.prepare("SELECT id,mailId,source,reference,amount,currency,date FROM gmail_documents WHERE reference<>'' AND amount IS NOT NULL").all<Row>();
 const sameMail=new Map<string,Row[]>();
 for(const doc of references.results){const group=sameMail.get(doc.mailId)||[];group.push(doc);sameMail.set(doc.mailId,group);}
 const promoted=new Set<string>();
 const canonical=new Map<string,string>();
 const subjectBills=new Map<string,Bill>();
 for(const r of items){
  if(r.kind||r.amount!==null||!r.reason.startsWith('Chờ kiểm tra quyền tải hóa đơn từ liên kết nguồn.'))continue;
  const same=sameMail.get(r.mailId)||[];
  const keys=new Set(same.map(x=>[x.source,x.reference,x.amount,x.currency].join('|')));
  if(keys.size===1){canonical.set(r.mailId,same[0].reference);continue;}
  if(notices.has(r.mailId)||same.length)continue;
  const ref=r.subject.match(/hóa đơn điện tử số\s*:?\s*<?(\d+)(?!\d)/i)?.[1];
  if(!ref)continue;
  const hits=bills.filter(b=>b.number===number(ref)&&seller(r.subject).includes(b.vendor)&&b.day.slice(0,4)===r.received.slice(0,4));
  if(hits.length!==1)continue;
  const bill=hits[0];
  const previous=references.results.filter(x=>seller(x.source)===bill.vendor&&number(x.reference)===bill.number&&x.amount===bill.total&&x.currency==='VND'&&x.date===bill.day);
  if(previous.length){canonical.set(r.mailId,bill.number);continue;}
  subjectBills.set(r.mailId,bill);
 }
 for(const [id,bill] of subjectBills){
  const group=items.filter(r=>r.mailId===id&&!r.kind&&r.amount===null).sort((a,b)=>a.id.localeCompare(b.id));
  if(!group.length)continue;
  const r=group[0];promoted.add(r.id);canonical.set(id,bill.number);
  actions.push(db.prepare("UPDATE gmail_documents SET source=?,reference=?,date=?,currency='VND',amount=?,identity=?,reason=? WHERE id=? AND state='pending' AND amount IS NULL")
   .bind(bill.vendor,bill.number,bill.day,bill.total,JSON.stringify(['fintab',bill.vendor,bill.day,bill.number]),'Đã khớp nhà cung cấp và số hóa đơn trong thư với hóa đơn đầu vào Fintab. Chờ xác định nội dung chi phí và kỳ sử dụng.',r.id));
 }
 for(const r of items){
  if(promoted.has(r.id))continue;
  let note=evidence(r);
  if(!note && !r.kind && r.amount===null && !r.reference && canonical.has(r.mailId) && r.reason.startsWith('Chờ kiểm tra quyền tải hóa đơn từ liên kết nguồn.'))note='Liên kết tra cứu bổ trợ. Hóa đơn số '+canonical.get(r.mailId)+' đã có trong hồ sơ Gmail.';
  const sibling=notices.get(r.mailId);
  if(!note && !r.kind && r.amount===null && r.reason.startsWith('Chờ kiểm tra quyền tải hóa đơn từ liên kết nguồn.') && sibling?.length===1 && matched.has(sibling[0].id))note='Đường dẫn tra cứu trong cùng thư. Theo dõi hóa đơn số '+sibling[0].reference+' tại mục thông báo đã khớp Fintab.';
  if(note)actions.push(db.prepare("UPDATE gmail_documents SET state='evidence',reason=? WHERE id=? AND state='pending' AND reason=?").bind(note,r.id,r.reason));
 }
 for(let i=0;i<actions.length;i+=40)await db.batch(actions.slice(i,i+40));
 return {matched:matched.size+promoted.size};
}
