type Price={sku:string;date:string;price:number};
export async function saleCost(moves:any[],prices:Price[],from:string,to:string,read:(from:string,to:string)=>Promise<any[]>){
 const norm=(s:any)=>String(s||'').trim().toUpperCase();
 const history=new Map<string,Price[]>();
 for(const p of prices){const code=norm(p.sku);const items=history.get(code)||[];items.push(p);history.set(code,items);}
 const codeOf=(r:any)=>norm(r.product?.custom_id);
 const active=new Set(moves.filter(r=>Number(r.sell_export)||Number(r.return_import)).map(codeOf));
 const starts=[...new Set([from,...prices.filter(p=>active.has(norm(p.sku))&&p.date>from&&p.date<=to).map(p=>p.date)])].sort();
 let known=0,matched=0,missingUnits=0;
 const missing=new Set<string>(),totals=new Map<string,number>();
 function units(r:any,k:string){const v=r[k];if(v==null||v===''||!Number.isSafeInteger(Number(v)))throw Error('Thiếu số lượng phát sinh POS');return Math.abs(Number(v));}
 const key=(r:any)=>String(r.id||r.product_id||codeOf(r));
 for(let i=0;i<starts.length;i++){
  const day=starts[i],end=starts[i+1]?new Date(Date.parse(starts[i+1])-86400000).toISOString().slice(0,10):to;
  const rows=starts.length===1?moves:await read(day,end);
  for(const r of rows){
   const sold=units(r,'sell_export'),returned=units(r,'return_import');if(!sold&&!returned)continue;
   for(const [suffix,q] of [['s',sold],['r',returned]] as const){const k=key(r)+suffix;totals.set(k,(totals.get(k)||0)+q);}
   if(sold===returned)continue;
   const code=codeOf(r),applicable=(history.get(code)||[]).filter(p=>(p.date||'')<=day);
   const date=applicable.reduce((last,p)=>(p.date||'')>last?p.date:last,'');
   const values=[...new Set(applicable.filter(p=>(p.date||'')===date).map(p=>p.price))];
   if(values.length!==1||!Number.isSafeInteger(values[0])||values[0]<=0){missing.add(code||String(r.product?.name||key(r)));missingUnits+=sold+returned;continue;}
   known+=(sold-returned)*values[0];matched+=sold+returned;
  }
 }
 for(const r of moves){for(const [suffix,k] of [['s','sell_export'],['r','return_import']]){const id=key(r)+suffix;if((totals.get(id)||0)!==units(r,k))throw Error('Số lượng theo ngày đổi giá lệch báo cáo cả kỳ');totals.delete(id);}}
 if([...totals.values()].some(Boolean))throw Error('Có phát sinh ngoài báo cáo cả kỳ');
 return {known,matched,missingUnits,missing:[...missing],complete:missing.size===0};
}
