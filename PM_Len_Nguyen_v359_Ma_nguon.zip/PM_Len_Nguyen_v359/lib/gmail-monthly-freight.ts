type InvoiceGroup={item:string;month:string;customer:string;branch:string;statement:string;tracking:string[]};
export async function linkMonthlyFreight(db:D1Database,groups:InvoiceGroup[]){
 if(!Array.isArray(groups)||!groups.length||groups.length>25)throw Error('Lô hóa đơn không hợp lệ');
 await db.prepare('CREATE TABLE IF NOT EXISTS gmail_jt_monthly_links(tracking TEXT PRIMARY KEY,item TEXT NOT NULL,customer TEXT NOT NULL,branch TEXT NOT NULL,month TEXT NOT NULL,statement TEXT NOT NULL)').run();
 for(const g of groups){
  if(!Array.isArray(g.tracking)||!g.tracking.length||g.tracking.length>6000||new Set(g.tracking).size!==g.tracking.length||
   !g.tracking.every(s=>/^\d{8,20}$/.test(s))||!/^20\d\d-\d\d$/.test(g.month)||!g.branch||!g.customer||!g.statement)throw Error('Danh sách đối chiếu không hợp lệ');
  const d=await db.prepare('SELECT d.source,d.state,d.targetType,d.month,d.amount,d.currency,i.details FROM gmail_documents d JOIN gmail_invoice_lines i ON i.item=d.id WHERE d.id=?').bind(g.item).first<any>();
  if(!d||!d.source.includes('THUẬN PHONG')||d.currency!=='VND'||g.month!==d.month||!JSON.parse(d.details).lines.some((s:string)=>s.includes(g.statement)))throw Error('Sai kỳ hoặc số bảng kê trên hóa đơn');
  const codes=JSON.stringify(g.tracking);
  const matched=await db.prepare(`SELECT COUNT(*) n,SUM(b.fee) total FROM gmail_jt_booked b JOIN pm_finance_docs f ON f.id=b.financeId JOIN gmail_document_facts facts ON facts.itemId=b.item
   WHERE b.tracking IN (SELECT value FROM json_each(?)) AND f.status='confirmed' AND json_extract(facts.facts,'$.reading.customer')=?`).bind(codes,g.customer).first<any>();
  if(matched?.n!==g.tracking.length||matched.total!==d.amount)throw Error('Tổng phiếu đã ghi hoặc mã khách chưa khớp '+g.statement);
  const existing=await db.prepare('SELECT COUNT(*) n FROM gmail_jt_monthly_links WHERE item=? AND tracking IN (SELECT value FROM json_each(?))').bind(g.item,codes).first<any>();
  if(d.state==='linked'&&d.targetType==='jt-monthly'&&existing?.n===g.tracking.length)continue;
  if(d.state!=='pending')throw Error('Hóa đơn đã được xử lý theo chứng từ khác');
  const reason='Đã khớp bảng kê '+g.statement+' · '+g.customer+' · '+g.branch+' · '+g.tracking.length+' vận đơn theo tháng ký nhận '+g.month+' · '+d.amount.toLocaleString('vi-VN')+'đ. Cước đã ghi theo từng vận đơn.';
  await db.batch([
   db.prepare('INSERT INTO gmail_jt_monthly_links SELECT value,?,?,?,?,? FROM json_each(?)').bind(g.item,g.customer,g.branch,g.month,g.statement,codes),
   db.prepare("UPDATE gmail_documents SET state='linked',targetType='jt-monthly',targetId=?,reason=? WHERE id=? AND state='pending'").bind(g.statement,reason,g.item)
  ]);
 }
 return {count:groups.length};
}
