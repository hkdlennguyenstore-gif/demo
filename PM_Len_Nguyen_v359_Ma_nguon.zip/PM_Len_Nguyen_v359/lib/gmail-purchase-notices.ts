type InvoiceNotice={vendor?:string;vendorTaxId?:string;number?:string;series?:string;date?:string;total?:string|number};
export function merchandiseSupplier(invoice?:InvoiceNotice){
 return invoice?.vendorTaxId==='017091001591' && /nguyễn huy minh/i.test(invoice.vendor||'');
}
export async function routePurchaseNotice(db:D1Database,mailId:string,invoice:InvoiceNotice){
 const number=invoice.number||'',series=invoice.series||'';
 if(!/^\d+$/.test(number)||!series)return;
 const key=[invoice.vendorTaxId,series,number].join('|');
 const original=series==='2C26TAA'&&number==='3'&&invoice.date==='2026-04-01';
 const replacement=series==='2C26TAA'&&number==='4'&&invoice.date==='2026-04-02';
 const documented=/^20\d{2}-\d{2}-\d{2}$/.test(invoice.date||'') && Number.isSafeInteger(Number(invoice.total)) && Number(invoice.total)>0;
 const related=original?'017091001591|2C26TAA|4':replacement?'017091001591|2C26TAA|3':'';
 await db.batch([
  db.prepare('INSERT INTO gmail_purchase_notices(id,supplier,series,number,date,printedTotal,status,related) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING')
   .bind(key,invoice.vendor,series,number,invoice.date||'',String(invoice.total??''),original?'superseded':documented?'documented':'incomplete',related),
  db.prepare('INSERT OR IGNORE INTO gmail_purchase_sources(noticeId,mailId) VALUES(?,?)').bind(key,mailId)
 ]);
 return {key,original,replacement,documented};
}
