import {movementPeriodRange,sumStockPeriodMovement} from './stock-period-movement';
import {readStockAdjustments} from './stock-adjustments';
import {readReceivedPeriod} from './stock-received-period';
import {readStockBaseline,nextStockDay} from './stock-baseline';
import {readStockSales,readStockSalesTotal} from './stock-sales';
import {saleCost} from './actual-sale-cost';
import {posGet} from './orders-store';
import {STOCK_START,calculateStockOverview} from './stock-overview-math';
import {vnDay} from './orders';
const cache=new Map<string,{time:number;value:any[]}>();
async function movements(config:any,from:string,to:string){
 if(!config.PANCAKE_API_KEY||!config.PANCAKE_SHOP_ID)throw Error('Chưa có kết nối POS để đọc lượng bán và hoàn về');
 const key=config.PANCAKE_SHOP_ID+'|'+from+'|'+to,old=cache.get(key);if(old&&Date.now()-old.time<60000)return old.value;
 const read=async(page:number)=>posGet(config.PANCAKE_API_KEY,config.PANCAKE_SHOP_ID,'inventory_analytics/inventory_by_product',{start_date:String(Math.floor(new Date(from+'T00:00:00+07:00').getTime()/1000)),end_date:String(Math.floor(new Date(to+'T23:59:59+07:00').getTime()/1000)),type:'actual',page:String(page),page_size:'250'});
 const value=(async()=>{const first=await read(1),pages=Number(first.total_pages),total=Number(first.total_entries);if(!Number.isSafeInteger(pages)||pages<0||pages>40||!Number.isSafeInteger(total)||total<0)throw Error('Báo cáo bán/hoàn POS chưa xác nhận đủ trang');const rows=[...first.data];for(let page=2;page<=pages;page+=3){const next=await Promise.all(Array.from({length:Math.min(3,pages-page+1)},(_,i)=>read(page+i)));for(const batch of next){if(Number(batch.total_pages)!==pages||Number(batch.total_entries)!==total)throw Error('Nguồn POS thay đổi trong lúc đọc; cần tải lại');rows.push(...batch.data);}}if(rows.length!==total)throw Error('Báo cáo POS chưa đủ dòng; chưa chốt số tồn');return rows;})();const rows=await value;cache.set(key,{time:Date.now(),value:rows});if(cache.size>8)cache.delete(cache.keys().next().value!);return rows;
}
export async function readStockOverview(db:any,config:any,requested:{from:string;to:string},canValue:boolean,includeCost=true,includeZero=false){
 const receivedPeriod=includeCost?await readReceivedPeriod(db,requested):null;const baseline=await readStockBaseline(db);const adjustmentState=await readStockAdjustments(db,baseline);const today=vnDay(),to=today,from=nextStockDay(baseline.date);
 const costRange={from:requested.from&&requested.from>STOCK_START?requested.from:STOCK_START,to:requested.to&&requested.to<today?requested.to:today};
 const receipts=await db.prepare('SELECT id,date,record FROM pm_stock_receipts WHERE active=1 AND date>=? AND date<=?').bind(from,to).all();
 const sameDay=await db.prepare('SELECT id,record FROM pm_stock_receipts WHERE active=1 AND date=?').bind(baseline.date).all();const countCodes=new Set(baseline.rows.map(r=>r.code));const cutoffReview=sameDay.results.flatMap((r:any)=>{const receipt=JSON.parse(r.record);return (receipt.lines||[]).filter((l:any)=>!countCodes.has(String(l.existingCode||l.newCode||'').trim().toUpperCase())).map((l:any)=>({receipt:r.id,code:String(l.existingCode||l.newCode||'').trim().toUpperCase(),quantity:l.quantity,time:receipt.time,note:l.note||receipt.note||''}));});
 let scanCoverage:any=null;try{scanCoverage=await db.prepare("SELECT COUNT(*) AS scans,SUM(CASE WHEN json_extract(record,'$.dateUnknown')=1 THEN 1 ELSE 0 END) AS unknownDates FROM pm_order_returns WHERE active=1 AND date>=? AND date<=?").bind(from,to).first();}catch(e){if(!String(e).includes('no such table'))throw e;}
 let prices:any[]=[],priceIssue='';
 if(canValue){try{const result=await db.prepare('SELECT sku,date,price FROM pm_price_history WHERE date<=? AND NOT EXISTS(SELECT 1 FROM pm_a3_deleted d WHERE d.id=pm_price_history.id) ORDER BY date DESC,rowid DESC').bind(to).all();prices=result.results;}catch{priceIssue='Chưa đọc được giá nhập A3';}}
 let periodMoves:any[]=[],allMoves:any[]=[],movementIssue='';
 try{const raw=from>today?[]:await movements(config,from,today);const sold=await readStockSales(config,from,today,raw);allMoves=[...sold,...raw.map(r=>({...r,id:'received:'+r.id,sell_export:0}))];periodMoves=allMoves;}catch(e){movementIssue=(e as Error).message;}
 const result=calculateStockOverview(receipts.results.map((r:any)=>({...JSON.parse(r.record),id:r.id,date:r.date})),periodMoves,allMoves,prices,{from,to},!movementIssue,baseline,includeZero,adjustmentState.events);
 if(!canValue){result.cumulative.value=null;result.cumulative.knownValue=null;result.rows=result.rows.map(r=>{const {price,value,...safe}=r;return safe as any;});result.issues.missingPrices=0;}
 let salesCost=null,costIssue='';
 if(includeCost&&canValue&&!movementIssue&&!priceIssue){
  try{if(costRange.from<=costRange.to){const costMoves=await movements(config,costRange.from,costRange.to);salesCost=await saleCost(costMoves,prices,costRange.from,costRange.to,(a,b)=>movements(config,a,b));}}catch(e){costIssue=(e as Error).message;}
 }
 return {...result,adjustmentState,receivedPeriod,baselineInfo:baseline,cutoffReview,scanCoverage,soldBasis:'Phần hàng bán/chốt (success) theo cấu hình báo cáo POS hiện tại',returnBasis:'Nhập hoàn thực tế POS (return_import); không cộng lại số quét đối chứng',stockMode:'current',salesCostRange:costRange,salesCost,costIssue,canValue,movementIssue,priceIssue,updatedAt:new Date().toISOString()};
}

// Selected-period KPIs are independent of the physical stocktake and rolling balance.
export async function readStockMovementPeriod(config:any,requested:{from:string;to:string}){
 const range=movementPeriodRange(requested,vnDay()),updatedAt=new Date().toISOString();
 try{if(range.from>range.to)throw Error('Chưa có dữ liệu cho thời gian chưa diễn ra');const [raw,totalSold]=await Promise.all([movements(config,range.from,range.to),readStockSalesTotal(config,range.from,range.to)]);return {...sumStockPeriodMovement([{id:'period-total',sell_export:-totalSold}],raw),range,requestedRange:requested,updatedAt,issue:''};}
 catch(e){return {sold:null,returned:null,range,requestedRange:requested,updatedAt,issue:(e as Error).message};}
}
