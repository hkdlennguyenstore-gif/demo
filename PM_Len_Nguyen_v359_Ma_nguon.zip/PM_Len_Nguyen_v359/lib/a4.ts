import {validDate} from './purchasing.ts';
import {a4Size} from './a4-display.ts';
export const A4_SIZES=[27,28,29,30,31,32,33,34,35];
export const a4Key=(v:unknown)=>String(v||'').normalize('NFC').trim().replace(/\s+/g,' ').toLocaleLowerCase('vi');
export const a4Code=(v:unknown)=>String(v||'').normalize('NFC').trim().toUpperCase();
const str=(v:unknown,max:number)=>{if(typeof v!=='string'||v.trim().length>max)throw Error('Thông tin quá dài hoặc sai định dạng');return v.normalize('NFC').trim();};
export function validateA4Plan(x:any){
 const date=validDate(x.date),lot='',supplier=str(x.supplier,120).replace(/\s+/g,' '),type=str(x.type,60),code=a4Code(x.code),due=x.due?validDate(x.due):'',note=str(x.note||'',1000);
 if(!supplier||!type||!/^[A-Z0-9][A-Z0-9._+ -]{0,29}$/.test(code))throw Error('Nhập đủ nhà cung cấp, loại hàng và mã hàng hợp lệ');
 if(due&&due<date)throw Error('Ngày hẹn giao phải từ ngày kế hoạch trở đi');
 if(!Array.isArray(x.colors)||x.colors.length<1||x.colors.length>30)throw Error('Mỗi lô gồm 1–30 màu');
 const seen=new Set<string>();
 const colors=x.colors.map((l:any)=>{const color=str(l.color,80);if(!color||seen.has(a4Key(color)))throw Error('Màu không được trống hoặc trùng trong lô');seen.add(a4Key(color));if(!Array.isArray(l.qty)||l.qty.length!==9||l.qty.some((q:any)=>!Number.isSafeInteger(q)||q<0||q>1000000)||!l.qty.some((q:number)=>q>0))throw Error('Mỗi màu cần ít nhất một size có số lượng nguyên lớn hơn 0');return {color,qty:l.qty as number[]};});
 const qty=A4_SIZES.map((_,i)=>colors.reduce((n:number,l:any)=>n+l.qty[i],0));
 return {date,lot,supplier,type,code,due,note,colors,qty,color:colors.map((l:any)=>l.color).join(' / ')};
}
export function transitionA4Plan(old:any,action:string,x:any){
 if(action==='save'){if(old.status!=='draft')throw Error('Chỉ sửa được kế hoạch nháp');return {...old,...validateA4Plan(x),lot:old.lot};}
 const date=validDate(x.date),note=str(x.note||'',500);
 if(action==='production'){if(old.status!=='draft')throw Error('Lô không còn ở danh sách nháp');if(date<old.date)throw Error('Ngày sản xuất phải từ ngày kế hoạch');return {...old,status:'production',productionDate:date,productionNote:note};}
 if(action==='return'){if(old.status!=='production')throw Error('Chỉ ghi nhận hàng về cho lô đã sản xuất');const remaining=old.qty.reduce((n:number,q:number)=>n+q,0)-(old.received||0);if(!Number.isSafeInteger(x.quantity)||x.quantity<1||x.quantity>remaining)throw Error('Số lượng trả phải từ 1 đến '+remaining);if(date<(old.returns?.at(-1)?.date||old.productionDate||old.date))throw Error('Ngày trả phải từ lần ghi nhận trước');const received=(old.received||0)+x.quantity;return {...old,received,status:received===old.qty.reduce((n:number,q:number)=>n+q,0)?'returned':'production',returns:[...(old.returns||[]),{date,qty:x.quantity,note}],...(received===old.qty.reduce((n:number,q:number)=>n+q,0)?{returnedDate:date}:{})};}
 throw Error('Thao tác A4 không hợp lệ');
}
function quantity(v:unknown){return v!==null&&v!==undefined&&v!==''&&typeof v!=='boolean'&&Number.isSafeInteger(Number(v))?Number(v):null;}
// Only parse explicit POS size encodings belonging to the selected product.
function variationSkuSize(value:unknown, productCode:string):string {
 const id=a4Code(value);
 if(!productCode || !id.startsWith(productCode))return '';
 const suffix=id.slice(productCode.length);
 if(!suffix || /^[A-Z0-9]/.test(suffix) && !/^[A-ZÀ-Ỹ]+(?:-?SIZE)/u.test(suffix))return '';
 const explicit=suffix.match(/SIZE\s*(\d{2})(?:\(\d+(?:[.,]\d+)?-\d+(?:[.,]\d+)?KG\)?)?$/);
 if(explicit)return explicit[1];
 if(!suffix.startsWith('_'))return '';
 const size=suffix.match(/(?:_|\s)(\d{2}|[2-9]XL|XXL|XL|XS|S|M|L)$/);
 return size?.[1]||'';
}
export function normalizeA4Variations(rows:any[],code:string){
 const mapped:any[]=[],issues:string[]=[],seen=new Set<string>();
 const productCode=a4Code(code);
 for(const v of rows){
  const p=v.product||{}, parent=a4Code(p.custom_id||p.display_id);
  if(v.is_removed||v.is_hidden||v.is_locked||p.is_removed)continue;
  // Marketplace imports may use a numeric parent ID and the shop code in each SKU.
  const matchesSku=[v.custom_id,v.display_id].some(id=>a4Code(id).startsWith(productCode+'_'));
  if(parent!==productCode && !(/^\d{10,}$/.test(parent) && matchesSku))continue;
  if(!v.id||seen.has(String(v.id)))throw Error('POS trả biến thể thiếu mã hoặc bị trùng; cần tải lại');seen.add(String(v.id));
  const fields=Array.isArray(v.fields)?v.fields:[];
  const colors=fields.filter((f:any)=>['mau','mau sac','color','colour'].includes(a4Key(f.name).normalize('NFD').replace(/[\u0300-\u036f]/g,'')));
  const sizes=fields.filter((f:any)=>['size','kich thuoc','kich co'].includes(a4Key(f.name).normalize('NFD').replace(/[\u0300-\u036f]/g,'')));
  const color=colors.length===1?String(colors[0].value||'').trim():'';
  const skuSize=variationSkuSize(v.custom_id,productCode)||variationSkuSize(v.display_id,productCode);
  const size=skuSize||(sizes.length===1?a4Size(sizes[0].value):'');
  const warehouses=Array.isArray(v.variations_warehouses)?v.variations_warehouses:[];
  const warehouseIds=warehouses.map((w:any)=>w.warehouse_id);if(new Set(warehouseIds).size!==warehouseIds.length)throw Error('Biến thể có kho bị trùng');
  const sum=(key:string)=>warehouses.length&&warehouses.every((w:any)=>quantity(w[key])!==null)?warehouses.reduce((n:number,w:any)=>n+Number(w[key]),0):null;
  const remain=quantity(v.remain_quantity)??sum('remain_quantity'),actual=quantity(v.actual_remain_quantity)??sum('actual_remain_quantity');
  if(!color||!size||remain===null)issues.push('Biến thể '+String(v.custom_id||v.display_id||v.id)+' thiếu màu, size hoặc số có thể bán');
  mapped.push({id:String(v.id),productId:String(v.product_id||p.id||''),code:productCode,name:String(p.name||''),color:color||'Chưa có màu',size:size||'Chưa có size',remain,actual,image:typeof p.image==='string'&&p.image.startsWith('https://')?p.image:null});
 }
 return {variants:mapped,issues,complete:mapped.length>0&&issues.length===0,remain:mapped.length&&mapped.every(v=>v.remain!==null)?mapped.reduce((n,v)=>n+v.remain,0):null,actual:mapped.length&&mapped.every(v=>v.actual!==null)?mapped.reduce((n,v)=>n+v.actual,0):null};
}
export function validateA4Page(page:any){if(page.success!==true||!Array.isArray(page.data)||!Number.isSafeInteger(page.total_entries)||page.total_entries<0||!Number.isSafeInteger(page.total_pages)||page.total_pages<0||page.total_pages>50)throw Error('POS chưa xác nhận đủ dữ liệu phân trang');}
