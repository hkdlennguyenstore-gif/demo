import type {State} from './payroll.ts';
export const SHOP_SETUP_ID='shop-accounts-2026-11-16';
export function setupShop(_s:State){return false;}
