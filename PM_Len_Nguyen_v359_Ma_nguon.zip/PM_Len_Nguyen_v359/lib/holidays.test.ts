import test from 'node:test';
import assert from 'node:assert/strict';
import {initial,payroll,hydrateState} from './payroll.ts';
import {employeeHolidays,holidayCalendar} from './holidays.ts';
function setup(){const s=initial('owner@test');const e=s.employees[0];e.salary=5200000;e.meal=25000;s.clocks=[{employee:e.id,date:'2026-11-16',start:'08:00',end:'16:30',note:''}];return {s,e};}
test('Future-only holidays: no earlier April/September/Tet, and no credit before the date',()=>{
 const {s,e}=setup();assert.equal(employeeHolidays(s,e,'2026-04','2027-01-01').length,0);assert.equal(employeeHolidays(s,e,'2026-09','2027-01-01').length,0);assert.equal(payroll(s,e,'2026-11','2026-11-23').holidayDays,0);assert.equal(payroll(s,e,'2026-11','2026-11-24').holidayDays,1);assert.equal(holidayCalendar(2027).filter(h=>h.date.startsWith('2027-02')).length,0);assert.equal(holidayCalendar(2027).filter(h=>h.date.startsWith('2027-09')).length,1);assert.equal(holidayCalendar(2027).find(h=>h.name==='Giỗ Tổ Hùng Vương')?.date,'2027-04-16');
});
test('Paid holiday is separate, no meal on a day off, replay cannot add duplicate punches',()=>{
 const {s,e}=setup(),before=JSON.stringify(s.clocks);const p=payroll(s,e,'2026-11','2026-11-24');assert.equal(p.holidayPay,200000);assert.equal(p.holidayDays,1);assert.equal(p.base,200000);assert.equal(p.meal,25000);assert.equal(p.holidayWorkedPay,0);assert.deepEqual(payroll(s,e,'2026-11','2026-11-24'),p);assert.equal(JSON.stringify(s.clocks),before);
});
test('Working a holiday replaces ordinary work pay with holiday pay and avoids double counting',()=>{
 const {s,e}=setup();s.clocks.push({employee:e.id,date:'2026-11-24',start:'08:00',end:'16:30',note:''});const p=payroll(s,e,'2026-11','2026-11-24');assert.equal(p.base,200000);assert.equal(p.holidayPay,200000);assert.equal(p.holidayWorkedPay,600000);assert.equal(p.holidayWorkedHours,8);assert.equal(p.otPay,0);assert.equal(p.meal,50000);
});
test('Future starters, expired contracts and archived staff do not accrue holidays; locked snapshots stay unchanged',()=>{
 const {s,e}=setup();e.contracts=[{id:'c',kind:'definite',start:'2026-11-01',end:'2026-11-20',signedOn:'2026-11-01',number:'x',note:'',updatedAt:''} as any];assert.equal(payroll(s,e,'2026-11','2026-11-24').holidayDays,0);e.contracts=[];e.active=false;assert.equal(payroll(s,e,'2026-11','2026-11-24').holidayDays,0);const saved=payroll(s,e,'2026-11','2026-11-17');s.locked=['2026-11'];s.closedPayroll={'2026-11':[saved]};const before=JSON.stringify(s.closedPayroll);hydrateState(s);assert.equal(JSON.stringify(s.closedPayroll),before);
});
