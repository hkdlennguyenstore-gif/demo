import {DatabaseSync} from 'node:sqlite';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {reconcileJt} from './gmail-jt';

function localDB(){
 const sql=new DatabaseSync(':memory:');
 sql.exec(`CREATE TABLE pm_orders(id PRIMARY KEY,channel,tracking,record);CREATE TABLE pm_finance_docs(id PRIMARY KEY,kind,date,channel,status,record);`);
 const db={prepare:(q:string)=>({bind:(...args:any[])=>({all:async()=>({results:sql.prepare(q).all(...args)})})})} as unknown as D1Database;
 return {sql,db};
}
test('J&T reports only unique exact tracking matches; preserves COD, unmatched and ambiguous fees; no posting',async()=>{
 const {sql,db}=localDB();
 sql.exec("INSERT INTO pm_orders VALUES('1','facebook','001','{}'),('2','shopee','002','{\"shippingFee\":15000}'),('3','tiktok2','003','{}'),('4','facebook','003','{}'),('5','facebook','5','{}')");
 const ins=sql.prepare("INSERT INTO pm_finance_docs VALUES(?,'expense','2026-11-15',?,'confirmed',?)");
 ins.run('a','facebook',JSON.stringify({category:'shipping',reference:'001'}));
 ins.run('b','shopee',JSON.stringify({category:'platform',expenseDetails:{fields:{'Mã vận đơn':'002'}}}));
 ins.run('c','facebook',JSON.stringify({category:'equipment',reference:'004'}));
 const trackingLines=['001','002','003','004','005'].map((tracking,i)=>({tracking,fee:(i+1)*5000,cod:200000}));
 const input={kind:'jt-statement',trackingLines,rows:5,total:75000,cod:1000000,fromDate:'2026-11-14',toDate:'2026-11-15'};
 const result=await reconcileJt(db,input);
 assert.equal(result?.valid,true);assert.deepEqual(result?.byShop,{facebook:{rows:1,fee:5000,cod:200000},shopee:{rows:1,fee:10000,cod:200000}});
 assert.deepEqual(result?.ambiguous,{rows:1,fee:15000,cod:200000});assert.deepEqual(result?.missing,{rows:2,fee:45000,cod:400000});
 assert.deepEqual(result?.posFeeEvidence,{candidateOrders:1,withoutFeeFields:1,fields:['shippingFee'],reconciledDelta:null});
 assert.deepEqual(result?.ledgerOverlap,{rows:2,fee:15000,cod:400000});assert.deepEqual(result?.samePeriodExpenseCounts,{facebook:1,shopee:1});
 assert.equal((await reconcileJt(db,{...input,total:65000}))?.valid,false);
 assert.equal((await reconcileJt(db,{...input,trackingLines:trackingLines.map(r=>({...r,tracking:'same'}))}))?.valid,false);
 assert.equal(sql.prepare('SELECT count(*) n FROM pm_finance_docs').get()!.n,3);
});
