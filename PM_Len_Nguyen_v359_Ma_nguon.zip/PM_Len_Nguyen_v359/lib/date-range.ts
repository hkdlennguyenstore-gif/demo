export type DateRange={from:string,to:string,fromTime?:string,toTime?:string};
export function checkedDate(value:string){if(!/^20\d{2}-\d{2}-\d{2}$/.test(value)||!Number.isFinite(Date.parse(value+'T12:00:00Z'))||new Date(value+'T12:00:00Z').toISOString().slice(0,10)!==value)throw Error('Ngày không hợp lệ');return value;}
export function readDateRange(params:URLSearchParams,fallbackMonth=''):DateRange{let from=params.get('from')||'',to=params.get('to')||'';const month=params.get('month')||fallbackMonth;if(params.get('range')==='all')return {from:'',to:''};if(month&&!from&&!to){if(!/^20\d{2}-(0[1-9]|1[0-2])$/.test(month))throw Error('Tháng không hợp lệ');from=month+'-01';to=new Date(Date.UTC(Number(month.slice(0,4)),Number(month.slice(5)),0)).toISOString().slice(0,10);}if(from)checkedDate(from);if(to)checkedDate(to);if(from&&to&&from>to)throw Error('Ngày bắt đầu không được sau ngày kết thúc');const fromTime=params.get('fromTime')||'',toTime=params.get('toTime')||'';
for(const time of [fromTime,toTime])if(time&&!/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/.test(time))throw Error('Giờ không hợp lệ');
if((fromTime&&!from)||(toTime&&!to))throw Error('Chọn ngày tương ứng với giờ lọc');
if(from&&from===to&&(fromTime||'00:00')>(toTime||'23:59'))throw Error('Giờ bắt đầu không được sau giờ kết thúc');
return {from,to,...(fromTime?{fromTime}:{}),...(toTime?{toTime}:{})};}
export const withinRange=(date:string,r:DateRange)=>Boolean(date)&&(!r.from||date>=r.from)&&(!r.to||date<=r.to);
export const rangeQuery=(r:DateRange)=>new URLSearchParams(r.from||r.to?{from:r.from,to:r.to,...(r.fromTime?{fromTime:r.fromTime}:{}),...(r.toTime?{toTime:r.toTime}:{})}:{range:'all'}).toString();
export const rangeLabel=(r:DateRange)=>!r.from&&!r.to?'Tất cả thời gian':(r.from||'…').split('-').reverse().join('/')+(r.fromTime?' '+r.fromTime:'')+' – '+(r.to||'…').split('-').reverse().join('/')+(r.toTime?' '+r.toTime:'');
