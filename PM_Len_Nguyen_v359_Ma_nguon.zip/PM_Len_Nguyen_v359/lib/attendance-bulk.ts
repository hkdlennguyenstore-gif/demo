import {isAttendanceMonth,isAttendanceStart} from './attendance-month';
import {checkedDate} from './date-range';

export const bulkRosterLimit=50;
export type BulkSchedule={month:string;days:string[];employees:string[];start:string};
export type BulkOutcome={changed:number;leave:number;off:number;existing:number;locked:number;total:number};
export function readBulkSchedule(value:unknown):BulkSchedule{
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).sort().join(',')!=='days,employees,month,start')throw Error('Chọn tháng, ngày, tên nhân viên và giờ bắt đầu.');
 const x=value as Record<string,unknown>,{month,days,employees,start}=x;
 if(typeof month!=='string'||!isAttendanceMonth(month)||!isAttendanceStart(start))throw Error('Chọn tháng và giờ bắt đầu hợp lệ theo định dạng 24 giờ.');
 if(!Array.isArray(days)||days.length<1||days.length>31||!days.every(d=>typeof d==='string'&&d.startsWith(month+'-')))throw Error('Chọn ít nhất một ngày trong đúng tháng đang mở.');
 const validDays=[...new Set<string>(days.map(checkedDate))].sort();
 if(!Array.isArray(employees)||employees.length<1||employees.length>bulkRosterLimit||!employees.every(id=>typeof id==='string'&&id.length>=1&&id.length<=100))throw Error('Chọn từ 1 đến '+bulkRosterLimit+' nhân viên.');
 return {month,days:validDays,employees:[...new Set<string>(employees)].sort(),start};
}
