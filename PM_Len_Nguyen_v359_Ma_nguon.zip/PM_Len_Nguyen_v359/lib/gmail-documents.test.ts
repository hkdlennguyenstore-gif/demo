import {DatabaseSync} from 'node:sqlite';
import assert from 'node:assert/strict';
import test from 'node:test';
import {readFileSync} from 'node:fs';
import {gmailSchema,saveGmailDocuments,reportGmailDocuments} from './gmail-documents';

function localDB(){
 const sql=new DatabaseSync(':memory:');
 sql.exec(gmailSchema.join(';')+';'+readFileSync('drizzle/0001_bouncy_silverclaw.sql','utf8')+`
 CREATE TABLE gmail_evidence(id PRIMARY KEY,received,subject,sender,digest,size);
 CREATE TABLE gmail_invoice_lines(item PRIMARY KEY,details);CREATE TABLE gmail_jt_checks(item PRIMARY KEY,summary);
 CREATE TABLE gmail_activity(lane PRIMARY KEY,success,detail,error);
 CREATE TABLE gmail_link_files(itemId PRIMARY KEY,blobKey,name);
 CREATE TABLE pm_purchase_docs(id PRIMARY KEY,date,total,active,number,supplier,kind);
 CREATE TABLE pm_purchase_suppliers(id PRIMARY KEY,name);
 CREATE TABLE app_state(id PRIMARY KEY,value,version);`);
 function prepare(q:string, args:any[]=[]):any{
  return {bind:(...a:any[])=>prepare(q,a),all:async()=>({results:sql.prepare(q).all(...args)}),first:async()=>sql.prepare(q).get(...args),run:()=>sql.prepare(q).run(...args)};
 }
 const db={prepare,batch:async(stmts:any[])=>{sql.exec('BEGIN');try{stmts.forEach(s=>s.run());sql.exec('COMMIT');}catch(e){sql.exec('ROLLBACK');throw e;}}} as unknown as D1Database;
 return {sql,db};
}
test('XML matched/deduplicated across Gmail, finance and purchasing; no COD/prepaid posting; legacy visible',async()=>{
 const {db,sql}=localDB();
 const base={name:'phi.xml',sha256:'8'.repeat(64),invoice:{vendor:'Công ty điện',vendorTaxId:'0312345678',buyerName:'Hộ kinh doanh Lên Nguyễn Store',series:'C26',number:'001',date:'2026-11-01',currency:'VND',total:'850000',descriptions:['Tiền điện tháng 10/2026 · Chi phí chung'],adjusted:false}};
 async function send(id:string, a:any=base,subject='Hóa đơn'){
   const mail={id,subject,sender:'vendor@example.com',digest:'f'.repeat(64)};
   sql.prepare('INSERT OR IGNORE INTO gmail_evidence VALUES(?,?,?,?,?,?)').run(id,'2026-11-02',subject,mail.sender,mail.digest,120);
   await saveGmailDocuments(db,mail,{bodyText:'',attachments:[a],links:[]});
 }
 await send('one');await send('one');await send('two');
 assert.equal(sql.prepare('SELECT count(*) AS n FROM pm_finance_docs').get()!.n,1);
 const actual=sql.prepare('SELECT * FROM pm_finance_docs').get()!;
 assert.equal(actual.date,'2026-10-01');assert.equal(JSON.parse(String(actual.record)).deductibility,'pending');assert.equal(JSON.parse(String(actual.record)).paid,0);
 const rep=await reportGmailDocuments(db,new URLSearchParams('month=2026-10'));
 assert.equal(rep.total,2);assert.equal(rep.monthly[0].postedAmount,850000);assert.equal(rep.monthly[0].amount,850000);assert.equal(rep.monthly[0].linked,1);
 const item=(number:string,desc:string)=>({...base,sha256:(Number(number)%10).toString().repeat(64),invoice:{...base.invoice,number,descriptions:[desc],total:'123456'}});
 await send('three',item('003','Đối soát COD tháng 11/2026 · Chi phí chung'));
 await send('four',item('004','Thiết bị trả trước tháng 11/2026 · Chi phí chung'));
 assert.equal(sql.prepare("SELECT count(*) n FROM gmail_documents WHERE state='pending'").get()!.n,2);
 sql.exec("INSERT INTO pm_purchase_suppliers VALUES('v','Công ty điện');INSERT INTO pm_purchase_docs VALUES('nh','2026-11-01',123456,1,'005','v','purchase')");
 await send('five',item('005','Nhập hàng quần jean'));
 assert.equal(sql.prepare("SELECT targetId FROM gmail_documents WHERE mailId='five'").get()!.targetId,'nh');
 sql.exec("INSERT INTO gmail_evidence VALUES('legacy','2026-11-18','Đối soát','J&T','x',120)");
 assert.equal((await reportGmailDocuments(db,new URLSearchParams('state=pending&source=J%26T'))).total,1);
 assert.equal(sql.prepare('SELECT count(*) n FROM pm_finance_docs').get()!.n,1);
});

test('links independently recorded manual cost and a matching Drive invoice; retains conflicting supplier for review',async()=>{
 const {sql,db}=localDB();
 sql.exec("CREATE TABLE pm_drive_ads_sources(id PRIMARY KEY,record)");
 const vendor='TikTok',number='VNTT202600003';
 sql.prepare('INSERT INTO pm_drive_ads_sources VALUES(?,?)').run('catalog',JSON.stringify({proofs:[{invoice:number,date:'2026-11-01',total:357000,channel:'tiktok2',fileId:'file-verified-by-drive-import'}]}));
 const manual={date:'2026-10-05',amount:600000,counterparty:'EVN',reference:'1234'};
 sql.prepare('INSERT INTO pm_finance_docs VALUES(?,?,?,?,?,?,?,?,?)').run('manual','expense',manual.date,manual.date,'shared','confirmed',JSON.stringify(manual),2,null);
 async function send(id:string,reference:string,vendorName:string,total:number,date:string,desc:string){
  sql.prepare('INSERT INTO gmail_evidence VALUES(?,?,?,?,?,?)').run(id,date,'Hoá đơn',vendorName,'digest',200);
  await saveGmailDocuments(db,{id,subject:'Hóa đơn',sender:'Shop',digest:'digest'},{attachments:[{sha256:(id==='drive'?'2':'3').repeat(64),invoice:{vendor:vendorName,number:reference,total,date,descriptions:[desc],currency:'VND'}}]});
 }
 await send('drive',number,vendor,357000,'2026-11-01','Quảng cáo TikTok 2');
 await send('manualmail','1234','EVN',600000,manual.date,'Tiền điện');
 await send('ambiguous','1234','Nhà cung cấp khác',600000,manual.date,'Tiền điện');
 const rows=sql.prepare("SELECT mailId,state,targetType,targetId FROM gmail_documents ORDER BY rowid").all();
 assert.equal(rows[0].targetType,'drive-invoice');assert.equal(rows[1].targetId,'manual');
 assert.equal(rows[2].state,'pending');assert.equal(sql.prepare('SELECT count(*) n FROM pm_finance_docs').get()!.n,1);
});
