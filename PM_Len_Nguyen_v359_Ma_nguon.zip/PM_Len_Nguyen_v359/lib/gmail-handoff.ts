type Candidate={id:string;sha256:string;size:number};

export async function verifyHistoricalMonth(db:D1Database,input:unknown){
  if(!input || typeof input!=='object')throw Error('Thiếu danh sách kiểm tra');
  const data=input as {month:string;scanned:number;candidates:Candidate[]};
  if(!/^2026-(0[4-9]|10|11)$/.test(data.month)||!Number.isSafeInteger(data.scanned)||data.scanned<0||
     !Array.isArray(data.candidates)||data.candidates.length>data.scanned||data.candidates.length>10000)throw Error('Danh sách kiểm tra không hợp lệ');
  const seen=new Set<string>();
  for(const row of data.candidates){
    if(!row||!/^\w{8,40}$/.test(row.id)||!Number.isSafeInteger(row.size)||row.size<1||!/^[a-f0-9]{64}$/.test(row.sha256)||seen.has(row.id))throw Error('Mã thư hoặc dấu kiểm tra không hợp lệ');
    seen.add(row.id);
  }
  const originals=await db.prepare("SELECT id,digest,size FROM gmail_evidence WHERE strftime('%Y-%m',received,'+7 hours')=? AND received < '2026-11-19T17:00:00.000Z'").bind(data.month).all<{id:string;digest:string;size:number}>();
  const byId=new Map(originals.results.map(r=>[r.id,r]));
  const verified=data.candidates.filter(c=>byId.get(c.id)?.digest===c.sha256 && byId.get(c.id)?.size===c.size).length;
  if(verified!==seen.size)return {ok:false,verified,expected:seen.size};
  const checked=new Date().toISOString();
  await db.prepare('INSERT INTO gmail_handoff(month,scanned,candidates,verified,checked) VALUES(?,?,?,?,?) ON CONFLICT(month) DO UPDATE SET scanned=excluded.scanned,candidates=excluded.candidates,verified=excluded.verified,checked=excluded.checked')
    .bind(data.month,data.scanned,seen.size,verified,checked).run();
  return {ok:true,month:data.month,verified,checked};
}
