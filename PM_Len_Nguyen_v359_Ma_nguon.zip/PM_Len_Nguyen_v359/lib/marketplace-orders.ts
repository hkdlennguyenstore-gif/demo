import {statusNames,utcStamp,vnDay,trackingCode} from './orders.ts';

// Verified against POS connected accounts and the source workbook's Ánh xạ shop.
export const marketplaceAccounts = [
 {channel:'tiktok1',source:'-9',account:'400050288',shopId:'7494549204538985115',shopCode:'VNLC3LWLRX',name:'Len Nguyen Store'},
 {channel:'tiktok2',source:'-9',account:'100046473',shopId:'7494924027339376972',shopCode:'VNLCFMLL2E',name:'Lên Nguyễn Store.'},
 {channel:'shopee',source:'-3',account:'100047072',shopId:'736225350',name:'Quần Jean Lên Nguyễn Store'},
];
export const marketplaceNote='Đơn và trạng thái đọc từ POS. TikTok HHTT chưa có mã vận đơn trả về riêng trong API đã kiểm tra; không dùng mã giao ban đầu thay mã trả về. Hàng về kho vẫn xác nhận bằng lượt quét.';
export function recentOrderStart(now=new Date()){const day=vnDay(now);return new Date(Date.parse(day+'T00:00:00Z')-29*86400000).toISOString().slice(0,10);}
export function normalizeMarketplace(o:any,shop:string){
 const account=marketplaceAccounts.find(a=>a.account===String(o.account)&&a.source===String(o.order_sources));
 if(!account)return null;
 if(String(o.shop_id)!==shop)throw Error('POS trả sai cửa hàng');
 if(typeof o.id==='number'&&!Number.isSafeInteger(o.id))throw Error('Mã đơn sàn mất độ chính xác');
 const sourceId=String(o.id||'');if(!/^[A-Za-z0-9_-]{4,100}$/.test(sourceId))throw Error('Mã đơn sàn không hợp lệ');
 const created=utcStamp(o.inserted_at),updated=utcStamp(o.updated_at||o.inserted_at),quantity=Number(o.total_quantity??0),status=Number(o.status);
 if(!Number.isSafeInteger(quantity)||quantity<0||!Number.isInteger(status))throw Error('POS trả số lượng/trạng thái không hợp lệ');
 let tracking='';const raw=o.partner?.extend_code||o.partner?.order_number_vtp;if(raw)tracking=trackingCode(raw);
 const events=Array.isArray(o.partner?.extend_update)?o.partner.extend_update:[];
 const carrierReturn=events.some((e:any)=>/return(?:ed|ing)? (?:package|to|parcel)|hoàn về|chuyển hoàn|trả về người gửi/i.test(String(e.status||e.description||'')));
 const deliveredCustomer=events.some((e:any)=>Number(e.action_code)===50101||/recipient:\s*customer|giao.*thành công/i.test(String(e.status||e.description||'')));
 // Status 4 alone also occurs on after-sale refunds; it cannot identify the return parcel.
 const expectedGroup=tracking&&[4,5].includes(status)&&carrierReturn&&!deliveredCustomer?(account.channel==='shopee'?'shopee':'delivery'):null;
 return {id:'pos:'+shop+':'+sourceId,channel:account.channel,sourceId,number:sourceId,date:vnDay(new Date(created)),created,updated,status,statusName:statusNames[status]||'Trạng thái '+status,quantity,tracking,carrier:String(o.partner?.partner_name||''),staff:'Hệ thống sàn',source:'Pancake POS',account:account.account,accountName:account.name,marketplaceShopId:account.shopId,carrierReturn,deliveredCustomer,expectedGroup,returnNeedsReview:[4,5,15].includes(status)&&!expectedGroup,returnNote:[4,5,15].includes(status)&&!expectedGroup?'Chờ mã vận đơn trả về hoặc hành trình hoàn rõ ràng':null};
}
