import {attendanceAccess,attendanceBatch,kioskEmployee,unlockedSchedule} from './attendance-access';
import {hasLeaveOverlap,leaveRange} from './attendance-leave-range';
import type {State} from './payroll';

export function leaveReason(value:unknown,required=true){
 if(typeof value!=='string'||value.length>500||value.includes('\0'))throw Error('Ghi tối đa 500 ký tự.');
 const trimmed=value.trim();
 if(required&&!trimmed)throw Error('Ghi lý do xin nghỉ.');
 return trimmed;
}
const auditRow=(db:D1Database,id:string)=>db.prepare('SELECT actor,action,record FROM pm_order_actions WHERE id=?').bind(id).first<{actor:string;action:string;record:string}>();
function checkedAudit(row:{actor:string;action:string;record:string},actor:string,action:string,matches:(v:any)=>boolean){
 if(row.actor.toLowerCase()!==actor||row.action!==action||!matches(JSON.parse(row.record)))throw Error('Mã yêu cầu đã dùng cho nội dung khác.');
}
export async function submitLeaveRange(db:D1Database,s:State,email:string,id:string,x:{employee:unknown;from:unknown;to:unknown;reason:unknown},now:string,authValue:string,mode:false|true|'admin-assisted'=false){
 const {from,to}=leaveRange(x.from,x.to),note=leaveReason(x.reason),actor=email.toLowerCase();
 const kiosk=mode===true,assisted=mode==='admin-assisted';
 if(assisted&&!attendanceAccess(s,email).admin)throw Error('Chỉ Chủ shop hoặc Quản trị viên được gửi hộ nhân viên.');
 const employee=kiosk?kioskEmployee(s,email,x.employee):assisted?s.employees.find(e=>e.active&&e.id===x.employee):attendanceAccess(s,email).employee;
 if(!employee||employee.id!==x.employee)throw Error(assisted?'Chọn nhân viên đang hoạt động trong PM.':'Chỉ được gửi đơn nghỉ cho chính mình bằng tài khoản cá nhân.');
 const action=kiosk?'Xin nghỉ từ máy chung (khoảng ngày)':assisted?'Gửi hộ yêu cầu nghỉ':'Xin nghỉ theo khoảng ngày';
 const verify=(row:NonNullable<Awaited<ReturnType<typeof auditRow>>>)=>checkedAudit(row,actor,action,v=>v.employee===employee.id&&v.date===from&&v.to===to&&v.note===note);
 const prior=await auditRow(db,id);if(prior){verify(prior);return {ok:true};}
 unlockedSchedule(s,from,to);
 const record=JSON.stringify({date:from,to,employee:employee.id,name:employee.name,note,actor,requestedAt:now,rangeVersion:1,...(kiosk?{source:'shared-clock',identityVerified:false}:assisted?{source:'admin-assisted',identityVerified:false}:{})});
 await attendanceBatch(db,authValue,from,[
  db.prepare("INSERT INTO pm_order_leave SELECT ?,?,?,'pending',? WHERE NOT EXISTS(SELECT 1 FROM pm_order_actions WHERE id=?) AND NOT EXISTS("+hasLeaveOverlap+") ON CONFLICT(id) DO NOTHING").bind(id,from,employee.id,record,id,employee.id,to,from),
  db.prepare('INSERT INTO pm_order_actions SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM pm_order_leave WHERE id=? AND record=?) ON CONFLICT(id) DO NOTHING').bind(id,now,actor,action,record,id,record)
 ],to);
 const saved=await auditRow(db,id);if(saved)verify(saved);
 else if(!kiosk)throw Error('Đã có đơn nghỉ chờ duyệt hoặc đã duyệt trùng một phần thời gian. Kiểm tra trạng thái trước khi gửi.');
 // A kiosk gives an identical acknowledgement even when an overlapping request already exists.
 return {ok:true};
}

export async function reviewAttendanceLeave(db:D1Database,s:State,email:string,id:string,x:{id:string;approved:boolean;note:string},now:string,authValue:string){
 if(!attendanceAccess(s,email).admin)throw Error('Chỉ Chủ shop hoặc Quản trị viên được duyệt nghỉ.');
 const actor=email.toLowerCase(),action='Duyệt yêu cầu nghỉ',status=x.approved?'approved':'rejected';
 const verify=(row:NonNullable<Awaited<ReturnType<typeof auditRow>>>)=>checkedAudit(row,actor,action,v=>v.id===x.id&&v.status===status&&(v.note===undefined||v.note===x.note));
 const prior=await auditRow(db,id);if(prior){verify(prior);return {ok:true,replayed:true};}
 const old=await db.prepare("SELECT date,employee,record FROM pm_order_leave WHERE id=? AND status='pending'").bind(x.id).first<{date:string;employee:string;record:string}>();
 if(!old){const replay=await auditRow(db,id);if(replay){verify(replay);return {ok:true,replayed:true};}throw Error('Yêu cầu đã được xử lý hoặc không còn tồn tại.');}
 const previous=JSON.parse(old.record),{from,to,days}=leaveRange(old.date,previous.to||old.date);
 if(!x.approved&&previous.rangeVersion===1&&!x.note)throw Error('Ghi phản hồi để nhân viên biết lý do không được duyệt.');
 unlockedSchedule(s,from,to);
 const audit=JSON.stringify({id:x.id,status,note:x.note,from,to});
 const pending="EXISTS(SELECT 1 FROM pm_order_leave WHERE id=? AND status='pending' AND record=?)";
 const free=x.approved?" AND NOT EXISTS(SELECT 1 FROM pm_order_schedule WHERE employee=? AND date BETWEEN ? AND ? AND json_extract(record,'$.kind')='leave')":"";
 const statements=[db.prepare('INSERT INTO pm_order_actions SELECT ?,?,?,?,? WHERE '+pending+free+' ON CONFLICT(id) DO NOTHING')
  .bind(id,now,actor,action,audit,x.id,old.record,...(x.approved?[old.employee,from,to]:[]))];
 const authorized="EXISTS(SELECT 1 FROM pm_order_actions WHERE id=? AND actor=? AND action=? AND record=?)";
 if(x.approved){
  const fields=JSON.stringify({employee:old.employee,name:previous.name,kind:'leave',note:'Nghỉ đã được duyệt',sourceLeaveId:x.id,actor,updatedAt:now});
  statements.push(db.prepare("INSERT INTO pm_order_schedule(id,date,employee,version,record) SELECT CASE WHEN ?=1 THEN ? ELSE ?||':'||value END,value,?,0,json_set(json(?),'$.date',value) FROM json_each(?) WHERE "+authorized+' AND '+pending+
   " ON CONFLICT(date,employee) DO UPDATE SET version=pm_order_schedule.version+1,record=json_patch(pm_order_schedule.record,excluded.record)")
   // Single and ranged requests both need unique primary keys for all dates.
   .bind(days.length,'leave:'+x.id,'leave:'+x.id,old.employee,fields,JSON.stringify(days),id,actor,action,audit,x.id,old.record));
 }
 statements.push(db.prepare("UPDATE pm_order_leave SET status=?,record=? WHERE id=? AND status='pending' AND record=? AND "+authorized)
  .bind(status,JSON.stringify({...previous,reviewedBy:actor,reviewedAt:now,reviewNote:x.note}),x.id,old.record,id,actor,action,audit));
 const results=await attendanceBatch(db,authValue,from,statements,to);
 const saved=await auditRow(db,id);
 if(saved){verify(saved);return results.at(-1)?.meta.changes?{ok:true}:{ok:true,replayed:true};}
 throw Error('Yêu cầu đã thay đổi hoặc trùng ngày nghỉ đã duyệt. Tải lại để kiểm tra; chưa ghi gì.');
}
