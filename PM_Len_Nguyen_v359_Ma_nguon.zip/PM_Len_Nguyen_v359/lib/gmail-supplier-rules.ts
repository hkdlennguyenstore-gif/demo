import {digest} from './a3-access';

export type SupplierRule = {id:string;names:string[];category:string;label:string;note:string};
export const approvedSupplierRules:SupplierRule[]=[
 {id:'dream-hub',names:['CÔNG TY TNHH DREAM HUB MEDIA'],category:'operations',label:'Dịch vụ vận hành TikTok Shop; phần Ads theo chứng từ',note:'Chờ căn cứ tách phần vận hành và quảng cáo khi hóa đơn gồm cả hai.'},
 {id:'jt',names:['CÔNG TY TNHH MỘT THÀNH VIÊN CHUYỂN PHÁT NHANH THUẬN PHONG - CHI NHÁNH THÀNH PHỐ HỒ CHÍ MINH','J&T Express · Chuyển phát nhanh Thuận Phong'],category:'shipping',label:'Giao hàng và hoàn hàng',note:'Đối chiếu cước theo vận đơn, tách COD và liên kết khoản đã có.'},
 {id:'pancake',names:['CÔNG TY TNHH PANCAKE VIỆT NAM'],category:'software',label:'Phần mềm, hạ tầng',note:'Gói trả trước cần căn cứ kỳ phân bổ.'},
 {id:'wevi',names:['CÔNG TY TNHH TRUYỀN THÔNG WEVI TECH'],category:'ads',label:'Quảng cáo · phí tư vấn TikTok',note:'Đối chiếu kỳ dịch vụ, shop chịu phí và hóa đơn đã có.'},
 {id:'di-dong-viet',names:['Công ty Cổ Phần Công nghệ Di Động Việt'],category:'equipment',label:'Thiết bị, dụng cụ',note:'Chờ hồ sơ tài sản và thời gian sử dụng.'},
 {id:'hoang-ngoc-loi',names:['HỘ KINH DOANH HOÀNG NGỌC LỢI'],category:'ads',label:'Quảng cáo · phí dịch vụ',note:'Đối chiếu từng hóa đơn và khoản quảng cáo đã ghi nhận.'},
 {id:'nguyen-huy-minh',names:['HỘ KINH DOANH NGUYỄN HUY MINH'],category:'cogs',label:'Nhập hàng · đối chiếu kho, công nợ',note:'Hóa đơn 4 thay số 3, hai thư gửi số 4 cùng một hồ sơ. Chờ phiếu nhập.'},
 {id:'runway',names:['Runway AI, Inc.'],category:'software',label:'Phần mềm, hạ tầng',note:'Tín dụng trả trước cần kỳ phân bổ, liên kết biên nhận cùng giao dịch.'},
 {id:'shopee',names:['SHOPEE'],category:'platform',label:'Phí sàn, thanh toán',note:'Khớp báo cáo quyết toán đúng shop trước khi ghi phí.'},
 {id:'tiktok',names:['TIKTOK PTE. LTD.'],category:'ads',label:'Quảng cáo · chứng từ tiền nạp',note:'Đối chứng tiền nạp theo bên mua. Chi tiêu theo báo cáo thực chạy.'}
];
const fold=(s:string)=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').toLowerCase().replace(/[^a-z0-9]/g,'');
export function supplierRule(vendor:string){return approvedSupplierRules.find(r=>r.names.some(n=>fold(n)===fold(vendor)));}
export function supplierCategory(rule:SupplierRule,text:string){
 if(rule.id!=='dream-hub')return rule.category;
 const normalized=fold(text),ads=/quangcao|advertis|facebookads|tiktokads/.test(normalized),operations=/vanhanh|operation/.test(normalized);
 return ads&&operations?'':ads?'ads':operations?'operations':'';
}
export const supplierRuleSchema=[
 'CREATE TABLE IF NOT EXISTS gmail_supplier_approvals(id TEXT PRIMARY KEY,approvedAt TEXT NOT NULL,actor TEXT NOT NULL,rules TEXT NOT NULL,backupKey TEXT NOT NULL,report TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS gmail_supplier_category_audit(approvalId TEXT NOT NULL,itemId TEXT NOT NULL,beforeCategory TEXT NOT NULL,afterCategory TEXT NOT NULL,changed TEXT NOT NULL,reason TEXT NOT NULL,PRIMARY KEY(approvalId,itemId))'
];
export const approvalId='supplier-map-owner-2026-11-20';
export async function supplierApproval(db:D1Database){return db.prepare('SELECT * FROM gmail_supplier_approvals WHERE id=?').bind(approvalId).first<any>();}
export async function supplierSnapshot(db:D1Database){
 const [items,finance]=await Promise.all([
  db.prepare('SELECT d.*,f.facts FROM gmail_documents d LEFT JOIN gmail_document_facts f ON f.itemId=d.id ORDER BY d.id').all<any>(),
  db.prepare("SELECT count(*) n,COALESCE(sum(json_extract(record,'$.amount')),0) amount FROM pm_finance_docs WHERE kind='expense'").first()
 ]);
 const changes:any[]=[],counts:Record<string,number>={};
 for(const row of items.results){
  const facts=row.facts?JSON.parse(row.facts):{},invoice=facts.invoice||{},rule=supplierRule(invoice.vendor||row.source);
  if(!rule)continue;
  counts[rule.id]=(counts[rule.id]||0)+1;
  const category=supplierCategory(rule,(invoice.descriptions||[]).join(' '));
  if(category!==row.category)changes.push({id:row.id,before:row.category,after:category,rule:rule.id,state:row.state});
 }
 return {items:items.results,finance,changes,counts,hash:await digest(JSON.stringify(items.results))};
}
export async function applySupplierApproval(db:D1Database,backupKey:string,snapshot:Awaited<ReturnType<typeof supplierSnapshot>>){
 const now=new Date().toISOString();
 const report={suppliers:11,rules:approvedSupplierRules.length,matched:snapshot.counts,changed:snapshot.changes.length,financeBefore:snapshot.finance};
 const statements=[db.prepare('INSERT INTO gmail_supplier_approvals VALUES(?,?,?,?,?,?)').bind(approvalId,now,'Chủ shop duyệt bảng Doi-chieu-nha-cung-cap-PM.xlsx',JSON.stringify(approvedSupplierRules),backupKey,JSON.stringify(report))];
 for(const c of snapshot.changes){
  if(c.state==='posted')throw Error('Khoản đã ghi sổ cần điều chỉnh riêng');
  statements.push(db.prepare('INSERT INTO gmail_supplier_category_audit VALUES(?,?,?,?,?,?)').bind(approvalId,c.id,c.before,c.after,now,'Chủ shop duyệt ánh xạ nhà cung cấp · '+c.rule),db.prepare('UPDATE gmail_documents SET category=? WHERE id=? AND category=? AND state<>\'posted\'').bind(c.after,c.id,c.before));
 }
 await db.batch(statements);
 return report;
}
