import {permission} from "./payroll.ts";
import test from "node:test";
import assert from 'node:assert/strict';
import {initial,hours,payroll,view} from './payroll.ts';
const s=initial('owner@example.com'),e=s.employees[1];e.salary=7800000;
assert.deepEqual(hours({employee:e.id,date:'2026-11-14',start:'07:55',end:'18:00',note:''},e),{regular:8,overtime:1.5,missing:false});
assert.equal(hours({employee:e.id,date:'2026-11-14',start:'08:05',end:'16:30',note:''},e).regular,7.92);
assert.equal(hours({employee:'nv3',date:'2026-11-14',start:'14:00',end:'22:00',note:''},s.employees[2]).regular,8);
assert.equal(hours({employee:'nv3',date:'2026-11-14',start:'14:00',end:'23:30',note:''},s.employees[2]).overtime,1.5);
s.clocks.push({employee:e.id,date:'2026-11-14',start:'08:00',end:'18:00',note:''});
s.adjustments.push({employee:e.id,month:'2026-11',allowance:100000,responsibility:200000,bonus:300000,orderBonus:50000,deduction:25000,advance:100000,note:''});
const p=payroll(s,e,'2026-11');assert.equal(p.base,300000);assert.equal(p.otPay,84375);assert.equal(p.net,947837);assert.equal(p.earned-p.net,100000);
s.members.push({email:'worker@example.com',role:'employee',employee:e.id},{email:'manager@example.com',role:'manager',employee:''});
const worker=view(s,'worker@example.com')!;assert.equal(worker.employees.length,1);assert.ok(!('salary' in worker.employees[0]));assert.equal(worker.adjustments.length,0);assert.equal(worker.audit.length,0);assert.ok(!JSON.stringify(view(s,'manager@example.com')).includes('7800000'));assert.equal(view(s,'unknown@example.com'),null);
console.log('Passed: shift, overtime, allowance, advance and salary privacy checks');

// Effective salary persists until a later effective month, including future raises and decreases.
const {salaryRate,rateConflict,hydrateState,payrollEmployees}=await import('./payroll.ts');
const ss=initial('boss@example.com'),ee=ss.employees[0];ee.salary=6500000;
const config={days:26,meal:38462,ot:1.5,attendanceBonus:200000,threshold:25.5,shift:'normal' as const,reason:'Test',updatedAt:'2026-11-16T00:00:00Z'};
ee.rates=[{...config,effectiveMonth:'2026-11',salary:7000000},{...config,effectiveMonth:'2026-12',salary:8000000},{...config,effectiveMonth:'2027-02',salary:6000000}];
assert.equal(salaryRate(ee,'2026-10').salary,6500000);
assert.equal(salaryRate(ee,'2026-11').salary,7000000);
assert.equal(salaryRate(ee,'2027-01').salary,8000000);
assert.equal(salaryRate(ee,'2027-02').salary,6000000);
assert.equal(salaryRate(ee,'2027-12').salary,6000000);
for(const month of ['2026-11','2026-12','2027-01','2027-02'])ss.clocks.push({employee:ee.id,date:month+'-01',start:'08:00',end:'16:30',note:''});
assert.equal(payroll(ss,ee,'2026-11').base,269231);
assert.equal(payroll(ss,ee,'2027-01').base,307692);
assert.equal(payroll(ss,ee,'2027-02').base,230769);
ss.locked=['2026-11'];assert.equal(rateConflict(ss,ee,'2026-11'),'2026-11');assert.equal(rateConflict(ss,ee,'2026-12'),undefined);assert.equal(rateConflict(ss,ee,'2026-10'),undefined);
hydrateState(ss);const frozen=JSON.stringify(ss.closedPayroll!['2026-11']);ee.active=false;ee.name='Tên mới';assert.equal(JSON.stringify(ss.closedPayroll!['2026-11']),frozen);assert.ok(payrollEmployees(ss,'2026-11').some(e=>e.id===ee.id));
ss.members.push({email:'warehouse@example.com',role:'manager',employee:''});const limited=JSON.stringify(view(ss,'warehouse@example.com'));assert.ok(!limited.includes('8000000'));assert.ok(!limited.includes('effectiveMonth'));assert.deepEqual(view(ss,'warehouse@example.com')?.closedPayroll,{});
console.log('Passed: persistent rates, future raises, decreases, locked months, archived employees and salary-history privacy');

import {insuranceAllocation} from './insurance.ts';
import {importSourceSalaries} from './source-import.ts';
test('Insurance allocation separates worker and employer, validates region and pending',()=>{
 const b=insuranceAllocation({status:'enrolled',base:5000000,region:2,reason:'HĐLĐ đã đối chiếu'},5000000,'2026-11');
 assert.equal(b.employeeTotal,525000);assert.equal(b.employerTotal,1075000);assert.equal(b.ready,true);
 assert.equal(insuranceAllocation(undefined,5000000,'2026-11').employeeTotal,0);
 assert.equal(insuranceAllocation(undefined,5000000,'2026-11').ready,false);
 assert.equal(insuranceAllocation({status:'enrolled',base:5000000,region:1,reason:'HĐLĐ'},5000000,'2026-11').ready,false);
 const cap=insuranceAllocation({status:'enrolled',base:200000000,region:2,reason:'HĐLĐ'},200000000,'2026-11');assert.equal(cap.socialBase,50600000);assert.equal(cap.unemploymentBase,94600000);
});
test('Source salaries import once and preserve prior months',()=>{
 const s=initial('owner@test.vn');assert.equal(importSourceSalaries(s),true);assert.equal(salaryRate(s.employees[0],'2026-11').salary,8000000);assert.equal(salaryRate(s.employees[4],'2026-12').salary,5000000);assert.equal(salaryRate(s.employees[0],'2026-10').salary,0);assert.equal(importSourceSalaries(s),false);
});

import {contractStatus,validateContract,currentContract} from './contracts.ts';
import {importNovember} from './november-import.ts';
test('Contract remaining days, expiry, indefinite and input validation',()=>{
 const c={id:'1',number:'HD01',kind:'fixed' as const,signedOn:'2026-01-01',start:'2026-01-01',end:'2026-11-30',note:'',updatedAt:''};validateContract(c);assert.equal(contractStatus(c,'2026-11-16').days,14);assert.equal(contractStatus(c,'2026-12-01').days,-1);assert.equal(contractStatus({...c,kind:'indefinite'},'2026-11-16').days,null);assert.throws(()=>validateContract({...c,end:'2025-01-01'}));assert.equal(currentContract([c,{...c,id:'2',start:'2027-01-01'}],'2026-11-16')?.id,'1');
});
test('Imported source calculation preserves A5 rounding and missing times',()=>{
 const s=initial('owner@test.vn'),e=s.employees[1];const c={employee:e.id,date:'2026-11-02',start:'07:58:56',end:'16:37:15',note:'',source:{sheet:'LenNguyen_Store',row:864,regular:8,overtime:.12}};assert.equal(hours(c,e).overtime,.12);assert.equal(hours({...c,end:''},e).missing,true);assert.throws(()=>importNovember(s,[]));
});
test('Separate probation has no insurance deduction and expires for month closing',()=>{
 const cfg={status:'probation' as const,base:5000000,region:1,reason:'HĐ thử việc riêng',probationStart:'2026-11-01',probationEnd:'2026-11-30'};
 const b=insuranceAllocation(cfg,5000000,'2026-11');assert.equal(b.employeeTotal,0);assert.equal(b.employerTotal,0);assert.equal(b.ready,true);assert.equal(insuranceAllocation(cfg,5000000,'2026-12').ready,false);assert.equal(insuranceAllocation({...cfg,probationStart:'2026-11-13'},5000000,'2026-11').ready,false);
 const s=initial('owner@test.vn');const e=s.employees[4];e.salary=5000000;e.insurance=cfg;s.clocks=[{employee:e.id,date:'2026-11-14',start:'08:00',end:'16:30',note:''}];const before=payroll(s,e,'2026-11');s.adjustments=[{employee:e.id,month:'2026-11',allowance:0,responsibility:0,bonus:0,orderBonus:0,deduction:0,advance:0,insuranceCash:100000,note:'Theo hồ sơ'}];const after=payroll(s,e,'2026-11');assert.equal(after.net-before.net,100000);assert.equal(after.employeeInsurance,0);
 const c={id:'p',kind:'probation' as const,number:'TV',signedOn:'2026-11-01',start:'2026-11-01',end:'2026-11-30',note:'',updatedAt:''};validateContract(c);assert.match(contractStatus(c,'2026-11-16').label,/Thử việc/);assert.throws(()=>validateContract({...c,end:''}));
});
import {clockView,recordPunch} from './terminal.ts';
test('Shared account sees all staff but no pay, notes, contracts or source hours',()=>{
 const s=initial('owner@test.vn');s.members.push({email:'shared@test.vn',role:'terminal',employee:''});s.employees[0].salary=8000000;s.clocks.push({employee:'nv1',date:'2026-11-15',start:'08:00',end:'16:30',note:'PRIVATE',source:{sheet:'x',row:1,regular:8,overtime:0}});const v=clockView(s,'shared@test.vn')!;assert.equal(v.employees.length,5);assert(!JSON.stringify(v).includes('8000000'));assert(!JSON.stringify(v).includes('PRIVATE'));assert(!JSON.stringify(v).includes('regular'));assert.equal(clockView(s,'unknown@test.vn'),null);
 const instant=new Date('2026-11-16T03:00:00Z');const p=recordPunch(s,'shared@test.vn',{employee:'nv2',field:'start'},instant);assert.equal(p.date,'2026-11-16');assert.equal(p.time,'10:00:00');assert.equal(recordPunch(s,'shared@test.vn',{employee:'nv2',field:'start'},new Date('2026-11-16T04:00:00Z')).duplicate,true);assert.equal(s.clocks.find(c=>c.employee==='nv2')?.start,'10:00:00');recordPunch(s,'shared@test.vn',{employee:'nv3',field:'start'},instant);assert.throws(()=>recordPunch(s,'shared@test.vn',{employee:'nv4',field:'end'},instant));s.locked.push('2026-11');assert.throws(()=>recordPunch(s,'shared@test.vn',{employee:'nv4',field:'start'},instant));
});
import {setupShop} from './shop-setup.ts';
import {canAccessModule} from './modules.ts';
test('Shop owner and shared employee are separate and setup preserves original editor',()=>{
 const s=initial('editor@test.vn');const before=JSON.stringify(s.employees);assert.equal(setupShop(s),true);assert.equal(setupShop(s),false);assert.equal(s.owner,'editor@test.vn');assert.equal(permission(s,'owner@example.invalid')?.role,'owner');assert.equal(permission(s,'editor@test.vn')?.role,'owner');assert.equal(permission(s,'staff@example.invalid')?.role,'terminal');assert.equal(JSON.stringify(s.employees),before);assert(canAccessModule('terminal','attendance'));assert(!canAccessModule('terminal','payroll'));assert(!canAccessModule('terminal','future-module'));const v=clockView(s,'staff@example.invalid')!;assert.equal(v.employees.length,5);assert(!JSON.stringify(v).includes('primaryOwnerEmail'));
});
