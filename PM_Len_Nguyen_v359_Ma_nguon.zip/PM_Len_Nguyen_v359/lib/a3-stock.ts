// A3 quantities come from the same current-stock calculation as Nhập kho.
export function stockTone(quantity:number|null){
 if(quantity===null)return 'retired';
 if(quantity===0)return 'empty';
 if(quantity<=10)return 'low';
 if(quantity<=20)return 'medium';
 return 'high';
}
export function a3StockRows(prices:any[],stock:any){
 const byCode=new Map<string,any>((stock?.rows||[]).map((r:any)=>[String(r.code).trim().toUpperCase(),r]));
 return prices.map(r=>{const entry=byCode.get(String(r.code).trim().toUpperCase());
 // No quantity on this tracking code means an old, unused code; retain its date and history.
 const remaining=entry?entry.remaining:null;
 return {...r,remaining,stockTone:stockTone(remaining)};
 }).sort((a,b)=>{
 const group=(n:number|null)=>n===null?2:n===0?1:0;
 return group(a.remaining)-group(b.remaining)||(b.remaining??0)-(a.remaining??0)||String(a.code).localeCompare(String(b.code),'vi',{numeric:true})||String(b.date||'').localeCompare(String(a.date||''))||String(a.id).localeCompare(String(b.id));
 });
}

export const a3StockFilters=['all','available','empty','low','medium','high','retired'] as const;
export type A3StockFilter=typeof a3StockFilters[number];
export function filterA3StockRows(rows:any[],filter:string){
 return filter==='available'?rows.filter(r=>r.remaining>0):a3StockFilters.includes(filter as A3StockFilter)&&filter!=='all'?rows.filter(r=>r.stockTone===filter):rows;
}
export function countA3StockRows(rows:any[]){
 return Object.fromEntries(a3StockFilters.map(key=>[key,filterA3StockRows(rows,key).length]));
}
