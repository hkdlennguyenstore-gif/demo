import {posGet} from './orders-store.ts';
import {sourceChannels,previousPeriod,relativeChange} from './order-source-summary.ts';
import {marketplaceAccounts} from './marketplace-orders.ts';
import {vnDay} from './orders.ts';
import type {DateRange} from './date-range.ts';
// Matches the shop's POS overview configuration verified on 17/11/2026.
export const posReportSettings={success_status:'1',success_record:'updated_at',returned_record:'updated_at',user_type:'assign'};
export function analyticsQuery(range:DateRange,now=new Date()){
 return {since:new Date((range.from||'2000-01-01')+'T'+(range.fromTime||'00:00')+':00+07:00').toISOString(),until:new Date((range.to||vnDay(now))+'T'+(range.toTime||'23:59')+':59+07:00').toISOString(),'split_by[]':'Order.source',...posReportSettings};
}
const metricKeys=['revenue','profit','sales','discount','confirmed','quantity'] as const;
export function mapPosSources(data:any[],previous:any[]|null){
 return sourceChannels.map(channel=>{
  const matches=(r:any)=>channel.id==='facebook'?String(r.order_sources)==='-1':marketplaceAccounts.some(a=>a.channel===channel.id&&String(r.account)===a.account&&String(r.order_sources)===a.source);
  const rows=data.filter(matches),old=previous?.filter(matches)||[];
  const sum=(rs:any[],section:string,key:string):number|null=>{
   if(!rs.length)return 0;
   // POS returns null sections for sources with no sales; never coerce an absent metric to zero.
   if(rs.some(r=>r[section]&& (r[section][key]===undefined||r[section][key]===null||!Number.isFinite(Number(r[section][key])))))return null;
   return rs.reduce((n,r)=>n+Number(r[section]?.[key]||0),0);
  };
  const values=(rs:any[])=>({revenue:sum(rs,'result','revenue'),profit:sum(rs,'result','profit'),sales:sum(rs,'result','sales'),discount:sum(rs,'result','discount'),confirmed:sum(rs,'success','order_count'),quantity:sum(rs,'success','product_count')});
  const current=values(rows),prior=values(old);
  return {...channel,shopId:marketplaceAccounts.find(a=>a.channel===channel.id)?.shopId,...current,...(Object.fromEntries(metricKeys.map(k=>[k+'Change',previous?relativeChange(current[k],prior[k]):null])) as Record<`${typeof metricKeys[number]}Change`,number|null>),ready:true,report:'pos',orders:sum(rows,'success','total_order_count'),allQuantity:null,statuses:[],returnedOrders:sum(rows,'returned','order_count'),returnedQuantity:sum(rows,'returned','product_count'),note:'Báo cáo Nguồn đơn của POS. Tiền lấy từ kết quả sau hoàn; đơn chốt và số lượng bán lấy từ phần hàng chốt, giống bảng POS. Lợi nhuận theo POS, chưa phải lợi nhuận ròng sau mọi chi phí của PM.'};
 });
}
export async function readPosSourceReport(config:{PANCAKE_API_KEY?:string,PANCAKE_SHOP_ID?:string},range:DateRange){
 if(!config.PANCAKE_API_KEY||!config.PANCAKE_SHOP_ID)throw Error('Chưa có kết nối báo cáo POS');
 const previous=range.fromTime||range.toTime?null:previousPeriod(range);
 const read=(r:DateRange)=>posGet(config.PANCAKE_API_KEY!,config.PANCAKE_SHOP_ID!,'analytics/sale',{...analyticsQuery(r),'select_fields[]':['revenue','profit','sales','discount','order_count','product_count','total_order_count']});
 const [current,old]=await Promise.all([read(range),previous?read(previous).catch(()=>null):Promise.resolve(null)]);
 if(current.pagination)throw Error('Báo cáo POS còn phân trang, chưa đủ dữ liệu để tổng hợp');
 return {rows:mapPosSources(current.data,old?.pagination?null:old?.data||null),previousRange:previous,comparisonAvailable:Boolean(old&&!old.pagination),report:'pos',range,updatedAt:new Date().toISOString(),settings:posReportSettings};
}

export async function readReturnedStock(config:{PANCAKE_API_KEY?:string,PANCAKE_SHOP_ID?:string},range:DateRange){
 if(!config.PANCAKE_API_KEY||!config.PANCAKE_SHOP_ID)throw Error('Chưa kết nối POS');
 const data=await posGet(config.PANCAKE_API_KEY,config.PANCAKE_SHOP_ID,'analytics/sale',{...analyticsQuery(range),'select_fields[]':['product_count','order_count']});
 if(data.pagination)throw Error('Báo cáo hoàn POS chưa đủ trang');
 return mapPosSources(data.data,null).map(r=>({shop:r.id,quantity:r.returnedQuantity,orders:r.returnedOrders}));
}
