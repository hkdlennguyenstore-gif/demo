import {flagteamApprovalKey,type ApprovedFee} from './flagteam-management';
import {digest} from './a3-access';
import {putSetting} from './expense-controls';
import {flagteamInvoiceDays} from './ads-costs';

type InvoiceProof={item:string;day:string;url:string;sha:string;number:string;issued:string;total:number};
export async function linkFlagteamPdfs(db:D1Database,config:{FLAGTEAM_ADS_LEDGER_URL?:string},proofs:InvoiceProof[]){
 if(!Array.isArray(proofs)||!proofs.length||proofs.length>40)throw Error('Số hóa đơn trong lô không hợp lệ');
 const month=String(proofs[0].day).slice(0,7);
 const days=await flagteamInvoiceDays(config,month);
 await db.prepare('CREATE TABLE IF NOT EXISTS gmail_flagteam_pdfs(item TEXT PRIMARY KEY,url TEXT NOT NULL UNIQUE,sha TEXT NOT NULL,day TEXT NOT NULL,fee INTEGER NOT NULL,total INTEGER NOT NULL)').run();
 let count=0;
 for(const p of proofs){
  if(!/^\d{4}-\d\d-\d\d$/.test(p.day)||!p.day.startsWith(month)||!/^\d+$/.test(p.number)||!/^\w{64}$/.test(p.sha))throw Error('Dữ liệu PDF không hợp lệ');
  const daily=days.find(d=>d.date===p.day);
  if(!daily||daily.invoice.length!==1||daily.invoice[0]!==p.url)throw Error('Không khớp liên kết PDF trong bảng phí '+p.day);
  const d=await db.prepare('SELECT d.*,i.details FROM gmail_documents d JOIN gmail_invoice_lines i ON i.item=d.id WHERE d.id=?').bind(p.item).first<any>();
  const bill=d&&JSON.parse(d.details);
  if(!d||!['pending','linked'].includes(d.state)||d.source!=='HỘ KINH DOANH HOÀNG NGỌC LỢI'||bill.buyer!=='087089000961'||bill.series!=='C26MYY'||d.currency!=='VND'||d.date!==p.issued||Number(d.reference)!==Number(p.number)||p.total!==bill.total||p.total!==d.amount)throw Error('Không khớp hóa đơn gốc '+p.number);
  if(d.targetType==='flagteam-approved' && d.state==='linked'){count++;continue;}
  const exact=daily.fee===p.total;
  const note='PDF trên dòng phí Flagteam '+p.day+' · HĐ '+d.reference+' · hóa đơn '+p.total.toLocaleString('vi-VN')+'đ, phí đại lý '+daily.fee.toLocaleString('vi-VN')+'đ. '+(exact?'Khớp số tiền.':'Chênh (hóa đơn trừ phí) '+(p.total-daily.fee).toLocaleString('vi-VN')+'đ. Chờ đối chiếu số chênh.');
  await db.batch([
   db.prepare('INSERT INTO gmail_flagteam_pdfs VALUES(?,?,?,?,?,?) ON CONFLICT(item) DO UPDATE SET url=excluded.url,sha=excluded.sha,day=excluded.day,fee=excluded.fee,total=excluded.total').bind(d.id,p.url,p.sha,p.day,daily.fee,p.total),
   db.prepare("UPDATE gmail_documents SET state=?,targetType='flagteam-pdf',targetId=?,category='ads',channel='facebook',month=?,reason=? WHERE id=?").bind(exact?'linked':'pending',p.url,month,note,d.id)
  ]);
  count++;
 }
 return {count};
}

export const flagteamSourceSchema='CREATE TABLE IF NOT EXISTS pm_flagteam_source_invoices(number TEXT PRIMARY KEY,issued TEXT NOT NULL,day TEXT NOT NULL,total INTEGER NOT NULL,fee INTEGER NOT NULL,sha TEXT NOT NULL UNIQUE,url TEXT NOT NULL UNIQUE)';

export async function saveFlagteamSource(db:D1Database,config:{BUCKET:R2Bucket;FLAGTEAM_ADS_LEDGER_URL?:string},p:InvoiceProof){
 if(!/^\d{1,12}$/.test(p.number)||!/^20\d\d-\d\d-\d\d$/.test(p.issued)||!/^20\d\d-\d\d-\d\d$/.test(p.day)||
  !Number.isSafeInteger(p.total)||p.total<=0||!/^[a-f0-9]{64}$/.test(p.sha))throw Error('Thông tin PDF không hợp lệ');
 const days=await flagteamInvoiceDays(config,p.day.slice(0,7));
 const row=days.find(r=>r.date===p.day&&r.invoice.length===1&&r.invoice[0]===p.url);
 if(!row)throw Error('Không có PDF tương ứng trên dòng phí đại lý');
 const gmail=await db.prepare("SELECT id FROM gmail_documents WHERE source='HỘ KINH DOANH HOÀNG NGỌC LỢI' AND ltrim(reference,'0')=?").bind(p.number).first();
 if(gmail)throw Error('Hóa đơn đã có trong Gmail, dùng liên kết PDF');
 const response=await fetch(p.url,{redirect:'manual',signal:AbortSignal.timeout(20000)});
 if(!response.ok||!response.headers.get('content-type')?.includes('application/pdf'))throw Error('Không tải được PDF');
 const bytes=await response.arrayBuffer();
 const sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
 if(sha!==p.sha||!response.headers.get('content-disposition')?.includes('2C26MYY_'+p.number.padStart(8,'0')+'_'))throw Error('PDF gốc hoặc số hóa đơn đã thay đổi');
 await config.BUCKET.put('agency-invoices/'+sha,bytes);
 await db.prepare('INSERT INTO pm_flagteam_source_invoices VALUES(?,?,?,?,?,?,?) ON CONFLICT(number) DO NOTHING').bind(p.number,p.issued,p.day,p.total,row.fee,sha,p.url).run();
 const saved=await db.prepare('SELECT sha,total,fee,issued,day FROM pm_flagteam_source_invoices WHERE number=?').bind(p.number).first<any>();
 if(saved?.sha!==sha||saved.total!==p.total||saved.fee!==row.fee||saved.issued!==p.issued||saved.day!==p.day)throw Error('Hóa đơn đã lưu khác với dữ liệu nguồn');
 return {count:1};
}

export async function approveHistoricalFlagteamFees(db:D1Database){
 if(await db.prepare('SELECT 1 FROM app_state WHERE id=?').bind(flagteamApprovalKey).first())return;
 const result=await db.prepare(`SELECT p.item,p.sha,p.day,p.fee,p.total FROM gmail_flagteam_pdfs p
  JOIN gmail_documents d ON d.id=p.item AND d.targetId=p.url AND d.amount=p.total
  WHERE d.state='pending' AND d.targetType='flagteam-pdf' AND d.channel='facebook'
  AND d.category='ads' AND d.currency='VND' AND d.source='HỘ KINH DOANH HOÀNG NGỌC LỢI' ORDER BY p.item`).all<ApprovedFee>();
 const rows=result.results;
 const signature=await digest(JSON.stringify(rows.map(r=>[r.item,r.sha,r.day,r.fee,r.total])));
 if(signature!=='77cba16f562be48828ab1660e86c4f95e733716cbdab2356c0a4b041749c2461')return;
 const note='Chủ shop duyệt 20/11/2026: dùng phí đại lý cho báo cáo quản trị. Giữ số tiền hóa đơn để đối chiếu.';
 await db.batch([putSetting(db,flagteamApprovalKey,rows),...rows.map(r=>db.prepare(`UPDATE gmail_documents
  SET state='linked',targetType='flagteam-approved',reason=replace(reason,'Chờ đối chiếu số chênh.',?)
  WHERE id=? AND targetType='flagteam-pdf' AND state='pending'`).bind(note,r.item))]);
}
