import {DatabaseSync} from 'node:sqlite';
import assert from 'node:assert/strict';
import test from 'node:test';
import {gmailSchema,saveGmailDocuments} from './gmail-documents';
import {approvedSupplierRules,supplierRule,supplierCategory,supplierSnapshot,applySupplierApproval,supplierApproval} from './gmail-supplier-rules';

test('owner-approved suppliers update labels with backup reference and audit; replay and future receipts retain amounts and states',async()=>{
 const sql=new DatabaseSync(':memory:');
 sql.exec(gmailSchema.join(';')+`;CREATE TABLE pm_finance_docs(id,kind,record);`);
 function prepare(query:string,args:any[]=[]):any{return {bind:(...values:any[])=>prepare(query,values),all:async()=>({results:sql.prepare(query).all(...args)}),first:async()=>sql.prepare(query).get(...args),run:()=>sql.prepare(query).run(...args)};}
 const db={prepare,batch:async(statements:any[])=>{sql.exec('BEGIN');try{statements.forEach(s=>s.run());sql.exec('COMMIT');}catch(e){sql.exec('ROLLBACK');throw e;}}} as unknown as D1Database;
 assert.equal(approvedSupplierRules.flatMap(r=>r.names).length,11);
 assert.equal(supplierRule('SoftDreams'),undefined);
 assert.equal(supplierRule('HỘ KINH DOANH NGUYỄN HUY MINH')?.category,'cogs');
 assert.equal(supplierCategory(supplierRule('CÔNG TY TNHH DREAM HUB MEDIA')!,'Vận hành và quảng cáo'),'');
 const statement=sql.prepare('INSERT INTO gmail_documents VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
 statement.run('one','mail1','goc.pdf','CÔNG TY TNHH PANCAKE VIỆT NAM','123','2026-11-01','2026-11','','shared','VND',850000,'pending','Chờ phân bổ','','','invoice:123','hash');
 statement.run('two','mail2','goc.pdf','TIKTOK PTE. LTD.','VNTT123','2026-11-01','2026-11','ads','','VND',200000,'evidence','Tiền nạp','','','invoice:456','hash2');
 const original=sql.prepare('SELECT * FROM gmail_documents ORDER BY id').all();
 const snapshot=await supplierSnapshot(db);
 assert.equal(snapshot.changes.length,1);
 await applySupplierApproval(db,'gmail-backups/fixture.json',snapshot);
 assert.equal((await supplierApproval(db)).backupKey,'gmail-backups/fixture.json');
 const current=sql.prepare('SELECT * FROM gmail_documents ORDER BY id').all();
 assert.deepEqual(current.map(r=>({...r,category:original.find(o=>o.id===r.id)!.category})),original.map(r=>({...r})));
 assert.equal(current[0].category,'software');
 assert.equal(sql.prepare('SELECT count(*) n FROM gmail_supplier_category_audit').get()!.n,1);
 assert.equal((await supplierSnapshot(db)).changes.length,0);
 assert.equal(sql.prepare('SELECT count(*) n FROM pm_finance_docs').get()!.n,0);
 // A newly received invoice uses the approved vendor even when its text lacks a category keyword.
 await saveGmailDocuments(db,{id:'newmail',subject:'Hóa đơn',sender:'delivery@softdreams.vn',digest:'x'},{attachments:[{name:'new.xml',invoice:{vendor:'CÔNG TY TNHH PANCAKE VIỆT NAM',descriptions:['Gói 1000 lượt']}}],links:[]});
 const added=sql.prepare("SELECT category,state,amount FROM gmail_documents WHERE mailId='newmail'").get()!;
 assert.equal(added.category,'software');assert.equal(added.state,'pending');assert.equal(added.amount,null);
});
