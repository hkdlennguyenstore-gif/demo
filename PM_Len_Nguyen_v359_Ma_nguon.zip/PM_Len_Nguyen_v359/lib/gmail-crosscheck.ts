import {validateFinance} from './finance';
import {putSetting} from './expense-controls';
import {digest} from './a3-access';
import {posGet} from './orders-store';
import {shippingFields} from './pos-shipping';

export const crossTables=[
 'CREATE TABLE IF NOT EXISTS gmail_return_freight(tracking TEXT PRIMARY KEY,fee INTEGER,remitted INTEGER,source TEXT)',
 'CREATE TABLE IF NOT EXISTS gmail_pos_freight(tracking TEXT PRIMARY KEY,fee INTEGER,shipping INTEGER,cod INTEGER,goods INTEGER,remitted INTEGER,revenue INTEGER)',
 'CREATE TABLE IF NOT EXISTS gmail_jt_dates(item TEXT PRIMARY KEY,days TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS gmail_jt_aliases(item TEXT PRIMARY KEY,canonical TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS gmail_jt_booked(tracking TEXT PRIMARY KEY,item TEXT NOT NULL,financeId TEXT NOT NULL,fee INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS gmail_jt_lines(item TEXT PRIMARY KEY,hash TEXT NOT NULL,lines TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS gmail_invoice_lines(item TEXT PRIMARY KEY,details TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS gmail_jt_checks(item TEXT PRIMARY KEY,summary TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS gmail_fee_runs(start TEXT PRIMARY KEY,cutoff INTEGER NOT NULL,page INTEGER NOT NULL,total INTEGER NOT NULL,done INTEGER NOT NULL DEFAULT 0)'
];
export async function receiveStatements(db:D1Database,items:{id:string;rows:unknown[][];days?:Record<string,string>;proofHash?:string}[]){
 if(!Array.isArray(items)||!items.length||items.length>100)throw Error('Lô bảng kê không hợp lệ');
 const statements=[];
 for(const item of items){
  if(!Array.isArray(item.rows)||item.rows.length>6000)throw Error('Số vận đơn không hợp lệ');
  const fact=await db.prepare("SELECT facts FROM gmail_document_facts WHERE itemId=?").bind(item.id).first<{facts:string}>();
  const reading=fact&&JSON.parse(fact.facts).reading;
  const hash=await digest(JSON.stringify(item.rows));
  if(reading?.kind!=='jt-statement'||reading.detailHash!==hash||reading.rows!==item.rows.length)throw Error('Các dòng không khớp bảng kê gốc: '+item.id);
  const lines=item.rows.map(r=>[r[0],Number(r[2])+Number(r[3])+Number(r[4])+Number(r[5]),r[1]]);
  statements.push(db.prepare('INSERT INTO gmail_jt_lines VALUES(?,?,?) ON CONFLICT(item) DO UPDATE SET hash=excluded.hash,lines=excluded.lines WHERE hash<>excluded.hash').bind(item.id,hash,JSON.stringify(lines)));
  if(item.days){
   const doc=await db.prepare('SELECT proofHash FROM gmail_documents WHERE id=?').bind(item.id).first<{proofHash:string}>();
   if(!doc||doc.proofHash!==item.proofHash || Object.keys(item.days).length!==lines.length || !lines.every(l=>Object.hasOwn(item.days!,String(l[0]))&&
     (item.days![String(l[0])]===''||/^\d{4}-\d\d-\d\d$/.test(item.days![String(l[0])]))) )throw Error('Ngày ký nhận chưa khớp bản gốc và danh sách vận đơn.');
   statements.push(db.prepare('INSERT INTO gmail_jt_dates VALUES(?,?) ON CONFLICT(item) DO UPDATE SET days=excluded.days').bind(item.id,JSON.stringify(item.days)));
  }
 }
 for(let i=0;i<statements.length;i+=20)await db.batch(statements.slice(i,i+20));
 return {count:items.length};
}
export async function receiveInvoices(db:D1Database,items:any[]){
 if(!Array.isArray(items)||items.length>250)throw Error('Lô hóa đơn không hợp lệ');
 let stored=0;
 for(const x of items){
  if(x.provider==='MISA'){
   const vendor='CÔNG TY TNHH ĐÓNG HÀNG NHANH';
   if(x.vendor!==vendor||x.buyerVerified!==true||!/^\d+$/.test(x.number)||!/^1C\d{2}TDH$/.test(x.series)||
    !/^20\d{2}-\d{2}-\d{2}$/.test(x.day)||!Number.isSafeInteger(x.total)||x.total<=0||
    !Array.isArray(x.lines)||x.lines.length!==1||typeof x.lines[0]!=='string'||!x.lines[0].includes('DHN60')||x.lines[0].length>500)throw Error('Hóa đơn MISA chưa đủ căn cứ');
   const d=await db.prepare("SELECT d.id,d.mailId,e.subject,e.sender FROM gmail_documents d JOIN gmail_evidence e ON e.id=d.mailId WHERE d.id=? AND d.state='pending' AND d.document='TRA CỨU'").bind(x.item).first<any>();
   if(!d||!String(d.sender).includes('saledohana@gmail.com')||!d.subject.includes(vendor)||!d.subject.includes(x.number))throw Error('Thông tin không khớp thư phát hành');
   const number=String(Number(x.number)),criteria={day:x.day,series:x.series,number,vendor,buyer:'087089000961',total:x.total,lines:x.lines,provider:'MISA'};
   await db.batch([
    db.prepare('INSERT OR REPLACE INTO gmail_invoice_lines VALUES(?,?)').bind(d.id,JSON.stringify(criteria)),
    db.prepare("UPDATE gmail_documents SET source=?,reference=?,date=?,currency='VND',category='software',channel='shared',amount=?,identity=?,reason=? WHERE id=? AND state='pending'").bind(vendor,number,x.day,x.total,[vendor,x.series,number].join(':'),'MISA · Đã đối chiếu người mua và nội dung hóa đơn gốc. Chờ kỳ sử dụng.',d.id),
    db.prepare("UPDATE gmail_documents SET state='linked',targetType='gmail',targetId=?,reason=? WHERE mailId=? AND document='https://www.meinvoice.vn/tra-cuu' AND amount IS NULL AND state='pending'").bind(d.id,'Trang tra cứu chung của cùng hóa đơn '+number,d.mailId)
   ]);
   stored++;continue;
  }
  if(x.buyer!=='087089000961'||!Array.isArray(x.lines)||!x.lines.length||!x.issued||!x.series||
    !x.lines.every((s:unknown)=>typeof s==='string'&&s.length<4000))continue;
  const [d,m,y]=x.issued,day=y+'-'+String(m).padStart(2,'0')+'-'+String(d).padStart(2,'0');
  const vendor=x.vendor.trim().replace(/^CÔNG TY TNHH SHOPEE$/i,'SHOPEE').toUpperCase();
  const hits=await db.prepare("SELECT id FROM gmail_documents WHERE source=? AND ltrim(reference,'0')=? AND date=? AND currency='VND' AND amount=? AND state='pending'").bind(vendor,String(x.invoiceNo).replace(/^0+/,''),day,x.total).all<{id:string}>();
  if(hits.results.length!==1)continue;
  await db.prepare('INSERT INTO gmail_invoice_lines VALUES(?,?) ON CONFLICT(item) DO UPDATE SET details=excluded.details').bind(hits.results[0].id,JSON.stringify({day,series:x.series,buyer:x.buyer,vendor,number:x.invoiceNo,lines:x.lines,total:x.total})).run();stored++;
 }
 return {count:stored};
}
type FeeEnv={PANCAKE_API_KEY?:string;PANCAKE_SHOP_ID?:string};
export async function loadFees(db:D1Database,env:FeeEnv){
 if(!env.PANCAKE_API_KEY||!env.PANCAKE_SHOP_ID)throw Error('Thiếu kết nối POS');
 const start='2026-04-01';
 await db.prepare('INSERT OR IGNORE INTO gmail_fee_runs(start,cutoff,page,total) VALUES(?,?,1,0)').bind(start,Math.floor(Date.now()/1000)).run();
 const run=await db.prepare('SELECT * FROM gmail_fee_runs WHERE start=?').bind(start).first<{cutoff:number;page:number;total:number;done:number}>();
 if(!run||run.done)return run;
 const data=await posGet(env.PANCAKE_API_KEY,env.PANCAKE_SHOP_ID,'orders',{page_size:'100',page_number:String(run.page),'order_sources[]':'[["-1"]]',include_removed:'1',option_sort:'inserted_at_asc',updateStatus:'inserted_at',startDateTime:String(Date.parse('2026-03-31T17:00:00Z')/1000),endDateTime:String(run.cutoff)});
 const total=Number(data.total_pages)||Math.ceil(Number(data.total_entries)/100);
 if(!Number.isSafeInteger(total)||total<1||!data.data.length&&run.page<=total)throw Error('POS chưa trả đủ trang');
 const updates=data.data.filter((o:any)=>String(o.shop_id)===env.PANCAKE_SHOP_ID&&o.id!=null).map((o:any)=>db.prepare("UPDATE pm_orders SET record=json_set(record,'$.shippingEvidence',json(?)) WHERE id=? AND tracking=? AND channel='facebook' AND updated<=?").bind(JSON.stringify(shippingFields(o)),'pos:'+env.PANCAKE_SHOP_ID+':'+o.id,String(o.partner?.extend_code||o.partner?.order_number_vtp||'').trim().toUpperCase(),new Date(/[zZ]|[+-]\d\d:\d\d$/.test(o.updated_at||o.inserted_at)?o.updated_at||o.inserted_at:(o.updated_at||o.inserted_at)+'Z').toISOString()));
 for(let i=0;i<updates.length;i+=50)await db.batch(updates.slice(i,i+50));
 await db.prepare('UPDATE gmail_fee_runs SET page=?,total=?,done=? WHERE start=? AND page=?').bind(run.page+1,total,Number(run.page>=total),start,run.page).run();
 return {page:run.page+1,total,done:run.page>=total};
}
export async function resolveStatementCopies(db:D1Database){
 const docs=await db.prepare(`SELECT d.id,d.amount,d.state,d.source,d.reason,d.date,f.facts,e.received,
 EXISTS(SELECT 1 FROM gmail_jt_booked b WHERE b.item=d.id) booked FROM gmail_document_facts f
 JOIN gmail_documents d ON d.id=f.itemId JOIN gmail_evidence e ON e.id=d.mailId
 WHERE json_extract(f.facts,'$.reading.kind')='jt-statement' ORDER BY booked DESC,d.amount IS NULL,e.received,d.id`).all<any>();
 const originals=new Map<string,any>();
 for(const d of docs.results){
  const r=JSON.parse(d.facts).reading;
  if(!/^[a-f0-9]{64}$/.test(r.detailHash)||!r.customer||!r.fromDate||!r.toDate)continue;
  const key=JSON.stringify([r.detailHash,r.customer,r.fromDate,r.toDate,r.total,r.rows]);
  const base=originals.get(key);
  if(!base){originals.set(key,d);continue;}
  if(d.state==='posted'||d.booked||base.amount!==r.total)continue;
  await db.batch([
   db.prepare('INSERT OR IGNORE INTO gmail_jt_lines SELECT ?,hash,lines FROM gmail_jt_lines WHERE item=?').bind(base.id,d.id),
   db.prepare('INSERT OR REPLACE INTO gmail_jt_aliases VALUES(?,?)').bind(d.id,base.id),
   db.prepare("UPDATE gmail_documents SET state='linked',targetType='gmail',targetId=?,reason=? WHERE id=? AND state IN ('pending','linked')").bind(base.id,'Bản lặp đã xác minh cùng mã khách, kỳ và toàn bộ dòng cước/COD với '+base.id,d.id),
   db.prepare("UPDATE gmail_documents SET state='pending',targetType='',targetId='',reason='Bảng kê gốc. Đã gộp các bản lặp theo toàn bộ dòng cước và COD.' WHERE id=? AND state='linked' AND targetType='gmail'").bind(base.id)
  ]);
 }
}
type Waybill=[string,number,number];
type PosRow={tracking:string;status:number;channel:string;record:string};
export function verifiedShippingFee(fee:number,cod:number,order:PosRow){
 const f=JSON.parse(order.record).shippingEvidence;
 return order.channel==='facebook' && [3,16].includes(order.status) && fee>0 && cod>0 &&
  f?.customerPays===false && f.shipping===0 && f.partner===fee &&
  (f.settled==null||f.settled===fee) && (f.cod==null||f.cod===cod);
}

export async function receiveFreight(db:D1Database, rows:unknown[][]){
 if(!Array.isArray(rows)||!rows.length||rows.length>4000)throw Error('Số dòng POS không hợp lệ');
 for(const row of rows){
  if(!Array.isArray(row)||row.length!==7||typeof row[0]!=='string'||!/^\d{8,20}$/.test(row[0])||
    !row.slice(1).every(n=>typeof n==='number'&&Number.isSafeInteger(n)&&n>=0))throw Error('Dòng đối chiếu POS không hợp lệ');
  const [,fee,shipping,cod,goods,remitted,revenue]=row as [string,number,number,number,number,number,number];
  if(!fee||!shipping||cod!==revenue||goods+shipping!==cod||cod-fee!==remitted)throw Error('COD, doanh thu hoặc tiền chuyển trả không khớp');
 }
 const statements=rows.map(row=>db.prepare('INSERT OR REPLACE INTO gmail_pos_freight VALUES(?,?,?,?,?,?,?)').bind(...row));
 for(let i=0;i<statements.length;i+=80)await db.batch(statements.slice(i,i+80));
 return {count:rows.length};
}

export async function receiveReturns(db:D1Database,rows:unknown[][]){
 if(!Array.isArray(rows)||!rows.length||rows.length>4000)throw Error('Số dòng hoàn không hợp lệ');
 const statements=rows.map(row=>{
  if(!Array.isArray(row)||row.length!==4)throw Error('Sai cấu trúc dòng hoàn');
  const [code,fee,remitted,source]=row;
  if(typeof code!=='string'||!/^\d{8,20}$/.test(code)||typeof fee!=='number'||!Number.isSafeInteger(fee)||fee<=0||
    remitted!==-fee||!['Facebook','Zalo','Chưa xác định'].includes(String(source)))throw Error('Cước hoặc khoản khấu trừ đơn hoàn chưa khớp');
  return db.prepare('INSERT OR REPLACE INTO gmail_return_freight VALUES(?,?,?,?)').bind(code,fee,remitted,source);
 });
 for(let i=0;i<statements.length;i+=80)await db.batch(statements.slice(i,i+80));
 return {count:rows.length};
}
export async function checkStatements(db:D1Database,itemId?:string,after='',post=false,actor='',settle=false){
 const {results:all}=await db.prepare('SELECT item,lines FROM gmail_jt_lines WHERE item NOT IN (SELECT item FROM gmail_jt_aliases) ORDER BY item').all<{item:string;lines:string}>();
 const uses=new Map<string,number>();
 for(const r of all)for(const [tracking] of JSON.parse(r.lines) as Waybill[])uses.set(tracking,(uses.get(tracking)||0)+1);
 const batch=all.filter(r=>itemId?r.item===itemId:r.item>after).slice(0,4);
 for(const row of batch){
  const lines=JSON.parse(row.lines) as Waybill[], codes=JSON.stringify(lines.map(l=>l[0]));
  const orders=await db.prepare('SELECT tracking,status,channel,record FROM pm_orders WHERE tracking IN (SELECT value FROM json_each(?))').bind(codes).all<PosRow>();
  const byCode=new Map<string,PosRow[]>();
  for(const o of orders.results){const list=byCode.get(o.tracking)||[];list.push(o);byCode.set(o.tracking,list);}
  const doc=await db.prepare(`SELECT d.*,e.digest,f.facts FROM gmail_documents d JOIN gmail_evidence e ON e.id=d.mailId JOIN gmail_document_facts f ON f.itemId=d.id WHERE d.id=?`).bind(row.item).first<any>();
  const proofs=doc&&JSON.parse(doc.facts),reading=proofs?.reading;
  const payer=String(proofs?.invoice?.buyerName||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
  // The source hash covers all eight original columns, including the actual remittance.
  const plainFreightRows=lines.map(([code,fee,cod])=>[code,cod,0,fee,0,0,0,cod-fee]);
  const paidByStatement=settle && doc?.currency==='VND' && reading?.detailHash &&
   await digest(JSON.stringify(plainFreightRows))===reading.detailHash;
  const summary={rows:lines.length,gross:0,matched:0,missing:0,multiple:0,payerKnown:0,customerPays:0,shopPays:0,bothSettled:0,positiveShipping:0,repeated:0,verified:0,verifiedAmount:0,booked:0,bookedAmount:0};
  const eligible:Waybill[]=[];
  const freight=await db.prepare('SELECT tracking,fee,shipping,cod,goods,remitted,revenue FROM gmail_pos_freight WHERE tracking IN (SELECT value FROM json_each(?))').bind(codes).all<{tracking:string;fee:number;shipping:number;cod:number;goods:number;remitted:number;revenue:number}>();
  const gross=new Map(freight.results.map(r=>[r.tracking,r]));

  const returns=await db.prepare('SELECT * FROM gmail_return_freight WHERE tracking IN (SELECT value FROM json_each(?))').bind(codes).all<{tracking:string;fee:number;remitted:number;source:string}>();
  const returned=new Map(returns.results.map(r=>[r.tracking,r]));
  function channelFor(code:string){
   const ret=returned.get(code);
   if(ret)return ret.source==='Facebook'?'facebook':'shared';
   const orders=byCode.get(code)||[];
   return orders.length===1 && ['facebook','tiktok1','tiktok2','shopee'].includes(orders[0].channel)?orders[0].channel:'shared';
  }
  for(const line of lines){
   const [code,fee,cod]=line,os=byCode.get(code)||[];
   summary.gross+=fee;
   const ret=returned.get(code);
   const settledLine=paidByStatement && fee>0 && uses.get(code)===1;
   if(settledLine || (ret && uses.get(code)===1 && ret.fee===fee && cod===0 && ret.remitted===-fee && os.length<=1 &&
    (!os.length||ret.source!=='Facebook'||os[0].channel==='facebook'))){
    eligible.push(line);summary.verified++;summary.verifiedAmount+=fee;
   }
   if(os.length!==1){if(!os.length)summary.missing++;else summary.multiple++;continue;}
   summary.matched++;
   const f=JSON.parse(os[0].record).shippingEvidence;
   if(typeof f?.customerPays==='boolean'){summary.payerKnown++;if(f.customerPays)summary.customerPays++;else summary.shopPays++;}
   if(f?.shipping>0)summary.positiveShipping++;
   if(f?.settled===fee&&f.cod===cod)summary.bothSettled++;
   if(uses.get(code)!==1){summary.repeated++;continue;}
   const proof=gross.get(code);
   const grossVerified=proof && os[0].channel==='facebook' && fee===proof.fee && cod===proof.cod &&
    (f?.shipping==null||f.shipping===proof.shipping) && (f?.partner==null||f.partner===fee) &&
    (f?.settled==null||f.settled===fee) && (f?.cod==null||f.cod===cod);
   if(!settledLine && (grossVerified||verifiedShippingFee(fee,cod,os[0]))){eligible.push(line);summary.verified++;summary.verifiedAmount+=fee;}
  }
  if(post&&doc?.state==='pending'&&doc.targetId===''&&doc.amount===summary.gross&&reading?.kind==='jt-statement'&&/LEN NGUYEN STORE|NGUYEN CHAU MINH NHAT/.test(payer)&&eligible.length){
   const exists=await db.prepare("SELECT tracking FROM gmail_jt_booked WHERE tracking IN (SELECT value FROM json_each(?))").bind(codes).all<{tracking:string}>();
   const seen=new Set(exists.results.map(x=>x.tracking)),fresh=eligible.filter(x=>!seen.has(x[0]));
   // Any manual/unidentified shipping aggregate in the month may cover the same shipments.
   const single=doc.month && reading.fromDate?.slice(0,7)===doc.month && reading.toDate?.slice(0,7)===doc.month;
   const dates=single?null:await db.prepare('SELECT days FROM gmail_jt_dates WHERE item=?').bind(row.item).first<{days:string}>();
   const signed=dates?JSON.parse(dates.days):{};
   const periods=new Map<string,Waybill[]>();
   for(const l of fresh){
    const day=single?reading.toDate:signed[l[0]];
    if(!day||day<reading.fromDate||day>reading.toDate)continue;
    const key=[day.slice(0,7),channelFor(l[0]),returned.has(l[0])?'returns':'shipping'].join('|');
    const list=periods.get(key)||[];list.push(l);periods.set(key,list);
   }
   for(const [key,group] of periods){
   const [month,channel,category]=key.split('|'),isReturn=category==='returns';
   const overlap=await db.prepare(`SELECT id FROM pm_finance_docs WHERE kind='expense' AND status IN ('confirmed','excluded')
    AND COALESCE(json_extract(record,'$.jtWaybills'),0)=0 AND (((channel IN ('shared',?) OR ?='shared') AND substr(date,1,7)=? AND json_extract(record,'$.category') IN ('shipping','platform','returns')
    AND NOT (channel IN ('tiktok1','tiktok2') AND COALESCE(json_extract(record,'$.category'),'')='platform'
    AND COALESCE(json_extract(record,'$.counterparty'),'')='TikTok Shop'
    AND COALESCE(json_extract(record,'$.description'),'') IN ('Phí giao dịch','Phí hoa hồng của TikTok Shop','Phí xử lý đơn hàng')))
    OR json_extract(record,'$.reference') IN (SELECT value FROM json_each(?)) OR json_extract(record,'$.expenseDetails.fields."Mã vận đơn"') IN (SELECT value FROM json_each(?))) LIMIT 1`).bind(channel,channel,month,codes,codes).first();
   if(!overlap&&group.length){
    const amount=group.reduce((a,x)=>a+x[1],0),now=new Date().toISOString(),date=single?reading.toDate:group.map(l=>signed[l[0]]).sort().at(-1);
    const id='jt-'+await digest(JSON.stringify([row.item,group.map(x=>x[0])]));
    const reference='J&T '+doc.document+' · '+id.slice(-10);
    const value={...validateFinance('expense',{channel,category,date,amount,paid:amount,description:(isReturn?'Cước J&T của đơn chuyển hoàn':'Cước J&T đã khấu trừ COD')+' · '+group.length+' vận đơn',reference,counterparty:doc.source,receipt:{key:'gmail-evidence/'+doc.digest,name:doc.document+' · thư gốc.eml',mime:'message/rfc822'},note:isReturn?'Đơn có dấu chuyển hoàn trên bảng kê gốc. COD bằng 0, số chuyển trả âm đúng bằng cước. Kênh chưa phân bổ hoặc Zalo được theo dõi ở Toàn shop.' :paidByStatement?'Đã đối chiếu mã vận đơn và cước với bảng kê gốc. Tiền J&T chuyển trả bằng COD trừ cước. Đơn chưa xác định kênh trên PM được ghi ở Toàn shop.':'Cước thực trừ theo bảng kê J&T. Đã so trùng mã vận đơn và phiếu phí.'}),paymentMethod:'offset',id,actor,version:0,status:'confirmed',confirmedAt:now,createdAt:now,updatedAt:now,jtWaybills:true,gmailEvidence:doc.mailId,trackingFees:group.map(x=>({tracking:x[0],fee:x[1],settlement:paidByStatement?{cod:x[2],remitted:x[2]-x[1],detailHash:reading.detailHash}:undefined,posFreight:gross.get(x[0]),returnFreight:returned.get(x[0])}))};
    await db.batch([
     db.prepare('INSERT INTO gmail_jt_booked SELECT value->>0,?,?,value->>1 FROM json_each(?)').bind(row.item,id,JSON.stringify(group)),
     db.prepare('INSERT INTO pm_finance_requests SELECT ?,COUNT(*) FROM pm_finance_requests').bind(id),
     db.prepare('INSERT INTO pm_finance_docs VALUES(?,?,?,?,?,?,?,?,?)').bind(id,'expense',date,date,channel,'confirmed',JSON.stringify(value),0,id),
     db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(id,now,actor,'gmail:jt-offset',JSON.stringify({after:value})),
     putSetting(db,'expense-changed:'+date,now)
    ]);
   }
   }
  }
  const booked=await db.prepare('SELECT count(*) n,coalesce(sum(fee),0) sum FROM gmail_jt_booked WHERE item=?').bind(row.item).first<{n:number;sum:number}>();
  summary.booked=booked?.n||0;summary.bookedAmount=booked?.sum||0;
  if(post && doc?.state==='pending' && summary.booked>0){
   const totals=summary.booked+'/'+summary.rows+' vận đơn, '+summary.bookedAmount.toLocaleString('vi-VN')+'đ. Cước J&T đã ghi vào Chi phí theo vận đơn.';
   if(summary.booked===lines.length && summary.bookedAmount===doc.amount){
    const ledger=await db.prepare('SELECT min(financeId) id,count(DISTINCT financeId) n FROM gmail_jt_booked WHERE item=?').bind(row.item).first<{id:string;n:number}>();
    if(ledger?.n)await db.prepare("UPDATE gmail_documents SET state='linked',targetType=?,targetId=?,reason=? WHERE id=? AND state='pending'").bind(ledger.n===1?'expense':'jt-ledger',ledger.n===1?ledger.id:row.item,totals+' Đã khớp '+ledger.n+' phiếu chi.',row.item).run();
   }else await db.prepare("UPDATE gmail_documents SET reason=? WHERE id=? AND state='pending'").bind(totals+' Phần còn lại chờ đối chiếu phí khách trả, tình trạng giao hoặc mã vận đơn.',row.item).run();
  }
  await db.prepare('INSERT OR REPLACE INTO gmail_jt_checks VALUES(?,?)').bind(row.item,JSON.stringify(summary)).run();
 }
 const cursor=batch.at(-1)?.item||after;
 return {count:all.filter(r=>r.item<=cursor).length,total:all.length,cursor,done:!batch.length||cursor===all.at(-1)?.item};
}
