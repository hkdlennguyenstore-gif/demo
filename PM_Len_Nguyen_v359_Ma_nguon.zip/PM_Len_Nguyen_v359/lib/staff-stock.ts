import {a4Key,A4_SIZES} from './a4.ts';
import {a4Size} from './a4-display.ts';
export const staffStockRoles=['terminal','owner','admin','manager'];
type Variant={name?:string;color:string;size:string;remain:number|null};
export function staffStockView(code:string,name:string,price:number|null,stock:{variants:Variant[];updatedAt:string;complete:boolean}){
 const byColor=new Map<string,{color:string;cells:Record<string,number|null>}>();
 const sizes:string[]=A4_SIZES.map(String);
 let warning=!stock.complete;
 for(const v of stock.variants){
  if(!v.color||v.color==='Chưa có màu'||!v.size||v.size==='Chưa có size'){warning=true;continue;}
  const size=a4Size(v.size);if(!sizes.includes(size)) sizes.push(size);
  const key=a4Key(v.color),row=byColor.get(key)??{color:v.color,cells:Object.create(null) as Record<string,number|null>};
  const previous=row.cells[size];row.cells[size]=v.remain===null||previous===null?null:(previous??0)+v.remain;
  byColor.set(key,row);
 }
 const total=(xs:(number|null)[])=>xs.includes(null)?null:xs.reduce<number>((n,x)=>n+(x??0),0);
 const rows=Array.from(byColor.values(),r=>({...r,total:total(Object.values(r.cells))}));
 return {code,name:name||stock.variants[0]?.name||code,facebookPrice:price,sizes,rows,updatedAt:stock.updatedAt,complete:!warning,total:warning||!rows.length?null:total(rows.map(r=>r.total))};
}
