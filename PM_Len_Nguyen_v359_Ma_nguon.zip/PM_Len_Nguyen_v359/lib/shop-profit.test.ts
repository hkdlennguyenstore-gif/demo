import * as management from './flagteam-management.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import * as dates from './date-range.ts';
import * as pay from './payroll.ts';
import * as access from './a3-access.ts';
function load(file:string,modules:Record<string,unknown>){
 const code=ts.transpileModule(readFileSync(new URL(file,import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const result:any={};vm.runInNewContext('(function(require,exports){'+code+'})',{Response,URL,crypto})((id:string)=>modules[id],result);return result;
}
test('Tách shop, kỳ và quyền, tính đủ chi phí, giữ số âm và thiếu nguồn',async()=>{
 const sql=new DatabaseSync(':memory:');
 const db={async batch(statements:any[]){sql.exec("BEGIN");try{for(const stmt of statements)await stmt.run();sql.exec("COMMIT");}catch(e){sql.exec("ROLLBACK");throw e;}},prepare(q:string){let args:any[]=[];return {bind(...v:any[]){args=v;return this;},async all(){return {results:sql.prepare(q).all(...args)};},async first(){return sql.prepare(q).get(...args);},async run(){return {meta:{changes:Number(sql.prepare(q).run(...args).changes)}};}};}};
 sql.exec("CREATE TABLE app_state(id TEXT PRIMARY KEY,value TEXT);CREATE TABLE pm_finance_docs(kind,status,date,end_date,channel,record);CREATE TABLE pm_ads_months(id,record)");
 sql.prepare("INSERT INTO app_state VALUES('main',?)").run(JSON.stringify(pay.initial('owner@test.vn')));
 sql.prepare("INSERT INTO pm_ads_months VALUES('tiktok2:2026-11',?)").run(JSON.stringify({provider:'tiktok2',days:[{date:'2026-11-01',ads:42,transfer:4000}]}));
 for(const [month,day,amount] of [['10','31',10],['11','01',20],['11','30',40]]){
  sql.prepare('INSERT INTO pm_ads_months VALUES(?,?)').run('giaminh:2026-'+month,JSON.stringify({provider:'giaminh',days:[{date:'2026-'+month+'-'+day,ads:Number(amount),fee:3,total:Number(amount)+3,transfer:2000}]}));
 }
 for(const [category,amount,status,channel] of [['packing',6,'confirmed','facebook'],['returns',8,'confirmed','facebook'],['shipping',17,'confirmed','facebook'],['ads',200,'confirmed','facebook'],['packing',9,'draft','facebook'],['returns',20,'confirmed','shopee']]){
  sql.prepare('INSERT INTO pm_finance_docs VALUES(?,?,?,?,?,?)').run('expense',status,'2026-11-02',null,channel,JSON.stringify({category,amount}));
 }
 const profit=load('./shop-profit.ts',{'./date-range':dates,'./flagteam-management':management});
 const range={from:'2026-11-01',to:'2026-11-30'},costs=await profit.shopCosts(db,range);
 assert.equal(costs.tiktok2.ads,42);assert.equal(costs.tiktok1.ads,null);assert.equal(costs.tiktok2.tax,null);
 assert.equal(costs.facebook.ads,36);assert.equal(costs.facebook.other,23);assert.equal(costs.facebook.packing,6);assert.equal(costs.facebook.returnCost,8);assert.equal(costs.shopee.other,20);
 await profit.profitReviews(db,range);
 let email='owner@test.vn';
 const modules={'cloudflare:workers':{env:{DB:db}},'../../chatgpt-auth':{getChatGPTUser:async()=>({email})},'../../../lib/payroll':pay,'../../../lib/a3-access':access,'../../../lib/date-range':dates,'../../../lib/shop-profit':profit};
 const report=load('../app/api/shop-profit/route.ts',modules),gate=load('../app/api/category-access/route.ts',modules);
 const post=(api:any,b:any)=>api.POST(new Request('https://pm.test/api/test?from='+range.from+'&to='+range.to,{method:'POST',headers:{origin:'https://pm.test'},body:JSON.stringify(b)}));
 const row={...range,version:0,channel:'tiktok2',revenue:200,cogs:100,platform:39,ads:42,tax:10,other:20,reference:'Đối soát thử'};
 assert.equal((await post(report,row)).status,200);assert.equal((await post(report,row)).status,409);
 assert.equal((await post(gate,{action:'grant'})).status,403);
 email='partner@test.vn';assert.equal((await post(report,{...row,version:1})).status,403);
 assert.equal((await post(gate,{action:'open'})).status,403);
 sql.close();
});
