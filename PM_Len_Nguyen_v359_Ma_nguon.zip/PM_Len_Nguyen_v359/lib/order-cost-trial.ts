import {readDateRange} from './date-range';
const channels=['facebook','tiktok1','tiktok2','shopee'];
// Read-only projection; never coerce missing counts or use product quantities.
export function trialOrders(query:string,data:any,shop:string):{day:string;count:number|null;basis:string}|null{
 let range;try{range=readDateRange(new URLSearchParams(query));}catch{return null;}
 if(!range.from||range.from!==range.to)return null;
 const result={day:range.from,count:null as number|null,basis:'Chưa đủ dữ liệu'};
 if(data?.range?.from!==range.from||data?.range?.to!==range.to)return result;
 const selected=shop==='all'?channels:[shop];if(selected.some(id=>!channels.includes(id)))return result;
 const pos=Array.isArray(data?.orderSources?.rows)?data.orderSources.rows:null;
 if(!pos)return result;
 const counts=selected.map(id=>{
  const matches=pos.filter((r:any)=>r.id===id);
  if(matches.length!==1||matches[0].ready!==true)return null;
  const row=matches[0];
  const count=id==='tiktok2'?row.orders:row.confirmed;
  return Number.isSafeInteger(count)&&count>=0?count:null;
 });
 if(counts.some(n=>n===null))return result;
 const count=counts.reduce<number>((sum,n)=>sum+n!,0);if(!Number.isSafeInteger(count))return result;
 return {...result,count,basis:shop==='tiktok2'?'Tổng đơn POS, gồm đơn hủy':shop==='all'?'Tổng đơn của TikTok 2 và đơn chốt của các kênh khác':'Số đơn chốt từ báo cáo nguồn đang xem'};
}
// The caller must explicitly confirm Ads was excluded before using displayed
// profit directly. Otherwise require the exact deducted Ads amount.
export function profitBeforeAds(displayedProfit:unknown,actualAds:unknown,adsWasDeducted?:boolean):number|null{
 if(typeof displayedProfit!=='number'||!Number.isSafeInteger(displayedProfit))return null;
 if(adsWasDeducted===false)return displayedProfit;
 if(typeof actualAds!=='number'||!Number.isSafeInteger(actualAds))return null;
 const value=displayedProfit+actualAds;return Number.isSafeInteger(value)?value:null;
}
export function orderCostTrial(raw:string,count:number|null):{kind:'blank'|'missing'|'invalid'|'ready';unit?:number;total?:number}{
 if(!raw.trim())return {kind:'blank'};
 if(!/^(?:\d+|\d{1,3}(?:\.\d{3})+|\d{1,3}(?:,\d{3})+|\d{1,3}(?: \d{3})+)$/.test(raw.trim()))return {kind:'invalid'};
 const unit=Number(raw.replace(/[., ]/g,''));if(!Number.isSafeInteger(unit)||unit<0)return {kind:'invalid'};
 if(count===null||!Number.isSafeInteger(count)||count<0)return {kind:'missing',unit};
 const total=unit*count;return Number.isSafeInteger(total)?{kind:'ready',unit,total}:{kind:'invalid'};
}

export function formatTrialInput(raw:string):string{
 const digits=/^[\d., ]+$/.test(raw)?raw.replace(/[., ]/g,''):raw;
 const parsed=orderCostTrial(digits,0);
 return parsed.kind==='ready'?parsed.unit!.toLocaleString('vi-VN'):raw;
}

// A browser-only projection: the same replacement drives shop rows and totals.
// Unknown source values remain unknown; no source records are changed.
export function projectTrial(raw:string,count:number|null,profit:number|null,expense:number|null,ads:unknown){
 const active=Boolean(raw.trim());
 if(!active)return {active:false,profit,expense,qc:null as number|null};
 const result=orderCostTrial(raw,count);
 if(result.kind!=='ready')return {active:true,profit:null,expense:null,qc:null as number|null};
 const knownAds=typeof ads==='number'&&Number.isSafeInteger(ads);
 const before=profitBeforeAds(profit,ads,knownAds);
 const delta=result.total!-(knownAds?ads:0);
 const projectedProfit=before===null?null:before-result.total!;
 const projectedExpense=expense===null?null:expense+delta;
 return {active:true,profit:Number.isSafeInteger(projectedProfit)?projectedProfit:null,expense:Number.isSafeInteger(projectedExpense)?projectedExpense:null,qc:result.total!};
}
