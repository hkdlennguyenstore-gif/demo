import {managementAdsMonths} from './flagteam-management';
import {withinRange, type DateRange} from './date-range';
type ChannelCost = {withheld?:number,withheldPit?:number,shipping?:number,adsSpend?:number,adsFee?:number,platform:number|null, tax:number|null, ads:number|null, other:number|null, packing:number|null, returnCost:number|null};
export async function shopCosts(db:D1Database,range:DateRange){
 const costs:Record<string,ChannelCost> = Object.fromEntries(['facebook','tiktok1','tiktok2','shopee'].map(c=>[c,{platform:null,tax:null,ads:null,other:null,packing:null,returnCost:null}]));
 const fees=await db.prepare(`SELECT channel,json_extract(record,'$.category') category,SUM(json_extract(record,'$.amount')) amount FROM pm_finance_docs
 WHERE kind='expense' AND status='confirmed' AND (?='' OR date>=?) AND (?='' OR date<=?) GROUP BY channel,category`).bind(range.from,range.from,range.to,range.to).all<{channel:string,category:string,amount:number}>();
 for(const row of fees.results){
  const cost=costs[row.channel];
  if(!cost||row.category==='ads')continue;
  if(row.category==='platform'){cost.platform=row.amount;continue;}
  if(row.category==='returns'){
   cost.returnCost=row.amount;
   if(row.channel==='facebook')continue;
  }
  cost.other=(cost.other??0)+row.amount;
  if(row.category==='shipping')cost.shipping=row.amount;
  if(row.category==='packing')cost.packing=row.amount;
 }
 // Tax documents cover whole quarters. Never allocate a quarter across arbitrary dates.
 if(range.from && range.to){
 const tax=await db.prepare("SELECT channel,date,end_date,json_extract(record,'$.amount') amount, json_extract(record,'$.withheldPit') withheldPit, COALESCE(json_extract(record,'$.withheldVat'),0)+COALESCE(json_extract(record,'$.withheldPit'),0) withheld FROM pm_finance_docs WHERE kind='tax' AND status='confirmed' AND date>=? AND end_date<=? ORDER BY date").bind(range.from,range.to).all<{channel:string,date:string,end_date:string,amount:number,withheld:number,withheldPit:number|null}>();
 for(const channel of Object.keys(costs)){
 let next=range.from,total=0,withheld=0,withheldPit=0,pitKnown=true,last='';
 for(const row of tax.results.filter(r=>r.channel===channel)){if(row.date!==next)break;total+=row.amount;withheld+=row.withheld;pitKnown&&=Number.isFinite(row.withheldPit);withheldPit+=row.withheldPit??0;last=row.end_date;next=new Date(Date.parse(last+'T00:00:00Z')+86400000).toISOString().slice(0,10);}
 if(last===range.to){costs[channel].tax=total;costs[channel].withheld=withheld;if(pitKnown)costs[channel].withheldPit=withheldPit;}
 }}
 const shiftDay=(day:string,offset:number)=>new Date(Date.parse(day+"T00:00:00Z")+offset*86400000).toISOString().slice(0,10);
 const earliest=range.from?shiftDay(range.from,-1):"";
 const ads=await db.prepare("SELECT record FROM pm_ads_months WHERE (?='' OR substr(id,-7)>=?) AND (?='' OR substr(id,-7)<=?)").bind(earliest,earliest.slice(0,7),range.to,range.to.slice(0,7)).all<{record:string}>();
 const reportMonths=await managementAdsMonths(db,ads.results,earliest,range.to);
 const ledgerSpend=new Set<string>(), receiptIds=new Set<string>(), receiptSpend=new Map<string,number>();
 for(const row of reportMonths){
  const entry=JSON.parse(row.record);
  if(entry.provider!=='flagteam')continue;
  for(const day of entry.days){
   if(day.ads>0)ledgerSpend.add(day.date);
   for(const receipt of day.receipts||[]){
    if(receiptIds.has(receipt.id))continue;
    receiptIds.add(receipt.id);
    for(const item of receipt.spend)receiptSpend.set(item.date,(receiptSpend.get(item.date)||0)+item.amount);
   }
  }
 }
 for(const [date,amount] of receiptSpend){
  if(ledgerSpend.has(date)||!withinRange(shiftDay(date,1),range))continue;
  costs.facebook.adsSpend=(costs.facebook.adsSpend??0)+amount;
  costs.facebook.ads=(costs.facebook.ads??0)+amount;
 }
 for(const row of reportMonths){const entry=JSON.parse(row.record);const channel=['giaminh','flagteam'].includes(entry.provider)?'facebook':entry.provider;
 if(!costs[channel])continue;
 for(const day of entry.days){if(!withinRange(channel==='facebook'?shiftDay(day.date,1):day.date,range)||!Number.isFinite(day.ads))continue;const cost=costs[channel];
  if(channel==='facebook'){
   if(!day.feeOnly)cost.adsSpend=(cost.adsSpend??0)+day.ads;
   cost.adsFee=(cost.adsFee??0)+(day.fee??0);
   cost.ads=(cost.ads??0)+(day.total??(day.ads+(day.fee??0)+(day.other??0)-(day.discount??0)));
  }else cost.ads=(cost.ads??0)+day.ads;}
 }
 return costs;
}

export async function profitReviews(db:D1Database,range:DateRange){
 await db.prepare('CREATE TABLE IF NOT EXISTS pm_profit_reviews(channel TEXT NOT NULL,start_day TEXT NOT NULL,end_day TEXT NOT NULL,revision INTEGER NOT NULL,record TEXT NOT NULL,PRIMARY KEY(channel,start_day,end_day,revision))').run();
 const rows=await db.prepare('SELECT channel,revision,record FROM pm_profit_reviews p WHERE start_day=? AND end_day=? AND revision=(SELECT MAX(revision) FROM pm_profit_reviews WHERE channel=p.channel AND start_day=p.start_day AND end_day=p.end_day)').bind(range.from,range.to).all<{channel:string,revision:number,record:string}>();
 return Object.fromEntries(rows.results.map(r=>[r.channel,{...JSON.parse(r.record),version:r.revision}]));
}

export async function feePolicies(db:D1Database){
 await db.prepare('CREATE TABLE IF NOT EXISTS pm_fee_rates(channel TEXT NOT NULL, starts TEXT NOT NULL, rate REAL NOT NULL, actor TEXT NOT NULL, PRIMARY KEY(channel,starts))').run();
 const rows=await db.prepare('SELECT channel,starts,rate FROM pm_fee_rates ORDER BY starts DESC').all<{channel:string,starts:string,rate:number}>();
 // Cover all reportable dates with the approved Shop 1 default. Dated owner settings take precedence.
 const baseline={channel:'tiktok1',starts:'2000-01-01',rate:27.31};
 return rows.results.some(row=>row.channel===baseline.channel&&row.starts===baseline.starts)
  ? rows.results : [...rows.results,baseline];
}
