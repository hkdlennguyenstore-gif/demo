import {attendanceAccess,attendanceBatch} from './attendance-access';
import {readBulkSchedule,type BulkOutcome} from './attendance-bulk';
import {storedLeaveEnd} from './attendance-leave-range';
import type {State} from './payroll';

const batchAction='Xếp lịch làm việc hàng loạt';
const pairSet=`WITH pairs AS (
 SELECT 'bulk:'||?||':'||days.key||':'||staff.key AS id,days.value AS day,
 json_extract(staff.value,'$.id') AS employee,json_extract(staff.value,'$.name') AS name
 FROM json_each(?) AS days CROSS JOIN json_each(?) AS staff
) `;
const approved=`EXISTS(SELECT 1 FROM pm_order_leave
 WHERE employee=pairs.employee AND status='approved' AND date<=pairs.day AND ${storedLeaveEnd}>=pairs.day)`;
export async function saveAttendanceBulk(db:D1Database,s:State,email:string,requestId:string,input:unknown,now:string,authValue:string){
 if(!attendanceAccess(s,email).admin)throw Error('Chỉ Chủ shop hoặc Quản trị viên được xếp lịch hàng loạt.');
 const req=readBulkSchedule(input),canonical=JSON.stringify(req),actor=email.toLowerCase(),total=req.days.length*req.employees.length;
 const readAudit=()=>db.prepare('SELECT actor,action,record FROM pm_order_actions WHERE id=?').bind(requestId).first<{actor:string;action:string;record:string}>();
 const readResult=(row:NonNullable<Awaited<ReturnType<typeof readAudit>>>,replayed:boolean)=>{
  const value=JSON.parse(row.record);
  if(row.actor!==actor||row.action!==batchAction||JSON.stringify(value.request)!==canonical)throw Error('Mã yêu cầu đã dùng cho nội dung khác.');
  return {ok:true,replayed,...value.outcome as BulkOutcome};
 };
 const prior=await readAudit();if(prior)return readResult(prior,true);
 if(s.locked.includes(req.month))return {ok:true,replayed:false,changed:0,leave:0,off:0,existing:0,locked:total,total};
 const people=await db.prepare('SELECT id,name FROM pm_order_schedule_people WHERE id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(req.employees)).all<{id:string;name:string}>();
 const extra=new Map(people.results.map(x=>[x.id,x.name]));
 const staff=req.employees.map(id=>({id,name:s.employees.find(e=>e.active&&e.id===id)?.name||extra.get(id)||''}));
 if(staff.some(x=>!x.name))throw Error('Có tên không còn trong danh sách xếp lịch. Tải lại và chọn lại.');
 const days=JSON.stringify(req.days),roster=JSON.stringify(staff);
 const insert=db.prepare(pairSet+`INSERT INTO pm_order_schedule(id,date,employee,version,record)
 SELECT pairs.id,day,employee,0,json_object('date',day,'employee',employee,'name',name,'kind','work','start',?,'end','','note','','scheduleMode','day','actor',?,'updatedAt',?)
 FROM pairs WHERE NOT EXISTS(SELECT 1 FROM pm_order_actions WHERE id=?)
 AND NOT EXISTS(SELECT 1 FROM pm_order_schedule WHERE date=pairs.day AND employee=pairs.employee) AND NOT ${approved}
 ON CONFLICT(date,employee) DO NOTHING`).bind(requestId,days,roster,req.start,actor,now,requestId);
 const audit=db.prepare(pairSet+`, result AS (
 SELECT CASE WHEN w.id=pairs.id THEN 'changed'
 WHEN json_extract(w.record,'$.kind')='leave' OR ${approved} THEN 'leave'
 WHEN json_extract(w.record,'$.kind')='off' THEN 'off' ELSE 'existing' END AS bucket
 FROM pairs LEFT JOIN pm_order_schedule AS w ON w.date=pairs.day AND w.employee=pairs.employee
 ) INSERT INTO pm_order_actions
 SELECT ?,?,?,?,json_object('request',json(?),'outcome',json_object('changed',COALESCE(SUM(bucket='changed'),0),'leave',COALESCE(SUM(bucket='leave'),0),'off',COALESCE(SUM(bucket='off'),0),'existing',COALESCE(SUM(bucket='existing'),0),'locked',0,'total',COUNT(*))) FROM result WHERE 1
 ON CONFLICT(id) DO NOTHING`).bind(requestId,days,roster,requestId,now,actor,batchAction,canonical);
 const result=await attendanceBatch(db,authValue,req.month+'-01',[insert,audit]);
 const saved=await readAudit();if(!saved)throw Error('Chưa xác nhận xếp lịch; hãy tải lại trước khi gửi tiếp.');
 return readResult(saved,!result[1].meta.changes);
}
