export const A3_COOKIE='ln_a3_session',A3_LOCKOUT=15*60*1000;
export function sessionExpires(now=Date.now()){const d=new Date(now),day=d.getUTCDate();d.setUTCDate(1);d.setUTCFullYear(d.getUTCFullYear()+1);const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(day,last));return d.getTime();}
const encoder=new TextEncoder();
export async function digest(value:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(value)))).map(v=>v.toString(16).padStart(2,'0')).join('');}
export async function pinHash(pin:string,salt:string){const key=await crypto.subtle.importKey('raw',encoder.encode(pin),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:encoder.encode(salt),iterations:100000},key,256);return Array.from(new Uint8Array(bits)).map(v=>v.toString(16).padStart(2,'0')).join('');}
export function constantEqual(a:string,b:string){let diff=a.length^b.length;for(let i=0;i<Math.max(a.length,b.length);i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return diff===0;}
export function validatePin(pin:unknown){if(typeof pin!=='string'||!/^\d{6,10}$/.test(pin)||/^(\d)\1+$/.test(pin)||['123456','654321','12345678','012345'].includes(pin))throw Error('PIN riêng gồm 6–10 chữ số, tránh dãy lặp hoặc quá dễ đoán');return pin;}
export async function prepareA3(db:D1Database){await db.batch([
 db.prepare('CREATE TABLE IF NOT EXISTS pm_a3_grants(employee TEXT PRIMARY KEY,name TEXT NOT NULL,shared_email TEXT NOT NULL,email TEXT NOT NULL DEFAULT \'\',salt TEXT NOT NULL,pin_hash TEXT NOT NULL,active INTEGER NOT NULL,revision INTEGER NOT NULL DEFAULT 0)'),
 db.prepare("CREATE UNIQUE INDEX IF NOT EXISTS pm_a3_email ON pm_a3_grants(email) WHERE email!='' AND active=1"),
 db.prepare('CREATE TABLE IF NOT EXISTS pm_a3_sessions(token_hash TEXT PRIMARY KEY,email TEXT NOT NULL,employee TEXT NOT NULL,revision INTEGER NOT NULL,expires INTEGER NOT NULL)'),
 db.prepare('CREATE TABLE IF NOT EXISTS pm_a3_attempts(id TEXT PRIMARY KEY,attempts INTEGER NOT NULL,until_time INTEGER NOT NULL)'),
 db.prepare('CREATE TABLE IF NOT EXISTS pm_a3_audit(id TEXT PRIMARY KEY,time TEXT NOT NULL,actor TEXT NOT NULL,action TEXT NOT NULL,record TEXT NOT NULL)'),
 db.prepare('CREATE TABLE IF NOT EXISTS pm_price_history(id TEXT PRIMARY KEY,sku TEXT NOT NULL,date TEXT NOT NULL,price INTEGER NOT NULL,record TEXT NOT NULL)'),
 db.prepare('CREATE INDEX IF NOT EXISTS pm_price_sku_date ON pm_price_history(sku,date)')]);}
export type A3Grant={employee:string,name:string,shared_email:string,email:string,salt:string,pin_hash:string,active:number,revision:number};
export async function delegatedAccess(db:D1Database,email:string,cookie:string,now=Date.now()){
 const direct=await db.prepare("SELECT employee,name FROM pm_a3_grants WHERE email=? AND email!='' AND shared_email!=email AND active=1").bind(email).first<{employee:string,name:string}>();if(direct)return {...direct,expires:null};
 const raw=cookie.split(';').map(s=>s.trim()).find(s=>s.startsWith(A3_COOKIE+'='))?.slice(A3_COOKIE.length+1);if(!raw||!/^[0-9a-f-]{73}$/.test(raw))return null;
 return db.prepare('SELECT g.employee,g.name,s.expires FROM pm_a3_sessions s JOIN pm_a3_grants g ON g.employee=s.employee AND g.revision=s.revision WHERE s.token_hash=? AND s.email=? AND g.shared_email=? AND s.expires>? AND g.active=1').bind(await digest(raw),email,email,now).first<{employee:string,name:string,expires:number}>();
}
