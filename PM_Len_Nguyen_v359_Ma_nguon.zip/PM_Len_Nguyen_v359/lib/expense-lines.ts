import {adKey,payrollKey,type ExpenseOverride} from './expense-controls';
import {expenseGroups} from './finance';
const legacy:Record<string,string>={rent:'operations',utilities:'operations',services:'operations'};
export type Line={provisional?:boolean;invoice?:boolean;reviewId?:string;account?:string;reconciled?:boolean;lineKey?:string;original?:number;excluded?:boolean;control?:ExpenseOverride;paid?:number;category?:string;id?:string;url?:string;date:string;shop:string;group:string;label:string;source:string;reference:string;proof:string;tax:string;amount:number};
export function collect(data:any,includeExcluded=false){
 const lines:Line[]=[];
 const invoices=new Set<string>();
 for(const source of data.driveAds?.readSources||[])for(const p of source.proofs||[]){
  if(p.invoice&&p.fileId)invoices.add([p.channel,p.account,p.period].join('|'));
 }
 for(const r of data.rows){
  if(r.status!=='confirmed'&&r.status!=='excluded')continue;
  lines.push({invoice:r.invoiceValid||undefined,excluded:r.status==='excluded',original:r.amount,id:r.id,category:r.category,paid:r.paid,url:r.receipt?.key?'/api/finance?id='+encodeURIComponent(r.id)+'&file='+encodeURIComponent(r.receipt.key):undefined,date:r.date,shop:r.channel,group:legacy[r.category]||(expenseGroups[r.category]?r.category:'unclassified'),label:r.description,source:r.counterparty||'Phiếu chi phí',reference:r.reference,proof:r.receipt?.name,tax:r.deductibility,amount:r.status==='excluded'?0:r.amount});
 }
 for(const r of data.adsCosts.rows){
  const shop=['flagteam','giaminh'].includes(r.provider)?'facebook':r.provider;
  for(const d of r.days){
   const base={reviewId:r.id,reconciled:Boolean(r.review?.paymentVerified&&r.review?.fingerprint===r.fingerprint),invoice:Boolean(r.review?.reference&&r.review?.receipt&&r.review?.paymentVerified),date:d.date,shop,group:'ads',label:'Quảng cáo',source:r.provider,reference:d.receiptIds?.join(', ')||'',proof:r.review?.receipt?.name||d.receiptIds?.join(', ')||'',url:r.review?.receipt?.key?'/api/finance?adsReview=1&id='+encodeURIComponent(r.id)+'&file='+encodeURIComponent(r.review.receipt.key):d.receiptIds?.length?'https://api.ads.flagteam.vn/transactions/'+encodeURIComponent(d.receiptIds[0])+'/pdf-download/':undefined,tax:r.status};
   if(d.accounts?.length){
    for(const a of d.accounts)lines.push({...base,account:a.account,invoice:base.invoice||invoices.has([shop,a.account,r.month].join('|')),lineKey:adKey(r.provider,d.date,a.account),control:a.control,excluded:a.control?.excluded,original:a.original??a.amount,source:(a.manual?'Nhập thủ công':'Drive')+' · '+a.account,reference:a.reference||a.sourceFile||a.key,proof:a.receipt?.name||a.sourceFile||base.proof,url:a.sourceFile?'https://drive.google.com/open?id='+encodeURIComponent(a.sourceFile):base.url,amount:a.amount});
   }else if(d.total||d.control)lines.push({...base,lineKey:adKey(r.provider,d.date),control:d.control,original:d.original??d.total,excluded:d.control?.excluded,label:'Chi quảng cáo sau phí và chiết khấu',amount:d.total});
  }
 }
 for(const r of data.payrollCosts.rows){

  const base={reviewId:r.id,date:r.month,shop:'shared',group:'staff',provisional:!r.locked,source:r.locked?'Bảng lương đã chốt':'Bảng lương tạm tính',proof:r.review?.receipt?.name||''};
  if(r.wage||r.wageControl)lines.push({...base,lineKey:payrollKey(r.id,'wage'),control:r.wageControl,original:r.rawWage??r.wage,excluded:r.wageControl?.excluded,label:'Lương · '+r.name,reference:r.review?.wageReference,tax:r.wageStatus,amount:r.wage});
  if(r.employer||r.employerControl)lines.push({...base,lineKey:payrollKey(r.id,'employer'),control:r.employerControl,original:r.rawEmployer??r.employer,excluded:r.employerControl?.excluded,label:'Bảo hiểm phần shop · '+r.name,reference:r.review?.insuranceReference,tax:r.insuranceStatus,amount:r.employer});
 }
 return lines.filter(l=>includeExcluded||!l.excluded).sort((a,b)=>b.date.localeCompare(a.date));
}
export function taxBucket(l:Line){return l.tax==='eligible'?'eligible':l.tax==='ineligible'?'ineligible':'pending';}
export function filterExpenses(rows:Line[],q:URLSearchParams){
 const query=(q.get('query')||'').trim().toLocaleLowerCase('vi');
 return rows.filter(l=>(!q.get('group')||l.group===q.get('group'))&&(!q.get('shop')||l.shop===q.get('shop'))&&
  (!q.get('source')||l.source===q.get('source'))&&(q.get('state')==='excluded'?l.excluded:!l.excluded)&&
  (!q.get('invoice')||(q.get('invoice')==='yes')===Boolean(l.invoice))&&(!q.get('tax')||taxBucket(l)===q.get('tax'))&&(!query||[l.label,l.reference,l.proof,l.source,l.date].join(' ').toLocaleLowerCase('vi').includes(query)));
}
