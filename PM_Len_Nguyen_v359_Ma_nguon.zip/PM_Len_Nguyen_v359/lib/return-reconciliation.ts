const DAY=24*60*60*1000;
export function reconciliation(expected:unknown,receipt:any,now=Date.now()){
 if(!receipt)return {status:'awaiting',matched:false,exact:false,auto30:false,eligibleAt:null,ageDays:null,daysRemaining:null};
 if(expected)return {status:'matched',matched:true,exact:true,auto30:false,eligibleAt:null,ageDays:null,daysRemaining:null};
 const raw=receipt.dateUnknown?(receipt.importedAt||receipt.receivedAt):(receipt.receivedAt||(receipt.date?receipt.date+'T00:00:00+07:00':'')),start=Date.parse(raw||''),eligible=Number.isFinite(start)?start+30*DAY:null,ageDays=Number.isFinite(start)?Math.max(0,Math.floor((now-start)/DAY)):null,auto30=eligible!==null&&now>=eligible;
 return {status:auto30?'auto30':'received_only',matched:auto30,exact:false,auto30,eligibleAt:eligible!==null?new Date(eligible).toISOString():null,ageDays,daysRemaining:ageDays===null?null:Math.max(0,30-ageDays)};
}
