export type TaxReviewItem={id:string;date:string;source:string;shop:string;label:string;amount:number;status:'pending'|'reviewed'|'excluded'|'separate';issues:string[];href:string;reference?:string;receipt?:string};
export function expenseReviewItem(r:any):TaxReviewItem{
 const issues:string[]=[];
 const separate=r.category==='cogs'||Boolean(r.supplierPayment);
 if(separate)issues.push('Đối chiếu nhập–xuất–tồn và giá vốn hàng đã bán; không trừ lần nữa tiền trả công nợ.');
 if(!r.reference)issues.push('Bổ sung mã hóa đơn / chứng từ.');
 if(!r.receipt?.key)issues.push('Bổ sung bản gốc hóa đơn hoặc chứng từ phù hợp.');
 if(!r.deductionBasis)issues.push('Rà soát căn cứ kinh doanh và điều kiện được trừ.');
 if(r.amount>=5000000&&r.paymentMethod!=='bank')issues.push('Đối chiếu chứng từ thanh toán không dùng tiền mặt từ 5 triệu đồng.');
 const reviewed=r.deductibility==='eligible'&&issues.length===0;
 if(!separate&&!reviewed&&r.deductibility!=='ineligible'&&!issues.length)issues.push('Hồ sơ đã có: cần kiểm tra nội dung, thanh toán và duyệt điều kiện thuế.');
 return {id:'expense:'+r.id,date:r.date,source:separate?'Tiền hàng / giá vốn':'Chi hoạt động',shop:r.channel,label:r.description,amount:r.amount,status:separate?'separate':r.deductibility==='ineligible'?'excluded':reviewed?'reviewed':'pending',issues,reference:r.reference,receipt:r.receipt?.name,href:separate?'/chi-phi':'/thue?'+new URLSearchParams({month:r.date.slice(0,7),type:'expense',review:r.id})};
}
export function flagSharedEvidence(items:TaxReviewItem[],keys:Map<string,string>){
 const occurrences=new Map<string,TaxReviewItem[]>();
 for(const item of items){const key=keys.get(item.id);if(key)occurrences.set(key,[...(occurrences.get(key)||[]),item]);}
 for(const same of occurrences.values())if(same.length>1)for(const item of same){item.issues.push('Có khoản khác dùng cùng chứng từ: đối chiếu phân bổ, tránh trừ trùng; chưa kết luận trùng.');if(item.status==='reviewed')item.status='pending';}
 return items;
}
