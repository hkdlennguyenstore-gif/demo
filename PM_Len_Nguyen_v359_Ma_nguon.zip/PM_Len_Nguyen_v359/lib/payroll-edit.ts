import {payroll,salaryRate,type State,type Adjustment} from './payroll';

export const payrollEditFields=['salary','days','overtime','holidayDays','holidayPay','holidayWorkedPay','base','otPay','meal','attendance','allowance','responsibility','insuranceCash','bonus','orderBonus','deduction','advance','employeeInsurance','employerInsurance'] as const;
export type PayrollEditField=typeof payrollEditFields[number];
export type PayrollEdits=Partial<Record<PayrollEditField,number>>;
const adjustmentFields=new Set(['allowance','responsibility','insuranceCash','bonus','orderBonus','deduction','advance']);

// A monthly correction never fabricates daily punches or changes another month's salary rate.
export function editPayrollCells(s:State,input:{employee:string,month:string,values:Record<string,unknown>}){
 if(!/^20\d{2}-(0[1-9]|1[0-2])$/.test(input.month))throw Error('Tháng không hợp lệ');
 if(s.locked.includes(input.month))throw Error('Tháng đã chốt. Chủ shop cần mở lại trước khi sửa.');
 const employee=s.employees.find(e=>e.id===input.employee);
 if(!employee)throw Error('Nhân viên không hợp lệ');
 if(!input.values||typeof input.values!=='object'||Array.isArray(input.values))throw Error('Thiếu khoản cần sửa');
 const entries=Object.entries(input.values);
 if(!entries.length||entries.length>payrollEditFields.length)throw Error('Chọn khoản cần sửa');
 const old=s.adjustments.find(a=>a.employee===input.employee&&a.month===input.month);
 const next:Adjustment={employee:input.employee,month:input.month,allowance:0,responsibility:0,bonus:0,orderBonus:0,deduction:0,advance:0,note:'',...old,payrollEditedAt:new Date().toISOString(),payrollEdits:{...old?.payrollEdits}};
 const before=payroll(s,employee,input.month),rate=salaryRate(employee,input.month);
 for(const [key,value] of entries){
  if(!payrollEditFields.includes(key as PayrollEditField))throw Error('Khoản lương không được sửa trực tiếp');
  const field=key as PayrollEditField;
  if(value!==null){
   const maximum=field==='days'?(input.month>='2026-11'?rate.days:31):field==='holidayDays'?31:field==='overtime'?744:1e10;
   if(typeof value!=='number'||!Number.isFinite(value)||value<0||value>maximum)throw Error(field==='days'?'Ngày công phải từ 0 đến '+maximum+'; phần vượt nhập vào tăng ca.':'Giá trị không hợp lệ: '+field);
   if(!['days','overtime','holidayDays'].includes(field)&&!Number.isSafeInteger(value))throw Error('Số tiền phải là số nguyên đồng');
  }
  if(adjustmentFields.has(field))(next as any)[field]=value??0;
  else if(value===null)delete next.payrollEdits![field];
  else next.payrollEdits![field]=value as number;
 }
 // Money follows the new inputs again unless this request explicitly edits that amount.
 if(entries.some(([k])=>['salary','days','overtime','holidayDays'].includes(k))){
  const dependent=new Set<string>();
  for(const [k] of entries){
   if(k==='salary')for(const f of ['base','otPay','holidayPay','holidayWorkedPay','employeeInsurance','employerInsurance'])dependent.add(f);
   if(k==='days')for(const f of ['base','meal','attendance'])dependent.add(f);
   if(k==='overtime')dependent.add('otPay');
   if(k==='holidayDays')for(const f of ['holidayPay','attendance'])dependent.add(f);
  }
  for(const f of dependent)if(!Object.hasOwn(input.values,f))delete (next.payrollEdits as any)[f];
 }
 s.adjustments=s.adjustments.filter(a=>!(a.employee===input.employee&&a.month===input.month));
 s.adjustments.push(next);
 return {before,after:payroll(s,employee,input.month),fields:entries.map(([field])=>field)};
}
