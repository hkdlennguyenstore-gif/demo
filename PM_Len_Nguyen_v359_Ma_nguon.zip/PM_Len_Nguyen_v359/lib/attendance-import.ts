import {hydrateState,payroll,payrollEmployees,salaryRate,type State,type Clock,type Employee,type SalaryRate} from './payroll.ts';
export const ATTENDANCE_RUN='attendance-apr-nov-20261117-v1';
const months=Array.from({length:8},(_,i)=>'2026-'+String(i+4).padStart(2,'0'));
const names=['Lên','Hạnh','Trang','Phương','Nhật Vy','Hoa','Hằng'];
const normalized=(s:string)=>s.trim().toLocaleLowerCase('vi');
function employee(s:State,name:string){return s.employees.find(e=>[e.name,e.alias].some(n=>normalized(n||'')===normalized(name)));}
function time(v:unknown,end=false){if(end&&v===1)return '24:00:00';if(v===null||v===undefined||v==='')return '';if(typeof v!=='number'||!Number.isFinite(v)||v<0||v>=1)throw Error('Giờ nguồn không hợp lệ');const n=Math.round(v*86400);return [Math.floor(n/3600),Math.floor(n%3600/60),n%60].map(v=>String(v).padStart(2,'0')).join(':');}
export function importAttendance(state:State,input:any){
 const s=hydrateState(structuredClone(state));
 if(input.run!==ATTENDANCE_RUN)throw Error('Sai mã đợt nhập');
 if(!Array.isArray(input.clocks)||input.clocks.length<1||input.clocks.length>5000)throw Error('Thiếu dữ liệu nguồn');
 if(s.imports?.includes(ATTENDANCE_RUN))return {s,report:{replayed:true,summary:summary(s)}};
 let added=0,updated=0,unchanged=0;const issues:any[]=[],seen=new Set<string>();
 for(const row of input.clocks){
  if(!names.includes(row.name)||!/^2026-(0[4-9]|1[01])-\d{2}$/.test(row.date)||row.date>'2026-11-17'||new Date(row.date+'T12:00:00Z').toISOString().slice(0,10)!==row.date||!Number.isInteger(row.row)||row.row<4||row.row>4736)throw Error('Dòng công ngoài phạm vi');
  let e=employee(s,row.name);if(!e){if(!['Hoa','Hằng'].includes(row.name))throw Error('Không tìm thấy nhân viên '+row.name);const template=s.employees.find(e=>e.name==='Hạnh')!;e={id:'legacy-'+normalized(row.name),name:row.name,alias:row.name,shift:'normal',salary:0,days:26,meal:template.meal,ot:template.ot,attendanceBonus:template.attendanceBonus,threshold:template.threshold,active:false,rates:[]};s.employees.push(e);}
  const key=e.id+':'+row.date;if(seen.has(key))throw Error('Trùng nhân viên/ngày trong nguồn: '+key);seen.add(key);
  const c:Clock={employee:e.id,date:row.date,start:time(row.start),end:time(row.end,true),note:'Nhập công từ Doanh Số Đơn Hàng · LenNguyen_Store dòng '+row.row,source:{sheet:'LenNguyen_Store',row:row.row,regular:row.regular,overtime:row.overtime}};
  for(const v of [row.regular,row.overtime])if(v!==null&&(typeof v!=='number'||!Number.isFinite(v)||v<0||v>24))throw Error('Số giờ không hợp lệ');
  const old=s.clocks.find(c=>c.employee===e!.id&&c.date===row.date);
  if(old&&old.start===c.start&&old.end===c.end&&old.source?.regular===c.source!.regular&&old.source?.overtime===c.source!.overtime){unchanged++;continue;}
  if(s.locked.includes(row.date.slice(0,7))){issues.push({date:row.date,name:row.name,reason:'Kỳ đã chốt, giữ nguyên công'});continue;}
  if(old&&(!old.source||old.source.sheet!=='LenNguyen_Store')){issues.push({date:row.date,name:row.name,reason:'Đã có công nhập trực tiếp, giữ nguyên để đối chiếu'});continue;}
  if(old){s.clocks[s.clocks.indexOf(old)]=c;updated++;}else{s.clocks.push(c);added++;}
 }
 // Import monthly source salary history only where no configured rate would be overwritten.
 for(const row of input.rates||[]){if(!names.includes(row.name)||!months.includes(row.month)||!Number.isFinite(row.salary)||row.salary<=0)throw Error('Mức lương nguồn không hợp lệ');const e=employee(s,row.name);if(!e)throw Error('Thiếu nhân viên cho mức lương');if(s.locked.includes(row.month))continue;if((e.rates||[]).some(r=>r.effectiveMonth===row.month))continue;const p=salaryRate(e,row.month);const r:SalaryRate={effectiveMonth:row.month,salary:row.salary,days:p.days,meal:p.meal,ot:p.ot,attendanceBonus:p.attendanceBonus,threshold:typeof row.threshold==='number'&&row.threshold>=0&&row.threshold<=31?row.threshold:p.threshold,shift:p.shift,insurance:p.insurance||{status:'pending',base:row.salary,region:1,reason:''},reason:'Lương cơ bản theo A5 / NhapLieu trong tháng '+row.month,updatedAt:new Date().toISOString()};e.rates=[...(e.rates||[]),r].sort((a,b)=>a.effectiveMonth.localeCompare(b.effectiveMonth));}
 for(const row of input.adjustments||[]){if(!names.includes(row.name)||!months.includes(row.month))throw Error('Điều chỉnh ngoài phạm vi');const e=employee(s,row.name);if(!e)throw Error('Thiếu nhân viên cho điều chỉnh');if(s.locked.includes(row.month))continue;const old=s.adjustments.find(a=>a.employee===e.id&&a.month===row.month);if(old){const fields=['responsibility','bonus','orderBonus','deduction','advance'] as const;if(fields.some(k=>(old[k]||0)!==(row[k]||0)))issues.push({name:row.name,month:row.month,reason:'Đã có điều chỉnh lương; giữ nguyên để đối chiếu',source:row,current:old});continue;}for(const k of ['responsibility','bonus','orderBonus','deduction','advance'])if(!Number.isFinite(row[k])||row[k]<0)throw Error('Khoản lương không hợp lệ');s.adjustments.push({employee:e.id,month:row.month,allowance:0,responsibility:row.responsibility,bonus:row.bonus,orderBonus:row.orderBonus,deduction:row.deduction,advance:row.advance,note:'Tổng theo A5 / NhapLieu · dòng '+row.sourceRows.join(', ')});}
 s.imports=[...(s.imports||[]),ATTENDANCE_RUN];s.audit.unshift({time:new Date().toISOString(),actor:'Chủ shop · cập nhật công/lương theo yêu cầu',action:`Nhập công 01/04–17/11/2026: thêm ${added}, cập nhật ${updated}, giữ ${unchanged}, chờ đối chiếu ${issues.length}. Giữ công đã chốt, mức lương đã thiết lập và công nhập trực tiếp.`});
 return {s,report:{replayed:false,added,updated,unchanged,issues,summary:summary(s)}};
}
export function summary(s:State){return months.map(month=>({month,locked:s.locked.includes(month),rows:payrollEmployees(s,month).filter(e=>s.clocks.some(c=>c.employee===e.id&&c.date.startsWith(month))).map(e=>({...payroll(s,e,month),clockRows:s.clocks.filter(c=>c.employee===e.id&&c.date.startsWith(month)).length}))}));}
