import test from 'node:test';
import assert from 'node:assert/strict';
import {shippingFields} from './pos-shipping';
import {classifyBill} from './gmail-invoice-classification';
test('keep missing POS amounts and payer distinct from confirmed zero',()=>{
 assert.equal(shippingFields({}).customerPays,null);
 assert.equal(shippingFields({customer_pay_fee:false,shipping_fee:0}).shipping,0);
 assert.equal(shippingFields({customer_pay_fee:true,reconciliation:{partner_fee:16000}}).settled,16000);
});
test('affiliate month is its service month and multi-line repairs stay under review',()=>{
 const b={vendor:'SHOPEE',buyer:'087089000961',day:'2026-11-03',series:'A',number:'1',total:100,lines:['AMS PPS 09/2026 quanjeanlennguyen']};
 assert.equal(classifyBill({...b,vendor:'HỘ KINH DOANH HOÀNG NGỌC LỢI',lines:['Phí dịch vụ quảng cáo']})?.channel,'facebook');
 assert.equal(classifyBill(b)?.channel,'shopee');
 assert.equal(classifyBill(b)?.month,'2026-09');
 assert.equal(classifyBill({...b,lines:['DỊCH VỤ SỬA CHỮA MÁY','vật tư khác']}),null);
});
import {verifiedShippingFee} from './gmail-crosscheck';
test('only match delivered Facebook fees with an explicit zero customer shipping charge',()=>{
 const order={tracking:'001',channel:'facebook',status:3,record:JSON.stringify({shippingEvidence:shippingFields({customer_pay_fee:false,shipping_fee:0,partner_fee:16000})})};
 assert.equal(verifiedShippingFee(16000,120000,order),true);
 assert.equal(verifiedShippingFee(16000,120000,{...order,record:JSON.stringify({shippingEvidence:shippingFields({customer_pay_fee:false,shipping_fee:20000,partner_fee:16000})})}),false);
 assert.equal(verifiedShippingFee(16000,120000,{...order,status:5}),false);
 assert.equal(verifiedShippingFee(17000,120000,order),false);
});
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {checkStatements,crossTables} from './gmail-crosscheck';
test('partial J&T posting reconciles once and excludes customer collection and overlapping waybills',async()=>{
 const sql=new DatabaseSync(':memory:');
 sql.exec(crossTables.join(';')+';'+readFileSync('drizzle/0001_bouncy_silverclaw.sql','utf8')+`
 CREATE TABLE app_state(id PRIMARY KEY,value,version);
 CREATE TABLE pm_orders(tracking,status,channel,record);
 CREATE TABLE gmail_documents(id PRIMARY KEY,mailId,state,targetId,amount,month,document,source,reason);
 CREATE TABLE gmail_evidence(id PRIMARY KEY,digest);
 CREATE TABLE gmail_document_facts(itemId PRIMARY KEY,facts);
 INSERT INTO gmail_documents VALUES('item','mail','pending','',32000,'2026-11','test.xlsx','J&T','');
 INSERT INTO gmail_evidence VALUES('mail','hash');
 INSERT INTO gmail_document_facts VALUES('item','{"invoice":{"buyerName":"HỘ KINH DOANH LÊN NGUYỄN STORE"},"reading":{"kind":"jt-statement","fromDate":"2026-11-01","toDate":"2026-11-02"}}');
 INSERT INTO gmail_jt_lines VALUES('item','hash','[["001",16000,220000],["002",16000,150000]]');
 INSERT INTO gmail_jt_lines VALUES('other','hash2','[["002",16000,150000]]');`);
 for(const code of ['001','002'])sql.prepare("INSERT INTO pm_orders VALUES(?,3,'facebook',?)").run(code,JSON.stringify({shippingEvidence:shippingFields({customer_pay_fee:false,shipping_fee:0,partner_fee:16000})}));
 function prepare(q:string,args:any[]=[]):any{return {bind:(...v:any[])=>prepare(q,v),first:async()=>sql.prepare(q).get(...args),all:async()=>({results:sql.prepare(q).all(...args)}),run:()=>sql.prepare(q).run(...args)};}
 const db={prepare,batch:async(items:any[])=>{sql.exec('BEGIN');try{for(const x of items)x.run();sql.exec('COMMIT');}catch(e){sql.exec('ROLLBACK');throw e;}}} as unknown as D1Database;
 await checkStatements(db,'item','',true,'owner');await checkStatements(db,'item','',true,'owner');
 assert.equal(sql.prepare('SELECT count(*) n FROM pm_finance_docs').get()?.n,1);
 assert.equal(sql.prepare('SELECT SUM(fee) n FROM gmail_jt_booked').get()?.n,16000);
 assert.equal(sql.prepare('SELECT count(*) n FROM pm_finance_audit').get()?.n,1);
});
