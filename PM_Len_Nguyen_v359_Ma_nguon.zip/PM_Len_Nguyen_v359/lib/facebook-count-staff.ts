// Links preserve the original count rows and their source identity.
export async function prepareCountStaffLinks(db:any){await db.prepare('CREATE TABLE IF NOT EXISTS pm_count_staff_links(source_employee TEXT PRIMARY KEY,employee TEXT NOT NULL,version INTEGER NOT NULL,record TEXT NOT NULL)').run();}
export async function readCountStaffLinks(db:any,employees:any[],range:{from:string;to:string}){
 await prepareCountStaffLinks(db);
 const clauses:string[]=[],args:string[]=[];
 if(range.from){clauses.push('date>=?');args.push(range.from);}if(range.to){clauses.push('date<=?');args.push(range.to);}
 const source=await db.prepare("SELECT employee,json_extract(record,'$.name') AS name FROM pm_order_counts GROUP BY employee ORDER BY name").all();
 const scoped=await db.prepare('SELECT employee,SUM(initial) AS initial,SUM(completed) AS completed,COUNT(*) AS rows FROM pm_order_counts'+(clauses.length?' WHERE '+clauses.join(' AND '):'')+' GROUP BY employee').bind(...args).all();
 const links=await db.prepare('SELECT source_employee,employee,version FROM pm_count_staff_links').all();
 const countSources=source.results.map((row:any)=>{
  const link=links.results.find((l:any)=>l.source_employee===row.employee);
  const member=employees.find(e=>e.id===(link?link.employee:row.employee));
  const counts=scoped.results.find((r:any)=>r.employee===row.employee);
  return {sourceEmployee:row.employee,sourceName:row.name||row.employee,employee:member?.id||'',employeeName:member?.name||'',linkVersion:link?.version||0,initial:counts?.initial??0,completed:counts?.completed??0,rows:counts?.rows??0};
 });
 const grouped=new Map<string,any>();
 for(const row of countSources.filter((r:any)=>r.rows>0)){
  const id=row.employee||'unassigned',value=grouped.get(id)||{employee:row.employee,name:row.employeeName||'Chưa gắn nhân viên',initial:0,completed:0,sources:0};
  value.initial+=row.initial;value.completed+=row.completed;value.sources++;grouped.set(id,value);
 }
 return {countSources,employeeCountStats:Array.from(grouped.values())};
}
export async function saveCountStaffLink(db:any,x:any,employees:any[],admin:boolean,actor:string,requestId:string,now:string){
 if(!admin)throw Error('Chỉ Chủ shop/Quản trị viên được gắn nhân viên shop');
 await prepareCountStaffLinks(db);
 if(await db.prepare('SELECT id FROM pm_order_actions WHERE id=?').bind(requestId).first())return {ok:true,replayed:true};
 const sourceEmployee=String(x.sourceEmployee||'').trim(),employee=String(x.employee||'');
 if(!sourceEmployee||sourceEmployee.length>200)throw Error('Chọn tên nhân viên nguồn');
 const source=await db.prepare('SELECT record FROM pm_order_counts WHERE employee=? LIMIT 1').bind(sourceEmployee).first();
 if(!source)throw Error('Không tìm thấy số lượng của tên nguồn này');
 const member=employee?employees.find(e=>e.id===employee&&e.active):null;
 if(employee&&!member)throw Error('Chọn nhân viên đang dùng trong shop');
 const old=await db.prepare('SELECT employee,version,record FROM pm_count_staff_links WHERE source_employee=?').bind(sourceEmployee).first();
 if(!Number.isSafeInteger(x.version)||x.version!==(old?.version||0))return {conflict:true,error:'Liên kết vừa thay đổi. Tải lại trước khi gắn.'};
 const version=(old?.version||0)+1,record={sourceEmployee,sourceName:JSON.parse(source.record).name,employee,name:member?.name||'',actor,updatedAt:now,requestId};
 const write=old?db.prepare('UPDATE pm_count_staff_links SET employee=?,version=?,record=? WHERE source_employee=? AND version=?').bind(employee,version,JSON.stringify(record),sourceEmployee,old.version):db.prepare('INSERT OR IGNORE INTO pm_count_staff_links VALUES(?,?,?,?)').bind(sourceEmployee,employee,version,JSON.stringify(record));
 const audit=db.prepare("INSERT INTO pm_order_actions SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM pm_count_staff_links WHERE source_employee=? AND version=? AND json_extract(record,'$.requestId')=?)").bind(requestId,now,actor,'Gắn nhân viên shop cho số lượng Facebook',JSON.stringify({before:old?JSON.parse(old.record):null,after:record}),sourceEmployee,version,requestId);
 const result=await db.batch([write,audit]);
 if(!result[0].meta.changes)return {conflict:true,error:'Có người vừa đổi liên kết. Tải lại.'};
 return {ok:true,version};
}
