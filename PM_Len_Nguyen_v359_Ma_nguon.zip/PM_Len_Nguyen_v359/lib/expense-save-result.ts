export const expenseSaveKey='ln-pm-expense-save-result-v1';
export type SaveSummary={added:number;duplicate:number;failed:number};
export type SavedBatch={counts:SaveSummary;keys:string[];time:number};
export function documentKey(row:any):string{
 if(row.kind==='invoice')return 'invoice:'+row.number;
 if(row.kind==='transaction')return 'transaction:'+row.account+':'+row.number;
 return 'evidence:'+JSON.stringify([row.ref,row.number,row.type,row.date,row.amount]);
}
export function readSavedBatch(raw:string|null):SavedBatch|null{
 try{const v=JSON.parse(raw||'null');if(!v||!Array.isArray(v.keys)||!v.keys.every((k:any)=>typeof k==='string')||!Number.isFinite(v.time)||Date.now()-v.time>86400000)return null;
 if(!['added','duplicate','failed'].every(k=>Number.isSafeInteger(v.counts?.[k])&&v.counts[k]>=0))return null;return v;}catch{return null;}
}
