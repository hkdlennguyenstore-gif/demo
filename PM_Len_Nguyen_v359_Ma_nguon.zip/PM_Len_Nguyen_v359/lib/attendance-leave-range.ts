import {checkedDate} from './date-range';

const dayMs=86400000;
export function leaveRange(from:unknown,to:unknown){
 if(typeof from!=='string'||typeof to!=='string')throw Error('Chọn ngày bắt đầu và ngày kết thúc nghỉ.');
 checkedDate(from);checkedDate(to);
 const first=Date.parse(from+'T00:00:00Z'),last=Date.parse(to+'T00:00:00Z'),count=(last-first)/dayMs+1;
 if(count<1)throw Error('Đến ngày không được trước từ ngày.');
 if(count>366)throw Error('Mỗi yêu cầu nghỉ tối đa 366 ngày.');
 return {from,to,days:Array.from({length:count},(_,i)=>new Date(first+i*dayMs).toISOString().slice(0,10))};
}
export const dateVN=(date:string)=>date.split('-').reverse().join('/');
export const leaveRangeLabel=(from:string,to:string)=>from===to?dateVN(from):dateVN(from)+' đến '+dateVN(to);
export const leaveStatus=(status:string)=>status==='approved'?'Đã duyệt':status==='rejected'?'Không được duyệt':'Chờ duyệt';
// Legacy requests store only date; the canonical date column remains the inclusive first day.
export const storedLeaveEnd="COALESCE(NULLIF(json_extract(record,'$.to'),''),date)";
export const hasLeaveOverlap="SELECT 1 FROM pm_order_leave WHERE employee=? AND status IN ('pending','approved') AND date<=? AND "+storedLeaveEnd+">=?";
