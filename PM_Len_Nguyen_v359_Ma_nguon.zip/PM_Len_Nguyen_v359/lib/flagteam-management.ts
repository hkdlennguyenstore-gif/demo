export const flagteamApprovalKey='flagteam-management:approved-2026-11-20';
export type ApprovedFee={item:string;sha:string;day:string;fee:number;total:number};

// Replace the daily agency charge in management views. A later ledger sync may
// supply the missing ad spend for the same day without adding its fee twice.
export async function managementAdsMonths(db:D1Database, rows:{record:string;id?:string}[], from='', to=''){
 const entry=await db.prepare('SELECT value FROM app_state WHERE id=?').bind(flagteamApprovalKey).first<{value:string}>();
 if(!entry)return rows;
 const months=new Map(rows.map(row=>{
  const month=JSON.parse(row.record);
  return [row.id??(month.provider+':'+month.month),month];
 }));
 for(const charge of JSON.parse(entry.value) as ApprovedFee[]){
  if((from && charge.day<from)||(to && charge.day>to))continue;
  const month=charge.day.slice(0,7),id='flagteam:'+month;
  const ledger=months.get(id)??{month,provider:'flagteam',days:[]};
  const day=ledger.days.find((d:{date:string})=>d.date===charge.day);
  if(day){
   if(day.fee===charge.fee)continue;
   day.total=(day.total??0)-(day.fee??0)+charge.fee;
   day.fee=charge.fee;
  }else{
   ledger.days.push({date:charge.day,ads:0,fee:charge.fee,total:charge.fee,feeOnly:true});
   ledger.days.sort((a:{date:string},b:{date:string})=>a.date.localeCompare(b.date));
  }
  months.set(id,ledger);
 }
 return Array.from(months,([id,month])=>({id,record:JSON.stringify(month)}));
}
