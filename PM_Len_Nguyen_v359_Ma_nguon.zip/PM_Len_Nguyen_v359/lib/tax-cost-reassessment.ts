export function operatingEligible(r:any){return Boolean(r.category!=='cogs'&&!r.supplierPayment&&r.deductibility==='eligible'&&r.receipt?.key&&r.reference&&r.deductionBasis&&(r.amount<5000000||r.paymentMethod==='bank'));}
export function reassessCost(old:any,x:any,actor:string,time:string){
if(old.category==='cogs'||old.supplierPayment)throw Error('Tiền hàng và thanh toán công nợ cần đối chiếu giá vốn hàng đã bán, không đưa vào chi hoạt động lần nữa');
if(old.kind!=='expense'||old.status!=='confirmed')throw Error('Chỉ bổ sung phiếu chi đã xác nhận; phiếu nháp cần hoàn tất trước');
if(operatingEligible(old))throw Error('Khoản này đã được tính vào chi phí thuế, không bổ sung lại');
if(x.version!==old.version)throw Error('Phiếu đã thay đổi. Tải lại danh sách');
const reason=String(x.reason||'').trim(),basis=String(x.basis||'').trim(),reference=String(x.reference||old.reference||'').trim(),receipt=x.receipt||old.receipt,paymentMethod=x.paymentMethod||old.paymentMethod;
if(reason.length<5||reason.length>1000)throw Error('Nhập lý do bổ sung từ 5 đến 1.000 ký tự');
if(!basis||basis.length>1000||!reference||reference.length>120)throw Error('Bổ sung mã chứng từ và căn cứ rà soát');
if(!receipt?.key||(!/^receipts\/[0-9a-f-]{36}$/.test(receipt.key)&&receipt.key!==old.receipt?.key))throw Error('Cần đính kèm chứng từ hợp lệ');
if(!['bank','cash'].includes(paymentMethod))throw Error('Chọn hình thức thanh toán');
if(old.amount>=5000000&&paymentMethod!=='bank')throw Error('Khoản từ 5 triệu cần chứng từ thanh toán không dùng tiền mặt để rà soát');
if(x.reviewed!==true)throw Error('Cần xác nhận đã kiểm tra hồ sơ và điều kiện thuế');
return {...old,reference,receipt:old.receipt||receipt,paymentMethod,deductionBasis:basis,deductibility:'eligible',version:old.version+1,actor,updatedAt:time,taxReassessment:{reason,previousStatus:old.deductibility,actor,time,receipt}};
}
