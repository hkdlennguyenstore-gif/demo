// A3 price_tt!G2: ARRAYFORMULA(IF(F2:F="";;F2:F+60000)).
export function facebookFormulaPrice(input:unknown):number|null {
  if(input===null||input===undefined||input==='')return null;
  const value=Number(input);
  return Number.isSafeInteger(value)&&value>=0&&value<=1e10?value+60000:null;
}
