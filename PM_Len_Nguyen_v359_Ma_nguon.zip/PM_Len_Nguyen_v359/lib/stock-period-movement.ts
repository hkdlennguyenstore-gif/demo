export function movementPeriodRange(requested:{from:string;to:string},today:string){return {from:requested.from||'2026-04-01',to:requested.to&&requested.to<today?requested.to:today};}
export function sumStockPeriodMovement(sold:any[],received:any[]){
 const count=(value:any)=>{if(value===null||value===undefined||value===''||typeof value==='boolean'||!Number.isSafeInteger(Number(value)))throw Error('POS thiếu số lượng sản phẩm trong kỳ');return Number(value);};
 let sales=0,returns=0;const saleIds=new Set<string>(),returnIds=new Set<string>();
 for(const row of sold){const id=String(row.id||''),n=count(row.sell_export);if(!id||saleIds.has(id)||n>0)throw Error('Dữ liệu hàng bán trong kỳ bị trùng hoặc mâu thuẫn');saleIds.add(id);sales+=-n;}
 for(const row of received){const id=String(row.id||''),n=count(row.return_import);if(!id||returnIds.has(id)||n<0)throw Error('Dữ liệu hoàn về trong kỳ bị trùng hoặc mâu thuẫn');returnIds.add(id);returns+=n;}
 if(!Number.isSafeInteger(sales)||!Number.isSafeInteger(returns))throw Error('Số lượng trong kỳ vượt phạm vi hợp lệ');return {sold:sales,returned:returns};
}
