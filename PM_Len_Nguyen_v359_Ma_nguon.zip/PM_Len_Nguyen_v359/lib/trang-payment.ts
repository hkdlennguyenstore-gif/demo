import {paymentDate} from './payment-date';
export const trangId='e70a7f61-d89b-5058-90a9-48dc985bbde1';
const fold=(v:string)=>v.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').trim().replace(/\s+/g,' ').toLowerCase();
export function directRecipient(v:string){return ['trinh thi trang','trang'].includes(fold(v));}
export function afterPayment(before:number,amount:number,applied:boolean){
 const balance=before-(applied?amount:0);return {debt:Math.max(0,balance),advance:Math.max(0,-balance)};
}
const amountLabel=/^(?:so tien(?: giao dich| chuyen khoan| chuyen| thanh toan)?|transfer amount|amount transferred|amount)(?:\s*\(vnd\))?\s*[:：|-]?\s*/;
const recipientLabel=/^(?:ten (?:tai khoan (?:nguoi nhan|thu huong)|nguoi nhan|nguoi thu huong|chu tai khoan nhan|thu huong)|nguoi (?:nhan|thu huong)|chuyen (?:tien )?den|beneficiary(?: name)?|recipient(?: name)?)(?=$|[\s:：|-])\s*[:：|-]?\s*/;
function transferAmount(value:string,requireCurrency:boolean){
 const match=fold(value).match(/^(?:(vnd|₫|d)\s*)?(\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]00)?\s*(vnd|₫|d)?$/);
 if(!match||(requireCurrency&&!match[1]&&!match[3]))return 0;
 const n=Number(match[2].replace(/\D/g,''));
 return Number.isSafeInteger(n)&&n>0?n:0;
}
export function readTransfer(raw:string){
 const lines=raw.normalize('NFC').split(/\r?\n/).map(v=>v.trim()).filter(Boolean);
 const amounts=new Set<number>(),headlines=new Set<number>(),names=new Map<string,string>();
 for(let i=0;i<lines.length;i++){
  const line=fold(lines[i]),next=lines[i+1]||'';
  const label=line.match(amountLabel);
  if(label){
   const amount=transferAmount(line.slice(label[0].length)||next,false);
   if(amount)amounts.add(amount);
  }
  const previous=fold(lines[i-1]||'');
  if(!/(so du|balance|phi|fee|han muc|limit)/.test(previous)){
   const amount=transferAmount(line,true);
   if(amount)headlines.add(amount);
  }
  const who=line.match(recipientLabel);
  if(who){
   const original=lines[i].replace(/\s+/g,' ');
   const value=(original.slice(who[0].length)||next).trim();
   if(/^[\p{L}][\p{L} .'-]{2,80}$/u.test(value)&&!/(ngan hang|bank|so tien|ngay giao dich|tai khoan|noi dung|chuyen tien|thoi gian|ma giao dich|so du)/.test(fold(value)))names.set(fold(value),value);
  }
 }
 const success=/chuyen (?:tien |khoan )?thanh cong|giao dich thanh cong|transfer successful/.test(fold(raw));
 // On Techcombank slips OCR may miss the pale recipient label. The bold recipient
 // appears directly between the headline amount and the beneficiary account.
 if(!names.size&&success&&/techcombank/.test(fold(raw))){
  for(let i=1;i+1<lines.length;i++){
   if(!transferAmount(lines[i-1],true)||!/^\d{6,20}$/.test(lines[i+1]))continue;
   const candidate=lines[i];
   if(/^[\p{Lu}][\p{Lu} .'-]{2,79}$/u.test(candidate)&&candidate.includes(' '))names.set(fold(candidate),candidate);
  }
 }
 const candidates=amounts.size?amounts:success?headlines:new Set<number>();
 const normalizedDate=raw.replace(/(\d)\s*([/.\-])\s*(?=\d)/g,'$1$2').replace(/(\d{1,2})\s+(?:tháng|thg)\s+(\d{1,2})(?:\s+năm|,)?\s+(20\d{2})/giu,'$1/$2/$3');
 return {date:paymentDate(normalizedDate),amount:candidates.size===1?[...candidates][0]:0,recipient:names.size===1?[...names.values()][0]:''};
}
