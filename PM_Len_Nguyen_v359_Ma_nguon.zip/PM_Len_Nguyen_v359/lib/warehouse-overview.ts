import {analyticsQuery,readReturnedStock} from './pos-source-report';
import {posGet} from './orders-store';
import {selectHistoricalPrice,type HistoricalPrice} from './price-history';
import type {DateRange} from './date-range';
import {marketplaceAccounts} from './marketplace-orders';

export async function warehouseOverview(db:D1Database,config:{PANCAKE_SHOP_ID?:string;PANCAKE_API_KEY?:string},range:DateRange){
 const received=await db.prepare("SELECT source, SUM(quantity) quantity FROM pm_stock_receipts WHERE active=1 AND date BETWEEN ? AND ? GROUP BY source ORDER BY source").bind(range.from||'0000',range.to||'9999').all<{source:string;quantity:number}>();
 const base={received:received.results,returned:null as number|null,orders:null as number|null,issued:null as number|null,cost:null as number|null,missing:[] as string[],reason:''};
 try{
  const summary=await readReturnedStock(config,range);
  if(summary.every(r=>Number.isSafeInteger(r.quantity)))base.returned=summary.reduce((n,r)=>n+r.quantity!,0);
  if(summary.every(r=>Number.isSafeInteger(r.orders)))base.orders=summary.reduce((n,r)=>n+r.orders!,0);
  const query={...analyticsQuery(range),success_status:'send_to_partner','select_fields[]':['product_count']};
  const aggregate=await posGet(config.PANCAKE_API_KEY!,config.PANCAKE_SHOP_ID!,'analytics/sale',query);
  const relevant=(r:any)=>String(r.order_sources)==='-1'||marketplaceAccounts.some(a=>a.source===String(r.order_sources)&&a.account===String(r.account));
  function units(r:any,section:string){if(r[section]===null)return 0;const v=r[section]?.product_count;if(v==null||v===''||!Number.isSafeInteger(Number(v))||Number(v)<0)throw Error('POS thiếu số lượng theo trạng thái');return Number(v);}
  if(aggregate.pagination)throw Error('Báo cáo xuất POS chưa đủ trang');
  base.issued=aggregate.data.filter(relevant).reduce((n:number,r:any)=>n+units(r,'success'),0);
  if(base.issued===0&&base.returned===0){base.cost=0;return base;}
  const detail=await posGet(config.PANCAKE_API_KEY!,config.PANCAKE_SHOP_ID!,'analytics/sale',{...query,'split_by[]':['Order.source','Time.day','Variation.product_id']});
  if(detail.pagination)throw Error('Chi tiết sản phẩm POS chưa đủ trang');
  const prices=(await db.prepare('SELECT record FROM pm_price_history').all<{record:string}>()).results.map(r=>JSON.parse(r.record) as HistoricalPrice);
  const codes=new Set(prices.map(p=>p.code.trim().toUpperCase()));
  let issued=0,returned=0,cost=0;const missing=new Set<string>();
  for(const row of detail.data.filter(relevant)){
   const sold=units(row,'success'),back=units(row,'returned');if(!sold&&!back)continue;
   issued+=sold;returned+=back;
   const day=String(row['Time.day']||row.day||'').slice(0,10);
   const product=row.product||row.variation?.product||{};
   const identifiers=[row.product_code,row.product_display_id,product.display_id,product.custom_id,row['Variation.product_id']].filter(v=>typeof v==='string').map(v=>v.trim().toUpperCase());
   const candidates=[...new Set(identifiers.filter(v=>codes.has(v)))];
   const price=candidates.length===1&&/^20\d\d-\d\d-\d\d$/.test(day)?selectHistoricalPrice(prices,candidates[0],day).price:null;
   if(price===null||price<=0){missing.add(String(identifiers[0]||product.name||row.product_id||'Thiếu mã hoặc ngày'));continue;}
   cost+=(sold-back)*price;
  }
  base.missing=[...missing];
  if(issued!==base.issued||returned!==base.returned)throw Error('Chi tiết theo mã chưa khớp tổng xuất và hoàn của bốn kênh');
  if(missing.size)throw Error(missing.size+' mã chưa ghép được với giá A3 đúng ngày');
  base.cost=cost;
 }catch(e){base.reason=(e as Error).message;}
 return base;
}
