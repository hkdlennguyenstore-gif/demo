export function paymentDate(text:string){
 const months=['january','february','march','april','may','june','july','august','september','october','november','december'];
 const normalized=text.replace(/\b([A-Za-z]{3,9})\.?\s+(\d{1,2}),?\s+(20\d{2})\b/g,(raw,month,day,year)=>{
  const n=months.findIndex(m=>m===month.toLowerCase()||m.slice(0,3)===month.toLowerCase());return n<0?raw:year+'-'+(n+1)+'-'+day;
 });
 const source=normalized.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').toLowerCase();
 const labels=/(?:ngay|thoi gian)(?:[, ]+(?:va )?gio)?\s+(?:giao dich|thanh toan|chuyen(?: tien| khoan)?|thuc hien|ghi no)|(?:transaction|payment|transfer) (?:date|time)|date paid|payment received on|paid (?:on|at)|thanh toan (?:luc|ngay)|支付时间|交易时间/g;
 const pattern=/(?:\b(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})|\b(\d{1,2})[-/.](\d{1,2})[-/.](20\d{2}))(?=\D|$)/g;
 const found=new Set<string>();
 for(const match of source.matchAll(pattern)){
  const y=match[1]||match[6],m=match[2]||match[5],d=match[3]||match[4];
  const iso=[y,m.padStart(2,'0'),d.padStart(2,'0')].join('-');
  const day=new Date(iso+'T00:00:00Z');
  if(!Number.isFinite(+day)||day.toISOString().slice(0,10)!==iso)continue;
  const prefix=source.slice(Math.max(0,match.index!-100),match.index);
  const label=Array.from(prefix.matchAll(labels)).at(-1);
  if(label && /^[\s:.,|–()\-\dht]*$/.test(prefix.slice(label.index!+label[0].length)))found.add(iso);
 }
 if(found.size===1)return [...found][0];
 if(!found.size&&/chuyen (?:tien |khoan )?thanh cong|giao dich thanh cong|transfer successful/.test(source)&&!/ngay lap|ngay hoa don|han thanh toan|due date|invoice date/.test(source)){
  const dates=[...source.matchAll(pattern)];
  if(dates.length===1)return paymentDate('ngay giao dich: '+dates[0][0]);
 }
 return '';
}
