import {zipSync,strToU8} from 'fflate';
import {financeChannels,expenseGroups,csvValue} from './finance';
import {taxBucket,type Line} from './expense-lines';

export const channels={facebook:'Facebook',tiktok1:'TikTok 1',tiktok2:'TikTok 2',shopee:'Shopee',shared:'Chi phí chung'};
export const names={...expenseGroups,unclassified:'Chờ phân nhóm'} as Record<string,string>;
export const amount=(lines:Line[])=>lines.reduce((n,l)=>n+l.amount,0);
type Cell=string|number;
export function matrix(lines:Line[]):Cell[][]{
 return Object.entries(names).flatMap(([id,name])=>{
  const group=lines.filter(l=>l.group===id);
  if(!group.length)return [];
  return [[name,...Object.keys(channels).map(k=>{const rows=group.filter(l=>l.shop===k);return rows.length?amount(rows):''}),amount(group)]];
 });
}
export function reportTable(lines:Line[],summary:boolean):Cell[][]{
 if(summary)return [['Đầu chi',...Object.values(channels),'Tổng'],...matrix(lines)];
 return [['Ngày','Shop','Đầu chi','Nội dung','Nguồn','Mã đối chiếu','Số tiền','Hóa đơn tài khoản/kỳ','Rà soát'],...lines.map(l=>[l.date,l.shop==='shared'?channels.shared:financeChannels[l.shop],names[l.group],l.label,l.source,l.reference||'',l.amount,l.invoice?'Đã có':'Chưa xác nhận',{eligible:'Đủ điều kiện',pending:'Chờ rà soát',ineligible:'Không được trừ'}[taxBucket(l)]])];
}
const escape=(s:string)=>s.replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g,'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
export function downloadBytes(table:Cell[][],xlsx:boolean){
 if(!xlsx)return strToU8('\uFEFF'+table.map(row=>row.map(v=>typeof v==='number'?String(v):csvValue(v)).join(',')).join('\r\n'));
 const main='http://schemas.openxmlformats.org/spreadsheetml/2006/main',rels='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
 const relationships=(type:string,target:string)=>'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="'+rels+'/'+type+'" Target="'+target+'"/></Relationships>';
 const rows=table.map((row,i)=>'<row r="'+(i+1)+'">'+row.map((c,j)=>{const ref=String.fromCharCode(65+j)+(i+1);return typeof c==='number'?'<c r="'+ref+'"><v>'+c+'</v></c>':'<c r="'+ref+'" t="inlineStr"><is><t xml:space="preserve">'+escape(c)+'</t></is></c>'}).join('')+'</row>').join('');
 return zipSync(Object.fromEntries(Object.entries({
 '[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>',
 '_rels/.rels':relationships('officeDocument','xl/workbook.xml'),
 'xl/workbook.xml':'<workbook xmlns="'+main+'" xmlns:r="'+rels+'"><sheets><sheet name="Chi phí" sheetId="1" r:id="rId1"/></sheets></workbook>',
 'xl/_rels/workbook.xml.rels':relationships('worksheet','worksheets/sheet1.xml'),
 'xl/worksheets/sheet1.xml':'<worksheet xmlns="'+main+'"><sheetData>'+rows+'</sheetData></worksheet>'
 }).map(([k,v])=>[k,strToU8(v)])));
}
