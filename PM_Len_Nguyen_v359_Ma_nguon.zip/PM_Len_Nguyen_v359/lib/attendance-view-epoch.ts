// A request started in a private view may update it only until its generation is revoked.
export function createAttendanceViewEpoch() {
 let generation=0;
 let active:AbortController|undefined;
 function revoke(){
  generation++;
  active?.abort();
  active=undefined;
 }
 return {
  revoke,
  begin(){
   revoke();
   const id=generation;
   const controller=new AbortController();
   active=controller;
   return {signal:controller.signal,current:()=>id===generation&&!controller.signal.aborted};
  },
 };
}

// The schedule endpoint derives this scope from server membership, not the selected kiosk row.
export function sameAttendanceEmployee(expected:string,view:{me?:{id:string}|null;admin?:boolean}){
 return view.admin===false&&view.me?.id===expected;
}
