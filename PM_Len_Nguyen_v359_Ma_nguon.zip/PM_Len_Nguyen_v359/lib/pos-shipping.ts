export function shippingFields(order:Record<string,any>){
 const money=(n:unknown)=>typeof n==='number'&&Number.isSafeInteger(n)&&n>=0?n:null;
 return {
  customerPays:typeof order.customer_pay_fee==='boolean'?order.customer_pay_fee:null,
  free:typeof order.is_free_shipping==='boolean'?order.is_free_shipping:null,
  shipping:money(order.shipping_fee),partner:money(order.partner_fee),
  settled:money(order.reconciliation?.partner_fee),cod:money(order.reconciliation?.cod_amount),
  settlement:typeof order.reconciliation?.status_reconciliation==='string'?order.reconciliation.status_reconciliation:null
 };
}
