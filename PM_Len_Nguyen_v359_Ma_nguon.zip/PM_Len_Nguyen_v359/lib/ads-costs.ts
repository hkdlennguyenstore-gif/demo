import {managementAdsMonths} from './flagteam-management';
import {applyAdControls,settings,overridePrefix,sourceMode,type ExpenseOverride} from './expense-controls';
import {checkedDate,withinRange,type DateRange} from './date-range';
import {taxPeriod} from './finance';
import {digest} from './a3-access';
import {text} from './purchasing';
export const adsProviders={giaminh:'Gia Minh Media',flagteam:'Flagteam',tiktok1:'TikTok 1',tiktok2:'TikTok 2',shopee:'Shopee'};
const clean=(s:string)=>s.replace(/<[^>]*>/g,' ').replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(+n)).replace(/&nbsp;|&#160;/g,' ').replace(/&amp;/g,'&').replace(/\s+/g,' ').trim();
const cells=(s:string)=>[...s.matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(m=>clean(m[1]));
const value=(s:string)=>{if(!/^\d[\d.,\s]*(?:đ|₫|VND)?$/i.test(s))throw Error('Số tiền nguồn không hợp lệ');const n=Number(s.replace(/[^\d]/g,''));if(!Number.isSafeInteger(n))throw Error('Số tiền nguồn vượt giới hạn');return n;};
export function parseGiaMinh(html:string,month:string){
 taxPeriod(month);if(!/^20\d{2}-\d{2}$/.test(month))throw Error('Chọn tháng nguồn');
 const table=[...html.matchAll(/<table\b[^>]*>[\s\S]*?<\/table>/gi)].map(m=>m[0]).find(s=>s.includes('QC Mess')&&s.includes('Tổng chi'));if(!table)throw Error('Nguồn không còn đúng bảng Sổ chi');
 const head=cells(table.match(/<thead\b[^>]*>([\s\S]*?)<\/thead>/i)?.[1]||'');if(head.join('|')!=='Ngày|Số tiền CK|QC Mess|QC Live AM|QC Live PM|Phí DV|Tổng chi')throw Error('Cột Sổ chi đã đổi; cần kiểm tra nguồn');
 const body=table.match(/<tbody\b[^>]*>([\s\S]*?)<\/tbody>/i)?.[1],foot=cells(table.match(/<tfoot\b[^>]*>([\s\S]*?)<\/tfoot>/i)?.[1]||'');if(body===undefined||foot.length!==7)throw Error('Nguồn thiếu bảng chi / tổng tháng');
 const seen=new Set<string>(),days=[...body.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)].map(m=>{const c=cells(m[1]);if(c.length!==7||!/^\d{2}\/\d{2}\/20\d{2}$/.test(c[0]))throw Error('Dòng nguồn không hợp lệ');const date=checkedDate(c[0].split('/').reverse().join('-'));if(!date.startsWith(month)||seen.has(date))throw Error('Nguồn sai tháng hoặc lặp ngày');seen.add(date);const [transfer,mess,am,pm,fee,total]=c.slice(1).map(value),ads=mess+am+pm;if(ads+fee!==total)throw Error('Quảng cáo + phí không khớp tổng ngày');return {date,transfer,ads,fee,total};});
 const expected=foot.slice(1).map(value),actual=[0,0,0,0,0,0];for(const m of [...body.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)])cells(m[1]).slice(1).map(value).forEach((n,i)=>actual[i]+=n);if(actual.some((n,i)=>n!==expected[i]))throw Error('Chi tiết không khớp tổng nguồn tháng');return days.sort((a,b)=>a.date.localeCompare(b.date));
}
// Keep ledger totals separate from Meta receipt evidence.
export function parseFlagteam(html:string,month:string){
 if(!/^20\d{2}-(0[1-9]|1[0-2])$/.test(month))throw Error('Chọn tháng nguồn');
 const table=[...html.matchAll(/<table\b[^>]*>[\s\S]*?<\/table>/gi)].map(m=>m[0]).find(t=>t.includes('TỔNG SỐ TIỀN ĐÃ NẠP')&&t.includes('Tổng FB'));if(!table)throw Error('Nguồn Flagteam không còn đúng bảng công nợ');
 const all=[...table.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)].map(m=>m[1]),header=all.map(cells).find(c=>c[0]==='NGÀY');if(!header||header.join('|')!=='NGÀY|TỔNG SỐ TIỀN ĐÃ NẠP|Thuế nhà thầu FCT|Dịch vụ khác|QC MESS|QC LIVE STREAM|Tổng FB|Phí DV (6%)|Tiền đã thanh toán phí DV|Chiết khấu|Hóa đơn|Tổng ngày|Dư nợ cuối')throw Error('Cột Flagteam đã đổi; cần kiểm tra nguồn');
 const get=(cell:string)=>{const el=[...cell.matchAll(/<(p|a|span)\b([^>]*)>([\s\S]*?)<\/\1>/gi)],main=el.filter(m=>(m[2].match(/class=["']([^"']*)["']/i)?.[1]||'').split(/\s+/).includes('money')),v=main.map(m=>clean(m[3])),extra=el.filter(m=>(m[2].match(/class=["']([^"']*)["']/i)?.[1]||'').split(/\s+/).includes('money-title')).map(m=>clean(m[3]).match(/^\(FCT:\s*([\d, .]+)\)$/)?.[1]).filter(Boolean);if(!main.length&&!extra.length&&/\d/.test(clean(cell)))throw Error('Số tiền Flagteam đổi định dạng');return v.reduce((n,s)=>n+(s&&s!=='-'?value(s):0),0)+extra.reduce((n,v)=>n+value(v!),0);};
 const parse=(raw:string[])=>{if(raw.length!==14)throw Error('Thiếu cột chi tiết Flagteam');const transfer=get(raw[1]),fct=get(raw[2]),other=get(raw[3]),mess=get(raw[4]),am=get(raw[5]),pm=get(raw[6]),ads=get(raw[7]),fee=get(raw[8]),feePaid=get(raw[9]),discount=get(raw[10]),total=get(raw[12]);if(mess+am+pm!==ads)throw Error('QC Mess / Live không khớp Tổng FB');if(ads+fee+other-discount!==total)throw Error('Chi phí không khớp Tổng ngày Flagteam');const invoice=[...raw[8].matchAll(/href=["'](https:\/\/crm\.anphatmedia\.vn\/hoa-don\/[0-9a-f-]+\/download)["']/gi)].map(m=>m[1]);return {transfer,fct,other,ads,fee,feePaid,discount,total,invoice};};
 const monthTitle='Tháng '+month.slice(5)+'/'+month.slice(0,4),seen=new Set<string>(),days:any[]=[];let expected:any=null;
 for(const row of all){const raw=[...row.matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(m=>m[1]),label=clean(raw[0]||'');if(label===monthTitle){if(expected)throw Error('Trùng tổng tháng Flagteam');expected=parse(raw);}else if(/^\d{2}\/\d{2}\/20\d{2}/.test(label)){const date=checkedDate(label.slice(0,10).split('/').reverse().join('-'));if(!date.startsWith(month))continue;if(seen.has(date))throw Error('Trùng ngày nguồn Flagteam');seen.add(date);const receiptIds=[...new Set([...raw[11].matchAll(/href=["']https:\/\/api\.ads\.flagteam\.vn\/transactions\/(\d+-\d+)\/pdf-download\/?["']/gi)].map(m=>m[1]))];
 days.push({date,...parse(raw),...(receiptIds.length?{receiptIds}:{})});}}
 if(!expected)throw Error('Flagteam chưa có bảng tháng '+month);for(const key of ['transfer','fct','other','ads','fee','feePaid','discount','total'])if(days.reduce((n,d)=>n+d[key],0)!==expected[key])throw Error('Chi tiết không khớp tổng tháng Flagteam: '+key);return days.sort((a,b)=>a.date.localeCompare(b.date));
}
export function sourceMonths(period:string,today:string){const p=taxPeriod(period),months=[];for(let m=p.date.slice(0,7);m<=p.endDate.slice(0,7)&&m<=today.slice(0,7);){months.push(m);const d=new Date(m+'-01T00:00:00Z');d.setUTCMonth(d.getUTCMonth()+1);m=d.toISOString().slice(0,7);}return months;}
export async function readAdsCosts(db:D1Database,range:DateRange){const controls=await settings<ExpenseOverride>(db,overridePrefix);const data=await db.prepare('SELECT id,record FROM pm_ads_months').all<any>(),reviews=await db.prepare('SELECT id,record,version FROM pm_ads_reviews').all<any>(),map=new Map(reviews.results.map(r=>[r.id,{...JSON.parse(r.record),version:r.version}])),rows:any[]=[];
 for(const entry of await managementAdsMonths(db,data.results)){const s=JSON.parse(entry.record);s.days=applyAdControls(s.days,s.provider,controls);const days=s.days.filter((d:any)=>withinRange(d.date,range));if(!days.length&&((range.from&&s.month<range.from.slice(0,7))||(range.to&&s.month>range.to.slice(0,7))))continue;const fingerprint=await digest(JSON.stringify(s.days)),review=map.get(entry.id),fresh=review?.fingerprint===fingerprint,status=fresh?review.status:'pending',sum=(k:string)=>days.reduce((n:number,d:any)=>n+(d[k]||0),0);rows.push({...s,id:entry.id,days,fullDays:s.days,fingerprint,review:review||null,status,stale:Boolean(review&&!fresh),ads:sum('ads'),fee:sum('fee'),fct:sum('fct'),other:sum('other'),discount:sum('discount'),feePaid:sum('feePaid'),total:sum('total'),transfer:sum('transfer')});}
 rows.sort((a,b)=>b.month.localeCompare(a.month)||a.provider.localeCompare(b.provider));const sum=(k:string,rs=rows)=>rs.reduce((n,r)=>n+r[k],0),sync=await db.prepare('SELECT id,record FROM pm_ads_sync').all<any>();return {rows,summary:{ads:sum('ads'),fee:sum('fee'),fct:sum('fct'),other:sum('other'),discount:sum('discount'),feePaid:sum('feePaid'),total:sum('total'),transfer:sum('transfer'),eligible:sum('total',rows.filter(r=>r.status==='eligible')),pending:rows.filter(r=>r.status==='pending').length},sync:sync.results.map(r=>({provider:r.id,...JSON.parse(r.record)})),snapshot:await digest(JSON.stringify(rows.map(r=>[r.id,r.fingerprint,r.status,r.review?.version||0]))),flagteam:{status:sync.results.some(r=>r.id==='flagteam'&&JSON.parse(r.record).lastSuccess)?'connected':'pending'}};}
export function validateAdsReview(row:any,x:any){if(!['eligible','pending','ineligible'].includes(x.status))throw Error('Chọn điều kiện thuế');const basis=text(x.basis,1500),reference=text(x.reference,150),paymentReference=text(x.paymentReference,150),receipt=x.receipt||null;if(x.status==='eligible'&&(!basis||!reference||!paymentReference||!receipt||x.paymentVerified!==true))throw Error('Cần hóa đơn, căn cứ, chứng từ và xác nhận thanh toán hợp lệ; bảng chi đối tác chưa đủ căn cứ thuế');return {fingerprint:row.fingerprint,status:x.status,basis,reference,paymentReference,paymentVerified:x.paymentVerified===true,receipt};}
function agencyUrl(base:string,provider:'giaminh'|'flagteam'){
 if(!base)throw Error('Chưa cấu hình link '+adsProviders[provider]+' trên máy chủ');const url=new URL(base);
 if(provider==='flagteam'&&url.origin==='https://ads.flagteam.vn'&&url.pathname==='/khach-hang')url.hostname='crm.anphatmedia.vn';
 const valid=provider==='giaminh'?url.origin==='https://ads.giaminhmedia.info'&&url.pathname.startsWith('/p/so-chi/'):url.origin==='https://crm.anphatmedia.vn'&&url.pathname==='/khach-hang'&&Boolean(url.searchParams.get('id'));if(!valid||url.username||url.password)throw Error('Link '+adsProviders[provider]+' không hợp lệ');
 return url;
}
async function agencyHtml(url:URL){
 const res=await fetch(url,{cache:'no-store',redirect:'manual',headers:{Accept:'text/html'},signal:AbortSignal.timeout(18000)});if(res.status>=300&&res.status<400)throw Error('Nguồn chuyển hướng; cần xác minh link mới');if(!res.ok)throw Error('Nguồn trả lỗi HTTP '+res.status);if(!res.headers.get('content-type')?.includes('text/html'))throw Error('Nguồn chưa trả bảng chi');const reader=res.body?.getReader();if(!reader)throw Error('Nguồn rỗng');let html='';let size=0;const decoder=new TextDecoder();for(;;){const part=await reader.read();if(part.done)break;size+=part.value.length;if(size>4*1024*1024){await reader.cancel();throw Error('Nguồn vượt giới hạn đọc');}html+=decoder.decode(part.value,{stream:true});}html+=decoder.decode();
 return html;
}
export async function readAgencyFees(db:D1Database,config:{GIAMINH_ADS_LEDGER_URL?:string;FLAGTEAM_ADS_LEDGER_URL?:string},months:string[]){
 const table=new Map<string,{provider:string;fee:number;paid?:number}[]>();
 const day=(date:string,provider:string,fee:number,paid?:number)=>{const values=table.get(date)||[];values.push({provider,fee,paid});table.set(date,values);};
 await Promise.all((['giaminh','flagteam'] as const).map(async provider=>{
  let cachedHtml:string|undefined;
  for(const month of months){
   const previous=await db.prepare('SELECT record FROM pm_ads_months WHERE id=?').bind(provider+':'+month).first<{record:string}>();
   if(previous){for(const d of JSON.parse(previous.record).days)day(d.date,provider,d.fee,d.feePaid);continue;}
   if(await sourceMode(db,provider)!=='active')continue;
   try{
    const url=agencyUrl((provider==='giaminh'?config.GIAMINH_ADS_LEDGER_URL:config.FLAGTEAM_ADS_LEDGER_URL)||'',provider);
    if(provider==='giaminh'){url.searchParams.set('year',month.slice(0,4));url.searchParams.set('month',String(+month.slice(5)));url.searchParams.set('view','thang');}
    const html=cachedHtml??await agencyHtml(url);
    if(provider==='flagteam')cachedHtml=html;
    const rows=provider==='giaminh'?parseGiaMinh(html,month):parseFlagteam(html,month);
    for(const d of rows)day(d.date,provider,d.fee,d.feePaid);
   }catch{continue;}
  }
 }));
 return table;
}
export async function syncAdsProvider(db:D1Database,base:string,period:string,actor:string,force=false,provider:'giaminh'|'flagteam'='giaminh'){
 if(await sourceMode(db,provider)!=='active')return {provider,busy:false,results:[{provider,paused:true}]};
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()),months=sourceMonths(period,today),name=adsProviders[provider];const url=agencyUrl(base,provider);
 const token=crypto.randomUUID(),now=Date.now(),lease=await db.prepare("INSERT INTO pm_ads_sync(id,record,lease_until,token) VALUES(?,'{}',?,?) ON CONFLICT(id) DO UPDATE SET lease_until=excluded.lease_until,token=excluded.token WHERE lease_until<?").bind(provider,now+90000,token,now).run();if(!lease.meta.changes)return {provider,busy:true,results:[]};const results:any[]=[];let flagHTML:string|undefined;
 try{for(const month of months){const id=provider+':'+month,oldRow=await db.prepare('SELECT record FROM pm_ads_months WHERE id=?').bind(id).first<any>(),old=oldRow?JSON.parse(oldRow.record):null;if(!force&&old?.lastSuccess&&now-Date.parse(old.lastSuccess)<60000){results.push({provider,month,cached:true});continue;}
 try{if(provider==='giaminh'){url.searchParams.set('year',month.slice(0,4));url.searchParams.set('month',String(+month.slice(5)));url.searchParams.set('view','thang');}let html=flagHTML;
 if(html===undefined){html=await agencyHtml(url);if(provider==='flagteam')flagHTML=html;}
 const days=provider==='giaminh'?parseGiaMinh(html,month):parseFlagteam(html,month);const receiptIssues:string[]=[];
 if(provider==='flagteam'){
  const recent=new Date(Date.parse(today+'T00:00:00Z')-3*86400000).toISOString().slice(0,10);
  for(const day of days as any[]){
   if(!day.receiptIds)continue;
   const previous=old?.days?.find((d:any)=>d.date===day.date);
   day.receipts=[];
   for(const id of day.receiptIds){
    const cached=previous?.receipts?.find((r:any)=>r.id===id);
    if(cached){day.receipts.push(cached);continue;}
    if(day.date<recent)continue;
    try{const {fetchReceipt}=await import('./flagteam-receipt');day.receipts.push(await fetchReceipt(id,day.date));}
    catch{receiptIssues.push(day.date+' '+id);}
   }
  }
 }
 const time=new Date().toISOString(),record={provider,month,days,lastSuccess:time};if(old && JSON.stringify(old.days)===JSON.stringify(days)){await db.prepare('UPDATE pm_ads_months SET record=? WHERE id=?').bind(JSON.stringify(record),id).run();results.push({provider,month,rows:days.length,unchanged:true,lastSuccess:time,receiptIssues});continue;}await db.batch([db.prepare('INSERT INTO pm_ads_months(id,record) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET record=excluded.record').bind(id,JSON.stringify(record)),db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),time,actor,'sync-ads:expense',JSON.stringify({id,previous:old?.days||[],days,total:days.reduce((n,d)=>n+d.total,0)}))]);results.push({provider,month,rows:days.length,total:days.reduce((n,d)=>n+d.total,0),lastSuccess:time,receiptIssues});}catch(e){results.push({provider,month,error:(e as Error).message});}}
 const record={lastAttempt:new Date().toISOString(),period,results,lastSuccess:results.length&&results.every(r=>!r.error)?new Date().toISOString():undefined};const previous=await db.prepare('SELECT record FROM pm_ads_sync WHERE id=?').bind(provider).first<any>();if(!record.lastSuccess&&previous)record.lastSuccess=JSON.parse(previous.record).lastSuccess;await db.prepare('UPDATE pm_ads_sync SET record=?,lease_until=0 WHERE id=? AND token=?').bind(JSON.stringify(record),provider,token).run();return {provider,busy:false,...record};
 }finally{await db.prepare('UPDATE pm_ads_sync SET lease_until=0 WHERE id=? AND token=?').bind(provider,token).run();}}
export const syncGiaMinh=(db:D1Database,base:string,period:string,actor:string,force=false)=>syncAdsProvider(db,base,period,actor,force,'giaminh');
export const syncFlagteam=(db:D1Database,base:string,period:string,actor:string,force=false)=>syncAdsProvider(db,base,period,actor,force,'flagteam');

export async function refreshFacebookAds(db:D1Database, config:{GIAMINH_ADS_LEDGER_URL?:string,FLAGTEAM_ADS_LEDGER_URL?:string},actor:string){
 const now=new Date();
 const vnDate=(date:Date)=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
 const months=new Set([vnDate(now).slice(0,7),vnDate(new Date(now.getTime()-86400000)).slice(0,7)]);
 const results=[];
 for(const month of months){
  const runs=await Promise.allSettled([syncGiaMinh(db,config.GIAMINH_ADS_LEDGER_URL||'',month,actor),syncFlagteam(db,config.FLAGTEAM_ADS_LEDGER_URL||'',month,actor)]);
  results.push(...runs.flatMap((run,i)=>run.status==='fulfilled'?run.value.busy?[{provider:run.value.provider,busy:true}]:run.value.results:[{provider:i?'flagteam':'giaminh',error:run.reason.message}]));
 }
 return results;
}

export async function flagteamInvoiceDays(config:{FLAGTEAM_ADS_LEDGER_URL?:string},month:string){
 const url=agencyUrl(config.FLAGTEAM_ADS_LEDGER_URL||'','flagteam');
 const html=await agencyHtml(url);
 const table=[...html.matchAll(/<table\b[^>]*>[\s\S]*?<\/table>/gi)].map(m=>m[0]).find(t=>t.includes('TỔNG SỐ TIỀN ĐÃ NẠP')&&t.includes('Tổng FB'));
 if(!table)throw Error('Thiếu bảng phí Flagteam');
 const rows=[...table.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)].map(r=>[...r[1].matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(m=>m[1]));
 if(!rows.some(r=>clean(r[0]||'')==='NGÀY'&&r.map(clean).join('|').includes('Tổng FB|Phí DV (6%)|Tiền đã thanh toán phí DV|Chiết khấu|Hóa đơn')))throw Error('Cột phí đã thay đổi');
 const days:{date:string;invoice:string[];fee:number}[]=[];
 for(const r of rows){
  const label=clean(r[0]||'');
  if(r.length!==14||!/^\d{2}\/\d{2}\/20\d{2}/.test(label))continue;
  const date=label.slice(0,10).split('/').reverse().join('-');
  if(!date.startsWith(month))continue;
  const invoice=[...r[8].matchAll(/href=["'](https:\/\/crm\.anphatmedia\.vn\/hoa-don\/[0-9a-f-]+\/download)["']/gi)].map(m=>m[1]);
  if(!invoice.length)continue;
  const amounts=[...r[8].matchAll(/<(?:p|span)\b[^>]*class=["']money["'][^>]*>([^<]+)</gi)].map(m=>value(clean(m[1])));
  if(amounts.length!==1||days.some(d=>d.date===date))throw Error('Nhiều dòng phí cần kiểm tra ngày '+date);
  days.push({date,invoice,fee:amounts[0]});
 }
 return days;
}
