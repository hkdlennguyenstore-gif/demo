import {holidayCalendar,holidayToday} from './holidays.ts';
import {view,type State} from './payroll.ts';
export function currentMonth(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()).slice(0,7);}
export function monthView(s:State,email:string,month=currentMonth()){if(!/^20\d{2}-(0[1-9]|1[0-2])$/.test(month))throw Error('Tháng không hợp lệ');const data=view(s,email);if(!data)return null;return {...data,clocks:data.clocks.filter(c=>c.date.startsWith(month)),adjustments:data.adjustments.filter(a=>a.month===month),closedPayroll:data.closedPayroll[month]?{[month]:data.closedPayroll[month]}:{},audit:data.audit.slice(0,100),loadedMonth:month};}
export function periodView(s:State,email:string,range:{from:string,to:string},month=currentMonth()){
const data=view(s,email);if(!data)return null;
const today=holidayToday(),holidayMonths=Array.from({length:Math.max(0,Number(today.slice(0,4))-2026+1)},(_,i)=>holidayCalendar(2026+i)).flat().filter(h=>h.date<=today).map(h=>h.date.slice(0,7));
const available=[...new Set([month,...holidayMonths,...data.clocks.map(c=>c.date.slice(0,7)),...data.adjustments.map(a=>a.month),...Object.keys(data.closedPayroll)])].filter(m=>(!range.from||m>=range.from.slice(0,7))&&(!range.to||m<=range.to.slice(0,7))).sort().reverse();
const months=available.length?available:[range.from?.slice(0,7)||range.to?.slice(0,7)||month];
return {...data,clocks:data.clocks.filter(c=>months.includes(c.date.slice(0,7))),adjustments:data.adjustments.filter(a=>months.includes(a.month)),closedPayroll:Object.fromEntries(Object.entries(data.closedPayroll).filter(([m])=>months.includes(m))),audit:data.audit.filter(a=>{const d=new Date(new Date(a.time).getTime()+7*3600000).toISOString().slice(0,10);return (!range.from||d>=range.from)&&(!range.to||d<=range.to);}).slice(0,1000),loadedMonth:month,payrollMonths:months,loadedRange:range};}
