import test from 'node:test';
import assert from 'node:assert/strict';
import {mapPosSources,analyticsQuery,readPosSourceReport} from './pos-source-report.ts';
test('POS net money and gross confirmed orders match the source report, with exact shop isolation',()=>{
 const current=[{order_sources:'-1',account:'page',success:{order_count:544,product_count:1002,total_order_count:811,revenue:181934000},returned:{order_count:16,product_count:24},result:{revenue:177700000,profit:52316000,sales:177900000,discount:200000}},{order_sources:'-9',account:'400050288',success:{order_count:5,product_count:8,total_order_count:5},result:{revenue:1823862,profit:873862,sales:3809390,discount:1704470}},{order_sources:'-9',account:'unknown',success:{order_count:999},result:{revenue:999}},{order_sources:null,success:{order_count:3},result:{revenue:1245000}}];
 const rows=mapPosSources(current,null);assert.deepEqual([rows[0].revenue,rows[0].profit,rows[0].sales,rows[0].discount,rows[0].confirmed,rows[0].quantity],[177700000,52316000,177900000,200000,544,1002]);assert.equal(rows[0].returnedQuantity,24);assert.equal(rows[1].confirmed,5);assert.equal(rows[2].confirmed,0);assert.equal(rows[3].revenue,0);
 const missing=mapPosSources([{order_sources:'-1',result:{revenue:null},success:null}],null);assert.equal(missing[0].revenue,null);assert.equal(missing[0].confirmed,0);
});
test('Report uses Vietnam whole days, POS confirmation time and return time, with separate comparison',()=>{
 const q=analyticsQuery({from:'2026-11-10',to:'2026-11-17'});assert.equal(q.since,'2026-11-09T17:00:00.000Z');assert.equal(q.until,'2026-11-17T16:59:59.000Z');assert.equal(q.success_record,'updated_at');assert.equal(q.returned_record,'updated_at');assert.equal(q.success_status,'1');
 const r=mapPosSources([{order_sources:'-1',result:{revenue:100},success:{order_count:10}}],[{order_sources:'-1',result:{revenue:50},success:{order_count:5}}]);assert.equal(r[0].revenueChange,100);assert.equal(r[0].confirmedChange,100);
});
test('API requests repeated fields, handles failures and never treats partial pages as complete',async()=>{
 const old=globalThis.fetch;let urls:string[]=[];
 globalThis.fetch=async(input:any)=>{urls.push(String(input));return Response.json({success:true,data:[],pagination:null});};
 try{const r=await readPosSourceReport({PANCAKE_API_KEY:'test',PANCAKE_SHOP_ID:'6111341'},{from:'2026-11-10',to:'2026-11-17'});assert.equal(r.rows[0].confirmed,0);assert.equal(urls.length,2);assert.equal(new URL(urls[0]).searchParams.getAll('select_fields[]').length,7);assert.ok(!JSON.stringify(r).includes('api_key'));
 globalThis.fetch=async()=>Response.json({success:true,data:[],pagination:{next:2}});await assert.rejects(readPosSourceReport({PANCAKE_API_KEY:'test',PANCAKE_SHOP_ID:'6111341'},{from:'',to:''}),/phân trang/);
 }finally{globalThis.fetch=old;}
});
