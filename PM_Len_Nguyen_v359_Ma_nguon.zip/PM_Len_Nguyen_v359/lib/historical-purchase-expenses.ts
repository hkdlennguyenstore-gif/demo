// The owner approved this closed set of historical purchases on 21 November 2026.
const paymentIds:string[] = [];
const invoiceIds:string[] = [];
export async function historicalPurchases(db:D1Database,from:string,to:string){
 const table='pm_management_purchase_expenses';
 await db.prepare(`CREATE TABLE IF NOT EXISTS ${table}(kind TEXT NOT NULL, source_id TEXT NOT NULL, date TEXT NOT NULL, supplier TEXT NOT NULL, amount INTEGER NOT NULL, reference TEXT NOT NULL, management_status TEXT NOT NULL, tax_status TEXT NOT NULL, PRIMARY KEY(kind,source_id))`).run();
 const missing=await db.prepare(`SELECT count(*) AS n FROM ${table}`).first<{n:number}>();
 if(missing?.n!==paymentIds.length+invoiceIds.length){
  const marks=(items:string[])=>items.map(()=>'?').join(',');
  await db.batch([
   db.prepare(`INSERT OR IGNORE INTO ${table} SELECT 'payment',p.id,p.date,s.name,p.total,'NhapLieu!M'||json_extract(p.record,'$.sourceRef.row'),'approved','unreviewed' FROM pm_purchase_docs p JOIN pm_purchase_suppliers s ON s.id=p.supplier WHERE p.id IN (${marks(paymentIds)}) AND p.active=1 AND p.kind='payment' AND json_extract(p.record,'$.sourceRef.sheet')='NhapLieu'`).bind(...paymentIds),
   db.prepare(`INSERT OR IGNORE INTO ${table} SELECT 'invoice',id,date,supplier,CAST(printedTotal AS INTEGER),series||' · HĐ '||number,'approved','unreviewed' FROM gmail_purchase_notices WHERE id IN (${marks(invoiceIds)}) AND status='documented'`).bind(...invoiceIds)
  ]);
 }
 return (await db.prepare(`SELECT h.* FROM ${table} h WHERE h.date BETWEEN ? AND ? AND ((kind='invoice' AND EXISTS(SELECT 1 FROM gmail_purchase_notices i WHERE i.id=h.source_id AND i.status='documented')) OR (kind='payment' AND EXISTS(SELECT 1 FROM pm_purchase_docs p WHERE p.id=h.source_id AND p.active=1))) ORDER BY date,kind,source_id`).bind(from||'0000',to||'9999').all()).results;
}

export type PurchaseExpenseEntry={kind:'payment'|'invoice';source_id:string;date:string;supplier:string;amount:number;reference:string};
export type PurchaseExpenseDocument={label:string;url:string;kind:'file'|'source'};
export async function historicalPurchaseDocuments(db:D1Database,rows:PurchaseExpenseEntry[]){
 const documents:Record<string,PurchaseExpenseDocument[]>={};
 const add=(id:string,doc:PurchaseExpenseDocument)=>{const list=documents[id]??=[];if(!list.some(d=>d.url===doc.url))list.push(doc);};
 const payments=rows.filter(r=>r.kind==='payment'),invoices=rows.filter(r=>r.kind==='invoice');
 if(payments.length){
  const records=await db.prepare(`SELECT id,record FROM pm_purchase_docs WHERE active=1 AND kind='payment' AND id IN (${payments.map(()=>'?').join(',')})`).bind(...payments.map(r=>r.source_id)).all<{id:string;record:string}>();
  for(const row of records.results){const p=JSON.parse(row.record);const cell=payments.find(r=>r.source_id===row.id)?.reference.split('!')[1];
   if(cell&&/^M\d+$/.test(cell))add('payment:'+row.id,{label:'Mở dữ liệu gốc · '+payments.find(r=>r.source_id===row.id)!.reference,url:'https://docs.google.com/spreadsheets/d/REPLACE_WITH_SHEET_ID/edit#gid=1534704923&range='+cell,kind:'source'});
   if(p.receipt?.key)add('payment:'+row.id,{label:p.receipt.name||'Tải chứng từ thanh toán',url:'/api/purchases/receipt?key='+encodeURIComponent(p.receipt.key),kind:'file'});
  }
 }
 if(invoices.length){
  const records=await db.prepare(`SELECT s.noticeId,s.mailId,l.itemId,l.name FROM gmail_purchase_sources s JOIN gmail_evidence e ON e.id=s.mailId LEFT JOIN gmail_documents d ON d.mailId=s.mailId AND d.targetId=s.noticeId LEFT JOIN gmail_link_files l ON l.itemId=d.id WHERE s.noticeId IN (${invoices.map(()=>'?').join(',')}) ORDER BY s.noticeId,s.mailId,l.itemId`).bind(...invoices.map(r=>r.source_id)).all<{noticeId:string;mailId:string;itemId:string|null;name:string|null}>();
  for(const r of records.results){const id='invoice:'+r.noticeId;
   if(r.itemId)add(id,{label:r.name||'Tải bản hóa đơn gốc',url:'/api/gmail-evidence?linkFile='+encodeURIComponent(r.itemId),kind:'file'});
   add(id,{label:'Tải thư gốc · '+r.mailId,url:'/api/gmail-evidence?id='+encodeURIComponent(r.mailId),kind:'source'});
  }
 }
 return documents;
}
