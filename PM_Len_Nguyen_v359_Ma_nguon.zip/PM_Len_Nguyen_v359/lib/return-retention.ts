import {reconciliation} from './return-reconciliation.ts';
import {digest} from './a3-access.ts';
const DAY=86400000;
export async function prepareReturnArchive(db:D1Database){await db.prepare('CREATE TABLE IF NOT EXISTS pm_return_archive(tracking_hash TEXT PRIMARY KEY,group_key TEXT NOT NULL,channel TEXT NOT NULL,matched_at TEXT NOT NULL,archived_at TEXT NOT NULL,mode TEXT NOT NULL)').run();}
export function matchedTime(expected:any,receipt:any,now=Date.now()){
 const result=reconciliation(expected,receipt,now);if(!result.matched)return null;
 if(result.auto30)return Date.parse(result.eligibleAt!);
 const a=Date.parse(receipt?.receivedAt||''),b=Date.parse(expected?.importedAt||'');
 return Number.isFinite(a)&&Number.isFinite(b)?Math.max(a,b):null;
}
export async function archiveMatchedReturns(db:D1Database,now=Date.now()){
 await prepareReturnArchive(db);
 const rows=await db.prepare("SELECT r.id,r.tracking,r.channel,r.record,e.record AS expected_record FROM pm_order_returns r LEFT JOIN pm_return_expected e ON e.tracking=r.tracking AND e.active=1 AND e.group_key=json_extract(r.record,'$.group') WHERE r.active=1 AND json_extract(r.record,'$.receivedAt')<=? ORDER BY r.date ASC LIMIT 500").bind(new Date(now-30*DAY).toISOString()).all<any>();
 let archived=0;const archivedAt=new Date(now).toISOString();
 for(const row of rows.results){
  const receipt=JSON.parse(row.record),expected=row.expected_record?JSON.parse(row.expected_record):null,matched=matchedTime(expected,receipt,now);
  if(matched===null||now<matched+30*DAY)continue;
  const hash=await digest(row.tracking),mode=expected?'exact':'auto30';
  // Record a compact fingerprint before removing details, so a later scan/import cannot revive it.
  const results=await db.batch([
   db.prepare('INSERT OR IGNORE INTO pm_return_archive VALUES(?,?,?,?,?,?)').bind(hash,receipt.group||'unresolved',row.channel,new Date(matched).toISOString(),archivedAt,mode),
   db.prepare('DELETE FROM pm_return_expected WHERE tracking=? AND EXISTS(SELECT 1 FROM pm_return_archive WHERE tracking_hash=?)').bind(row.tracking,hash),
   db.prepare('DELETE FROM pm_order_returns WHERE id=? AND EXISTS(SELECT 1 FROM pm_return_archive WHERE tracking_hash=?)').bind(row.id,hash),
  ]);archived+=results[2].meta.changes||0;
 }
 if(archived)await db.prepare('INSERT INTO pm_order_actions VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),archivedAt,'Hệ thống','Dọn chi tiết đơn đã khớp quá 30 ngày',JSON.stringify({archived,retentionDays:30,mode:'Giữ dấu vết băm chống trùng; không xóa dữ liệu trên POS/sàn'})).run();
 return {archived,retentionDays:30};
}
export async function isArchived(db:D1Database,tracking:string){await prepareReturnArchive(db);return Boolean(await db.prepare('SELECT tracking_hash FROM pm_return_archive WHERE tracking_hash=?').bind(await digest(tracking)).first());}

export async function archiveFingerprints(db:D1Database){await prepareReturnArchive(db);const rows=await db.prepare('SELECT tracking_hash FROM pm_return_archive').all<{tracking_hash:string}>();return new Set(rows.results.map(r=>r.tracking_hash));}
