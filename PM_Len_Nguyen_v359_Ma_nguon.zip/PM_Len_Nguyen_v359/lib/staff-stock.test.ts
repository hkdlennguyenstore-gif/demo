import {test} from 'node:test';
import assert from 'node:assert/strict';
import {staffStockView} from './staff-stock.ts';
function view(variants:Parameters<typeof staffStockView>[3]['variants'],complete=true){
 return staffStockView('B4','',190000,{variants,complete,updatedAt:'2026-11-25T16:00:00Z'});
}
test('groups exact variants and distinguishes zero from a missing cell',()=>{
 const a=view([{name:'B4',color:'Xanh Nhạt',size:'31',remain:2},{color:'xanh nhạt',size:'31',remain:3},{color:'Xanh Đậm',size:'29',remain:0}]);
 assert.equal(a.rows[0].cells['31'],5);
 assert.equal(a.rows[1].cells['29'],0);
 assert.equal(a.rows[1].cells['35'],undefined);
 assert.equal(a.total,5);
});
test('projects only Facebook selling price and quantity, not extra POS fields',()=>{
 const variant={color:'Xanh',size:'31',remain:2,cost:123,tiktokPrice:222,actual:45,id:'private-id'};
 const a=view([variant]);
 assert.equal(a.facebookPrice,190000);
 assert.doesNotMatch(JSON.stringify(a),/123|222|cost|tiktok|private-id|"actual"/);
});
test('incomplete source does not claim an exact total',()=>{
 const a=view([{color:'Xanh',size:'31',remain:null}],false);
 assert.equal(a.total,null);
 assert.equal(a.rows[0].cells['31'],null);
 assert.equal(a.complete,false);
});
