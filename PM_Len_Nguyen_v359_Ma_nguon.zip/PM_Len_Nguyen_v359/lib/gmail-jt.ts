type JtLine = {tracking:string;fee:number;cod:number};
type Totals = {rows:number;fee:number;cod:number};
const empty=():Totals=>({rows:0,fee:0,cod:0});
const shopNames:Record<string,string>={facebook:'Facebook',shopee:'Shopee',tiktok1:'TikTok 1',tiktok2:'TikTok 2'};
function add(dest:Totals,line:JtLine){
 dest.rows++;
 dest.fee+=line.fee;
 dest.cod+=line.cod;
}
function checkLines(source:Record<string,unknown>){
 if(!Array.isArray(source.trackingLines)||source.trackingLines.length!==source.rows||!source.trackingLines.length||source.trackingLines.length>6000)return null;
 const seen=new Set<string>(), totals=empty(),lines:JtLine[]=[];
 for(const value of source.trackingLines){
  if(!value||typeof value.tracking!=='string'||value.tracking.trim()!==value.tracking||!value.tracking||value.tracking.length>100||
    !Number.isSafeInteger(value.fee)||!Number.isSafeInteger(value.cod)||seen.has(value.tracking))return null;
  seen.add(value.tracking);const line={tracking:value.tracking,fee:value.fee,cod:value.cod};
  add(totals,line);lines.push(line);
 }
 if(!Number.isSafeInteger(totals.fee)||!Number.isSafeInteger(totals.cod)||totals.fee!==source.total||totals.cod!==source.cod)return null;
 return lines;
}

export async function reconcileJt(db:D1Database,reading:Record<string,unknown>){
 if(reading.kind!=='jt-statement'||!('trackingLines' in reading))return undefined;
 const lines=checkLines(reading),matched=empty(),missing=empty(),ambiguous=empty(),ledgerOverlap=empty();
 const byShop:Record<string,Totals>={};
 let posCostCandidates=0,posWithoutFeeFields=0;
 const posFeeFields=new Set<string>();
 const checkedAt=new Date().toISOString();
 if(!lines)return {checkedAt,valid:false,reason:'Danh sách vận đơn sai cấu trúc, trùng mã hoặc không khớp tổng phí và COD của bảng kê'};
 const periods=/^\d{4}-\d\d-\d\d$/;
 const from=typeof reading.fromDate==='string'&&periods.test(reading.fromDate)?reading.fromDate:'';
 const to=typeof reading.toDate==='string'&&periods.test(reading.toDate)?reading.toDate:'';
 const possible:Record<string,number>={};
 for(let offset=0;offset<lines.length;offset+=200){
  const part=lines.slice(offset,offset+200),codes=JSON.stringify(part.map(r=>r.tracking));
  const [orders,fees]=await Promise.all([
   db.prepare(`WITH matched AS (
     SELECT tracking,channel,record FROM pm_orders WHERE tracking IN (SELECT value FROM json_each(?))
    ) SELECT tracking,MIN(channel) shop,COUNT(*) n,
     (SELECT group_concat(DISTINCT CAST(j.key AS TEXT)) FROM matched one, json_tree(one.record) j
       WHERE one.tracking=o.tracking AND j.type IN ('integer','real','text') AND (
        lower(j.key) LIKE '%fee%' OR lower(j.key) LIKE '%cước%' OR lower(j.key) LIKE '%phí%' OR
        lower(j.key) LIKE '%shipping%cost%' OR lower(j.key) LIKE '%shipping%price%' OR
        lower(j.key) LIKE '%carrier%charge%' OR lower(j.key) LIKE '%freight%')) priceKeys
     FROM matched o GROUP BY tracking`).bind(codes).all<{tracking:string;shop:string;n:number;priceKeys:string|null}>(),
   db.prepare(`WITH refs AS (SELECT value FROM json_each(?)), costs AS (
    SELECT json_extract(record,'$.reference') reference,json_extract(record,'$.expenseDetails.fields."Mã vận đơn"') barcode
    FROM pm_finance_docs WHERE kind='expense' AND status IN ('confirmed','excluded') AND json_extract(record,'$.category') IN ('shipping','returns','platform'))
    SELECT reference code FROM costs WHERE reference IN refs UNION SELECT barcode FROM costs WHERE barcode IN refs`)
    .bind(codes).all<{code:string}>()
  ]);
  const orderMap=new Map(orders.results.map(row=>[row.tracking,row])),feeRefs=new Set(fees.results.map(r=>r.code));
  for(const l of part){
   const r=orderMap.get(l.tracking);
   if(!r)add(missing,l);
   else if(r.n!==1||!Object.hasOwn(shopNames,r.shop))add(ambiguous,l);
   else {
    add(matched,l);add(byShop[r.shop]??=empty(),l);
    if(r.priceKeys){posCostCandidates++;for(const key of r.priceKeys.split(','))posFeeFields.add(key);}
    else posWithoutFeeFields++;
   }
   if(feeRefs.has(l.tracking))add(ledgerOverlap,l);
  }
 }
 if(from&&to&&Object.keys(byShop).length){
  // Period-level platform/manual fee aggregates cannot prove an individual shipment is already paid.
  const nearby=await db.prepare(`SELECT channel,COUNT(*) n FROM pm_finance_docs WHERE kind='expense' AND status='confirmed'
    AND date BETWEEN ? AND ? AND channel IN (SELECT value FROM json_each(?))
    AND json_extract(record,'$.category') IN ('shipping','returns','platform') GROUP BY channel`)
    .bind(from,to,JSON.stringify(Object.keys(byShop))).all<{channel:string;n:number}>();
  for(const r of nearby.results)possible[r.channel]=r.n;
 }
 const shops=Object.entries(byShop).map(([k,v])=>shopNames[k]+' '+v.rows+' mã · '+v.fee.toLocaleString('vi-VN')+'đ').join(', ');
 const reason='Đối chiếu PM: '+matched.rows+'/'+lines.length+' mã khớp duy nhất'+(shops?' ('+shops+')':'')+
  '. '+missing.rows+' chưa thấy, '+ambiguous.rows+' khớp nhiều đơn hoặc chưa rõ kênh. '+ledgerOverlap.rows+' mã đã xuất hiện trên phiếu phí. '+posWithoutFeeFields+' đơn khớp thiếu trường phí POS; '+posCostCandidates+' đơn có trường phí cần xác minh bên chịu phí. Chưa xác định chênh lệch cần ghi.';
 return {valid:true,checkedAt,matched,missing,ambiguous,byShop,ledgerOverlap,posFeeEvidence:{candidateOrders:posCostCandidates,withoutFeeFields:posWithoutFeeFields,fields:[...posFeeFields].sort(),reconciledDelta:null},samePeriodExpenseCounts:possible,reason};
}
