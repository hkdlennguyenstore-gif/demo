export type NavItem={id:string,label:string,href:string};
export type NavGroup={id:string,label:string,items:NavItem[]};
export function navigationFor(role:string){
 const payroll=['owner','admin','payroll'].includes(role),finance=['owner','admin'].includes(role),staff=['owner','admin','payroll','manager','employee','terminal'].includes(role),operations=['owner','admin','manager','employee','terminal'].includes(role);
 const groups:NavGroup[]=[];
 const attendanceBase=role==='terminal'?'/cham-cong?':'/?view=clock&';
 const attendance=['owner','admin','employee','terminal'].includes(role)?[
  {id:'hr-schedule',label:'Lịch làm việc',href:attendanceBase+'attendance=schedule'},
  {id:'hr-leave',label:'Xin nghỉ',href:attendanceBase+'attendance=leave'},
 ]:[];

 if(staff)groups.push({id:'hr',label:'Nhân sự',items:[{id:'hr-clock',label:'Chấm công',href:role==='terminal'?'/cham-cong':'/?view=clock'},...attendance,...(payroll?[{id:'hr-pay',label:'Bảng lương',href:'/?view=pay'},{id:'hr-insurance',label:'Bảo hiểm',href:'/?view=insurance'},{id:'hr-terminal',label:'Máy chấm công dùng chung',href:'/cham-cong'}]:[])]});
 if(operations)groups.push({id:'orders',label:'Đơn hàng',items:[{id:'orders-facebook',label:'Đơn Facebook',href:'/don-hang?view=facebook'},{id:'orders-returns',label:'Bắn đơn hoàn',href:'/don-hang?view=returns'},{id:'orders-tiktok1',label:'TikTok 1',href:'/don-hang?view=tiktok1'},{id:'orders-tiktok2',label:'TikTok 2',href:'/don-hang?view=tiktok2'},{id:'orders-shopee',label:'Shopee',href:'/don-hang?view=shopee'}].filter(item=>!['employee','terminal'].includes(role)||!['orders-tiktok1','orders-tiktok2','orders-shopee'].includes(item.id))});
 if(finance)groups.push({id:'finance',label:'Công nợ & Nhà cung cấp',items:[{id:'finance-debt',label:'Công nợ nhà cung cấp',href:'/nhap-hang?view=debt'},{id:'finance-audit',label:'Lịch sử & đối chiếu nhập hàng',href:'/nhap-hang?view=audit'}]});
 return {financeModules:finance,overview:payroll,settings:payroll,stock:operations,a4:operations,a3:finance||role==='terminal',groups};
}
