import { PDFArray, PDFDocument, PDFRawStream, PDFString, decodePDFRawStream } from 'pdf-lib';

type Spend = { date: string; amount: number };
export type Receipt = { id: string; spend: Spend[] };
const datePattern = '(\\d{1,2}) tháng (\\d{1,2}), (20\\d{2})';
const period = new RegExp('^Từ \\d{2}:\\d{2} '+datePattern+' đến \\d{2}:\\d{2} '+datePattern+'$');
function iso(day:string, month:string, year:string) {
 const date=year+'-'+month.padStart(2,'0')+'-'+day.padStart(2,'0');
 if(new Date(date).toISOString().slice(0,10)!==date) throw Error('Ngày chứng từ sai');
 return date;
}
function amount(text:string) {
 if(!/^\d{1,3}(?:\.\d{3})* ₫$/.test(text || '')) throw Error('Số tiền chứng từ không rõ');
 return Number(text.replace(/\D/g,''));
}
export async function parseReceipt(bytes:Uint8Array, id:string, issued:string):Promise<Receipt> {
 const pdf=await PDFDocument.load(bytes);
 const lines:string[]=[];
 for(const page of pdf.getPages()){
  const contents=page.node.Contents();
  const streams=contents instanceof PDFArray ? contents.asArray().map(ref=>pdf.context.lookup(ref)) : [contents];
  for(const stream of streams){
   if(!(stream instanceof PDFRawStream)) throw Error('Không đọc được trang PDF');
   const decoded=decodePDFRawStream(stream).decode();
   if(decoded.length>4*1024*1024) throw Error('Trang chứng từ quá lớn');
   const pieces:string[]=[];
   for(let i=0;i<decoded.length;i+=8192) pieces.push(String.fromCharCode(...decoded.subarray(i,i+8192)));
   // Meta TCPDF uses UTF-16BE literal strings in TJ arrays.
   for(const match of pieces.join('').matchAll(/\[\(((?:\\[\s\S]|[^\\)])*)\)\]\s*TJ/g)){
    const bytes=PDFString.of(match[1]).asBytes();
    if(bytes.length%2)continue;
    let line='';
    for(let i=0;i<bytes.length;i+=2)line+=String.fromCharCode(bytes[i]*256+bytes[i+1]);
    lines.push(line);
   }
  }
 }
 const after=(label:string)=>lines[lines.indexOf(label)+1];
 const stamp=after('Ngày lập hóa đơn/thanh toán')?.match(new RegExp('^\\d{2}:\\d{2} '+datePattern+'$'));
 if(!stamp || iso(stamp[1],stamp[2],stamp[3])!==issued || after('ID giao dịch')!==id || after('Loại sản phẩm')!=='Meta quảng cáo' || !lines.some(l=>l.startsWith('Biên lai cho ')&&l.includes('LÊN NGUYỄN STORE'))) throw Error('Chứng từ chưa khớp nguồn');
 const paid=amount(after('Đã thanh toán')), sums=new Map<string,number>();
 for(let i=0;i<lines.length;i++){
  if(!lines[i].startsWith('Từ ')) continue;
  const m=lines[i].match(period);
  if(!m) throw Error('Chưa đọc được kỳ chi tiêu');
  const date=iso(m[1],m[2],m[3]);
  if(date!==iso(m[4],m[5],m[6])) throw Error('Chứng từ nhiều ngày chưa phân bổ');
  sums.set(date,(sums.get(date)||0)+amount(lines[i+1]));
 }
 if(!paid || [...sums.values()].reduce((a,b)=>a+b,0)!==paid) throw Error('Chiến dịch không khớp số đã thanh toán');
 return {id,spend:[...sums].map(([date,amount])=>({date,amount}))};
}
export async function fetchReceipt(id:string, issued:string){
 if(!/^\d+-\d+$/.test(id)) throw Error('Mã giao dịch sai');
 const options={redirect:'manual' as const,signal:AbortSignal.timeout(18000)};
 let response=await fetch('https://api.ads.flagteam.vn/transactions/'+id+'/pdf-download',options);
 if(response.status>=300 && response.status<400){
  const target=new URL(response.headers.get('location')||'');
  if(target.origin!=='https://ads-pdf.0868231d3c24dabff0feb930860ad6a2.r2.cloudflarestorage.com'||target.username||target.password)throw Error('Kho PDF chưa xác minh');
  response=await fetch(target,options);
 }
 if(!response.ok || !response.body) throw Error('Chưa tải được PDF');
 const reader=response.body.getReader(),chunks:Uint8Array[]=[];let size=0;
 for(;;){const part=await reader.read();if(part.done)break;size+=part.value.length;if(size>4*1024*1024){await reader.cancel();throw Error('PDF quá lớn');}chunks.push(part.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
 return parseReceipt(bytes,id,issued);
}
