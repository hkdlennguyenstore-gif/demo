import {attendanceAccess,attendanceBatch,unlockedSchedule} from './attendance-access';
import {isAttendanceStart} from './attendance-month';
import type {State} from './payroll';

const rosterAction='Thêm tên xếp lịch';
const dayAction='Ghi ngày làm việc';
const cancelAction='Hủy lịch làm việc';
const nameKey=(name:string)=>name.trim().normalize('NFC').replace(/\s+/gu,' ').toLocaleLowerCase('vi-VN');
function ownerCalendar(s:State,email:string) {
  if(!attendanceAccess(s,email).admin)throw Error('Chỉ Chủ shop hoặc Quản trị viên được sửa danh sách hoặc lịch làm việc.');
}
export function calendarName(value:unknown) {
  if(typeof value!=='string'||value.length>120||/[\p{Cc}\p{Cf}]/u.test(value))throw Error('Nhập tên nhân viên hợp lệ, tối đa 80 ký tự.');
  const name=value.trim().normalize('NFC').replace(/\s+/gu,' ');
  if(name.length>80||!/[\p{L}]/u.test(name))throw Error('Nhập tên nhân viên hợp lệ, tối đa 80 ký tự.');
  return name;
}
async function readAction(db:D1Database,id:string) {
  return db.prepare('SELECT actor,action,record FROM pm_order_actions WHERE id=?').bind(id).first<{actor:string;action:string;record:string}>();
}
type Action=Awaited<ReturnType<typeof readAction>>;
function replay(row:NonNullable<Action>,actor:string,action:string,matches:(value:any)=>boolean){
  if(row.actor!==actor||row.action!==action||!matches(JSON.parse(row.record)))throw Error('Mã yêu cầu đã dùng cho nội dung khác.');
  return {ok:true,replayed:true};
}

export async function addScheduleName(db:D1Database,s:State,email:string,id:string,rawName:unknown,now:string,authValue:string) {
  ownerCalendar(s,email);
  const name=calendarName(rawName), key=nameKey(name), actor=email.toLowerCase(),personId='schedule:'+id;
  const result=(row:NonNullable<Action>)=>replay(row,actor,rosterAction,x=>x.name===name&&x.id===personId);
  const employee={id:personId,name,scheduleOnly:true as const};
  const prior=await readAction(db,id);if(prior)return {...result(prior),employee};
  if(s.employees.some(e=>e.active&&nameKey(e.name)===key))throw Error('Tên này đã có trong danh sách nhân viên đang hoạt động.');
  try {
    await db.batch([
      db.prepare("SELECT CASE WHEN EXISTS(SELECT 1 FROM app_state WHERE id='main' AND value=?) THEN 1 ELSE json('ATTENDANCE_CONTEXT_CHANGED') END AS allowed").bind(authValue),
      db.prepare("INSERT INTO pm_order_schedule_people SELECT ?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM pm_order_actions WHERE id=?) AND (SELECT COUNT(*) FROM pm_order_schedule_people)<500 ON CONFLICT DO NOTHING").bind(personId,name,key,now,id),
      db.prepare("INSERT INTO pm_order_actions SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM pm_order_schedule_people WHERE id=? AND name_key=? AND name=?) ON CONFLICT(id) DO NOTHING").bind(id,now,actor,rosterAction,JSON.stringify({id:personId,name}),personId,key,name)
    ]);
  }catch(e){
    if(String(e).includes('malformed JSON'))throw Error('Quyền hoặc danh sách đã thay đổi; tải lại trước khi thêm tên.');
    throw e;
  }
  const saved=await readAction(db,id);if(saved){result(saved);return {ok:true,employee};}
  if(await db.prepare('SELECT id FROM pm_order_schedule_people WHERE name_key=?').bind(key).first())throw Error('Tên này đã có trong danh sách xếp lịch.');
  throw Error('Danh sách xếp lịch đã đạt giới hạn 500 tên.');
}

type Day={date:string;employee:string;kind:'work'|'off';start?:string;version?:number};
export async function saveScheduleDay(db:D1Database,s:State,email:string,requestId:string,x:Day,now:string,authValue:string) {
  ownerCalendar(s,email);
  if(x.start!==undefined&&(x.kind!=='work'||!isAttendanceStart(x.start)))throw Error('Chọn giờ bắt đầu theo định dạng 24 giờ.');
  const actor=email.toLowerCase();
  const matches=(v:any)=>v.date===x.date&&v.employee===x.employee&&v.kind===x.kind&&(v.start??null)===(x.start??null)&&v.requestVersion===(x.version??null);
  const prior=await readAction(db,requestId);if(prior)return replay(prior,actor,dayAction,matches);
  unlockedSchedule(s,x.date);
  const employee=s.employees.find(e=>e.id===x.employee&&e.active)
    ||await db.prepare('SELECT id,name FROM pm_order_schedule_people WHERE id=?').bind(x.employee).first<{id:string;name:string}>();
  if(!employee)throw Error('Chọn tên nhân viên đang hoạt động hoặc tên dùng xếp lịch.');
  const old=await db.prepare('SELECT id,version,record FROM pm_order_schedule WHERE date=? AND employee=?').bind(x.date,employee.id).first<{id:string;version:number;record:string}>();
  if(old&&old.version!==x.version||!old&&x.version!==undefined)throw Error('Lịch đã thay đổi. Mở lại lịch trước khi lưu.');
  const previous=old?JSON.parse(old.record):null;
  if(previous?.kind==='leave')throw Error('Ngày này đã duyệt nghỉ phép. Không ghi đè bằng lịch đi làm hoặc OFF.');
  const record=JSON.stringify({date:x.date,employee:employee.id,name:employee.name,kind:x.kind,
    start:x.start??(typeof previous?.start==='string'?previous.start:''),end:typeof previous?.end==='string'?previous.end:'',
    note:typeof previous?.note==='string'?previous.note:'',scheduleMode:'day',actor,updatedAt:now});
  const audit=JSON.stringify({date:x.date,employee:employee.id,kind:x.kind,start:x.start??null,requestVersion:x.version??null});
  const write=old
    ? db.prepare("UPDATE pm_order_schedule SET version=version+1,record=? WHERE id=? AND version=? AND NOT EXISTS(SELECT 1 FROM pm_order_actions WHERE id=?)").bind(record,old.id,old.version,requestId)
    : db.prepare("INSERT INTO pm_order_schedule SELECT ?,?,?,0,? WHERE NOT EXISTS(SELECT 1 FROM pm_order_actions WHERE id=?) ON CONFLICT(date,employee) DO NOTHING").bind(requestId,x.date,employee.id,record,requestId);
  const expected=old?old.version+1:0;
  const id=old?.id??requestId;
  const results=await attendanceBatch(db,authValue,x.date,[
    write,
    db.prepare("INSERT INTO pm_order_actions SELECT ?,?,?,?,? WHERE changes()=1 AND EXISTS(SELECT 1 FROM pm_order_schedule WHERE id=? AND version=? AND record=?) ON CONFLICT(id) DO NOTHING").bind(requestId,now,actor,dayAction,audit,id,expected,record)
  ]);
  const saved=await readAction(db,requestId);
  if(saved){replay(saved,actor,dayAction,matches);return results[0].meta.changes?{ok:true}:{ok:true,replayed:true};}
  throw Error('Lịch đã thay đổi. Mở lại lịch trước khi lưu.');
}


type CancelDay={id:string;date:string;employee:string;version:number};
export async function cancelScheduleDay(db:D1Database,s:State,email:string,requestId:string,x:CancelDay,now:string,authValue:string) {
  ownerCalendar(s,email);
  const actor=email.toLowerCase();
  const matches=(v:any)=>v.id===x.id&&v.date===x.date&&v.employee===x.employee&&v.version===x.version;
  const prior=await readAction(db,requestId);if(prior)return replay(prior,actor,cancelAction,matches);
  unlockedSchedule(s,x.date);
  const readback=()=>readAction(db,requestId);
  const stale=()=>Error('Lịch đã thay đổi hoặc đã hủy. Tải lại trước khi thao tác.');
  const row=await db.prepare('SELECT id,date,employee,version,record FROM pm_order_schedule WHERE id=? AND date=? AND employee=? AND version=?')
    .bind(x.id,x.date,x.employee,x.version).first<{record:string}>();
  if(!row){const seen=await readback();if(seen)return replay(seen,actor,cancelAction,matches);throw stale();}
  const previous=JSON.parse(row.record);
  if(previous.kind!=='work'&&previous.kind!=='off')throw Error('Chỉ hủy được lịch Đi làm hoặc OFF. Không hủy nghỉ phép đã duyệt tại đây.');
  const audit=JSON.stringify({id:x.id,date:x.date,employee:x.employee,version:x.version,before:previous});
  const results=await attendanceBatch(db,authValue,x.date,[
    db.prepare("DELETE FROM pm_order_schedule WHERE id=? AND date=? AND employee=? AND version=? AND record=? AND NOT EXISTS(SELECT 1 FROM pm_order_actions WHERE id=?)").bind(x.id,x.date,x.employee,x.version,row.record,requestId),
    db.prepare("INSERT INTO pm_order_actions SELECT ?,?,?,?,? WHERE changes()=1 ON CONFLICT(id) DO NOTHING").bind(requestId,now,actor,cancelAction,audit)
  ]);
  const saved=await readback();
  if(saved){replay(saved,actor,cancelAction,matches);return results[0].meta.changes?{ok:true}:{ok:true,replayed:true};}
  throw stale();
}
