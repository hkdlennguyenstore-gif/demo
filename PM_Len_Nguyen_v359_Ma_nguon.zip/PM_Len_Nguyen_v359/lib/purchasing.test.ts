import * as historicalPurchases from './historical-purchase-expenses.ts';
import * as trang from './trang-payment.ts';
import * as invoices from './payment-invoices.ts';
import * as controls from './expense-controls.ts';
import * as expenses from './supplier-payment-expense.ts';
import * as dateRange from './date-range.ts';
import * as historicalPrices from './price-history.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import {DatabaseSync} from 'node:sqlite';
import * as store from './purchasing-store.ts';
import * as stockStore from './stock-store.ts';
import {monthView} from './month-view.ts';
import {periodView} from './month-view.ts';
import {initial} from './payroll.ts';
import * as purchases from './purchasing.ts';
import {canAccessModule} from './modules.ts';
const {emptyPurchasing,validatePurchase,purchaseTotal,supplierBalance,supplierLedger}=purchases;
const supplier={id:'s1',name:'Xưởng A',phone:'',note:'',opening:1000000,openingDate:'2026-11-01'};
const fixture=()=>{const s=emptyPurchasing();s.suppliers.push({...supplier});return s;};
const invoice={supplier:'s1',date:'2026-11-02',due:'2026-11-20',number:'A001',lines:[{sku:'S90',name:'Jean suông',color:'Xanh',size:'29',quantity:10,price:110000}],discount:50000,extra:20000,note:''};
test('Khoảng chung: nợ trước khoảng được chuyển vào đầu kỳ, sổ vẫn giữ số dư lũy kế',async()=>{
 const h=harness();await store.preparePurchasing(h.DB);
 h.sqlite.prepare('INSERT INTO pm_purchase_suppliers(id,name,opening,record) VALUES(?,?,?,?)').run('s1',supplier.name,1000000,JSON.stringify(supplier));
 for(const [id,date,kind,total] of [['a','2026-11-01','purchase',100000],['b','2026-11-10','payment',40000],['c','2026-11-20','purchase',60000],['d','2026-12-01','purchase',200000]] as const)h.sqlite.prepare('INSERT INTO pm_purchase_docs(id,supplier,date,kind,total,record) VALUES(?,?,?,?,?,?)').run(id,'s1',date,kind,total,JSON.stringify({...invoice,id,date,lines:[],amount:total}));
 const result=await store.readPurchasing(h.DB,new URL('https://pm.test/?from=2026-11-15&to=2026-11-30'));
 assert.equal(result.purchases.length,1);assert.equal(result.periodTotal,60000);assert.equal(result.balances[0].periodOpening,1060000);assert.equal(result.balances[0].imported,60000);assert.equal(result.balances[0].paid,0);assert.equal(result.balances[0].balance,1120000);
 const ledger=await store.readLedger(h.DB,'s1',1,{from:'2026-11-15',to:'2026-11-30'});assert.equal(ledger.total,1);assert.equal(ledger.rows[0].balance,1120000);
 const all=await store.readPurchasing(h.DB,new URL('https://pm.test/?range=all'));assert.equal(all.purchases.length,3);assert.equal(all.balances[0].balance,1320000);h.sqlite.close();
});
test('Khoảng ngày chấm công không cắt mất dữ liệu tính lương của tháng liên quan',()=>{
 const s=initial('boss@shop.vn');s.clocks=[{employee:'nv1',date:'2026-11-01',start:'08:00',end:'16:30',note:''},{employee:'nv1',date:'2026-11-17',start:'08:00',end:'16:30',note:''},{employee:'nv1',date:'2026-12-01',start:'08:00',end:'16:30',note:''}];
 const result=periodView(s,'boss@shop.vn',{from:'2026-11-17',to:'2026-11-17'},'2026-11')!;
 assert.deepEqual(result.payrollMonths,['2026-11']);assert.equal(result.clocks.length,2);assert.equal(result.clocks.filter(c=>dateRange.withinRange(c.date,result.loadedRange)).length,1);assert.equal(periodView(s,'unknown@shop.vn',{from:'',to:''}),null);
});
test('Tổng tiền, số dư công nợ và ứng trước theo từng NCC',()=>{const s=fixture();const p={...validatePurchase(invoice,s),id:'p1',receipt:null};assert.equal(purchaseTotal(p),1070000);s.purchases.push(p);s.payments.push({id:'t1',supplier:'s1',date:'2026-11-03',amount:500000,method:'Tiền mặt',note:'',receipt:null});assert.equal(supplierBalance(s,'s1').balance,1570000);assert.equal(supplierLedger(s,'s1').at(-1)?.balance,1570000);s.payments.push({id:'t2',supplier:'s1',date:'2026-11-04',amount:2000000,method:'Chuyển khoản',note:'',receipt:null});assert.equal(supplierBalance(s,'s1').balance,-430000);assert.equal(supplierBalance(s,'other').balance,0);});
test('Chặn ngày sai, số tiền âm, giảm vượt phiếu, dòng rỗng và phiếu trùng',()=>{const s=fixture();for(const x of [{...invoice,date:'2026-02-30'},{...invoice,date:'2026-10-31'},{...invoice,due:'2026-11-01'},{...invoice,discount:2000000},{...invoice,lines:[]},{...invoice,lines:[{...invoice.lines[0],quantity:1.5}]},{...invoice,lines:[{...invoice.lines[0],price:-1}]}])assert.throws(()=>validatePurchase(x,s));s.purchases.push({...validatePurchase(invoice,s),id:'p1',receipt:null});assert.throws(()=>validatePurchase(invoice,s),/đã có/);});
test('Tài khoản chấm công không được cấp thêm phân hệ',()=>{for(const r of ['terminal','employee','manager','payroll'])assert.equal(canAccessModule(r,'purchases'),false);assert.equal(canAccessModule('owner','purchases'),true);});
function harness(){const sqlite=new DatabaseSync(':memory:');sqlite.exec('CREATE TABLE app_state(id TEXT PRIMARY KEY,value TEXT,version INTEGER)');sqlite.prepare('INSERT INTO app_state VALUES(?,?,0)').run('main',JSON.stringify({owner:'boss@shop.vn',members:[{email:'worker@shop.vn',role:'terminal'}]}));let email='boss@shop.vn';
function statement(sql:string){let args:any[]=[];return {bind(...v:any[]){args=v;return this;},async first(){return sqlite.prepare(sql).get(...args)||null;},async all(){return {results:sqlite.prepare(sql).all(...args)};},async run(){const result=sqlite.prepare(sql).run(...args);return {meta:{changes:Number(result.changes)}};}};}
const DB={prepare:statement,async batch(statements:any[]){sqlite.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sqlite.exec('COMMIT');return out;}catch(e){sqlite.exec('ROLLBACK');throw e;}}} as unknown as D1Database;
const code=ts.transpileModule(readFileSync(new URL('../app/api/purchases/route.ts',import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const exports:any={};const modules:any={'../../../lib/historical-purchase-expenses':historicalPurchases,'../../../lib/trang-payment':trang,'../../../lib/payment-invoices':invoices,'../../../lib/expense-controls':controls,'../../../lib/supplier-payment-expense':expenses,'../../../lib/date-range':dateRange,'cloudflare:workers':{env:{DB,BUCKET:{head:async()=>null}}},'../../chatgpt-auth':{getChatGPTUser:async()=>email?{email}:null},'../../../lib/payroll':{permission:(s:any,e:string)=>s.owner===e?{role:'owner'}:s.members.find((m:any)=>m.email===e)},'../../../lib/purchasing':purchases,'../../../lib/price-history':historicalPrices,'../../../lib/purchasing-store':store,'../../../lib/stock-store':stockStore};
vm.runInNewContext('(function(require,exports){'+code+'})',{Response,URL,crypto,console})( (id:string)=>{if(!modules[id])throw Error(id);return modules[id];},exports);
return {api:exports,DB,sqlite,setEmail:(v:string)=>{email=v;},get:async(query='')=>{const r=await exports.GET(new Request('https://pm.test/api/purchases?'+query));return {status:r.status,body:await r.json() as any};},post:async(action:string,data:any,version:number,id=crypto.randomUUID())=>{const r=await exports.POST(new Request('https://pm.test/api/purchases',{method:'POST',headers:{origin:'https://pm.test','Content-Type':'application/json'},body:JSON.stringify({action,data,version,requestId:id})}));return {status:r.status,body:await r.json() as any};}};}
test('API và SQLite: phân quyền, nguyên tử, replay, xung đột và hủy cập nhật số dư',async()=>{const h=harness();h.setEmail('worker@shop.vn');assert.equal((await h.get()).status,403);assert.equal((await h.post('supplier',supplier,0)).status,400);h.setEmail('boss@shop.vn');assert.equal((await h.post('supplier',{...supplier,id:undefined},0)).status,200);let state=(await h.get()).body;const id=state.suppliers[0].id;const request=crypto.randomUUID();assert.equal((await h.post('purchase',{...invoice,supplier:id,paid:200000,method:'Tiền mặt'},1,request)).status,200);state=(await h.get()).body;assert.equal(state.purchases.length,1);assert.equal(state.balances[0].balance,1870000);assert.equal(state.purchases[0].total,1070000);assert.equal(state.purchases[0].quantity,10);assert.equal(state.purchases[0].lines.length,0);assert.equal((await h.post('purchase',{...invoice,supplier:id,paid:200000},1,request)).status,200);state=(await h.get()).body;assert.equal(state.version,2);assert.equal(state.purchases.length,1);assert.equal((await h.post('payment',{supplier:id,date:'2026-11-03',amount:1},1)).status,409);assert.equal((await h.post('purchase',{...invoice,number:'A002',supplier:id,paid:99999999},2)).status,400);const p=state.purchases[0];assert.equal((await h.post('void',{id:p.id,kind:'purchase',reason:'Nhập nhầm'},2)).status,200);state=(await h.get()).body;assert.equal(state.balances[0].balance,1000000);assert.equal((await h.get('tab=audit')).body.audit.length,3);const paid=(await h.get('tab=payments')).body.payments[0];assert.ok(paid.voidReason);h.sqlite.close();});
test('Chuyển dữ liệu cũ đúng một lần, giữ tổng nợ và chứng từ',async()=>{const h=harness();const legacy=fixture();legacy.purchases.push({...validatePurchase(invoice,legacy),id:'old',receipt:{key:'receipts/old',name:'Phiếu cũ',mime:'application/pdf'}});h.sqlite.prepare('INSERT INTO app_state VALUES(?,?,?)').run('purchasing',JSON.stringify(legacy),7);await store.preparePurchasing(h.DB);await store.preparePurchasing(h.DB);const state=await store.readPurchasing(h.DB,new URL('https://pm.test/?month=2026-11'));assert.equal(state.version,7);assert.equal(state.purchases.length,1);assert.equal(state.balances[0].balance,2070000);const detail=await store.docRecord(h.DB,'old');assert.equal(detail?.value.receipt?.key,'receipts/old');assert.ok(h.sqlite.prepare('SELECT value FROM app_state WHERE id=?').get('purchasing'));h.sqlite.close();});
test('10.000 phiếu: trang chỉ có 50 tóm tắt, tổng nợ không phụ thuộc trang',async()=>{const h=harness();await store.preparePurchasing(h.DB);h.sqlite.prepare('INSERT INTO pm_purchase_suppliers(id,name,opening,record) VALUES(?,?,?,?)').run(supplier.id,supplier.name,supplier.opening,JSON.stringify(supplier));const insert=h.sqlite.prepare('INSERT INTO pm_purchase_docs(id,supplier,date,kind,number,total,record) VALUES(?,?,?,?,?,?,?)');h.sqlite.exec('BEGIN');for(let i=0;i<10000;i++){const p={...invoice,id:'p'+String(i).padStart(5,'0'),number:'N'+i};insert.run(p.id,'s1','2026-11-02','purchase',p.number,1070000,JSON.stringify(p));}h.sqlite.exec('COMMIT');const started=performance.now();const first=await store.readPurchasing(h.DB,new URL('https://pm.test/?month=2026-11'));const second=await store.readPurchasing(h.DB,new URL('https://pm.test/?month=2026-11&page=2'));const elapsed=performance.now()-started;assert.equal(first.pagination.total,10000);assert.equal(first.purchases.length,50);assert.equal(second.purchases.length,50);assert.ok(!first.purchases.some(p=>second.purchases.some(q=>q.id===p.id)));assert.equal(first.balances[0].balance,1000000+1070000*10000);assert.equal(first.periodTotal,1070000*10000);assert.ok(JSON.stringify(first).length<30000);console.log('10.000 phiếu · 2 trang:',Math.round(elapsed),'ms · phản hồi trang 1:',JSON.stringify(first).length,'ký tự (SQLite trong bộ nhớ, không phải tốc độ mạng thật)');const ledger=await store.readLedger(h.DB,'s1',2);assert.equal(ledger.rows.length,50);assert.equal(ledger.rows[0]?.id,'p09949');assert.equal(ledger.rows.at(-1)?.balance,1000000+1070000*9901);h.sqlite.close();});

test('Nhân sự chỉ tải tháng đang xem; giữ phân quyền và số tháng đã chốt',()=>{const s=initial('boss@shop.vn');for(let i=0;i<10000;i++)s.clocks.push({employee:'nv1',date:i===0?'2026-11-16':'2025-01-01',start:'08:00',end:'16:30',note:''});s.adjustments.push({employee:'nv1',month:'2025-01',allowance:0,responsibility:0,bonus:0,orderBonus:0,deduction:0,advance:100000,note:''});const data=monthView(s,'boss@shop.vn','2026-11')!;assert.equal(data.clocks.length,1);assert.equal(data.adjustments.length,0);assert.equal(monthView(s,'unknown@shop.vn','2026-11'),null);assert.throws(()=>monthView(s,'boss@shop.vn','2026-99'));assert.equal(s.clocks.length,10000);});

test('Trả theo số dư Trang, đối chiếu một lần và tách trả trước',async()=>{
 const h=harness();await store.preparePurchasing(h.DB);
 const sup={...supplier,id:trang.trangId,name:'Trang',opening:100000000};
 h.sqlite.prepare('INSERT INTO pm_purchase_suppliers(id,name,opening,record) VALUES(?,?,?,?)').run(sup.id,sup.name,sup.opening,JSON.stringify(sup));
 const transfer={supplier:sup.id,date:'2026-11-20',recipient:'Trịnh Thị Trang',amount:35000000};
 assert.equal((await h.post('payment',transfer,0)).status,200);
 const balance=async()=>(await h.get('mode=balance-at&date=2026-11-20&supplier='+sup.id)).body.balance;
 assert.equal(await balance(),65000000);
 assert.equal((await h.post('payment',{...transfer,recipient:'Nguyễn Huy Minh',amount:70000000},1)).status,200);
 assert.equal(await balance(),65000000);
 assert.equal((await h.get('mode=cash-paid')).body.paid,105000000);
 const id=h.sqlite.prepare("SELECT id FROM pm_purchase_docs WHERE total=0").get()!.id;
 assert.equal((await h.post('confirm-trang',{id},2)).status,200);
 assert.equal((await h.post('confirm-trang',{id},3)).status,400);
 assert.deepEqual(trang.afterPayment(await balance(),0,false),{debt:0,advance:5000000});
 assert.equal((await h.post('void',{kind:'payment',id,reason:'test'},3)).status,200);
 assert.equal(await balance(),65000000);
 assert.equal((await h.get('mode=cash-paid')).body.paid,35000000);
 assert.deepEqual(trang.readTransfer('Ngày giao dịch: 20/11/2026\nSố tiền: 35.000.000 VND\nTên người nhận: TRỊNH THỊ TRANG'),{date:'2026-11-20',amount:35000000,recipient:'TRỊNH THỊ TRANG'});
 h.sqlite.close();
});
test('Chi phí mua hàng lịch sử: đúng kỳ, duyệt quản trị, chạy lại không giảm công nợ',async()=>{
 const h=harness();await store.preparePurchasing(h.DB);
 const id='0b64a9cb-7932-5eff-8188-8fb6baa4257c',bill='017091001591|2C26TAA|10';
 h.sqlite.prepare('INSERT INTO pm_purchase_suppliers(id,name,opening,record) VALUES(?,?,?,?)').run('s1','Trang',500000000,JSON.stringify(supplier));
 h.sqlite.prepare("INSERT INTO pm_purchase_docs(id,supplier,date,kind,total,record) VALUES(?,?,?,'payment',?,?)").run(id,'s1','2026-06-04',200000000,JSON.stringify({sourceRef:{sheet:'NhapLieu',row:58}}));
 h.sqlite.exec('CREATE TABLE gmail_purchase_notices(id,date,supplier,printedTotal,series,number,status)');
 h.sqlite.prepare('INSERT INTO gmail_purchase_notices VALUES(?,?,?,?,?,?,?)').run(bill,'2026-07-13','Minh','46000000','2C26TAA','10','documented');
 const query=(from:string,to:string)=>historicalPurchases.historicalPurchases(h.DB,from,to);
 assert.equal((await query('','')).length,2);
 assert.equal((await query('2026-06-01','2026-06-30'))[0].reference,'NhapLieu!M58');
 assert.equal((await query('2026-07-01','2026-07-31'))[0].management_status,'approved');
 assert.equal(h.sqlite.prepare('SELECT opening-paid AS balance FROM pm_purchase_suppliers').get()!.balance,300000000);
 assert.equal(h.sqlite.prepare('SELECT count(*) AS n FROM pm_management_purchase_expenses').get()!.n,2);
 h.sqlite.close();
});

test('Tài liệu chi phí mua hàng: đúng phiếu, đúng hóa đơn, không trùng thư hoặc thay đổi công nợ',async()=>{
 const h=harness();await store.preparePurchasing(h.DB);
 h.sqlite.prepare('INSERT INTO pm_purchase_suppliers(id,name,opening,record) VALUES(?,?,?,?)').run('s1','Trang',500000000,JSON.stringify(supplier));
 h.sqlite.prepare("INSERT INTO pm_purchase_docs(id,supplier,date,kind,total,record) VALUES(?,?,?,'payment',?,?)").run('p1','s1','2026-06-04',200000000,JSON.stringify({receipt:{key:'receipts/proof',name:'Chuyển khoản.pdf'}}));
 h.sqlite.exec(`CREATE TABLE gmail_purchase_sources(noticeId,mailId);CREATE TABLE gmail_evidence(id);CREATE TABLE gmail_documents(id,mailId,targetId);CREATE TABLE gmail_link_files(itemId,name);
 INSERT INTO gmail_purchase_sources VALUES('invoice1','mail1');INSERT INTO gmail_evidence VALUES('mail1');
 INSERT INTO gmail_documents VALUES('doc1','mail1','invoice1'),('doc2','mail1','invoice1'),('unrelated','mail1','invoice2');
 INSERT INTO gmail_link_files VALUES('doc1','Hóa đơn.pdf'),('doc2','Hóa đơn.xml'),('unrelated','Khác.pdf');`);
 const rows:historicalPurchases.PurchaseExpenseEntry[]=[{kind:'payment',source_id:'p1',date:'2026-06-04',supplier:'Trang',amount:200000000,reference:'NhapLieu!M58'},{kind:'invoice',source_id:'invoice1',date:'2026-06-04',supplier:'Minh',amount:200000000,reference:'HĐ 10'}];
 const before=h.sqlite.prepare('SELECT paid FROM pm_purchase_suppliers').get()!.paid;
 const documents=await historicalPurchases.historicalPurchaseDocuments(h.DB,rows);
 assert.equal(documents['payment:p1'].length,2);
 assert.ok(documents['payment:p1'][0].url.endsWith('range=M58'));
 assert.equal(documents['payment:p1'][1].url,'/api/purchases/receipt?key=receipts%2Fproof');
 assert.equal(documents['invoice:invoice1'].filter(d=>d.kind==='file').length,2);
 assert.equal(documents['invoice:invoice1'].filter(d=>d.kind==='source').length,1);
 assert.ok(!JSON.stringify(documents).includes('unrelated'));
 assert.equal(h.sqlite.prepare('SELECT paid FROM pm_purchase_suppliers').get()!.paid,before);
 assert.deepEqual(await historicalPurchases.historicalPurchaseDocuments(h.DB,[]),{});
 h.sqlite.close();
});

test('Điều chỉnh số gốc cập nhật công nợ theo kỳ và số dư ngày thanh toán',async()=>{
 const h=harness();
 try {
  await h.post('supplier',{...supplier,id:undefined},0);
  const id=(await h.get()).body.suppliers[0].id;
  await h.post('purchase',{...invoice,supplier:id,paid:0},1);
  const change={id,opening:-50000,reason:'Đối chiếu số đầu kỳ'};
  assert.equal((await h.post('adjust-opening',{...change,reason:''},2)).status,400);
  const request=crypto.randomUUID();
  assert.equal((await h.post('adjust-opening',change,2,request)).status,200);
  assert.equal((await h.post('adjust-opening',change,2,request)).status,200);
  const view=(await h.get('tab=debt&from=2026-11-03&to=2026-11-30')).body;
  assert.equal(view.suppliers[0].opening,-50000);
  assert.equal(view.balances[0].periodOpening,1020000);
  assert.equal(view.balances[0].balance,1020000);
  assert.equal((await h.get('mode=balance-at&date=2026-11-03&supplier='+id)).body.balance,1020000);
  assert.equal(view.version,3);
 } finally { h.sqlite.close(); }
});
