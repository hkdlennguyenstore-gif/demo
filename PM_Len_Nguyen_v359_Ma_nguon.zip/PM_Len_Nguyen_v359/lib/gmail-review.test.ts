import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import test from 'node:test';
import {parseBills,reviewGmail,reviewSchema} from './gmail-review';

test('Fintab assigns one amount across links and preserves that result on replay',async()=>{
 const sql=new DatabaseSync(':memory:');
 sql.exec(reviewSchema+`;CREATE TABLE gmail_documents(id,mailId,document,source,reference,date,currency,amount,reason,state,targetId,identity);
 CREATE TABLE gmail_evidence(id,subject,received);CREATE TABLE gmail_document_facts(itemId,facts);
 INSERT INTO gmail_evidence VALUES('m','ABC gửi hóa đơn điện tử số 0002 cho Quý khách','2026-09-02');
 INSERT INTO gmail_fintab_bills VALUES('ABC','2','2026-09-01',100);`);
 const note='Chờ kiểm tra quyền tải hóa đơn từ liên kết nguồn.';
 for(const id of ['m:0','m:1'])sql.prepare("INSERT INTO gmail_documents VALUES(?,'m','Tra cứu','sender','','','',null,?,'pending','','')").run(id,note);
 function prep(q:string,args:any[]=[]):any{return {bind:(...values:any[])=>prep(q,values),all:async()=>({results:sql.prepare(q).all(...args)}),run:()=>sql.prepare(q).run(...args)};}
 const db={prepare:prep,batch:async(a:any[])=>a.forEach(s=>s.run())} as unknown as D1Database;
 await reviewGmail(db);await reviewGmail(db,'m');
 assert.deepEqual(sql.prepare('SELECT reference,state,amount FROM gmail_documents ORDER BY id').all().map(r=>[r.reference,r.state,r.amount]),[['2','pending',100],['','evidence',null]]);
 assert.throws(()=>parseBills('31/02/2026\t1\tABC\t500'));
});
