import {validDate} from './purchasing';
import {putSetting} from './expense-controls';

const feeTypes=['Phí giao dịch','Phí hoa hồng của TikTok Shop','Phí xử lý đơn hàng'];
type Fee={ref:string;type:string;amount:number};
export async function settlementImport(db:D1Database,b:any,actor:string){
 const {shop,date,rows,commit}=b;
 validDate(date);
 if(!['tiktok1','tiktok2'].includes(shop)||!Array.isArray(rows)||!rows.length||rows.length>2000)throw Error('Kiểm tra shop, ngày và số dòng.');
 const keys=new Set<string>();
 for(const row of rows as Fee[]){
   const k=JSON.stringify([row.ref,row.type]);
   if(typeof row.ref!=='string'||!/^\d{12,24}$/.test(row.ref)||!feeTypes.includes(row.type)||!Number.isSafeInteger(row.amount)||!row.amount||Math.abs(row.amount)>1e10||keys.has(k))throw Error('Mã đơn, loại phí, số tiền hoặc dòng trùng cần rà soát.');
   keys.add(k);
 }
 await db.prepare('CREATE TABLE IF NOT EXISTS pm_settlement_fees(shop TEXT,date TEXT,ref TEXT,type TEXT,amount INTEGER,batch TEXT,file TEXT,PRIMARY KEY(shop,date,ref,type))').run();
 const input=JSON.stringify(rows),batch=crypto.randomUUID(),now=new Date().toISOString();
 const incoming="SELECT value->>'$.ref' ref,value->>'$.type' type,value->>'$.amount' amount,value->>'$.file' file FROM json_each(?)";
 const match='f.shop=? AND f.date=? AND f.ref=i.ref AND f.type=i.type';
 const legacy="SELECT 1 FROM pm_finance_docs WHERE kind='expense' AND channel=? AND date=? AND json_extract(record,'$.category')='platform' AND COALESCE(json_extract(record,'$.settlementImport'),0)=0";
 const check=db.prepare('WITH i AS ('+incoming+') SELECT COUNT(*) n,COALESCE(SUM(i.amount),0) amount,SUM(f.ref IS NULL) fresh,COALESCE(SUM(CASE WHEN f.ref IS NULL THEN i.amount ELSE 0 END),0) delta,SUM(f.ref IS NOT NULL AND f.amount!=i.amount) conflicts,EXISTS('+legacy+') overlap FROM i LEFT JOIN pm_settlement_fees f ON '+match).bind(input,shop,date,shop,date);
 const before=await check.first<any>();
 if(before.conflicts||before.overlap)throw Error(date+' · Có khoản phí cùng kỳ cần đối chiếu với dữ liệu đã ghi.');
 if(commit!==true)return before;
 const base={kind:'expense',category:'platform',channel:shop,date,endDate:date,settlementImport:true,status:'confirmed',counterparty:'TikTok Shop',deductibility:'pending',paid:0,payments:[],actor,confirmedAt:now,createdAt:now};
 const insert=db.prepare('WITH i AS ('+incoming+') INSERT OR IGNORE INTO pm_settlement_fees SELECT ?,?,ref,type,amount,?,file FROM i WHERE NOT EXISTS('+legacy+')').bind(input,shop,date,batch,shop,date);
 const doc=db.prepare("INSERT INTO pm_finance_docs SELECT ?||type,'expense',?,?,?,'confirmed',json_set(?,'$.amount',SUM(amount),'$.description',type,'$.reference',?,'$.feeRows',COUNT(*)),0,NULL FROM pm_settlement_fees WHERE batch=? GROUP BY type").bind(batch,date,date,shop,JSON.stringify(base),batch,batch);
 const audit=db.prepare("INSERT INTO pm_finance_audit SELECT ?,?,?,?,json_object('batch',?,'date',?,'shop',?,'rows',COUNT(*),'amount',SUM(amount)) FROM pm_settlement_fees WHERE batch=? HAVING COUNT(*)>0").bind(batch,now,actor,'import:settlement',batch,date,shop,batch);
 if(before.fresh)await db.batch([insert,doc,audit,putSetting(db,'expense-changed:'+date,now)]);
 const read=await check.first<any>();
 if(read.fresh||read.conflicts||read.overlap)throw Error(date+' · Chưa xác nhận đủ dữ liệu đã ghi.');
 const inserted=before.fresh ? await db.prepare('SELECT COUNT(*) fresh, COALESCE(SUM(amount),0) delta FROM pm_settlement_fees WHERE batch=?').bind(batch).first<any>() : {fresh:0,delta:0};
 return {...read,...inserted};
}
