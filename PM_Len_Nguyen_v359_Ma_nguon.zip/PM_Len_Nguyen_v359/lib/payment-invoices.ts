// Include active payments from before and after multi-invoice allocation was introduced.
export async function availableInvoices(db:D1Database){
 const query=`WITH amounts AS (
 SELECT json_extract(p.record,'$.invoiceId') id,p.total amount FROM pm_purchase_docs p
 WHERE p.active=1 AND p.kind='payment' AND json_extract(p.record,'$.invoiceId')<>'' AND json_extract(p.record,'$.allocations') IS NULL
 UNION ALL SELECT json_extract(j.value,'$.id'),json_extract(j.value,'$.amount')
 FROM pm_purchase_docs p,json_each(p.record,'$.allocations') j WHERE p.active=1 AND p.kind='payment'
 ), used AS (SELECT id,SUM(amount) paid FROM amounts GROUP BY id)
 SELECT i.id,i.number,i.date,i.supplier,CAST(i.printedTotal AS INTEGER)-COALESCE(used.paid,0) remaining
 FROM gmail_purchase_notices i LEFT JOIN used ON used.id=i.id WHERE i.status='documented' ORDER BY i.date,i.number`;
 return (await db.prepare(query).all<{id:string;number:string;date:string;supplier:string;remaining:number}>()).results;
}
