import test from 'node:test';
import assert from 'node:assert/strict';
import {selectHistoricalPrice} from './price-history.ts';

const history=[
  {code:'B91',date:'2026-05-21',price:115000,row:243},
  {code:'B91',date:'2026-07-01',price:120000,row:250},
];
test('Giá gần nhất không sau ngày nhập; giá tương lai không áp cho phiếu cũ',()=>{
  assert.equal(selectHistoricalPrice(history,'b91','2026-05-19').status,'missing');
  assert.equal(selectHistoricalPrice(history,' B91 ','2026-05-21').price,115000);
  assert.equal(selectHistoricalPrice(history,'B91','2026-06-30').price,115000);
  assert.equal(selectHistoricalPrice(history,'B91','2026-07-01').price,120000);
  const receipt={price:selectHistoricalPrice(history,'B91','2026-06-30').price};
  selectHistoricalPrice([...history,{code:'B91',date:'2026-08-01',price:130000,row:260}],'B91','2026-08-01');
  assert.equal(receipt.price,115000);
});
test('Giá nền duy nhất và giá trùng ngày mâu thuẫn được phân biệt',()=>{
  const baseline={code:'B91',date:'',price:100000,row:2};
  assert.equal(selectHistoricalPrice([baseline,...history],'B91','2026-05-19').price,100000);
  assert.equal(selectHistoricalPrice([baseline,...history],'B91','2026-05-21').price,115000);
  assert.equal(selectHistoricalPrice([...history,{...history[0],price:110000,row:244}],'B91','2026-05-21').status,'ambiguous');
});
