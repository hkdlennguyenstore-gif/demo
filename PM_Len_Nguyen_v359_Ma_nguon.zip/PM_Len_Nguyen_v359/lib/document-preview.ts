export type PreviewFile={name:string;mime:string;bytes:Uint8Array};
function decode(bytes:Uint8Array,charset='utf-8'){try{return new TextDecoder(charset).decode(bytes);}catch{return new TextDecoder().decode(bytes);}}
function binaryBytes(value:string){return Uint8Array.from(value,c=>c.charCodeAt(0)&255);}
function transfer(value:string,encoding:string){
 if(encoding.toLowerCase()==='base64')return binaryBytes(atob(value.replace(/\s/g,'')));
 if(encoding.toLowerCase()==='quoted-printable')return binaryBytes(value.replace(/=\r?\n/g,'').replace(/=([a-f\d]{2})/gi,(_,n)=>String.fromCharCode(parseInt(n,16))));
 return binaryBytes(value);
}
export function decodeMailHeader(value:string){return value.replace(/(\?=)\s+(=\?)/g,'$1$2').replace(/=\?([^?]+)\?([bq])\?([^?]*)\?=/gi,(whole,charset,encoding,text)=>{try{return decode(transfer(encoding.toLowerCase()==='q'?text.replaceAll('_',' '):text,encoding.toLowerCase()==='b'?'base64':'quoted-printable'),charset);}catch{return whole;}});}
function parameter(value:string,key:string){
 const encoded=value.match(new RegExp('(?:^|;)\\s*'+key+"\\*=([^;]+)",'i'))?.[1]?.trim();
 if(encoded){try{return decodeURIComponent(encoded.replace(/^"|"$/g,'').replace(/^[^']*'[^']*'/,''));}catch{}}
 return decodeMailHeader(value.match(new RegExp('(?:^|;)\\s*'+key+'=(?:"([^"]*)"|([^;]*))','i'))?.slice(1).find(Boolean)?.trim()||'');
}
function splitPart(source:string){const end=/\r?\n\r?\n/.exec(source);if(!end)return {headers:{} as Record<string,string>,body:source};const headers:Record<string,string>={};for(const line of source.slice(0,end.index).replace(/\r?\n[ \t]+/g,' ').split(/\r?\n/)){const index=line.indexOf(':');if(index>0)headers[line.slice(0,index).toLowerCase()]=line.slice(index+1).trim();}return {headers,body:source.slice(end.index+end[0].length)};}
export function parseEmail(bytes:Uint8Array){
 let raw='';for(let i=0;i<bytes.length;i+=8192)raw+=String.fromCharCode(...bytes.subarray(i,i+8192));
 const main=splitPart(raw),texts:string[]=[],htmls:string[]=[],attachments:PreviewFile[]=[];let parts=0;
 function walk(source:string,depth=0){
  if(depth>12||++parts>200)throw Error('Thư có quá nhiều phần. Tải thư gốc để mở đầy đủ.');
  const {headers,body}=splitPart(source),type=headers['content-type']||'text/plain; charset=utf-8',mime=type.split(';')[0].trim().toLowerCase();
  const boundary=parameter(type,'boundary');
  if(mime.startsWith('multipart/')&&boundary){const escaped=boundary.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');for(const part of body.split(new RegExp('(?:^|\\r?\\n)--'+escaped+'(?=--|\\r?\\n)')).slice(1)){if(part.startsWith('--'))break;walk(part.replace(/^\r?\n/,''),depth+1);}return;}
  const name=parameter(headers['content-disposition']||'','filename')||parameter(type,'name');
  const data=transfer(body,headers['content-transfer-encoding']||'');
  if(name||/^attachment\b/i.test(headers['content-disposition']||'')||!['text/plain','text/html'].includes(mime)){if(data.length)attachments.push({name:name||'tai-lieu-'+(attachments.length+1),mime,bytes:data});return;}
  const text=decode(data,parameter(type,'charset')||'utf-8');if(mime==='text/html')htmls.push(text);else texts.push(text);
 }
 walk(raw);
 return {subject:decodeMailHeader(main.headers.subject||''),from:decodeMailHeader(main.headers.from||''),date:main.headers.date||'',text:texts.join('\n\n'),html:htmls.join('\n'),attachments};
}
export function previewType(file:PreviewFile){const ext=file.name.split('.').pop()?.toLowerCase(),mime=file.mime.toLowerCase();
 if(ext==='eml'||mime.includes('rfc822'))return 'email';
 if(new TextDecoder().decode(file.bytes.subarray(0,5))==='%PDF-'||mime==='application/pdf'||ext==='pdf')return 'pdf';
 if(['png','jpg','jpeg','webp','gif'].includes(ext||'')||/^image\/(png|jpeg|webp|gif)$/.test(mime))return 'image';
 if(['xlsx','docx','csv','tsv'].includes(ext||''))return 'document';
 if(['xml','txt','json','log'].includes(ext||'')||mime.startsWith('text/')||mime.includes('xml')||mime.includes('json'))return 'text';
 return 'unsupported';
}
export function previewMime(file:PreviewFile){const type=previewType(file);if(type==='pdf')return 'application/pdf';if(type==='image'){const ext=file.name.split('.').pop()?.toLowerCase();return /^image\/(png|jpeg|webp|gif)$/.test(file.mime)?file.mime:'image/'+(ext==='jpg'?'jpeg':ext);}return file.mime||'application/octet-stream';}
