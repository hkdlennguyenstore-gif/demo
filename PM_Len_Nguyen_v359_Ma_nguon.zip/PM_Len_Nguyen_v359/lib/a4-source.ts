import {posGet} from './orders-store';
import {normalizeA4Variations,validateA4Page,a4Code} from './a4';
const snapshots=new Map<string,{at:number,value:any}>();
export async function readA4Product(config:any,code:string,fresh=false){
 if(!config.PANCAKE_API_KEY||!config.PANCAKE_SHOP_ID)throw Error('Chưa có kết nối POS để đọc tồn màu–size');
 const key=config.PANCAKE_SHOP_ID+'|'+code,previous=snapshots.get(key);if(!fresh&&previous&&Date.now()-previous.at<1000)return previous.value;
 const read=(page:number)=>posGet(config.PANCAKE_API_KEY,config.PANCAKE_SHOP_ID,'products/variations',{search:code,page_size:'100',page_number:String(page)});
 const first=await read(1);validateA4Page(first);const rows=[...first.data];
 for(let page=2;page<=first.total_pages;page+=3){const batches=await Promise.all(Array.from({length:Math.min(3,first.total_pages-page+1)},(_,i)=>read(page+i)));for(const batch of batches){validateA4Page(batch);if(batch.total_entries!==first.total_entries||batch.total_pages!==first.total_pages)throw Error('Nguồn POS vừa thay đổi trong lúc đọc. Bấm tải lại.');rows.push(...batch.data);}}
 if(rows.length!==first.total_entries)throw Error('Chưa đọc đủ biến thể POS; không dùng số lượng này để nhận hàng');
 const value={...normalizeA4Variations(rows,code),updatedAt:new Date().toISOString(),source:'POS · Có thể bán theo từng biến thể',code:a4Code(code)};
 snapshots.set(key,{at:Date.now(),value});if(snapshots.size>100)snapshots.delete(snapshots.keys().next().value!);return value;
}
