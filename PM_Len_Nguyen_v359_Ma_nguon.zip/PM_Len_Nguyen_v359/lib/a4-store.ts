import {validateA4Plan,transitionA4Plan} from './a4.ts';
const lastLot = `SELECT COALESCE(MAX(CAST(lot AS INTEGER)),0) FROM pm_a4_plans
 WHERE lot<>'' AND lot NOT GLOB '*[^0-9]*'`;
const legacyDrafts = `SELECT id,CAST((${lastLot}) + ROW_NUMBER() OVER (ORDER BY rowid) AS TEXT) AS nextLot
 FROM pm_a4_plans WHERE status='draft' AND lot=''`;
export const numberedPlans = `WITH legacy AS (${legacyDrafts}), numbered AS (
 SELECT p.rowid AS seq,p.id,p.date,p.status,p.version,p.record,COALESCE(legacy.nextLot,p.lot) AS lot
 FROM pm_a4_plans p LEFT JOIN legacy ON legacy.id=p.id WHERE p.status<>'archived')`;
export class A4Conflict extends Error{}
export async function saveA4Plan(db:D1Database,actor:string,requestId:string,action:string,x:any){
 const replay=await db.prepare('SELECT record FROM pm_a4_requests WHERE id=? AND actor=?').bind(requestId,actor).first<{record:string}>();if(replay)return {...JSON.parse(replay.record).response,replayed:true};
 await db.prepare(`WITH legacy AS MATERIALIZED (${legacyDrafts})
 UPDATE pm_a4_plans SET (lot,record)=(SELECT nextLot,json_set(record,'$.lot',nextLot) FROM legacy WHERE legacy.id=pm_a4_plans.id)
 WHERE status='draft' AND lot=''`).run();
 const old=x.id?await db.prepare('SELECT version,record FROM pm_a4_plans WHERE id=?').bind(x.id).first<{version:number,record:string}>():null;
 if(x.id&&!old)throw Error('Không tìm thấy kế hoạch');if(old&&old.version!==x.version)throw new A4Conflict('Lô đã thay đổi ở cửa sổ khác. Tải lại trước khi sửa.');
 if(!old&&action!=='save')throw Error('Không tìm thấy lô cần cập nhật');
 const now=new Date().toISOString(),id=old?x.id:crypto.randomUUID(),version=old?old.version+1:0;
 if(action==='delete'){
  if(!old)throw Error('Không tìm thấy lô');
  const status=JSON.parse(old.record).status;
  if(!['draft','production','returned'].includes(status))throw Error('Lô đã xóa');
  const response={ok:true,id,version};
  const audit=JSON.stringify({time:now,action,before:JSON.parse(old.record),after:null,response});
  try{
   const result=await db.batch([
    db.prepare("INSERT INTO pm_a4_requests(id,actor,record) SELECT ?,?,? FROM pm_a4_plans WHERE id=? AND version=? AND status=?").bind(requestId,actor,audit,id,old.version,status),
    db.prepare("UPDATE pm_a4_plans SET status='archived',record=json_set(record,'$.status','archived'),version=? WHERE id=? AND version=? AND status=?").bind(version,id,old.version,status)
   ]);
   if(!result[1].meta.changes)throw new A4Conflict('Lô đã thay đổi. Tải lại danh sách.');
  }catch(error){
   const replay=await db.prepare('SELECT record FROM pm_a4_requests WHERE id=? AND actor=?').bind(requestId,actor).first<{record:string}>();
   if(replay)return {...JSON.parse(replay.record).response,replayed:true};
   throw error;
  }
  return response;
 }
 const value=old?transitionA4Plan(JSON.parse(old.record),action,x):{...validateA4Plan(x),id,status:'draft',received:0,returns:[],createdAt:now,createdBy:actor};
 Object.assign(value,{id,updatedAt:now,updatedBy:actor});const record=JSON.stringify(value),response={ok:true,id,version};
 const audit=JSON.stringify({time:now,action,before:old?JSON.parse(old.record):null,after:value,response});
 try{
  const result=await db.batch([
   old?db.prepare('UPDATE pm_a4_plans SET lot=?,date=?,status=?,version=?,record=? WHERE id=? AND version=?').bind(value.lot,value.date,value.status,version,record,id,old.version):db.prepare(`INSERT INTO pm_a4_plans(id,lot,date,status,version,record)
    SELECT ?,n,?,?,?,json_set(?,'$.lot',n) FROM (SELECT CAST((${lastLot})+1 AS TEXT) AS n)`).bind(id,value.date,value.status,version,record),
   db.prepare(`INSERT INTO pm_a4_requests(id,actor,record)
    SELECT ?,?,json_set(?,'$.after',json(record),'$.response.lot',lot)
    FROM pm_a4_plans WHERE id=? AND version=? AND changes()=1`).bind(requestId,actor,audit,id,version)
  ]);
  if(!result[0].meta.changes||!result[1].meta.changes)throw new A4Conflict('Có người vừa sửa lô này. Tải lại để xem bản mới.');
 }catch(e){const retried=await db.prepare('SELECT record FROM pm_a4_requests WHERE id=? AND actor=?').bind(requestId,actor).first<{record:string}>();if(retried)return {...JSON.parse(retried.record).response,replayed:true};throw e;}
 const saved=await db.prepare('SELECT record FROM pm_a4_requests WHERE id=? AND actor=?').bind(requestId,actor).first<{record:string}>();
 return JSON.parse(saved!.record).response;
}
