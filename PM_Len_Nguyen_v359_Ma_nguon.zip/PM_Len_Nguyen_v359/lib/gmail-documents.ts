import {supplierRuleSchema,supplierApproval,supplierRule,supplierCategory,type SupplierRule} from './gmail-supplier-rules';
import {merchandiseSupplier,routePurchaseNotice} from './gmail-purchase-notices';
import {checkStatements} from './gmail-crosscheck';
import {reconcileJt} from './gmail-jt';
import {digest} from './a3-access';
import {validateFinance} from './finance';
import {putSetting} from './expense-controls';

type Invoice = {vendor?:string;vendorTaxId?:string;buyerName?:string;buyerTaxId?:string;series?:string;number?:string;date?:string;currency?:string;total?:string|number;descriptions?:string[];adjusted?:boolean};
type Attachment = {verifiedReading?:Record<string,unknown>;name?:string;mimeType?:string;sha256?:string;invoice?:Invoice;error?:string;readIssue?:string};
export type Manifest = {quarantine?:string;bodyText?:string;notice?:Attachment;attachments?:Attachment[];links?:{url:string;label?:string;error?:string}[];reasons?:string[]};
type Mail = {id:string;subject:string;sender:string;digest:string};
const actor='Gmail · owner@example.invalid';
const clean=(v:unknown)=>typeof v==='string'?v.trim():'';
const fold=(v:string)=>v.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').toLowerCase();
export const gmailSchema=[
 ...supplierRuleSchema,
 'CREATE TABLE IF NOT EXISTS gmail_purchase_notices(id TEXT PRIMARY KEY,supplier TEXT NOT NULL,series TEXT NOT NULL,number TEXT NOT NULL,date TEXT NOT NULL,printedTotal TEXT NOT NULL,status TEXT NOT NULL,related TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS gmail_purchase_sources(noticeId TEXT NOT NULL,mailId TEXT NOT NULL,PRIMARY KEY(noticeId,mailId))',
 'CREATE TABLE IF NOT EXISTS gmail_category_history(itemId TEXT NOT NULL,oldCategory TEXT,newCategory TEXT,reason TEXT,changed TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(itemId,oldCategory,newCategory))',
 'CREATE TABLE IF NOT EXISTS gmail_documents(id TEXT PRIMARY KEY,mailId TEXT NOT NULL,document TEXT NOT NULL,source TEXT NOT NULL,reference TEXT NOT NULL,date TEXT NOT NULL,month TEXT NOT NULL,category TEXT NOT NULL,channel TEXT NOT NULL,currency TEXT NOT NULL,amount REAL,state TEXT NOT NULL,reason TEXT NOT NULL,targetType TEXT NOT NULL,targetId TEXT NOT NULL,identity TEXT NOT NULL,proofHash TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS gmail_document_facts(itemId TEXT PRIMARY KEY,quality INTEGER NOT NULL,facts TEXT NOT NULL)',
 'CREATE INDEX IF NOT EXISTS gmail_documents_identity ON gmail_documents(identity)',
 'CREATE INDEX IF NOT EXISTS gmail_documents_mail ON gmail_documents(mailId)',
 'CREATE INDEX IF NOT EXISTS gmail_documents_period ON gmail_documents(month,source)'
];
const groups:[string,RegExp][]=[
 ['ads',/quang cao|advertising|facebook ads|tiktok ads|广告/],
 ['platform',/phi san|phi nen tang|platform fee|commission fee|hoa hong tiktok/],
 ['shipping',/van chuyen|van don|cuoc giao|shipping fee|j&t|doi soat cod/],
 ['software',/phan mem|software|ten mien|hosting|subscription/],
 ['operations',/tien dien|tien nuoc|cuoc internet|tien thue mat bang/],
 ['equipment',/thiet bi|may in |may tinh xach tay|laptop|\biphone\b/],
 ['packing',/bao bi|tui dong goi|thung carton|packaging/],
 ['cogs',/nhap hang|quan jean|quan jeans|denim jeans/]
];
function category(text:string){const matches=groups.filter(([,pattern])=>pattern.test(fold(text)));return matches.length===1?matches[0][0]:'';}
function invoiceDay(v:unknown){
 const s=clean(v);if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return '';
 const d=new Date(s+'T00:00:00Z');return Number.isFinite(d.valueOf())&&d.toISOString().slice(0,10)===s?s:'';
}
function invoiceAmount(v:unknown){
 if((typeof v!=='number'&&typeof v!=='string')||!/^\d{1,14}(?:\.\d{1,4})?$/.test(String(v)))return null;
 return Number(v);
}
export function inspectDocument(mail:Mail,a:Attachment,body:string,approvedRule?:SupplierRule){
 const i=a.invoice||{},labels=Array.isArray(i.descriptions)?i.descriptions.map(clean).filter(Boolean):[];
 const text=labels.length?labels.join(' · '):[mail.subject,a.name,body].join(' ');
 const deliveryPlatform=/@(?:softdreams|easyinvoice)\.vn\b/i.test(mail.sender);
 const group=merchandiseSupplier(i)?'cogs':approvedRule?supplierCategory(approvedRule,labels.join(' ')):deliveryPlatform&&!labels.length?'':category(text), normalized=fold(text),date=invoiceDay(i.date);
 const source=clean(i.vendor)||clean(mail.sender.match(/<([^<>]+)>/)?.[1])||mail.sender;
 const reference=clean(i.number),series=clean(i.series),currency=clean(i.currency).toUpperCase(),amount=invoiceAmount(i.total);
 const explicitShop=[['tiktok1',/\b(?:tiktok 1|7494549204538985115)\b/],['tiktok2',/\b(?:tiktok 2|7494924027339376972)\b/],['shopee',/\b(?:shopee 736225350|736225350)\b/],['facebook',/\bkenh facebook\b/],['shared',/\b(?:chi phi chung|toan shop)\b/]] as const;
 const channels=explicitShop.filter(([,p])=>p.test(normalized));
 const channel=approvedRule?.id==='hoang-ngoc-loi'?'facebook':channels.length===1?channels[0][0]:'';
 const months=[...normalized.matchAll(/\b(?:thang|ky)\s+(0?[1-9]|1[0-2])\s*[/-]\s*(20\d{2})\b/g)].map(m=>m[2]+'-'+m[1].padStart(2,'0'));
 const uniqueMonths=[...new Set(months)];
 const month=uniqueMonths.length===1?uniqueMonths[0]:uniqueMonths.length?'':date.slice(0,7);
 const payer=fold(clean(i.buyerName)).replace(/[^a-z0-9]/g,'');
 const proofHash=/^[a-f0-9]{64}$/.test(a.sha256||'')?a.sha256!:'';
 const tax=clean(i.vendorTaxId),numberKey=tax&&series&&reference?[tax,series,reference].join('|'):'';
 const notice=a.verifiedReading?.kind==='invoice_notice',domain=clean(a.verifiedReading?.authenticatedDomain);
 const buyerId=clean(i.buyerTaxId)||fold(clean(i.buyerName));
 const noticeKey=notice&&domain&&source&&series&&reference&&buyerId?
   JSON.stringify([domain,fold(source),series,reference,buyerId]):'';
 const identity=numberKey?'invoice:'+numberKey:proofHash?'file:'+proofHash:noticeKey?'notice:'+noticeKey:'';
 const neutral=/\bcod\b|tien thu ho|tien nap|top.?up|prepayment on account|autopay on account|so du vi|dat coc|bao gia|quotation/.test(fold([mail.subject,text].join(' ')));
 const reasons:string[]=[];
 if(a.readIssue||a.error)reasons.push(String(a.readIssue||a.error));
 if(!a.invoice)reasons.push('Chưa trích xuất được dữ liệu hóa đơn có cấu trúc');
 if(!numberKey||!proofHash)reasons.push('Thiếu định danh hóa đơn, mã số thuế nhà cung cấp hoặc dấu tệp');
 if(!date||!currency||amount===null)reasons.push('Thiếu ngày, loại tiền hoặc tổng hóa đơn');
 if(!group)reasons.push('Chưa xác định duy nhất một đầu chi');
 if(group==='equipment'||group==='software'&&(uniqueMonths.length!==1||/tra truoc|goi nam|nhieu ky|annual|prepaid|[2-9] thang/.test(normalized)))reasons.push('Cần căn cứ thời gian sử dụng hoặc kỳ cung cấp để phân bổ');
 if(group==='cogs')reasons.push('Đối chiếu phiếu nhập hàng, công nợ và giá vốn');
 if(group==='ads'||group==='platform'||group==='shipping')reasons.push('Đối chiếu báo cáo chi tiêu, phí thực tế theo tài khoản hoặc đơn hàng');
 if(i.adjusted!==false||/thay the|dieu chinh|credit note|hoan tien/.test(fold([mail.subject,text].join(' '))))reasons.push('Cần xác định hóa đơn gốc và chênh lệch điều chỉnh');
 if(!channel)reasons.push('Chưa xác định shop hoặc phạm vi chi phí chung');
 const buyerVerified=['lennguyenstore','hokinhdoanhlennguyenstore','hkdlennguyenstore'].includes(payer);
 if(!buyerVerified)reasons.push('Chưa xác minh bên mua');
 if(uniqueMonths.length!==1||months.length!==1||/\b(?:tu ngay|den ngay|tra truoc|nhieu ky|annual|nam)\b/.test(normalized))reasons.push('Chưa xác minh chứng từ thuộc một kỳ duy nhất');
 if(!date||month<'2026-04'||currency!=='VND'||!Number.isSafeInteger(amount)||Number(amount)<=0)reasons.push('Chưa đủ điều kiện về kỳ và số tiền VND');
 if(!labels.length||labels.some(l=>category(l)!==group))reasons.push('Các dòng hàng chưa cùng nhóm');
 if(neutral)reasons.unshift('Có khoản thu hộ, nạp tiền, trả trước hoặc báo giá cần đối chiếu');
 return {buyerVerified,source:source.slice(0,300),reference,date,month,category:group,channel,currency,amount,proofHash,identity,description:text.slice(0,240),reason:reasons.join('. '),neutral};
}
type Parsed=ReturnType<typeof inspectDocument>;
type Match={state:string;reason:string;targetType:string;targetId:string};
async function findMatch(db:D1Database,d:Parsed):Promise<Match|undefined>{
 const pending=(reason:string):Match=>({state:'pending',reason,targetType:'',targetId:''});
 if(d.reference||d.proofHash){
  const finance=await db.prepare(`SELECT id,status,record FROM pm_finance_docs WHERE kind='expense' AND ((?<>'' AND lower(json_extract(record,'$.reference'))=lower(?)) OR (?<>'' AND json_extract(record,'$.documentHash')=?)) LIMIT 10`).bind(d.reference,d.reference,d.proofHash,d.proofHash).all<{id:string;status:string;record:string}>();
  const matches=finance.results.filter(r=>{const f=JSON.parse(r.record);return d.proofHash&&d.proofHash===f.documentHash||d.currency==='VND'&&d.amount===f.amount&&d.date===f.date&&fold(d.source)===fold(String(f.counterparty||''));});
  if(matches.length===1&&finance.results.length===1)return {state:'linked',reason:'Đã có phiếu chi phí · '+matches[0].status,targetType:'expense',targetId:matches[0].id};
  if(finance.results.length)return pending('Trùng mã hoặc dấu tệp với phiếu chi. Cần kiểm tra số tiền, nhà cung cấp và ngày');
 }
 if(d.reference){
  const purchases=await db.prepare("SELECT p.id,p.date,p.total,p.active,s.name FROM pm_purchase_docs p JOIN pm_purchase_suppliers s ON p.supplier=s.id WHERE p.kind='purchase' AND lower(p.number)=lower(?) LIMIT 10").bind(d.reference).all<{id:string;date:string;total:number;active:number;name:string}>();
  const m=purchases.results.filter(p=>p.active&&p.date===d.date&&p.total===d.amount&&d.currency==='VND'&&fold(p.name)===fold(d.source));
  if(m.length===1&&purchases.results.length===1)return {state:'linked',reason:'Đã khớp phiếu nhập hàng và công nợ. Giá vốn theo dữ liệu hàng bán',targetType:'purchase',targetId:m[0].id};
  if(purchases.results.length)return pending('Có phiếu nhập cùng số. Chờ xác minh nhà cung cấp, ngày và giá trị');
 }
 if((d.category==='ads'||/^VNTT\d{6,}$/.test(d.reference))&&d.reference){
  const drive=await db.prepare(`SELECT s.id,json_extract(p.value,'$.channel') channel,json_extract(p.value,'$.total') amount,json_extract(p.value,'$.date') date,json_extract(p.value,'$.fileId') fileId FROM pm_drive_ads_sources s JOIN json_each(s.record,'$.proofs') p WHERE json_extract(p.value,'$.invoice')=? LIMIT 3`).bind(d.reference).all<{id:string;channel:string;amount:number;date:string;fileId:string}>();
  if(drive.results.length){
   const row=drive.results[0];
   if(drive.results.length===1&&d.currency==='VND'&&row.amount===d.amount&&row.date===d.date&&(d.channel===row.channel||/^VNTT\d{6,}$/.test(d.reference)))return {state:'linked',reason:'Khớp số hóa đơn, ngày và tổng chứng từ quảng cáo trên Drive; giữ chi tiêu theo báo cáo thực chạy',targetType:'drive-invoice',targetId:row.fileId};
   return pending('Có cùng số chứng từ trên Drive nhưng chưa khớp tài khoản, ngày hoặc số tiền');
  }
  const exists=await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='ads_import_rows'").first();
  if(exists){
   const row=await db.prepare("SELECT id,record FROM ads_import_rows WHERE id=?").bind('invoice:'+d.reference).first<{id:string;record:string}>();
   if(row&&d.currency==='VND'&&JSON.parse(row.record).amount===d.amount&&JSON.parse(row.record).date===d.date)return {state:'linked',reason:'Khớp chứng từ quảng cáo đã nhập. Chi tiêu lấy từ báo cáo nguồn',targetType:'ad-evidence',targetId:row.id};
  }
 }
}
type Resource=Attachment&{originalField?:string;readIssue?:string;url?:string;label?:string};
export async function saveGmailDocuments(db:D1Database,mail:Mail,manifest:Manifest){
 const resources:Resource[]=[...(manifest.attachments||[]),...(manifest.links||[]).map((l:Resource)=>({...l,name:l.name||l.label||'Liên kết chứng từ',error:l.readIssue||l.error}))];
 if(manifest.notice)resources.push(manifest.notice);
 if(!resources.length)resources.push({name:'Nội dung thư'});
 const rulesApproved=!!await supplierApproval(db);
 const invoice=manifest.notice?.invoice;
 const purchasing=merchandiseSupplier(invoice)&&invoice?await routePurchaseNotice(db,mail.id,invoice):undefined;
 for(let index=0;index<resources.length;index++){
  const a=resources[index];
  const id=mail.id+':'+index;
  const jt=a.verifiedReading&&await reconcileJt(db,a.verifiedReading);
  if(jt&&a.verifiedReading){
   const {trackingLines:_omit,...summary}=a.verifiedReading;
   if(jt.valid && Array.isArray(_omit) && typeof summary.detailHash==='string'){
    const lines=_omit.map(row=>[row.tracking,row.fee,row.cod]);
    await db.prepare('INSERT INTO gmail_jt_lines VALUES(?,?,?) ON CONFLICT(item) DO UPDATE SET hash=excluded.hash,lines=excluded.lines WHERE hash<>excluded.hash').bind(id,summary.detailHash,JSON.stringify(lines)).run();
    await checkStatements(db,id);
   }
   a.verifiedReading={...summary,orderReconciliation:jt};
   if(jt.valid && /\.xlsx$/i.test(a.name||'') && a.readIssue==='XML không phân tích được')delete a.readIssue;
   a.readIssue=[a.readIssue,jt.reason].filter(Boolean).join(' ');
  }
  const quality=(a.sha256?1:0)+(a.invoice?10:0)+(a.verifiedReading?20:0)+(jt?.valid?10:0);
  const facts=JSON.stringify({invoice:a.invoice,reading:a.verifiedReading});
  const previous=await db.prepare('SELECT quality FROM gmail_document_facts WHERE itemId=?').bind(id).first<{quality:number}>();
  if(previous&&previous.quality>quality)continue;
  if(previous && !a.invoice && !a.verifiedReading){
   const manual=await db.prepare("SELECT 1 ok FROM gmail_invoice_lines WHERE item=? AND json_extract(details,'$.provider')='MISA'").bind(id).first();
   if(manual)continue;
  }
  const readIssue=clean(a.readIssue||a.error);
  const existing=await db.prepare("SELECT state,targetId FROM gmail_documents WHERE id=?").bind(id).first<{state:string;targetId:string}>();
  const storeFacts=db.prepare('INSERT INTO gmail_document_facts VALUES(?,?,?) ON CONFLICT(itemId) DO UPDATE SET quality=excluded.quality,facts=excluded.facts WHERE excluded.quality>=gmail_document_facts.quality').bind(id,quality,facts);
  if(purchasing&&invoice&&existing?.state!=='posted'){
   const isNotice=a===manifest.notice;
   const reason=purchasing.original?'Hóa đơn 3 đã được thay thế bằng số 4':(purchasing.replacement?'Hóa đơn 4 thay thế số 3. ':'')+(purchasing.documented?'Đã ghi nhận mua hàng theo hóa đơn':'Chờ bổ sung thông tin hóa đơn');
   const args=[id,mail.id,clean(a.name)||'Tài liệu liên quan',invoice.vendor||'',invoice.number||'',invoice.date||'',(invoice.date||'').slice(0,7),'cogs','','',isNotice&&!purchasing.original?invoiceAmount(invoice.total):null,'evidence',reason,'purchase-notice',purchasing.key,'purchase:'+purchasing.key,a.sha256||''];
   await db.batch([storeFacts,db.prepare("INSERT OR IGNORE INTO gmail_category_history(itemId,oldCategory,newCategory,reason) SELECT id,category,'cogs',? FROM gmail_documents WHERE id=? AND category<>'cogs'").bind('Chủ shop xác nhận hóa đơn Nguyễn Huy Minh là hóa đơn nhập hàng',id),
    db.prepare('INSERT INTO gmail_documents VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET source=excluded.source,reference=excluded.reference,date=excluded.date,month=excluded.month,category=excluded.category,currency=excluded.currency,amount=excluded.amount,state=excluded.state,reason=excluded.reason,targetType=excluded.targetType,targetId=excluded.targetId,identity=excluded.identity WHERE gmail_documents.state<>\'posted\'').bind(...args)]);
   continue;
  }
  if(existing&&['posted','linked'].includes(existing.state)){await storeFacts.run();continue;}
  const d=inspectDocument(mail,a,clean(manifest.bodyText),rulesApproved?supplierRule(clean(a.invoice?.vendor)):undefined);
  const related=d.identity?await db.prepare("SELECT id,state,source,reference,date,currency,amount FROM gmail_documents WHERE identity=? AND id<>? ORDER BY rowid LIMIT 1").bind(d.identity,id).first<any>():null;
  let result:Match|undefined=manifest.quarantine?{state:'pending',reason:'Thư cần kiểm tra vị trí hoặc tính xác thực. '+String(manifest.quarantine).slice(0,180),targetId:'',targetType:''}:await findMatch(db,d);
  if(!result&&a.verifiedReading?.kind==='invoice_notice'&&d.reference){
   const sibling=resources.slice(0,index).map((res,n)=>({res,n})).filter(({res})=>{
    const iv=res.invoice, notice=a.invoice;
    return iv&&notice&&res.sha256&&iv.vendor&&iv.number===notice.number&&iv.series===notice.series&&fold(clean(iv.vendor))===fold(clean(notice.vendor))&&(
     !!iv.vendorTaxId&&iv.vendorTaxId===notice.vendorTaxId||!!iv.buyerTaxId&&iv.buyerTaxId===notice.buyerTaxId);
   });
   if(sibling.length===1){
    const match=inspectDocument(mail,sibling[0].res,'');
    if((!d.date||!match.date||d.date===match.date)&&(d.amount===null||match.amount===null||d.amount===match.amount&&d.currency===match.currency)){
     result={state:'linked',reason:'Thông báo phát hành khớp số, ký hiệu và bên liên quan với bản gốc trong cùng thư',targetType:'gmail',targetId:mail.id+':'+sibling[0].n};
     d.identity=match.identity;
    }else result={state:'pending',reason:'Thông báo và bản gốc cùng hóa đơn nhưng ngày hoặc tổng tiền khác nhau',targetType:'gmail',targetId:mail.id+':'+sibling[0].n};
   }
  }
  if(related&&!result){
   if(related.date!==d.date||related.amount!==d.amount||related.currency!==d.currency){
    result={state:'pending',reason:'Cùng định danh nhưng thông tin khác nhau. Cần rà soát bản điều chỉnh',targetType:'gmail',targetId:related.id};
   }else result={state:'linked',reason:'Bản chứng từ đã có từ thư khác',targetType:'gmail',targetId:related.id};
  }
  const statements:D1PreparedStatement[]=[storeFacts];
  if(!result && !a.invoice && !a.verifiedReading && /^icon\.png$/i.test(a.name||'') &&
    /^(?:re:\s*)*delivery status notification \(failure\)$/i.test(mail.subject.trim())){
   result={state:'evidence',reason:'Biểu tượng thông báo gửi thư thất bại. Không phát sinh chi phí.',targetType:'',targetId:''};
  }
  if(!result&&!d.reason){
   // A pre-existing manual row may lack a reference. Hold a matching total for review.
   const near=await db.prepare("SELECT id FROM pm_finance_docs WHERE kind='expense' AND json_extract(record,'$.amount')=? AND (date=? OR channel=? AND substr(date,1,7)=?) LIMIT 1").bind(d.amount,d.date,d.channel,d.month).first();
   if(near)result={state:'pending',reason:'Có khoản cùng giá trị trong kỳ. Kiểm tra chứng từ nhập tay trước khi ghi',targetType:'',targetId:''};
   else{
    const financeId='gmail-'+await digest(d.identity),now=new Date().toISOString(),date=d.date.slice(0,7)===d.month?d.date:d.month+'-01';
    const finance={...validateFinance('expense',{date,channel:d.channel,category:d.category,amount:d.amount,description:d.description,reference:d.reference,counterparty:d.source,receipt:{key:'gmail-evidence/'+mail.digest,name:'Chứng từ Gmail.eml',mime:'message/rfc822'}}),id:financeId,version:0,status:'confirmed',actor,confirmedAt:now,createdAt:now,updatedAt:now,gmailEvidence:mail.id,documentHash:d.proofHash};
    const fingerprint=await digest('expense:'+d.source.toLowerCase()+':'+d.reference.toLowerCase());
    statements.push(db.prepare('INSERT INTO pm_finance_requests SELECT ?,COUNT(*) FROM pm_finance_requests').bind(financeId),
     db.prepare('INSERT INTO pm_finance_docs VALUES(?,?,?,?,?,?,?,?,?)').bind(financeId,'expense',date,date,d.channel,'confirmed',JSON.stringify(finance),0,fingerprint),
     putSetting(db,'expense-changed:'+date,now),db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(financeId,now,actor,'gmail:expense',JSON.stringify({id:financeId,after:finance})));
    result={state:'posted',reason:'Đã ghi nhận theo hóa đơn và kỳ dịch vụ; chờ rà soát thuế',targetType:'expense',targetId:financeId};
   }
  }
  if(!result&&readIssue&&/lỗi|không hợp lệ|không phân tích được|HTTP [45]|thiếu nội dung/i.test(readIssue))result={state:'error',reason:readIssue,targetType:'',targetId:''};
  if(!result&&d.neutral&&d.buyerVerified&&d.category==='ads'&&/prepayment on account|top.?up|n[aạ]p ti[eề]n/i.test([mail.subject,d.description].join(' ')))result={state:'evidence',reason:'Tiền nạp tài khoản quảng cáo. Lưu để đối chiếu với báo cáo chi tiêu thực tế',targetType:'',targetId:''};
  result??={state:'pending',reason:d.reason||'Cần rà soát chứng từ',targetType:'',targetId:''};
  const args=[id,mail.id,clean(a.name).slice(0,240)||'Chứng từ',d.source,d.reference,d.date,d.month,d.category,d.channel,d.currency,d.amount,result.state,result.reason,result.targetType,result.targetId,d.identity,d.proofHash];
  statements.push(db.prepare(`INSERT INTO gmail_documents VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
   document=excluded.document,source=excluded.source,reference=excluded.reference,date=excluded.date,month=excluded.month,category=excluded.category,channel=excluded.channel,currency=excluded.currency,amount=excluded.amount,state=excluded.state,reason=excluded.reason,targetType=excluded.targetType,targetId=excluded.targetId,identity=excluded.identity,proofHash=excluded.proofHash WHERE gmail_documents.state NOT IN ('posted','linked')`).bind(...args));
  await db.batch(statements);
 }
}
const sourceRows=`SELECT g.*,e.received,e.subject FROM gmail_documents g JOIN gmail_evidence e ON e.id=g.mailId UNION ALL SELECT e.id||':legacy',e.id,'Thư gốc',e.sender,'','','','','','',NULL,'pending','Bản gốc đã lưu. Chờ đọc lại để phân loại','','','','',e.received,e.subject FROM gmail_evidence e WHERE NOT EXISTS(SELECT 1 FROM gmail_documents g WHERE g.mailId=e.id)`;
export async function reportGmailDocuments(db:D1Database,params:URLSearchParams){
 const where:string[]=[],args:string[]=[];
 for(const k of ['month','state'] as const){const value=params.get(k);if(value){where.push(k+'=?');args.push(value);}}
 if(params.get('source')){where.push('instr(lower(source),lower(?))>0');args.push(params.get('source')!);}
 if(params.get('query')){where.push("instr(lower(subject||' '||document||' '||source||' '||reference||' '||reason),lower(?))>0");args.push(params.get('query')!);}
 const filtered='SELECT * FROM ('+sourceRows+')'+(where.length?' WHERE '+where.join(' AND '):'');
 const offset=Math.max(0,Number.parseInt(params.get('offset')||'0')||0);
 const dimension=params.get('groupBy')==='category'?'category':'source';
 const [rows,monthly,count,activity]=await Promise.all([
  db.prepare('SELECT *,(SELECT details FROM gmail_invoice_lines WHERE item=t.id) invoiceLines,(SELECT summary FROM gmail_jt_checks WHERE item=t.id) jtCheck,(SELECT facts FROM gmail_document_facts f WHERE f.itemId=t.id) facts,EXISTS(SELECT 1 FROM gmail_link_files l WHERE l.itemId=t.id) hasLinkFile FROM ('+filtered+') t ORDER BY received DESC,id LIMIT 50 OFFSET ?').bind(...args,offset).all(),
  db.prepare(`WITH selected AS (${filtered}), items AS (SELECT *,ROW_NUMBER() OVER(PARTITION BY CASE WHEN identity='' THEN id ELSE identity END ORDER BY CASE state WHEN 'posted' THEN 0 WHEN 'linked' THEN 2 ELSE 1 END,amount IS NULL,id) rn FROM selected)
   SELECT month,${dimension} source,currency,count(*) documents, sum(CASE WHEN rn=1 THEN amount END) amount,count(CASE WHEN rn=1 THEN amount END) knownAmounts,
    sum(COALESCE((SELECT json_extract(summary,'$.bookedAmount') FROM gmail_jt_checks c WHERE c.item=items.id),0)) waybillExpense, sum(state='posted') posted,sum(CASE WHEN state='posted' THEN COALESCE((SELECT json_extract(f.record,'$.amount') FROM pm_finance_docs f WHERE f.id=items.targetId AND f.status='confirmed'),0) END) postedAmount,sum(state='linked' AND targetType<>'gmail') linked,sum(state='linked' AND targetType='gmail') duplicates,sum(state='pending') pending,sum(state='evidence') evidence,sum(state='error') errors
    FROM items GROUP BY month,${dimension},currency ORDER BY month DESC,${dimension},currency`).bind(...args).all(),
  db.prepare('SELECT count(*) n FROM ('+filtered+')').bind(...args).first<{n:number}>(),db.prepare('SELECT * FROM gmail_activity').all()]);
 return {rows:rows.results,monthly:monthly.results,total:count?.n||0,activity:activity.results};
}
