// Page actual stock lines, retaining their original receipt indexes for safe edits.
export async function readStockLinePage(db:any,where:string[],args:(string|number)[],query:string,page:number,pageSize:number){
 const clauses=where.map(s=>s.replaceAll('pm_stock_receipts.record','r.record').replace(/\bdate\b/g,'r.date').replace(/\bsource\b/g,'r.source').replace(/(?<![.\w])record\b/g,'r.record'));
 const params=[...args];
 if(query){clauses.push("(instr(lower(json_extract(l.value,'$.existingCode')),lower(?))>0 OR instr(lower(json_extract(l.value,'$.newCode')),lower(?))>0)");params.push(query,query);}
 const from=" FROM pm_stock_receipts r JOIN json_each(r.record,'$.lines') l"+(clauses.length?' WHERE '+clauses.join(' AND '):'');
 const totals=await db.prepare("SELECT COUNT(*) AS lines,COUNT(DISTINCT r.id) AS n,COUNT(DISTINCT upper(trim(COALESCE(NULLIF(json_extract(l.value,'$.existingCode'),''),json_extract(l.value,'$.newCode'))))) AS codes,COALESCE(SUM(CASE WHEN r.active=1 THEN json_extract(l.value,'$.quantity') ELSE 0 END),0) AS quantity"+from).bind(...params).first();
 const totalLines=Number(totals?.lines||0),totalPages=Math.ceil(totalLines/pageSize),current=Math.min(page,Math.max(1,totalPages));
 const result=await db.prepare('SELECT r.id,r.record,r.version,r.purchase_id,r.actor_email,CAST(l.key AS INTEGER) AS line_index'+from+' ORDER BY r.date DESC,COALESCE(json_extract(l.value,\'$.checked\'),0) ASC,COALESCE((SELECT s.name FROM pm_purchase_suppliers s WHERE s.id=json_extract(r.record,\'$.supplierId\')),r.source),r.id DESC,CAST(l.key AS INTEGER) ASC LIMIT ? OFFSET ?').bind(...params,pageSize,(current-1)*pageSize).all();
 const grouped=new Map<string,any>();for(const r of result.results){if(!grouped.has(r.id))grouped.set(r.id,{...r,visibleLineIndexes:[]});grouped.get(r.id).visibleLineIndexes.push(r.line_index);}
 return {rows:{results:[...grouped.values()]},totals,page:current,totalLines,totalPages,pageSize,start:totalLines?(current-1)*pageSize+1:0,end:Math.min(current*pageSize,totalLines)};
}
