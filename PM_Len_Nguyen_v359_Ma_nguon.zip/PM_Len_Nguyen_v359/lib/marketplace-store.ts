import {readReturnBaseline,allowPosReturn} from './return-baseline';
import {prepareOrders,posGet} from './orders-store.ts';
import {normalizeMarketplace,marketplaceAccounts,marketplaceNote,recentOrderStart} from './marketplace-orders.ts';
import {digest} from './a3-access.ts';
import {archiveMatchedReturns,archiveFingerprints} from './return-retention.ts';
import {trackingCode} from './orders.ts';

export async function syncFacebookExpected(db:D1Database){
 await prepareOrders(db);const baseline=await readReturnBaseline(db);const archived=await archiveFingerprints(db),now=new Date().toISOString(),statements:D1PreparedStatement[]=[];
 const rows=await db.prepare("SELECT record FROM pm_orders WHERE channel='facebook' AND date>=? AND status IN (4,5,15) AND tracking!=''").bind(recentOrderStart()).all<{record:string}>();
 for(const row of rows.results){const r=JSON.parse(row.record),tracking=trackingCode(r.tracking);if(r.status===15&&!tracking.endsWith('-001'))continue;if(archived.has(await digest(tracking)))continue;if(!await allowPosReturn(db,tracking,r.updated,baseline))continue;
  const value={tracking,group:'delivery',kind:tracking.endsWith('-001')?'partial':'failed',channel:'facebook',date:r.date,dateUnknown:false,importedAt:now,source:'Pancake POS · Trạng thái hoàn Facebook',sourceOrderId:r.id,rule:'Đơn Facebook đang/đã hoàn; không tự xác nhận đã nhận hàng về kho'};
  statements.push(db.prepare('INSERT OR IGNORE INTO pm_return_expected SELECT ?,?,?,?,1,? WHERE NOT EXISTS(SELECT 1 FROM pm_return_expected WHERE tracking=? AND active=1)').bind(await digest('return-expected:delivery:'+tracking),'delivery',tracking,r.date,JSON.stringify(value),tracking));
 }
 let added=0;for(let i=0;i<statements.length;i+=60){const results=await db.batch(statements.slice(i,i+60));added+=results.reduce((sum,r)=>sum+(r.meta.changes||0),0);}
 return {added,scopeStart:recentOrderStart()};
}

export async function marketplaceStatus(db:D1Database){
 await prepareOrders(db);
 const record=await db.prepare("SELECT record FROM pm_order_sync WHERE id='marketplaces'").first<{record:string}>();
 const state=record?JSON.parse(record.record):{phase:'backfill',page:1,processed:0,complete:false,started:new Date().toISOString(),scopeStart:recentOrderStart(),scopeDays:30};
 const stored=await db.prepare("SELECT channel,COUNT(*) AS orders,SUM(CASE WHEN tracking!='' THEN 1 ELSE 0 END) AS tracking,SUM(CASE WHEN json_extract(record,'$.returnNeedsReview')=1 THEN 1 ELSE 0 END) AS returnNeedsReview,MIN(date) AS earliest,MAX(date) AS latest FROM pm_orders WHERE channel IN ('tiktok1','tiktok2','shopee') GROUP BY channel").all();
 return {...state,accounts:marketplaceAccounts,stored:stored.results,note:marketplaceNote};
}
export async function storeMarketplaceRows(db:D1Database,rows:NonNullable<ReturnType<typeof normalizeMarketplace>>[]){
 const statements:D1PreparedStatement[]=[],now=new Date().toISOString(),archived=await archiveFingerprints(db),baseline=await readReturnBaseline(db);
 for(const r of rows){
  statements.push(db.prepare('INSERT INTO pm_orders VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET channel=excluded.channel,number=excluded.number,date=excluded.date,updated=excluded.updated,status=excluded.status,staff=excluded.staff,tracking=excluded.tracking,quantity=excluded.quantity,record=excluded.record WHERE excluded.updated>=pm_orders.updated AND excluded.record<>pm_orders.record').bind(r.id,r.channel,r.sourceId,r.number,r.date,r.updated,r.status,r.staff,r.tracking,r.quantity,JSON.stringify(r)));
  if(r.expectedGroup&&!archived.has(await digest(r.tracking))){
   if(!await allowPosReturn(db,r.tracking,r.updated,baseline))continue;
   const id=await digest('return-expected:'+r.expectedGroup+':'+r.tracking),value={tracking:r.tracking,group:r.expectedGroup,kind:'failed',channel:r.channel,date:r.date,dateUnknown:false,source:'Pancake POS · Hành trình chuyển hoàn',sourceOrderId:r.id,sourceUpdated:r.updated,importedAt:now,rule:'Có hành trình hoàn; chưa có hành trình giao thành công cho khách'};
   statements.push(db.prepare('INSERT OR IGNORE INTO pm_return_expected SELECT ?,?,?,?,1,? WHERE EXISTS(SELECT 1 FROM pm_orders WHERE id=? AND updated=?) AND NOT EXISTS(SELECT 1 FROM pm_return_expected WHERE tracking=? AND active=1)').bind(id,r.expectedGroup,r.tracking,r.date,JSON.stringify(value),r.id,r.updated,r.tracking));
  }else{
   statements.push(db.prepare("UPDATE pm_return_expected SET active=0 WHERE active=1 AND json_extract(record,'$.sourceOrderId')=? AND json_extract(record,'$.source')='Pancake POS · Hành trình chuyển hoàn' AND EXISTS(SELECT 1 FROM pm_orders WHERE id=? AND updated=?)").bind(r.id,r.id,r.updated));
  }
 }
 // One order and its expected parcel stay in the same batch, retrying safely after errors.
 for(let i=0;i<statements.length;i+=60)await db.batch(statements.slice(i,i+60));
}
export async function syncMarketplaces(db:D1Database,env:{PANCAKE_API_KEY?:string,PANCAKE_SHOP_ID?:string},pages=2){
 await prepareOrders(db);if(!env.PANCAKE_API_KEY||!env.PANCAKE_SHOP_ID)throw Error('Chưa có kết nối POS');
 const now=Date.now(),lease=now+240000,lock=await db.prepare("INSERT INTO pm_order_sync_lock VALUES('marketplaces',?) ON CONFLICT(id) DO UPDATE SET expires=excluded.expires WHERE expires<?").bind(lease,now).run();
 if(!lock.meta.changes)return {busy:true,...await marketplaceStatus(db)};
 let state:any=await marketplaceStatus(db);
 try{
  if(state.complete){state={...state,phase:'delta',page:1,windowStart:state.watermark||state.started,windowEnd:new Date().toISOString(),complete:false};}
  const source=await posGet(env.PANCAKE_API_KEY,env.PANCAKE_SHOP_ID,'order_source');
  for(const a of marketplaceAccounts){if(!source.data.some((s:any)=>String(s.id)===a.account&&String(s.parent_id)===a.source&&String(s.custom_id)===a.shopId))throw Error('Định danh shop POS thay đổi: '+a.name);}
  const fixedEnd=state.phase==='backfill'?state.started:state.windowEnd;
  const scopeStart=state.phase==='backfill'?state.scopeStart:recentOrderStart();
  const query:Record<string,string>={page_size:'500',include_removed:'1','order_sources[]':JSON.stringify(marketplaceAccounts.map(a=>[a.source,a.account])),option_sort:state.phase==='backfill'?'inserted_at_asc':'last_updated_order_asc',updateStatus:state.phase==='backfill'?'inserted_at':'updated_at',startDateTime:String(state.phase==='backfill'?Date.parse(scopeStart+'T00:00:00+07:00')/1000:Math.max(0,Math.floor(Date.parse(state.windowStart)/1000)-300)),endDateTime:String(Math.floor(Date.parse(fixedEnd)/1000))};
  const first=state.page||1;
  const count=Math.max(1,Math.min(2,pages,state.totalPages?state.totalPages-first+1:1));
  const responses=await Promise.all(Array.from({length:count},(_,i)=>posGet(env.PANCAKE_API_KEY!,env.PANCAKE_SHOP_ID!,'orders',{...query,page_number:String(first+i)})));
  for(let i=0;i<responses.length;i++){
   const response=responses[i],page=first+i,total=Number(response.total_entries)||0,size=Number(response.page_size)||500,totalPages=Number(response.total_pages)||Math.ceil(total/size);
   const rows=response.data.map((o:any)=>normalizeMarketplace(o,env.PANCAKE_SHOP_ID!));
   if(rows.some((r:any)=>!r))throw Error('POS trả đơn ngoài shop đã xác minh; dừng để kiểm tra');
   const recentRows=rows.filter((r:any)=>r.date>=scopeStart);
   await storeMarketplaceRows(db,recentRows);
   const complete=page>=totalPages||response.data.length===0;
   const {stored,accounts,note,...cursor}=state;
   state={...cursor,page:complete?1:page+1,total,totalPages,backfillTotal:state.phase==='backfill'?total:state.backfillTotal,processed:(state.processed||0)+recentRows.length,scopeStart,scopeDays:30,complete,lastSuccess:new Date().toISOString(),error:null,...(complete?{watermark:fixedEnd}: {})};
   await db.prepare('INSERT INTO pm_order_sync VALUES(?,?) ON CONFLICT(id) DO UPDATE SET record=excluded.record').bind('marketplaces',JSON.stringify(state)).run();
   if(complete)break;
  }
  const cleanup=await archiveMatchedReturns(db);
  return {...await marketplaceStatus(db),cleanup};
 }catch(e){const message=e instanceof Error?e.message:'Chưa đồng bộ được đơn sàn';const {stored,accounts,note,...cursor}=state;await db.prepare('INSERT INTO pm_order_sync VALUES(?,?) ON CONFLICT(id) DO UPDATE SET record=excluded.record').bind('marketplaces',JSON.stringify({...cursor,error:message})).run();throw Error(message);}
 finally{await db.prepare("DELETE FROM pm_order_sync_lock WHERE id='marketplaces' AND expires=?").bind(lease).run();}
}
