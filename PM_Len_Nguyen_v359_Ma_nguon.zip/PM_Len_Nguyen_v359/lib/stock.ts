import {validDate,text} from './purchasing.ts';
export type StockLine={checkNote?:string,noteOverride?:boolean,checked?:boolean,checkedAt?:string,checkedBy?:string,existingCode:string,newCode:string,color:string,quantity:number,note:string};
export type StockReceipt={id:string,date:string,time:string,source:string,supplierId?:string,supplierPending?:boolean,supplierHint?:string,lines:StockLine[],note:string,actor:string,createdAt:string,updatedAt:string,voidReason?:string};
export const stockRoles=['owner','admin','manager','employee','terminal'];
export const privateStockRole=(role:string)=>['owner','admin'].includes(role);
export function resolveStockCode(record:StockReceipt,index:number,rawCode:unknown){
  const code=text(rawCode,80).toUpperCase();
  if(!/^[A-Z0-9][A-Z0-9._+-]{0,29}$/.test(code))throw Error('Mã hàng gồm 1–30 ký tự: chữ, số, dấu chấm, gạch, cộng hoặc gạch dưới');
  if(!Number.isInteger(index)||index<0||index>=record.lines.length)throw Error('Dòng hàng không hợp lệ');
  const line=record.lines[index];
  if(line.existingCode||!line.newCode)throw Error('Chỉ bổ sung mã cho mẫu chưa có mã chính thức');
  return {...record,lines:record.lines.map((l,i)=>i===index?{...l,existingCode:code,checked:false,checkedAt:undefined,checkedBy:undefined}:l)};
}
export function safeStock(record:StockReceipt,version:number,locked:boolean){return {id:record.id,date:record.date,time:record.time,source:record.source,supplierId:record.supplierId,supplierPending:Boolean(record.supplierPending),supplierHint:record.supplierHint||'',lines:record.lines.map(l=>({existingCode:l.existingCode,newCode:l.newCode,color:l.color,quantity:l.quantity,note:l.note,noteOverride:l.noteOverride,checkNote:l.checkNote,checked:Boolean(l.checked)})),note:record.note,actor:record.actor,createdAt:record.createdAt,updatedAt:record.updatedAt,voidReason:record.voidReason,version,locked};}
export function parseStockDate(value:unknown){const s=String(value||'').trim();if(/^20\d{2}-\d{2}-\d{2}$/.test(s))return validDate(s);const m=s.match(/^(\d{1,2})\s*[-/.]\s*(\d{1,2})\s*[-/.]\s*(\d{2}|20\d{2})$/);if(!m)throw Error('Ngày phải có dạng ngày/tháng/năm');return validDate((m[3].length===2?'20':'')+m[3]+'-'+m[2].padStart(2,'0')+'-'+m[1].padStart(2,'0'));}
export function validateStock(x:any,codes:string[]){const date=parseStockDate(x.date),source=text(x.source,100);if(!source)throw Error('Chọn nguồn hàng');if(!Array.isArray(x.lines)||x.lines.length<1||x.lines.length>100)throw Error('Mỗi lần nhập từ 1 đến 100 dòng');const lines:StockLine[]=x.lines.map((l:any)=>{const existingCode=text(l.existingCode,80).toUpperCase(),newCode=text(l.newCode,120),color=text(l.color,80),note=text(l.note,500);if(!existingCode&&!newCode)throw Error('Chọn mã đã có hoặc điền mã hàng mới');if(existingCode&&!codes.includes(existingCode))throw Error('Mã đã có không nằm trong danh mục: '+existingCode);if(!color)throw Error('Nhập màu hàng');if(!Number.isSafeInteger(l.quantity)||l.quantity<1||l.quantity>1000000)throw Error('Số lượng phải là số nguyên lớn hơn 0');return {existingCode,newCode,color,quantity:l.quantity,note};});return {date,source,lines,note:text(x.note)};}
