import {administrativeNotice} from './gmail-review';
import {readAgencyFees} from './ads-costs';
import {digest} from './a3-access';
import {putSetting} from './expense-controls';
import {validateFinance} from './finance';

type Bill={provider?:string;lines:string[];number:string;vendor:string;buyer:string;day:string;series:string;total:number};
export function classifyBill(b:Bill){
 const s=b.lines.join(' '),explicit=s.match(/(?:tháng\s*|PPS\s+)(0?[1-9]|1[0-2])\/(20\d{2})/i);
 const month=explicit?explicit[2]+'-'+explicit[1].padStart(2,'0'):'';
 if(b.lines.length===1 && /DỊCH VỤ SỬA CHỮA MÁY/i.test(s))return {category:'equipment',channel:'shared',month:b.day.slice(0,7),note:'Dịch vụ sửa chữa thiết bị của hộ kinh doanh',repair:true};
 if(b.vendor==='SHOPEE'&&month&&/quanjeanlennguyen/i.test(s)&&/AMS|PPS/i.test(s))return {category:'platform',channel:'shopee',month,note:'Phí tiếp thị liên kết của quanjeanlennguyen. Chờ ghép khoản AMS/PPS đã khấu trừ trong quyết toán đúng kỳ.'};
 if(/THUẬN PHONG/.test(b.vendor)&&month&&/chuyển phát nhanh/i.test(s))return {category:'shipping',channel:'',month,note:'Hóa đơn cước tháng '+month+' · '+(s.match(/bảng kê số\s+([A-Z0-9-]+)/i)?.[1]||'')+'. Chờ ghép bảng kê tháng với các vận đơn đã đối soát.'};
 if(b.vendor==='HỘ KINH DOANH HOÀNG NGỌC LỢI'&&/phí dịch vụ quảng cáo/i.test(s))return {category:'ads',channel:'facebook',month:'',note:'Đã xác nhận phí dịch vụ quảng cáo. Chờ đối chiếu phiếu phí đại lý với khoản quảng cáo trong PM.'};
 if(/phần mềm|chữ ký số/i.test(s)){
  const scope={category:'software',channel:'shared',month:''};
  if(/DHN60/i.test(s)){
   const qty=s.match(/Tháng\s*(\d+)\s*[x×]\s*150[.,]000/i)?.[1] || s.match(/DHN60Tháng(\d+)150,000/i)?.[1];
   if(qty && Number(qty)*150000===b.total)return {...scope,note:'DHN60 · '+qty+' tháng × 150.000đ. Chờ ngày bắt đầu dịch vụ để phân bổ.'};
  }
  const duration=s.match(/thời hạn sử dụng (\d+) tháng/i)?.[1];
  if(duration)return {...scope,note:'Gói Pancake '+duration+' tháng. Chờ ngày kích hoạt để phân bổ.'};
  if(/chữ ký số.*01 năm/i.test(s))return {...scope,note:'Chữ ký số HSM 12 tháng. Chờ ngày hiệu lực chứng thư để phân bổ.'};
  if(/Hoá đơn5,000100/i.test(s)&&b.total===500000)return {...scope,note:'Gói 5.000 hóa đơn × 100đ. Chờ số lượng phát hành thực tế theo gói.'};
 }
 if(/phần mềm|chữ ký số/i.test(s))return {category:'software',channel:'',month:'',note:'Dịch vụ phần mềm trả trước. Cần kỳ kích hoạt hoặc mức sử dụng để phân bổ.'};
 return null;
}
// Historical DHN60 invoices approved by the owner for invoice-date allocation.
const approvedDhn = new Map([
 ['19d6ffb68605e335', {number:'723', day:'2026-04-09', months:1}],
 ['19eabbe47edad41b', {number:'1224', day:'2026-06-09', months:1}],
 ['19f4ae547a993e48', {number:'1534', day:'2026-07-10', months:3}]
]);

const pancakePlans:Record<string,[string,number,number,string]>={
 '1904':['2026-05-27',890000,12,'Chữ ký số HSM'],
 '37474':['2026-09-09',1750000,6,'Pancake POS'],
 '11800':['2026-06-30',100000,1,'Gói 1.000 lượt hóa đơn'],
 '25244':['2026-08-07',500000,1,'Gói 5.000 lượt hóa đơn'],
 '28771':['2026-08-18',500000,1,'Gói 5.000 lượt hóa đơn'],
 '45714':['2026-10-01',500000,1,'Gói 5.000 lượt hóa đơn'],
 '50622':['2026-10-12',500000,1,'Gói 5.000 lượt hóa đơn'],
 '61391':['2026-11-08',500000,1,'Gói 5.000 lượt hóa đơn']
};
const affiliateSettlements:Record<string,{month:string;amount:number;orders:number;workbook:string;digest:string}>={
 "2026-06": {
  "month": "2026-06",
  "amount": 1513301,
  "orders": 79,
  "workbook": "Income.đã phát hành.vn.20260401_20260630.xlsx",
  "digest": "0eb268162c68ee68a9c9ceecffa08db5d291856822527a114596f35d3a820353"
 },
 "2026-05": {
  "month": "2026-05",
  "amount": 1703645,
  "orders": 82,
  "workbook": "Income.đã phát hành.vn.20260401_20260630.xlsx",
  "digest": "0eb268162c68ee68a9c9ceecffa08db5d291856822527a114596f35d3a820353"
 },
 "2026-04": {
  "month": "2026-04",
  "amount": 1677331,
  "orders": 89,
  "workbook": "Income.đã phát hành.vn.20260401_20260630.xlsx",
  "digest": "0eb268162c68ee68a9c9ceecffa08db5d291856822527a114596f35d3a820353"
 },
 "2026-07": {
  "month": "2026-07",
  "amount": 1852259,
  "orders": 99,
  "workbook": "Income.đã phát hành.vn.20260701_20260731.zip",
  "digest": "0dd798e72a678d7314e453c1c2443eeebdbf56b246c5e0186e247f57fae45ac9"
 },
 "2026-08": {
  "month": "2026-08",
  "amount": 1826461,
  "orders": 92,
  "workbook": "Income.đã phát hành.vn.20260801_20260831.zip",
  "digest": "929b16cbae24b8d4fc98159e3c19a7ef02af83dc077489ad137091e48b6b1264"
 },
 "2026-09": {
  "month": "2026-09",
  "amount": 2178201,
  "orders": 99,
  "workbook": "Income.đã phát hành.vn.20260901_20260930.zip",
  "digest": "fb2e0afa8b4b057ce81650cb56c64a74ab0f833d1008e2c916ef3788eb3c5c88"
 }
};
async function postApprovedSoftware(db:D1Database, actor:string, doc:any, bill:Bill){
 const original=approvedDhn.get(doc.mailId);
 const number=String(Number(bill.number));
 const pancake=bill.vendor==='CÔNG TY TNHH PANCAKE VIỆT NAM'?pancakePlans[number]:null;
 const plan=pancake?{number,day:pancake[0],months:pancake[2]}:original;
 if(!plan || bill.day!==plan.day || number!==plan.number)return false;
 const label=pancake?pancake[3]:'DHN60';
 if(pancake?bill.total!==pancake[1]:bill.vendor!=='CÔNG TY TNHH ĐÓNG HÀNG NHANH' ||
    bill.total!==plan.months*150000 || !bill.lines.some(line=>line.includes('DHN60')))return false;
 const ref=bill.series+' / '+bill.number;
 const overlap=await db.prepare(`SELECT id FROM pm_finance_docs WHERE kind='expense' AND status<>'void' AND
   (json_extract(record,'$.gmailEvidence')=? OR (lower(json_extract(record,'$.counterparty'))=lower(?) AND
   (json_extract(record,'$.reference') IN (?,?) OR (date=? AND json_extract(record,'$.amount') IN (?,?))))) LIMIT 1`)
   .bind(doc.mailId,bill.vendor,ref,bill.number,plan.day,bill.total,Math.round(bill.total/plan.months)).first();
 if(overlap)return false;
 const now=new Date().toISOString(), statements:D1PreparedStatement[]=[], ids:string[]=[];
 for(let i=0;i<plan.months;i++){
  const day=new Date(plan.day+'T00:00:00Z');
  day.setUTCMonth(day.getUTCMonth()+i);
  const date=day.toISOString().slice(0,10);
  const reference=plan.months===1?ref:ref+' · '+(i+1)+'/'+plan.months;
  const key=await digest('expense:'+bill.vendor.toLowerCase()+':'+reference.toLowerCase());
  const id='gmail-'+key;
  ids.push(id);
  const value={...validateFinance('expense',{date,reference,channel:'shared',category:'software',amount:Math.round(bill.total*(i+1)/plan.months)-Math.round(bill.total*i/plan.months),
    counterparty:bill.vendor,description:label+' · kỳ '+(i+1)+'/'+plan.months,
    note:'Chủ shop duyệt phân bổ từ ngày lập hóa đơn '+plan.day,
    receipt:{key:'gmail-evidence/'+doc.digest,name:'Hóa đơn '+bill.number+'.eml',mime:'message/rfc822'}}),
    id,status:'confirmed',actor,version:0,createdAt:now,updatedAt:now,confirmedAt:now,gmailEvidence:doc.mailId,fintabEvidence:bill};
  statements.push(db.prepare('INSERT INTO pm_finance_requests SELECT ?,count(*) FROM pm_finance_requests').bind(id),
   db.prepare('INSERT INTO pm_finance_docs VALUES(?,?,?,?,?,?,?,?,?)').bind(id,'expense',date,date,'shared','confirmed',JSON.stringify(value),0,key),
   db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(id,now,actor,'gmail:invoice-date-allocation',JSON.stringify({after:value})),
   putSetting(db,'expense-changed:'+date,now));
 }
 statements.push(db.prepare("UPDATE gmail_documents SET state='posted',category='software',channel='shared',month=?,targetType='expense',targetId=?,reason=? WHERE id=? AND state='pending'")
  .bind(plan.day.slice(0,7),ids[0],label+' · Đã ghi '+bill.total.toLocaleString('vi-VN')+'đ trong '+plan.months+' kỳ từ ngày lập '+plan.day+' theo duyệt của chủ shop.',doc.id));
 await db.batch(statements);
 return true;
}
export async function applyInvoiceDetails(db:D1Database,actor:string,config:Parameters<typeof readAgencyFees>[1]){
 const docs=await db.prepare(`SELECT d.*,i.details,e.digest FROM gmail_invoice_lines i JOIN gmail_documents d ON d.id=i.item
 JOIN gmail_evidence e ON e.id=d.mailId WHERE d.state='pending' AND d.targetType<>'flagteam-pdf'`).all<any>();
 const months=Array.from(new Set<string>(docs.results.filter(d=>d.source.includes('NGỌC LỢI')).map(d=>d.date.slice(0,7))));
 await db.prepare('CREATE TABLE IF NOT EXISTS gmail_flagteam_links(day TEXT PRIMARY KEY,item TEXT NOT NULL UNIQUE,invoice TEXT NOT NULL UNIQUE,amount INTEGER NOT NULL,actor TEXT NOT NULL)').run();
 const agency=await readAgencyFees(db,config,months);
 let classified=0,posted=0;
 for(const d of docs.results){
  const bill:Bill=JSON.parse(d.details);
  if(bill.buyer!=='087089000961'||bill.total!==d.amount||bill.day!==d.date||d.currency!=='VND'||String(d.reference).replace(/^0+/,'')!==String(bill.number).replace(/^0+/,''))continue;
  const c=classifyBill(bill);
  if(!c||(c.month&&d.month&&c.month!==d.month)||(c.channel&&d.channel&&c.channel!==d.channel))continue;
  const settlement=c.channel==='shopee' && c.category==='platform'?affiliateSettlements[c.month]:null;
  if(settlement && settlement.amount===bill.total && bill.vendor==='SHOPEE'){
   const reason='Đối chiếu '+settlement.orders+' đơn có hoa hồng trong '+settlement.workbook+
    '. Phí sàn đã khấu trừ '+bill.total.toLocaleString('vi-VN')+'đ, kỳ '+c.month+'. Ngày lập '+bill.day+'.';
   await db.prepare("UPDATE gmail_documents SET state='linked',category='platform',channel='shopee',month=?,targetType='shopee-settlement',targetId=?,reason=? WHERE id=? AND state='pending'")
    .bind(c.month,settlement.digest+':'+c.month,reason,d.id).run();
   classified++;continue;
  }
  if(c.category==='software' && await postApprovedSoftware(db,actor,d,bill)){posted++;classified++;continue;}
  let summary=(bill.provider||'Fintab')+' · '+bill.series+' / '+bill.number+'. '+c.note;
  if(c.category==='ads'){
   const fees=agency.get(bill.day)||[];
   const previousDay=new Date(Date.parse(bill.day+'T00:00:00Z')-86400000).toISOString().slice(0,10);
   summary=(bill.provider||'Fintab')+' · '+bill.series+' / '+bill.number+'. Chủ shop xác nhận Hoàng Ngọc Lợi xuất hóa đơn phí dịch vụ Flagteam. ';
   const candidates=[previousDay,bill.day].filter(day=>(agency.get(day)||[]).some(f=>f.provider==='flagteam'&&f.fee===bill.total&&bill.total>0));
   if(candidates.length===1){
    const day=candidates[0],invoice=bill.series+'/'+bill.number;
    const rivals=await db.prepare(`SELECT count(*) n FROM gmail_documents WHERE source=? AND amount=? AND date IN (?,date(?,'+1 day')) AND state IN ('pending','linked','posted') AND currency='VND' AND reference<>'' AND (state<>'linked' OR targetType<>'gmail')`).bind(d.source,bill.total,day,day).first<{n:number}>();
    if(rivals?.n===1){
     const reason=summary+'Khớp riêng một dòng phí dịch vụ ngày '+day+' · '+bill.total.toLocaleString('vi-VN')+'đ. Đã liên kết với phí trong sổ Flagteam.';
     await db.batch([
      db.prepare('INSERT OR IGNORE INTO gmail_flagteam_links VALUES(?,?,?,?,?)').bind(day,d.id,invoice,bill.total,actor),
      db.prepare("UPDATE gmail_documents SET state='linked',category='ads',channel='facebook',month=?,targetType='flagteam-fee',targetId=?,reason=? WHERE id=? AND state='pending' AND EXISTS(SELECT 1 FROM gmail_flagteam_links WHERE day=? AND item=? AND invoice=? AND amount=?)").bind(day.slice(0,7),day,reason,d.id,day,d.id,invoice,bill.total)
     ]);
     const linked=await db.prepare("SELECT id FROM gmail_documents WHERE id=? AND state='linked'").bind(d.id).first();
     if(linked){classified++;continue;}
    }
   }
   summary+='Chờ ghép dòng phí thực tế. ';
   summary+=fees.length?' Phí đại lý ngày '+bill.day+': '+fees.map(f=>f.provider+' '+f.fee.toLocaleString('vi-VN')+'đ'+(f.paid!=null?' (đã trả phí '+f.paid.toLocaleString('vi-VN')+'đ)':'')).join(', ')+'. '+(fees.some(f=>f.fee===bill.total||f.paid===bill.total)?'Có số tiền khớp, cần mã giao dịch để liên kết.':'Chưa khớp trực tiếp số tiền hóa đơn.'):' Chưa có dòng phí đại lý cùng ngày.';
  }
  if(c.repair){
   const ref=bill.series+' / '+bill.number;
   const key=await digest('expense:'+bill.vendor.toLowerCase()+':'+ref.toLowerCase()),id='gmail-'+key;
   const overlaps=await db.prepare(`SELECT id FROM pm_finance_docs WHERE kind='expense' AND (fingerprint=? OR json_extract(record,'$.gmailEvidence')=?
    OR json_extract(record,'$.reference') IN (?,?) OR (date BETWEEN ? AND ? AND json_extract(record,'$.amount')=?)) LIMIT 1`)
    .bind(key,d.mailId,ref,bill.number,bill.day.slice(0,7)+'-01',bill.day.slice(0,7)+'-31',bill.total).first();
   if(!overlaps){
    const now=new Date().toISOString();
    const value={...validateFinance('expense',{date:bill.day,amount:bill.total,category:c.category,channel:c.channel,description:'Dịch vụ sửa chữa thiết bị · '+bill.vendor,counterparty:bill.vendor,reference:ref,note:summary,receipt:{key:'gmail-evidence/'+d.digest,name:'Thư gốc hóa đơn '+bill.number+'.eml',mime:'message/rfc822'}}),
     id,status:'confirmed',actor,version:0,createdAt:now,updatedAt:now,confirmedAt:now,gmailEvidence:d.mailId,fintabEvidence:bill};
    await db.batch([
     db.prepare('INSERT INTO pm_finance_requests SELECT ?,count(*) FROM pm_finance_requests').bind(id),
     db.prepare('INSERT INTO pm_finance_docs VALUES(?,?,?,?,?,?,?,?,?)').bind(id,'expense',bill.day,bill.day,c.channel,'confirmed',JSON.stringify(value),0,key),
     db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(id,now,actor,'gmail:fintab-expense',JSON.stringify({after:value})),
     db.prepare("UPDATE gmail_documents SET state='posted',targetType='expense',targetId=?,month=?,channel=?,category=?,reason=? WHERE id=? AND state='pending'").bind(id,c.month,c.channel,c.category,summary+'. Đã ghi nhận chi phí, chờ rà soát thuế.',d.id),
     putSetting(db,'expense-changed:'+bill.day,now)
    ]);
    posted++;classified++;continue;
   }
  }
  await db.prepare("UPDATE gmail_documents SET category=?,channel=?,month=?,reason=? WHERE id=? AND state='pending'").bind(c.category,c.channel||d.channel,c.month||d.month,summary,d.id).run();
  classified++;
 }
 const prepaid=await db.prepare(`SELECT d.*,e.digest,f.facts FROM gmail_documents d JOIN gmail_evidence e ON e.id=d.mailId
  JOIN gmail_document_facts f ON f.itemId=d.id WHERE d.state='pending' AND d.source='CÔNG TY TNHH PANCAKE VIỆT NAM'
  AND json_extract(f.facts,'$.reading.kind')='prepaid-software-invoice' AND d.proofHash<>'' AND d.document LIKE '%.pdf'`).all<any>();
 for(const d of prepaid.results){
  const {invoice,reading}=JSON.parse(d.facts);
  if(invoice?.number!==d.reference||invoice.date!==d.date||reading.currency!=='VND'||d.currency!==reading.currency||
   !Number.isSafeInteger(reading.purchasedUnits)||reading.purchasedUnits<=0||!Number.isSafeInteger(reading.unitPrice)||reading.unitPrice<=0||
   reading.purchasedUnits*reading.unitPrice!==d.amount||reading.printedTotal!==d.amount||
   !Array.isArray(invoice.descriptions)||invoice.descriptions.some((s:string)=>/điều chỉnh|thay thế/i.test(s)))continue;
  if(invoice.series && await postApprovedSoftware(db,actor,d,{vendor:d.source,buyer:invoice.buyerTaxId||'',number:d.reference,
    day:d.date,total:d.amount,series:invoice.series,lines:invoice.descriptions})){classified++;posted++;continue;}
  const reason='PDF gốc · '+invoice.series+' / '+invoice.number+' · Gói trả trước '+reading.purchasedUnits.toLocaleString('vi-VN')+
   ' lượt × '+reading.unitPrice.toLocaleString('vi-VN')+'đ. Chờ số lượng phát hành thực tế theo gói để phân bổ.';
  await db.prepare("UPDATE gmail_documents SET category='software',channel='shared',reason=? WHERE id=? AND state='pending'").bind(reason,d.id).run();
  classified++;
 }
 // Stripe receipt 2493-7423 records the VND card charge alongside the USD invoice.
 const runway=await db.prepare(`SELECT d.*,e.digest FROM gmail_documents d JOIN gmail_evidence e ON e.id=d.mailId
  WHERE d.mailId='1a1c62f01a7f41b5' AND d.reference='MZU3ZKFB-0001' AND d.source='Runway AI, Inc.'
  AND d.document='Invoice-MZU3ZKFB-0001.pdf' AND d.currency='USD' AND d.amount=8.89 AND d.date='2026-11-10'
  AND d.state='pending'`).first<any>();
 if(runway){
  const charged=236684,day=runway.date;
  const key=await digest('expense:'+runway.source.toLowerCase()+':'+runway.reference.toLowerCase()), id='gmail-'+key;
  const overlap=await db.prepare(`SELECT id FROM pm_finance_docs WHERE kind='expense' AND status<>'void'
    AND (fingerprint=? OR json_extract(record,'$.gmailEvidence')=? OR json_extract(record,'$.reference')=? OR
    (date=? AND json_extract(record,'$.amount')=?)) LIMIT 1`).bind(key,runway.mailId,runway.reference,day,charged).first();
  if(!overlap){
   const now=new Date().toISOString(), note='Stripe 2493-7423 · 8,89 USD · thực thu 236.684đ trên thẻ theo biên nhận 10/11/2026.';
   const value={...validateFinance('expense',{date:day,amount:charged,category:'software',channel:'shared',description:'Runway · mua 1.000 credits',reference:runway.reference,
    counterparty:runway.source,note,paymentMethod:'bank',receipt:{key:'gmail-evidence/'+runway.digest,name:'Stripe 2493-7423.eml',mime:'message/rfc822'}}),
    id,status:'confirmed',actor,version:0,createdAt:now,updatedAt:now,confirmedAt:now,gmailEvidence:runway.mailId,originalCurrency:'USD',originalAmount:8.89};
   await db.batch([db.prepare('INSERT INTO pm_finance_requests SELECT ?,count(*) FROM pm_finance_requests').bind(id),
    db.prepare('INSERT INTO pm_finance_docs VALUES(?,?,?,?,?,?,?,?,?)').bind(id,'expense',day,day,'shared','confirmed',JSON.stringify(value),0,key),
    db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(id,now,actor,'gmail:stripe-expense',JSON.stringify({after:value})),
    db.prepare("UPDATE gmail_documents SET state='posted',targetType='expense',targetId=?,month='2026-11',channel='shared',category='software',reason=? WHERE id=? AND state='pending'").bind(id,note,runway.id),
    putSetting(db,'expense-changed:'+day,now)]);
   posted++;classified++;
  }
 }
 const ancillary=await db.prepare("SELECT d.id,d.source,d.document,d.amount,e.subject FROM gmail_documents d JOIN gmail_evidence e ON e.id=d.mailId WHERE d.state='pending' AND d.amount IS NULL AND d.source IN ('invoice@pancake.vn','possupport@pancake.vn')").all<any>();
 for(const d of ancillary.results){
  const reason=administrativeNotice(d);
  if(reason)await db.prepare("UPDATE gmail_documents SET state='evidence',reason=? WHERE id=? AND state='pending' AND amount IS NULL").bind(reason,d.id).run();
 }
 return {count:classified,posted};
}
