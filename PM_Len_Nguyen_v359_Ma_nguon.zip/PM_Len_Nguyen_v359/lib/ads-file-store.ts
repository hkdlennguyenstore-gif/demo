import {accounts} from './drive-marketplace-ads';
type Row = {kind:string; number:string; ref:string; account:string; date:string; type:string; amount:number; net?:number; tax?:number; status?:string; zone?:string; direction?:string};
async function setup(db:D1Database){
  await db.batch([
    db.prepare('CREATE TABLE IF NOT EXISTS expense_account_shops(account TEXT PRIMARY KEY,shop TEXT NOT NULL,actor TEXT NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP)'),
    db.prepare('CREATE TABLE IF NOT EXISTS ads_import_files(hash TEXT PRIMARY KEY,name TEXT NOT NULL,actor TEXT NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP)'),
    db.prepare('CREATE TABLE IF NOT EXISTS ads_import_rows(id TEXT PRIMARY KEY,ref TEXT NOT NULL,record TEXT NOT NULL,file TEXT NOT NULL)'),
    db.prepare("CREATE TRIGGER IF NOT EXISTS ads_import_conflict BEFORE INSERT ON ads_import_rows WHEN EXISTS(SELECT 1 FROM ads_import_rows WHERE id=NEW.id AND record<>NEW.record) BEGIN SELECT RAISE(ABORT,'conflicting ads record'); END")
  ]);
}
export async function storeAdsFile(db:D1Database,bucket:R2Bucket,request:Request,actor:string){
  const form=await request.formData(), file=form.get('file');
  if(!(file instanceof File)||!file.size||file.size>12*1024*1024||!/(\.zip|\.pdf|\.xlsx)$/i.test(file.name))throw Error('Tệp không hợp lệ hoặc vượt 12 MB');
  const rows=JSON.parse(String(form.get('rows'))) as Row[];
  if(!Array.isArray(rows)||!rows.length||rows.length>500)throw Error('Mỗi tệp cần từ 1 đến 500 bản ghi');
  const bytes=await file.arrayBuffer();
  const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
  await setup(db);
  const statements=rows.map(r=>{
    if(r.kind!=='evidence'&&(!Number.isSafeInteger(r.amount)||!/^\d{4}-\d\d-\d\d/.test(r.date)||!r.type||JSON.stringify(r).length>1800))throw Error('Dòng không đủ dữ liệu');
    let id;
    if(r.kind==='invoice'&&/^VNTT\d+$/.test(r.number)&&r.ref===r.number&&Number.isSafeInteger(r.net)&&Number.isSafeInteger(r.tax)&&Number(r.net)+Number(r.tax)===r.amount)id='invoice:'+r.number;
    else if(r.kind==='evidence'&&/^\d{1,4}$/.test(r.number)&&typeof r.ref==='string'&&(r.amount===null||Number.isSafeInteger(r.amount))&&JSON.stringify(r).length<4500)id='evidence:'+hash+':'+r.number;
    else if(r.kind==='transaction'&&/^\d{10,25}$/.test(r.account)&&/^\d{10,25}(?:\|\d{10,25}){0,4}$/.test(r.number))id='txn:'+r.account+':'+r.number;
    else throw Error('Thiếu mã hóa đơn, ID giao dịch hoặc sai tổng tiền');
    return db.prepare('INSERT INTO ads_import_rows VALUES(?,?,?,?) ON CONFLICT(id) DO NOTHING').bind(id,r.ref,JSON.stringify(r),hash);
  });
  await bucket.put('ads-import/'+hash,bytes);
  try{
    const results=await db.batch([db.prepare('INSERT INTO ads_import_files(hash,name,actor) VALUES(?,?,?) ON CONFLICT DO NOTHING').bind(hash,file.name.slice(0,250),actor),...statements]);
    const added=results.slice(1).reduce((n,v)=>n+v.meta.changes,0);
    return {added,duplicate:rows.length-added};
  }catch(e){if(String(e).includes('conflicting ads record'))throw Error('Trùng mã nhưng dữ liệu khác. Tệp chưa được nhập, cần đối chiếu bản gốc.');throw e;}
}
export async function adsFileReport(db:D1Database){
  await setup(db);
  const data=await db.prepare('SELECT record,file FROM ads_import_rows ORDER BY ref DESC,id').all<{record:string,file:string}>();
  const mappings=await db.prepare('SELECT account,shop FROM expense_account_shops').all<{account:string,shop:string}>();
  const linked={...Object.fromEntries(mappings.results.map(m=>[m.account,m.shop])),...accounts};
  const groups=new Map<string,any>();
  for(const item of data.results){
    const r:Row=JSON.parse(item.record),key=/^VNTT\d+$/.test(r.ref)?r.ref:'GD '+r.number;
    if(r.kind==='evidence'){const key='evidence:'+item.file+':'+r.number;groups.set(key,{ref:key,invoice:null,transactions:[],evidence:{...r,file:item.file,shop:accounts[r.account]||(r as any).channel||''}});continue;}
    const g=groups.get(key)||{ref:key,invoice:null,transactions:[]};
    const row={...r,file:item.file,shop:linked[r.account]||''};
    if(r.kind==='invoice')g.invoice=row;else g.transactions.push(row);
    groups.set(key,g);
  }
  return [...groups.values()];
}

export async function assignTikTokAccount(db:D1Database,account:string,shop:string,actor:string){
 await setup(db);
 if(!/^\d{10,25}$/.test(account)||!['tiktok1','tiktok2'].includes(shop)||accounts[account])throw Error('Liên kết tài khoản không hợp lệ');
 const seen=await db.prepare("SELECT 1 FROM ads_import_rows WHERE json_extract(record,'$.kind')='transaction' AND json_extract(record,'$.account')=? LIMIT 1").bind(account).first();
 if(!seen)throw Error('Chưa có giao dịch của tài khoản');
 await db.prepare('INSERT INTO expense_account_shops(account,shop,actor) VALUES(?,?,?) ON CONFLICT(account) DO NOTHING').bind(account,shop,actor).run();
 const saved=await db.prepare('SELECT shop FROM expense_account_shops WHERE account=?').bind(account).first<{shop:string}>();
 if(saved?.shop!==shop)throw Error('Tài khoản đã được gán cho shop khác');
 return {ok:true};
}
