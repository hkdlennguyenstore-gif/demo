import {a4Code} from './a4.ts';
import {a4Prices} from './a4-display.ts';
import {stockTone} from './a3-stock.ts';
type Product={sku:string;date:string;name:string|null;fbBase:number|null;pending:number|null;fbCalculated:number|null};
export function staffCatalogRows(source:Product[],stock:{code:string;remaining:number|null}[]|null,today:string){
 const products=new Map<string,{name:string;date:string|null;prices:Set<number|null>}>();
 for(const r of source){
  const code=a4Code(r.sku);if(!code)continue;
  const p=products.get(code)??{name:'',date:null,prices:new Set<number|null>()};
  if(!p.name&&r.name)p.name=r.name;
  if(r.date<=today&&(p.date===null||p.date===r.date)){
   p.date=r.date;p.prices.add(a4Prices({fbPrice:r.fbBase,calculated:[r.fbCalculated],calculatedPending:Boolean(r.pending)}).facebook);
  }
  products.set(code,p);
 }
 const quantities=new Map(stock?.map(r=>[a4Code(r.code),r.remaining]));
 const group=(n:number|null)=>n===null?3:n<0?2:n===0?1:0;
 return [...products].map(([code,p])=>{
  const remaining=quantities.get(code)??null;
  return {code,name:p.name,facebookPrice:p.prices.size===1?(p.prices.values().next().value??null):null,remaining,tone:remaining===null?'unknown':remaining<0?'negative':stockTone(remaining)};
 }).sort((a,b)=>group(a.remaining)-group(b.remaining)||(b.remaining??0)-(a.remaining??0)||a.code.localeCompare(b.code,'vi',{numeric:true}));
}
