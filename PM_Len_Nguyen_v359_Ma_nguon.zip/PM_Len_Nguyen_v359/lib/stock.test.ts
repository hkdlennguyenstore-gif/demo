import {navigationFor} from './navigation.ts';
import * as dateRange from './date-range.ts';
import * as historicalPrices from './price-history.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import * as stock from './stock.ts';
import * as stockStore from './stock-store.ts';
import * as purchase from './purchasing.ts';
import * as purchaseStore from './purchasing-store.ts';
import {stockCatalog} from './stock-catalog.ts';
import {canAccessModule} from './modules.ts';
function fixture(){const sqlite=new DatabaseSync(':memory:');sqlite.exec('CREATE TABLE app_state(id TEXT PRIMARY KEY,value TEXT,version INTEGER)');sqlite.prepare('INSERT INTO app_state VALUES(?,?,0)').run('main',JSON.stringify({owner:'boss@shop.vn',members:[{email:'cv@shop.vn',role:'terminal'},{email:'nv@shop.vn',role:'employee'},{email:'other@shop.vn',role:'employee'}]}));let email='cv@shop.vn';const DB={prepare(sql:string){let args:any[]=[];return {bind(...v:any[]){args=v;return this;},async first(){return sqlite.prepare(sql).get(...args)||null;},async all(){return {results:sqlite.prepare(sql).all(...args)};},async run(){return {meta:{changes:Number(sqlite.prepare(sql).run(...args).changes)}};}};},async batch(statements:any[]){sqlite.exec('BEGIN');try{for(const s of statements)await s.run();sqlite.exec('COMMIT');return [];}catch(e){sqlite.exec('ROLLBACK');throw e;}}} as unknown as D1Database;
const modules:any={'../../../lib/date-range':dateRange,'cloudflare:workers':{env:{DB,BUCKET:{head:async()=>null}}},'../../chatgpt-auth':{getChatGPTUser:async()=>({email})},'../../../lib/payroll':{permission:(s:any,e:string)=>s.owner===e?{role:'owner'}:s.members.find((m:any)=>m.email===e)},'../../../lib/stock-catalog':{stockCatalog},'../../../lib/stock':stock,'../../../lib/stock-store':stockStore,'../../../lib/purchasing':purchase,'../../../lib/price-history':historicalPrices,'../../../lib/purchasing-store':purchaseStore};
function load(path:string){const code=ts.transpileModule(readFileSync(new URL(path,import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const exports:any={};vm.runInNewContext('(function(require,exports){'+code+'})',{Response,URL,crypto,console})((id:string)=>{if(!modules[id])throw Error(id);return modules[id];},exports);return exports;}
const api=load('../app/api/stock/route.ts'),finance=load('../app/api/purchases/route.ts');
return {sqlite,DB,as:(v:string)=>{email=v;},get:async(q='')=>{const r=await api.GET(new Request('https://pm.test/api/stock?'+q));return {status:r.status,body:await r.json() as any};},financeGet:async()=>finance.GET(new Request('https://pm.test/api/purchases')),post:async(action:string,data:any,requestId=crypto.randomUUID(),financial=false)=>{const r=await (financial?finance:api).POST(new Request('https://pm.test/api/'+(financial?'purchases':'stock'),{method:'POST',headers:{origin:'https://pm.test','Content-Type':'application/json'},body:JSON.stringify({action,data,requestId,version:data.financeVersion})}));return {status:r.status,body:await r.json() as any};}};}
const input={date:'16 - 11 - 26',source:'Trang',lines:[{existingCode:'D10',newCode:'Wash nhẹ',color:'Xanh',quantity:10,note:'Kiểm hàng'}],note:'Đủ hàng'};
test('Màu phát sinh lưu vào danh mục dùng chung; lọc ngày, năm và khoảng ngày bao gồm hai đầu',async()=>{
 const h=fixture();
 for(const [date,quantity] of [['2025-12-31',2],['2026-01-01',3],['2026-11-17',5],['2027-01-01',7]] as const)assert.equal((await h.post('save',{...input,date,lines:[{...input.lines[0],color:'Xanh rêu ánh vàng',quantity}]})).status,200);
 const all=(await h.get()).body;assert.equal(all.quantity,17);assert.ok(all.catalog.colors.includes('Xanh rêu ánh vàng'));assert.equal(all.catalog.colors.filter((c:string)=>c==='Xanh rêu ánh vàng').length,1);
 const day=(await h.get('from=2026-11-17&to=2026-11-17')).body;assert.equal(day.total,1);assert.equal(day.quantity,5);
 const year=(await h.get('from=2026-01-01&to=2026-12-31')).body;assert.equal(year.total,2);assert.equal(year.quantity,8);
 const custom=(await h.get('from=2025-12-31&to=2026-01-01')).body;assert.equal(custom.total,2);assert.equal(custom.quantity,5);
 assert.equal((await h.get('month=2026-11')).body.quantity,5);
 assert.equal((await h.get('from=2026-02-30')).status,403);assert.equal((await h.get('from=2027-01-01&to=2026-01-01')).status,403);assert.equal((await h.get('month=2026-11&from=2026-01-01')).status,403);
 h.as('other@shop.vn');assert.ok((await h.get()).body.catalog.colors.includes('Xanh rêu ánh vàng'));h.sqlite.close();
});
test('Nhân viên nhận hàng chờ NCC; chủ shop bổ sung vào cùng phiếu trước khi ghi công nợ',async()=>{
 const h=fixture();h.as('boss@shop.vn');await h.post('supplier',{name:'Trang',opening:0,openingDate:'2026-11-01',financeVersion:0},crypto.randomUUID(),true);h.as('cv@shop.vn');
 assert.equal((await h.post('save',{...input,source:'',supplierPending:true,supplierHint:'Xưởng mới giao hàng'})).status,200);
 let row=(await h.get()).body.rows[0];assert.equal(row.supplierPending,true);assert.equal(row.supplierHint,'Xưởng mới giao hàng');assert.equal(row.source,'Chờ bổ sung nhà cung cấp');
 assert.equal((await h.post('resolve-supplier',{id:row.id,version:0,source:'Trang',reason:'Tự xác nhận'})).status,400);
 assert.equal((await h.post('save',{...input,id:row.id,version:0,reason:'Bỏ chờ'})).status,400);
 assert.equal((await h.post('check',{id:row.id,version:0,line:0,checked:true})).status,200);
 h.as('boss@shop.vn');const supplier=h.sqlite.prepare('SELECT id FROM pm_purchase_suppliers').get()!.id;
 const priced={supplier,date:'2026-11-16',due:'',number:'PENDING1',lines:[{sku:'D10',name:'Wash nhẹ',color:'Xanh',size:'',quantity:10,price:120000}],discount:0,extra:0,paid:0,stockReceipt:row.id,stockVersion:1,financeVersion:1};
 assert.equal((await h.post('purchase',priced,crypto.randomUUID(),true)).status,400);
 assert.equal(h.sqlite.prepare('SELECT COUNT(*) AS n FROM pm_purchase_docs').get()!.n,0);
 const key=crypto.randomUUID(),resolve={id:row.id,version:1,source:'Trang',reason:'Xác nhận NCC'};
 assert.equal((await h.post('resolve-supplier',resolve,key)).status,200);assert.equal((await h.post('resolve-supplier',resolve,key)).status,200);
 row=(await h.get()).body.rows[0];assert.equal(row.supplierPending,false);assert.equal(row.supplierId,supplier);assert.equal(row.source,'Trang');assert.equal(row.lines[0].checked,true);assert.equal((await h.get()).body.quantity,10);assert.equal((await h.get()).body.total,1);
 assert.equal((await h.post('purchase',{...priced,stockVersion:2},crypto.randomUUID(),true)).status,200);h.sqlite.close();
});
test('Lưu Trang, đổi sang Mạnh hoặc nguồn khác; mẫu chưa có mã vẫn nhập được',async()=>{
 const h=fixture();
 h.as('boss@shop.vn');for(const [financeVersion,name] of ['Trang','Mạnh','Xưởng mới'].entries())assert.equal((await h.post('supplier',{name,opening:0,openingDate:'2026-11-01',financeVersion},crypto.randomUUID(),true)).status,200);h.as('cv@shop.vn');
 for(const source of ['Trang','Mạnh','Xưởng mới'])assert.equal((await h.post('save',{...input,source,lines:[{...input.lines[0],existingCode:'',newCode:'Mẫu suông mới'}]})).status,200);
 const d=(await h.get()).body;
 assert.equal(d.total,3);assert.ok(d.catalog.sources.includes('Xưởng mới'));
 assert.deepEqual(new Set(d.rows.map((r:any)=>r.source)),new Set(['Trang','Mạnh','Xưởng mới']));
 assert.equal((await h.post('save',{...input,source:'Tên tự thêm'})).status,400);
 const choices=(await h.get('mode=suppliers')).body;assert.ok(choices.suppliers.some((s:any)=>s.name==='Xưởng mới'));assert.ok(!JSON.stringify(choices).includes('opening'));assert.ok(!JSON.stringify(choices).includes('paid'));
 h.as('boss@shop.vn');const supplier=choices.suppliers.find((s:any)=>s.name==='Xưởng mới');assert.equal((await h.post('supplier',{id:supplier.id,name:'Xưởng đổi tên',opening:0,openingDate:'2026-11-01',financeVersion:3},crypto.randomUUID(),true)).status,200);
 h.as('cv@shop.vn');const after=(await h.get()).body;assert.ok(after.catalog.sources.includes('Xưởng đổi tên'));assert.ok(!after.catalog.sources.includes('Xưởng mới'));assert.ok(after.rows.some((r:any)=>r.source==='Xưởng đổi tên'));assert.equal((await h.get('source='+encodeURIComponent('Xưởng đổi tên'))).body.total,1);h.sqlite.close();
});
test('Bổ sung mã mẫu lưu đúng dòng, giữ mô tả, chặn sửa phiếu người khác và replay',async()=>{
 const h=fixture();await h.post('save',{...input,lines:[{...input.lines[0],existingCode:'',newCode:'Mẫu suông mới'}]});
 const row=(await h.get()).body.rows[0];
 const x={id:row.id,version:0,line:0,code:'s95',reason:'Có mã mới'};
 h.as('other@shop.vn');assert.equal((await h.post('resolve-code',x)).status,400);h.as('cv@shop.vn');
 assert.equal((await h.post('resolve-code',{...x,code:'không hợp lệ'})).status,400);
 const key=crypto.randomUUID();assert.equal((await h.post('resolve-code',x,key)).status,200);assert.equal((await h.post('resolve-code',x,key)).status,200);
 const updated=(await h.get('id='+row.id)).body;assert.equal(updated.lines[0].existingCode,'S95');assert.equal(updated.lines[0].newCode,'Mẫu suông mới');assert.equal(updated.lines[0].quantity,10);assert.equal(updated.lines[0].checked,false);
 assert.ok((await h.get()).body.catalog.codes.includes('S95'));assert.equal((await h.post('resolve-code',{...x,version:1,code:'S96'})).status,400);h.sqlite.close();
});
test('Bổ sung mã sau nhập giá chỉ đổi SKU; giữ nguyên giá, tổng nợ và khóa số lượng',async()=>{
 const h=fixture();await h.post('save',{...input,lines:[{...input.lines[0],existingCode:'',newCode:'Mẫu suông mới'}]});const row=(await h.get()).body.rows[0];
 h.as('boss@shop.vn');await h.post('supplier',{name:'Trang',opening:0,openingDate:'2026-11-01',financeVersion:0},crypto.randomUUID(),true);
 const supplier=h.sqlite.prepare('SELECT id FROM pm_purchase_suppliers').get()!.id;
 const r=await h.post('purchase',{supplier,date:'2026-11-16',due:'',number:'NEW1',lines:[{sku:'Mẫu suông mới',name:'Mẫu suông mới',color:'Xanh',size:'',quantity:10,price:120000}],discount:0,extra:0,paid:0,stockReceipt:row.id,stockVersion:0,financeVersion:1},crypto.randomUUID(),true);assert.equal(r.status,200,JSON.stringify(r.body));
 h.as('cv@shop.vn');const key=crypto.randomUUID(),x={id:row.id,version:1,line:0,code:'S95',reason:'Có mã chính thức'};
 assert.equal((await h.post('resolve-code',x,key)).status,200);await h.post('resolve-code',x,key);
 const doc=h.sqlite.prepare("SELECT total,record FROM pm_purchase_docs WHERE kind='purchase'").get()!;
 assert.equal(doc.total,1200000);const line=JSON.parse(doc.record as string).lines[0];assert.equal(line.sku,'S95');assert.equal(line.price,120000);assert.equal(line.quantity,10);
 assert.equal(h.sqlite.prepare('SELECT imported-paid AS balance FROM pm_purchase_suppliers').get()!.balance,1200000);
 const safe=JSON.stringify((await h.get()).body);assert.ok(!safe.includes('120000'));assert.equal((await h.financeGet()).status,403);
 assert.equal((await h.post('save',{...input,id:row.id,version:2,reason:'Đổi SL'})).status,400);h.sqlite.close();
});
test('Ngày chuẩn hóa, mã đã có, mã mới, màu, nguồn và số lượng đúng mẫu',()=>{assert.equal(stock.parseStockDate('16 - 11 - 26'),'2026-11-16');assert.equal(stock.parseStockDate('16/11/2026'),'2026-11-16');assert.throws(()=>stock.parseStockDate('31/02/2026'));assert.equal(stock.validateStock(input,stockCatalog.codes).lines[0].quantity,10);assert.throws(()=>stock.validateStock({...input,lines:[{...input.lines[0],quantity:0}]},stockCatalog.codes));assert.throws(()=>stock.validateStock({...input,lines:[{...input.lines[0],existingCode:'UNKNOWN'}]},stockCatalog.codes));});
test('Nhân viên tạo/sửa phiếu kho, không nhận giá hoặc công nợ; replay không ghi trùng',async()=>{const h=fixture();const key=crypto.randomUUID();assert.equal((await h.post('save',{...input,price:999999,debt:88888},key)).status,200);await h.post('save',input,key);let d=(await h.get()).body;assert.equal(d.total,1);assert.equal(d.quantity,10);assert.equal(d.privateAccess,false);const id=d.rows[0].id;assert.equal((await h.financeGet()).status,403);assert.equal((await h.post('supplier',{name:'Không được',opening:0,openingDate:'2026-11-16',financeVersion:0},crypto.randomUUID(),true)).status,400);const raw=JSON.parse(h.sqlite.prepare('SELECT record FROM pm_stock_receipts WHERE id=?').get(id)!.record as string);assert.equal(raw.price,undefined);const response=JSON.stringify(d);assert.ok(!response.includes('999999'));assert.ok(!response.includes('purchase_id'));assert.ok(!response.includes('imported'));assert.equal((await h.post('save',{...input,id,version:0,reason:'Đếm lại',lines:[{...input.lines[0],quantity:12}]})).status,200);d=(await h.get()).body;assert.equal(d.quantity,12);assert.equal((await h.post('save',{...input,id,version:0,reason:'Phiên cũ'})).status,409);h.as('other@shop.vn');assert.equal((await h.post('save',{...input,id,version:1,reason:'Không phải phiếu của mình'})).status,400);h.sqlite.close();});
test('Chủ shop nhập giá liên kết nguyên tử; nhân viên không sửa phiếu đã đối chiếu',async()=>{const h=fixture();await h.post('save',input);const row=(await h.get()).body.rows[0];h.as('boss@shop.vn');await h.post('supplier',{name:'Trang',opening:0,openingDate:'2026-11-01',financeVersion:0},crypto.randomUUID(),true);const suppliers=h.sqlite.prepare('SELECT id FROM pm_purchase_suppliers').all();const payload={supplier:suppliers[0].id,date:'2026-11-16',due:'',number:'PN001',lines:[{sku:'D10',name:'Wash nhẹ',color:'Xanh',size:'',quantity:10,price:120000}],discount:0,extra:0,paid:200000,stockReceipt:row.id,stockVersion:0,financeVersion:1};const r=await h.post('purchase',payload,crypto.randomUUID(),true);assert.equal(r.status,200,JSON.stringify(r.body));const purchaseId=h.sqlite.prepare("SELECT id FROM pm_purchase_docs WHERE kind='purchase'").get()!.id;h.as('cv@shop.vn');const safe=(await h.get('id='+row.id)).body;assert.equal(safe.locked,true);assert.ok(!JSON.stringify(safe).includes('120000'));assert.equal((await h.financeGet()).status,403);assert.equal((await h.post('save',{...input,id:row.id,version:1,reason:'Sửa sau đối chiếu'})).status,400);h.as('boss@shop.vn');assert.equal((await h.post('void',{id:purchaseId,kind:'purchase',reason:'Nhập lại giá',financeVersion:2},crypto.randomUUID(),true)).status,200);h.as('cv@shop.vn');assert.equal((await h.get('id='+row.id)).body.locked,false);assert.equal((await h.get()).body.quantity,10);assert.equal(h.sqlite.prepare('SELECT imported-paid AS balance FROM pm_purchase_suppliers').get()!.balance,0);h.sqlite.close();});
test('Vai trò nhân viên có tab Kho, không có tab tài chính',()=>{for(const role of ['terminal','employee','manager']){assert.equal(canAccessModule(role,'stock'),true);assert.equal(canAccessModule(role,'purchases'),false);}assert.equal(canAccessModule('unknown','stock'),false);});
test('Ô kiểm SL mặc định chưa tích, lưu tích/bỏ tích, đổi số lượng tự bỏ kiểm',async()=>{const h=fixture();await h.post('save',input);let row=(await h.get()).body.rows[0];assert.equal(row.lines[0].checked,false);h.as('other@shop.vn');const key=crypto.randomUUID();assert.equal((await h.post('check',{id:row.id,version:0,line:0,checked:true,quantity:999,price:888},key)).status,200);await h.post('check',{id:row.id,version:0,line:0,checked:true},key);row=(await h.get()).body.rows[0];assert.equal(row.lines[0].checked,true);assert.equal(row.lines[0].quantity,10);assert.equal(row.version,1);assert.equal((await h.post('check',{id:row.id,version:1,line:0,checked:false})).status,200);row=(await h.get()).body.rows[0];assert.equal(row.lines[0].checked,false);await h.post('check',{id:row.id,version:2,line:0,checked:true});h.as('cv@shop.vn');assert.equal((await h.post('save',{...input,id:row.id,version:3,reason:'Đếm lại',lines:[{...input.lines[0],quantity:11}]})).status,200);row=(await h.get()).body.rows[0];assert.equal(row.lines[0].checked,false);assert.equal(row.lines[0].quantity,11);assert.equal((await h.post('check',{id:row.id,version:4,line:9,checked:true})).status,400);h.sqlite.close();});
test('Sửa SL và ghi chú trực tiếp: tổng kho cập nhật, bỏ dấu kiểm khi đổi SL, replay không cộng trùng',async()=>{
 const h=fixture();await h.post('save',input);let row=(await h.get()).body.rows[0];await h.post('check',{id:row.id,version:row.version,line:0,checked:true});row=(await h.get()).body.rows[0];const request=crypto.randomUUID();const payload={id:row.id,version:row.version,line:0,field:'quantity',value:15};assert.equal((await h.post('patch-line',payload,request)).status,200);assert.equal((await h.post('patch-line',payload,request)).status,200);let list=(await h.get()).body;assert.equal(list.quantity,15);row=list.rows[0];assert.equal(row.lines[0].checked,false);assert.equal((await h.post('patch-line',{id:row.id,version:row.version,line:0,field:'note',value:'Đã sửa trên dòng'})).status,200);row=(await h.get()).body.rows[0];assert.equal(row.lines[0].note,'Đã sửa trên dòng');assert.equal((await h.post('patch-line',{...payload,version:row.version,value:0})).status,400);assert.equal((await h.post('patch-line',payload)).status,409);h.as('other@shop.vn');assert.equal((await h.post('patch-line',{...payload,version:row.version,value:20})).status,400);h.sqlite.close();
});
test('Chủ shop sửa trực tiếp phiếu liên kết: kho, tổng phiếu, công nợ cùng đổi; giá lịch sử và tiền trả giữ nguyên',async()=>{
 const h=fixture();await h.post('save',input);const row=(await h.get()).body.rows[0];h.as('boss@shop.vn');await h.post('supplier',{name:'Trang',opening:0,openingDate:'2026-11-01',financeVersion:0},crypto.randomUUID(),true);const supplier=h.sqlite.prepare('SELECT id FROM pm_purchase_suppliers').get()!.id;assert.equal((await h.post('purchase',{supplier,date:'2026-11-16',due:'',number:'EDIT-LINK',lines:[{sku:'D10',name:'Jeans',color:'Xanh',size:'',quantity:10,price:120000}],discount:0,extra:0,paid:200000,stockReceipt:row.id,stockVersion:0,financeVersion:1},crypto.randomUUID(),true)).status,200);
 let stockRow=(await h.get()).body.rows[0];assert.equal(stockRow.canEditLine,true);const key=crypto.randomUUID(),x={id:row.id,version:stockRow.version,line:0,field:'quantity',value:12};assert.equal((await h.post('patch-line',x,key)).status,200);assert.equal((await h.post('patch-line',x,key)).status,200);assert.equal((await h.get()).body.quantity,12);
 const doc=h.sqlite.prepare("SELECT total,record FROM pm_purchase_docs WHERE kind='purchase'").get()!;assert.equal(doc.total,1440000);const line=JSON.parse(doc.record as string).lines[0];assert.equal(line.quantity,12);assert.equal(line.price,120000);assert.equal((await h.get()).body.rows[0].pricing.lines[0].price,120000);assert.equal(h.sqlite.prepare('SELECT imported-paid AS balance FROM pm_purchase_suppliers').get()!.balance,1240000);assert.equal(h.sqlite.prepare("SELECT total FROM pm_purchase_docs WHERE kind='payment'").get()!.total,200000);
 stockRow=(await h.get()).body.rows[0];assert.equal((await h.post('patch-line',{id:row.id,version:stockRow.version,line:0,field:'note',value:''})).status,200);assert.equal((await h.get()).body.rows[0].lines[0].noteOverride,true);assert.equal(h.sqlite.prepare('SELECT imported-paid AS balance FROM pm_purchase_suppliers').get()!.balance,1240000);
 h.as('cv@shop.vn');stockRow=(await h.get()).body.rows[0];assert.equal(stockRow.canEditLine,false);assert.equal((await h.post('patch-line',{...x,version:stockRow.version,value:20})).status,400);assert.ok(!JSON.stringify(stockRow).includes('120000'));h.sqlite.close();
});

test('Menu chỉ có một lối nhập hàng; nhân viên không có menu công nợ',()=>{for(const role of ['owner','admin','employee','terminal']){const nav=navigationFor(role);assert.equal(nav.stock,true);assert.equal(nav.groups.flatMap(g=>g.items).filter(i=>i.id==='finance-purchases').length,0);if(['employee','terminal'].includes(role))assert.equal(nav.groups.some(g=>g.id==='finance'),false);}});
