import test from 'node:test';
import assert from 'node:assert/strict';
import {saleCost} from './actual-sale-cost.ts';
test('Giá đổi trong kỳ, hàng hoàn và phần chưa khớp',async()=>{
 const item=(code:string,q:number,r=0)=>({id:code,product:{custom_id:code},sell_export:-q,return_import:r});
 const rows=[item('D15',5,1),item('U',1)];
 const prices=[{sku:'D15',price:110000,date:'2026-05-24'},{sku:'D15',price:145000,date:'2026-11-17'}];
 const v=await saleCost(rows,prices,'2026-11-01','2026-11-20',async day=>day==='2026-11-01'?[item('D15',2)]:[item('D15',3,1),item('U',1)]);
 assert.equal(v.known,510000);assert.deepEqual(v.missing,['U']);assert.equal(v.complete,false);
});
