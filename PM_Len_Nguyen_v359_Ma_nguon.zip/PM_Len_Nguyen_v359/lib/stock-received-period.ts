import type {DateRange} from './date-range';
// Receipt reporting follows the selected calendar period; inventory uses its own cutoff.
export async function readReceivedPeriod(db:any,range:DateRange){
 const total=await db.prepare("SELECT COUNT(*) AS receipts,SUM(quantity) AS quantity,SUM(CASE WHEN quantity IS NULL OR quantity<0 OR quantity!=CAST(quantity AS INTEGER) THEN 1 ELSE 0 END) AS invalid FROM pm_stock_receipts WHERE active=1 AND (?='' OR date>=?) AND (?='' OR date<=?)").bind(range.from,range.from,range.to,range.to).first();
 if(!total||!Number.isSafeInteger(total.receipts)||total.receipts<0)throw Error('Chưa xác nhận được dữ liệu nhập trong kỳ');
 const quantity=total.receipts===0?0:total.quantity;
 return {range,receipts:total.receipts,quantity:!total.invalid&&Number.isSafeInteger(quantity)&&quantity>=0?quantity:null};
}
