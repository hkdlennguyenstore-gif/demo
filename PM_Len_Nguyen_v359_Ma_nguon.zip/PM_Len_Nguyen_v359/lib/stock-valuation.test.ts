import test from 'node:test';
import assert from 'node:assert/strict';
import {calculateStockOverview} from './stock-overview-math.ts';
test('Giá chung gần nhất đến cuối kỳ; mã hết tồn vẫn giữ lượng nhập, xuất',()=>{
 const range={from:'2026-11-01',to:'2026-11-20'};
 const receipts=[{date:range.from,lines:[{existingCode:'d14',quantity:5},{existingCode:'B1',quantity:2}]}];
 const moves=[{id:'a',product:{custom_id:'B1'},sell_export:-2,return_import:0}];
 const prices=[{sku:'D14',date:'2026-11-01',price:100000},{sku:'d14',date:'2026-11-12',price:110000},{sku:'D14',date:'2026-11-21',price:120000}];
 const r=calculateStockOverview(receipts,moves,moves,prices,range);
 assert.deepEqual(r.rows.map(r=>r.code),['D14']);assert.equal(r.cumulative.value,550000);
 assert.equal(r.issues.missingPrices,0);assert.equal(r.period.received,7);assert.equal(r.period.sold,2);
 assert.equal(calculateStockOverview(receipts,[],[],prices,range,false).rows.length,2);
});
