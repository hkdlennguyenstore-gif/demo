'use client';

import {useState} from 'react';

const options = (count:number) => Array.from({length:count}, (_, i) => String(i).padStart(2,'0'));
const hours = options(24);
const minutes = options(60);

export default function TimePicker({label,name,value,defaultValue='',onChange,seconds=false,allowEndOfDay=false}:{
 label:string;
 name?:string;
 value?:string;
 defaultValue?:string;
 onChange?:(value:string)=>void;
 seconds?:boolean;
 allowEndOfDay?:boolean;
}){
 const [saved,setSaved]=useState(defaultValue);
 const time=value??saved;
 const [hour='',minute='',second='']=time.split(':');
 const endOfDay=hour==='24';
 function update(h:string,m:string,s:string){
  const next=!h?'':h==='24'?'24:00':h+':'+(m||'00')+(seconds&&s?':'+s:'');
  if(value===undefined)setSaved(next);
  onChange?.(next);
 }
 return <div className="time-picker" role="group" aria-label={label}>
  <span className="time-picker-label">{label}</span>
  <div className="time-picker-controls">
   <select aria-label={label+' · Giờ'} value={hour} onChange={e=>update(e.target.value,minute,second)}>
    <option value="">Giờ</option>
    {hours.map(h=><option key={h} value={h}>{h}</option>)}
    {allowEndOfDay&&<option value="24">24</option>}
   </select>
   <span aria-hidden="true">:</span>
   <select aria-label={label+' · Phút'} value={minute} disabled={!hour||endOfDay} onChange={e=>update(hour,e.target.value,second)}>
    {!minute&&<option value="">Phút</option>}
    {minutes.map(m=><option key={m} value={m}>{m}</option>)}
   </select>
   {seconds&&<><span aria-hidden="true">:</span><select aria-label={label+' · Giây'} value={second} disabled={!hour||endOfDay} onChange={e=>update(hour,minute,e.target.value)}>
    <option value="">Giây</option>
    {minutes.map(s=><option key={s} value={s}>{s}</option>)}
   </select></>}
  </div>
  {name&&<input type="hidden" name={name} value={time}/>}
 </div>;
}
