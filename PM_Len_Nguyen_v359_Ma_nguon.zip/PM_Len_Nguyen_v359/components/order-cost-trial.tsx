'use client';
import {trialOrders,orderCostTrial} from '../lib/order-cost-trial';
const money=(n:number)=>n.toLocaleString('vi-VN')+' đ';
export default function OrderCostTrial({query,data,displayedProfit,profitLabel,shopId,raw,onChange,storageError}:{query:string;data:any;displayedProfit:number|null;profitLabel:string;shopId:string;raw:string;onChange:(value:string)=>void;storageError:string}){
 const scope=trialOrders(query,data,shopId);
 if(!scope)return <div><dt>{profitLabel}</dt><dd>{Number.isFinite(displayedProfit)?money(displayedProfit!):'Chờ nguồn'}</dd></div>;
 const result=orderCostTrial(raw,scope.count);
 const active=Boolean(raw.trim());
 return <>
  <div aria-live="polite"><dt title={active?'Đã trừ QC tạm · Chỉ tính thử · Nhớ trên trình duyệt, không ghi sổ':undefined}>{active?'Lãi tạm tính':profitLabel}</dt><dd title={active?'Đã trừ QC tạm · Chỉ tính thử · Nhớ trên trình duyệt, không ghi sổ':undefined}>{active?(displayedProfit===null?'Chưa đủ dữ liệu':money(displayedProfit)):(Number.isFinite(displayedProfit)?money(displayedProfit!):'Chờ nguồn')}</dd></div>
  <div className="shop-qc-trial" style={{alignItems:'start'}}>
   <dt title="Chi phí QC ước tính/đơn · Chỉ tính thử · Nhớ trên trình duyệt, không ghi sổ">QC tạm</dt>
   <dd style={{minWidth:0,maxWidth:'70%'}}>
    <input aria-label="Chi phí QC ước tính/đơn (đ)" title="Chi phí QC ước tính/đơn (đ) · Chỉ tính thử · Nhớ trên trình duyệt, không ghi sổ" type="text" inputMode="numeric" autoComplete="off" value={raw} onChange={e=>onChange(e.target.value)} placeholder="đ/đơn" style={{width:96,maxWidth:'100%',minWidth:0,height:30,padding:'2px 6px',fontSize:16,textAlign:'right',boxSizing:'border-box'}}/>
    {active&&<output aria-live="polite" title="Chỉ tính thử · Nhớ trên trình duyệt, không ghi sổ" style={{display:'block',fontSize:14,marginTop:2,overflowWrap:'anywhere'}}>{result.kind==='ready'?money(result.total!):result.kind==='missing'?'Chưa đủ dữ liệu':'Số tiền chưa hợp lệ'}</output>}
    {shopId==='tiktok2'&&scope.count!==null&&<small style={{display:'block'}}>{scope.count.toLocaleString('vi-VN')} đơn POS, gồm đơn hủy</small>}
    {storageError&&<small role="status">{storageError}</small>}
   </dd>
  </div>
 </>;
}
