'use client';
import {useEffect,useState} from 'react';
import {rangeLabel} from '../lib/date-range';
const money=(n:number)=>n.toLocaleString('vi-VN')+' đ';
export function StockReceivedPeriod({from,to,revision}:{from:string;to:string;revision:string}){
 const key=from+'|'+to,[snapshot,setSnapshot]=useState<any>(null);
 useEffect(()=>{let stop=false,active:AbortController|undefined,inflight=false;async function read(){if(inflight)return;inflight=true;const controller=new AbortController();active=controller;try{const response=await fetch('/api/stock?'+new URLSearchParams({mode:'received-period',from,to}),{cache:'no-store',signal:controller.signal}),body=await response.json();if(!response.ok)throw Error(body.error);if(!stop)setSnapshot({key,body});}catch(e){if(!stop&&!controller.signal.aborted)setSnapshot({key,error:(e as Error).message});}finally{inflight=false;}}const visible=()=>{if(document.visibilityState==='visible')void read();};void read();const timer=setInterval(visible,60000);window.addEventListener('focus',visible);return()=>{stop=true;active?.abort();clearInterval(timer);window.removeEventListener('focus',visible);};},[key,revision]);
 const current=snapshot?.key===key?snapshot:null,n=current?.body?.quantity;
 return <><strong title={current?.error||''}>{typeof n==='number'?n.toLocaleString('vi-VN'):current?.error?'Chờ dữ liệu':'Đang lấy…'}</strong><small>{rangeLabel({from,to})}</small></>;
}
export function StockPeriodCost({from,to}:{from:string;to:string}){
 const [data,setData]=useState<any>(null),[error,setError]=useState('');useEffect(()=>{const controller=new AbortController();setData(null);setError('');fetch('/api/stock?'+new URLSearchParams({mode:'inventory-summary',from,to}),{cache:'no-store',signal:controller.signal}).then(async r=>{const body=await r.json();if(!r.ok)throw Error(body.error);setData(body);}).catch(e=>{if(!controller.signal.aborted)setError(e.message);});return()=>controller.abort();},[from,to]);
 return <><small>{rangeLabel({from,to})}</small>{!data?<p role="status">{error||'Đang đối chiếu giá vốn theo kỳ…'}</p>:<p><strong>{data.salesCost&&(data.salesCost.complete||data.salesCost.matched)?money(data.salesCost.known):'Chờ dữ liệu'}</strong>{data.salesCost&&!data.salesCost.complete&&<span> · Phần đã khớp A3; còn {data.salesCost.missingUnits} lượt sản phẩm cần ghép giá: {data.salesCost.missing.join(', ')}</span>}{data.costIssue&&<small>{data.costIssue}</small>}</p>}</>;
}

export function StockMovementsPeriod({from,to,revision}:{from:string;to:string;revision:string}){
 const key=from+'|'+to,[snapshot,setSnapshot]=useState<any>(null);
 useEffect(()=>{let stop=false,inflight=false,active:AbortController|undefined;async function read(){if(inflight)return;inflight=true;const controller=new AbortController();active=controller;try{const response=await fetch('/api/stock?'+new URLSearchParams({mode:'movement-period',from,to}),{cache:'no-store',signal:controller.signal}),body=await response.json();if(!response.ok)throw Error(body.error);if(!stop)setSnapshot({key,body});}catch(e){if(!stop&&!controller.signal.aborted)setSnapshot({key,error:(e as Error).message});}finally{inflight=false;}}const visible=()=>{if(document.visibilityState==='visible')void read();};void read();const timer=setInterval(visible,60000);window.addEventListener('focus',visible);document.addEventListener('visibilitychange',visible);return()=>{stop=true;active?.abort();clearInterval(timer);window.removeEventListener('focus',visible);document.removeEventListener('visibilitychange',visible);};},[key,revision]);
 const current=snapshot?.key===key?snapshot:null,issue=current?.error||current?.body?.issue||'';
 return <>{[['Đã bán (POS)','sold'],['Hoàn về','returned']].map(([label,field])=><div key={field}><span>{label}</span><strong title={issue}>{typeof current?.body?.[field]==='number'?current.body[field].toLocaleString('vi-VN'):current?'Chờ dữ liệu':'Đang lấy…'}</strong><small>{rangeLabel({from,to})}</small>{issue&&<small role="status">{issue}</small>}</div>)}</>;
}
