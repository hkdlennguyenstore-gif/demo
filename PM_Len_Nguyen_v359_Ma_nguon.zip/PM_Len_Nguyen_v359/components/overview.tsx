'use client';
import {rangeLabel} from '../lib/date-range';
import {marketplaceAccounts} from '../lib/marketplace-orders';
import {sourceChannels} from '../lib/order-source-summary';
import {ArrowUpRight,ChevronDown,GripVertical} from 'lucide-react';
import {useEffect,useRef,useState} from 'react';
import IssueList from './issue-list';
import HelpHint from './help-hint';
import StockOverview from './stock-overview';
import ShopProfit from './shop-profit';
import OrderSources from './order-sources';
import OrderCostTrial from './order-cost-trial';
import {projectTrial,trialOrders} from '../lib/order-cost-trial';
import {useQcTrial} from './use-qc-trial';
import {displayDate} from '../lib/display-date';
const facebookShippingPerOrder=10000;
const money=(n:number)=>Number(n).toLocaleString('vi-VN')+' đ';
const num=(n:number)=>Number(n).toLocaleString('vi-VN');
export default function Overview({query,expenseOnly=false}:{query:string;expenseOnly?:boolean}){
 const qcTrial=useQcTrial();
 const [shopOrder,setShopOrder]=useState<string[]>(sourceChannels.map(shop=>shop.id));
 const [orderMessage,setOrderMessage]=useState('');
 const draggedShop=useRef<string|null>(null);
 const orderKey='ln-overview-shop-order';
 useEffect(()=>{
  try{
   const saved=JSON.parse(localStorage.getItem(orderKey)||'null');
   if(Array.isArray(saved)){
    const valid=saved.filter((id,index)=>sourceChannels.some(shop=>shop.id===id)&&saved.indexOf(id)===index);
    setShopOrder([...valid,...sourceChannels.map(shop=>shop.id).filter(id=>!valid.includes(id))]);
   }
  }catch{setOrderMessage('Chưa đọc được thứ tự đã lưu trên trình duyệt.');}
 },[]);
 function moveShop(id:string,position:number){
  const next=shopOrder.filter(shop=>shop!==id);
  next.splice(Math.max(0,Math.min(position,next.length)),0,id);
  setShopOrder(next);
  try{localStorage.setItem(orderKey,JSON.stringify(next));setOrderMessage('Đã lưu thứ tự trên trình duyệt này.');}
  catch{setOrderMessage('Đã đổi thứ tự. Trình duyệt chưa cho phép lưu lại.');}
 }
 const orderedShops=shopOrder.map(id=>sourceChannels.find(shop=>shop.id===id)!);
 const [detail,setDetail]=useState('');
 function showDetail(id:string){setDetail(id);requestAnimationFrame(()=>document.getElementById('command-details')?.scrollIntoView({block:'start'}));}
 const [data,setData]=useState<any>(null),[error,setError]=useState(''),[loading,setLoading]=useState(false);const seq=useRef(0);
 async function load(){const n=++seq.current;setLoading(true);try{const r=await fetch('/api/overview?'+query,{cache:'no-store'}),v=await r.json() as any;if(!r.ok)throw Error(v.error);if(n===seq.current){setData(v);setError('');}}catch(e){if(n===seq.current){setData(null);setError((e as Error).message);}}finally{if(n===seq.current)setLoading(false);}}
 useEffect(()=>{setData(null);void load();return()=>{seq.current++;};},[query]);
 const maySync=Boolean(data?.canReviewProfit!==undefined);
 const [adsMessage,setAdsMessage]=useState('');
 useEffect(()=>{
  if(expenseOnly||!maySync)return;
  let active=true,running=false;
  async function refresh(){
   if(running||document.hidden)return;
   running=true;
   try{
    const res=await fetch('/api/finance',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'refresh-facebook-ads'})});
    const parsed=await res.json() as any;
    if(!res.ok)throw Error(parsed.error||'Chưa đọc được nguồn Facebook');
    if(active){
     setAdsMessage((parsed.results||[]).filter((row:any)=>row.error).map((row:any)=>row.provider+' · '+row.error).join(' / '));
     await load();
    }
   }catch(e){if(active){setAdsMessage((e as Error).message);await load();}}
   finally{running=false;}
  }
  void refresh();
  const timer=setInterval(refresh,60000);
  document.addEventListener('visibilitychange',refresh);
  return ()=>{active=false;clearInterval(timer);document.removeEventListener('visibilitychange',refresh);};
 },[maySync,query,expenseOnly]);
 const channels=sourceChannels.map(c=>c.id);
 const sources=data?.orderSources?.rows||[];
 const byShop=(id:string)=>sources.find((r:any)=>r.id===id);
 const hourly=Boolean(data?.range.fromTime||data?.range.toTime);
 const reviews=hourly?{}:data?.reviews||{};
 const closed=channels.filter(id=>reviews[id]).length;
 const total=(values:(number|null|undefined)[],format=money)=>values.every(Number.isFinite)?format(values.reduce<number>((a,b)=>a+b!,0)):'Chờ nguồn';
 const metric=(key:string,format=money)=>total(channels.map(id=>byShop(id)?.[key]),format);
 const cost=(key:string)=>total(channels.map(id=>reviews[id]?.[key]??data?.costs?.[id]?.[key]));
 const value=(n:any,format=num)=>Number.isFinite(n)?format(n):'Chờ nguồn';
 function tile(label:string,amount:string,note:string,destination:string,featured=false){
  const content=<><span className="cmd-label">{label}<ArrowUpRight size={15} aria-hidden="true"/></span><strong>{amount}</strong><small>{note}</small></>;
  const cls='cmd-tile'+(featured?' cmd-featured':'');
  return destination.startsWith('#')?<button type="button" className={cls} onClick={()=>showDetail(destination.slice(1))}>{content}</button>:<a className={cls} href={destination}>{content}</a>;
 }
 const [incomeTaxStatus,setIncomeTaxStatus]=useState('');
 const incomeTax=data?.businessIncomeTax;
 async function saveBusinessIncomeTax(event:React.FormEvent<HTMLFormElement>){
  event.preventDefault();
  const fields=new FormData(event.currentTarget);
  try{
   const response=await fetch('/api/shop-profit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'business-income-tax',enabled:fields.has('enabled'),rate:Number(fields.get('rate'))})});
   if(!response.ok)throw Error((await response.json() as {error?:string}).error||'Chưa lưu được cài đặt TNCN.');
   await load();
   setIncomeTaxStatus('Đã lưu cách tính thuế TNCN toàn shop.');
  }catch(error){setIncomeTaxStatus((error as Error).message);}
 }
 const policies:any[]=Array.isArray(data?.feePolicies)?data.feePolicies:[];
 const [feeMessage,setFeeMessage]=useState('');
 async function saveTax(e:React.FormEvent<HTMLFormElement>){
  e.preventDefault();
  const f=new FormData(e.currentTarget);
  try{
   const res=await fetch('/api/shop-profit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'overview-tax',rate:Number(f.get('rate')),inclusive:f.getAll('inclusive')})});
   if(!res.ok){const failure=await res.json() as {error?:string};throw Error(failure.error||'Không lưu được cài đặt');}
   await load();setFeeMessage('Đã lưu cách tính thuế.');
  }catch(err){setFeeMessage((err as Error).message);}
 }
 async function saveRate(e:React.FormEvent<HTMLFormElement>){
  e.preventDefault();const f=new FormData(e.currentTarget);
  try{const res=await fetch('/api/shop-profit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'fee-rate',channel:f.get('channel'),rate:Number(f.get('rate')),starts:f.get('starts')})});
   if(!res.ok)throw Error((await res.json() as any).error);await load();setFeeMessage('Đã lưu tỷ lệ phí sàn.');
  }catch(err){setFeeMessage((err as Error).message);}
 }
 function summary(shop:typeof sourceChannels[number]){
  const row=byShop(shop.id), review=reviews[shop.id], costs=review??data.costs?.[shop.id];

  const shopeeNet=shop.id==='shopee'&&!review;
  const isTikTok=shop.id==='tiktok1'||shop.id==='tiktok2';
  const tiktokNet=isTikTok&&!review&&row?.report==='pos';
  const rates=policies.filter(r=>r.channel===shop.id);
  const policy=rates.find(r=>r.starts<=(data?.range.from||'2000-01-01'));
  const mixed=rates.some(r=>r.rate!==policy?.rate&&r.starts>(data?.range.from||'2000-01-01')&&r.starts<=(data?.range.to||'2099-12-31'));
  const rateIncludesTax=(shop.id==='tiktok1'&&policy?.rate===27.31)||(shop.id==='tiktok2'&&policy?.rate===33.65);
  const shopeeFeeRate=36.54;
  const shopeeBase=shopeeNet&&Number.isFinite(row?.sales)&&Number.isFinite(row?.discount)
   ? Math.max(0,row.sales-row.discount):null;
  const feeBase=shopeeNet?shopeeBase:isTikTok?row?.revenue:row?.sales;
  const estimate=shopeeNet?(costs?.platform==null&&shopeeBase!=null?Math.round(shopeeBase*shopeeFeeRate/100):null):!review&&costs?.platform==null&&policy&&!mixed&&(data?.range.to||isTikTok)&&Number.isFinite(feeBase)?Math.round(Math.max(0,feeBase)*policy.rate/100):null;
  const dailyFacebook=shop.id==='facebook'&&!review&&data.range.from&&data.range.from===data.range.to;
  const estimatedShipping=dailyFacebook&&costs&&costs.shipping==null&&Number.isFinite(row?.confirmed)
   ? row.confirmed*facebookShippingPerOrder : null;
  const platform=costs?.platform??estimate;
  const rate=shop.id==='facebook'?data.overviewTax?.rate:1.5;
  const taxBase=shopeeNet?shopeeBase:isTikTok?feeBase:row?.sales;
  const provisional=Number.isFinite(taxBase)&&Number.isFinite(rate)?Math.round(Math.max(0,taxBase)*rate/100):null;
  const tax=shopeeNet?(costs?.withheld??costs?.tax??provisional):(costs?.tax??provisional);
  const bundled=!shopeeNet&&!review&&shop.id!=='facebook'&&(data.overviewTax?.inclusive.includes(shop.id)||(rateIncludesTax&&estimate!=null))&&Number.isFinite(platform)&&(Number.isFinite(costs?.withheld)||Number.isFinite(taxBase));
  const included=bundled?Math.min(platform,costs?.withheld??Math.round(Math.max(0,taxBase)*0.015)):0;
  // Shopee POS profit already reflects settlement fees and withheld tax.
  const entries=[costs?.ads,costs?.other,estimatedShipping];
  if(tiktokNet)entries.unshift(tax);
  else if(!shopeeNet)entries.unshift(platform==null?null:platform-included,tax);
  const known=entries.filter((n):n is number=>Number.isFinite(n));
  const expense=known.reduce((sum,n)=>sum+n,0);
  const expenseLabel=known.length?money(expense)+(!review?' · tạm tính':''):'Chờ nguồn';
  const margin=review?review.revenue-review.cogs:row?.profit;
  if(hourly)return {platform:null,tax:null,rate,included:0,row,review:undefined,costs:undefined,policy,estimate:null,shopeeFeeRate,shopeeBase:null,tiktokNet:false,estimatedShipping:null,margin:null,expense:null,expenseLabel:'Xem theo ngày',profit:null};
  const profit=Number.isFinite(margin)&&(shopeeNet||tiktokNet||known.length)?margin-expense:null;
  return {platform,tax,rate,included,row,review,costs,policy,estimate,shopeeFeeRate,shopeeBase,tiktokNet,estimatedShipping,margin,expense:shopeeNet||tiktokNet||known.length?expense:null,expenseLabel,profit};
 }
 const figures=data?sourceChannels.map(summary):[];
 const partialCost=(values:(number|null|undefined)[])=>{
  const known=values.filter((v):v is number=>typeof v==='number'&&Number.isFinite(v));
  return known.length?money(known.reduce((a,b)=>a+b,0)):'Chờ nguồn';
 };
 const totalKnown=figures.some(f=>f.expense!=null)?money(figures.reduce((sum,f)=>sum+(f.expense??0),0)):'Chờ nguồn';
 const provisionalNet=figures.length&&figures.every(f=>Number.isFinite(f.margin))&&figures.some(f=>f.expense!=null)?money(figures.reduce((sum,f)=>sum+(f.profit??f.margin),0)):'Chờ nguồn';
 const trialFigures=figures.map((f,i)=>{
  const id=sourceChannels[i].id,scope=!hourly&&!expenseOnly&&id!=='facebook'?trialOrders(query,data,id):null;
  return scope?projectTrial(qcTrial.rates[id]??'',scope.count,f.profit,f.expense,f.costs?.ads):{active:false,profit:f.profit,expense:f.expense,qc:null};
 });
 const hasTrial=trialFigures.some(f=>f.active);
 const trialTotal=(key:'profit'|'expense')=>trialFigures.length&&trialFigures.every(f=>Number.isSafeInteger(f[key]))?money(trialFigures.reduce((sum,f)=>sum+f[key]!,0)):'Chưa đủ dữ liệu';
 const shownCost=hasTrial?trialTotal('expense'):totalKnown;
 const shownProfit=hasTrial?trialTotal('profit'):provisionalNet;
 const taxEnabled=!hourly&&incomeTax?.enabled===true;
 const incomeTaxRate=incomeTax?.rate??17;
 const incomeTaxOn=(profit:number|null|undefined)=>taxEnabled&&typeof profit==='number'&&Number.isFinite(profit)
  ? Math.round(Math.max(0,profit)*incomeTaxRate/100):null;
 const allShopProfit=trialFigures.length===sourceChannels.length&&trialFigures.every(f=>typeof f.profit==='number'&&Number.isFinite(f.profit))
  ? trialFigures.reduce((sum,f)=>sum+f.profit!,0):null;
 const allShopIncomeTax=incomeTaxOn(allShopProfit);

 const ops=Boolean(data?.stock);
 const [livePacking,setLivePacking]=useState<{facebook:number;marketplace:number;observedAt:string}|null>(null);
 const [livePackingError,setLivePackingError]=useState(false);
 useEffect(()=>{
  if(expenseOnly)return;
  const controller=new AbortController();
  let reading=false;
  async function refreshPacking(){
   if(reading||document.visibilityState!=='visible')return;
   reading=true;
   try{
    const response=await fetch('/api/packing-pos',{cache:'no-store',signal:controller.signal});
    if(!response.ok)throw Error('Chưa đọc được POS');
    const value=await response.json();
    if(!Number.isSafeInteger(value.facebook)||!Number.isSafeInteger(value.marketplace))throw Error('Số POS chưa hợp lệ');
    if(!controller.signal.aborted){setLivePacking(value);setLivePackingError(false);}
   }catch{
    if(!controller.signal.aborted)setLivePackingError(true);
   }finally{reading=false;}
  }
  void refreshPacking();
  const timer=setInterval(refreshPacking,10000);
  document.addEventListener('visibilitychange',refreshPacking);
  window.addEventListener('focus',refreshPacking);
  return ()=>{controller.abort();clearInterval(timer);document.removeEventListener('visibilitychange',refreshPacking);window.removeEventListener('focus',refreshPacking);};
 },[expenseOnly]);
 const storedPacking=data?.pendingConfirmation;
 const packing=livePacking&&(!storedPacking?.observedAt||livePacking.observedAt>=storedPacking.observedAt)?livePacking:storedPacking;
 const packingReady=Number.isSafeInteger(packing?.facebook)&&Number.isSafeInteger(packing?.marketplace);
 const packingTime=packingReady?new Date(packing.observedAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}):'';
 const [packingMessage,setPackingMessage]=useState('');
 const [savingPacking,setSavingPacking]=useState(false);
 async function savePacking(event:React.FormEvent<HTMLFormElement>){
  event.preventDefault();
  if(savingPacking)return;
  const fields=new FormData(event.currentTarget);
  setSavingPacking(true);
  try{
   const response=await fetch('/api/packing-pos',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({facebook:Number(fields.get('facebook')),marketplace:Number(fields.get('marketplace'))})});
   const result=await response.json();
   if(!response.ok)throw Error(result.error||'Chưa lưu được số POS');
   setPackingMessage('Đã lưu tổng từ hai bộ lọc POS.');
   await load();
  }catch(error){setPackingMessage((error as Error).message);}
  finally{setSavingPacking(false);}
 }
 const boards=hourly?[['orders','Đơn theo từng shop']]:[['orders','Đơn theo từng shop'],['profit','Lợi nhuận và đối soát']];
 if(expenseOnly)return <section className="panel overview"><div className="returns-section-head"><h2>Tổng quan chi phí theo shop</h2><button className="btn" onClick={load} disabled={loading}>Tải lại chi phí</button></div>
 {error&&<p role="alert">{error}</p>}{!data&&!error&&<p>Đang tải chi phí…</p>}
 {data&&(data.canReviewProfit===undefined?<p>Quyền hiện tại chưa xem được chi phí theo shop.</p>:<>
 <p><strong>{totalKnown}</strong> · {closed===4?'Đã đối soát cả 4 shop':'Tạm tính theo các khoản đã có'} · {closed}/4 shop đã đối soát · {rangeLabel(data.range)}</p>
 <div className="table-scroll"><table className="finance-table"><thead><tr>{['Shop','Phí sàn sau tách thuế','Thuế','Quảng cáo','Chi phí khác','Cước tạm tính bổ sung','Tổng chi phí'].map(h=><th key={h}>{h}</th>)}</tr></thead>
 <tbody>{sourceChannels.map((shop,i)=>{const f=figures[i];return <tr key={shop.id}><th>{shop.name}</th><td>{value(f.platform==null?null:f.platform-f.included,money)}{f.estimate!=null&&<small>Ước tính theo tỷ lệ</small>}</td><td>{value(f.tax,money)}{f.tax!=null&&f.costs?.tax==null&&<small>Tạm tính</small>}</td><td>{value(f.costs?.ads,money)}</td><td>{value(f.costs?.other,money)}</td><td>{f.estimatedShipping==null?'—':money(f.estimatedShipping)}</td><td><strong>{f.expenseLabel}</strong>{f.review&&<small>Đã đối soát</small>}</td></tr>})}</tbody></table></div>
 <p className="muted">Tổng theo các khoản trừ thêm vào lãi của Bảng tổng quan. Phí sàn đã nằm trong lãi POS hiển thị để đối chiếu. Khoản chờ nguồn sẽ được bổ sung khi có dữ liệu. Xem chi phí chung, nhân sự và chứng từ từng shop trong sổ bên dưới.</p>
 <details><summary>Đối soát và chỉnh số thực tế theo shop</summary><ShopProfit data={data.orderSources} costs={data.costs} reviews={data.reviews} range={data.range} canReview={data.canReviewProfit} refresh={load}/></details></>)}</section>;
 return <div className="overview command-overview"><div className="panel-title"><div>{data&&<p className="muted">Cập nhật lúc {new Date(data.updatedAt).toLocaleTimeString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',hourCycle:'h23'})}</p>}</div><button className="btn" onClick={load} disabled={loading}>{loading?'Đang tải…':'Cập nhật'}</button></div>
 {error&&<p role="alert" className="notice">{error}</p>}{loading&&!data&&<p role="status">Đang lấy số liệu trong kỳ…</p>}
 {data&&<>{hourly&&<p className="notice">Lọc theo giờ Việt Nam áp dụng cho báo cáo bán hàng POS. Kho, công nợ và các nguồn chỉ có ngày vẫn hiển thị theo kỳ ngày. Chi phí và lãi theo shop xem ở chế độ trọn ngày.</p>}{ops&&<><h3>Kinh doanh trong kỳ và kho hiện tại</h3><div className="cmd-grid ov-top-metrics">
 {tile('Doanh số',metric('sales'),'Facebook · TikTok 1 · TikTok 2 · Shopee','#orders',true)}
 {tile('Đơn chốt',metric('confirmed',num),'SL chốt (sản phẩm): '+metric('quantity',num),'#orders')}
 {tile('Chờ xác nhận đóng gói',packingReady?num(packing.facebook+packing.marketplace):'Chờ số POS',packingReady?(livePacking&&!livePackingError?'POS trực tiếp · ':'Số gần nhất · ')+packingTime:'FB_MOI + TMĐT_CHỜ_XỬ_LÝ','#pending-packing')}
 {tile(hasTrial?'Chi phí tạm tính':'Chi phí',hourly?'Xem theo ngày':shownCost,hasTrial?'Đã tính QC tạm · chỉ xem':closed===4?'Đã đối soát':'Tạm tính theo khoản đã có','#profit')}
 {tile(!hasTrial&&closed===4?'Lợi nhuận sau chi phí':'Lãi tạm tính',hourly?'Xem theo ngày':shownProfit,hasTrial?'Đã trừ QC tạm · còn khoản chờ nguồn':closed===4?'Đã đối soát':'Chỉ trừ các khoản đã có số liệu','#profit',true)}
 <StockOverview from={data.range.from} to={data.range.to} compact revision={data.updatedAt}/></div>{adsMessage&&<p role="status">Đang hiển thị chi phí Facebook đã lưu. {adsMessage}</p>}<div className="ov-shop-heading"><h3>Kết quả theo shop</h3><HelpHint label="Sắp xếp shop">Kéo biểu tượng cạnh tên shop để đổi thứ tự, hoặc chọn vị trí.</HelpHint></div>{orderMessage&&<p className="muted" role="status">{orderMessage}</p>}<div className="cmd-shops">{orderedShops.map((shop,position)=>{
  const {tax,rate,included,row,review,costs,policy,estimate,shopeeFeeRate,shopeeBase,tiktokNet,estimatedShipping,expenseLabel,profit}=summary(shop);
  // The aggregate includes packing and, for marketplace shops, return costs.
  const otherDisplay=Number.isFinite(costs?.other)
   ? costs.other-(review?0:(costs.packing??0)+(shop.id==='facebook'?0:(costs.returnCost??0)))
   : null;
  const shopeeNet=shop.id==='shopee'&&!review;
  const projected=trialFigures[sourceChannels.findIndex(s=>s.id===shop.id)];
  const shopIncomeTax=incomeTaxOn(projected?.profit);
  const account=marketplaceAccounts.find(a=>a.channel===shop.id);
  return <article key={shop.id}
   onDragOver={event=>{if(draggedShop.current){event.preventDefault();event.dataTransfer.dropEffect='move';}}}
   onDrop={event=>{event.preventDefault();const id=draggedShop.current;draggedShop.current=null;if(id&&id!==shop.id)moveShop(id,position);}}>
   <div className="shop-order-controls">
    <button type="button" draggable className="shop-drag-handle" aria-label={'Kéo để di chuyển '+shop.name} title="Kéo để đổi thứ tự. Dùng phím mũi tên khi chọn nút."
     onDragStart={event=>{draggedShop.current=shop.id;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',shop.id);}}
     onDragEnd={()=>{draggedShop.current=null;}}
     onKeyDown={event=>{const offsets:Record<string,number>={ArrowLeft:-1,ArrowUp:-1,ArrowRight:1,ArrowDown:1};const offset=offsets[event.key];if(offset){event.preventDefault();moveShop(shop.id,position+offset);}}}>
     <GripVertical size={18} aria-hidden="true"/>
    </button>
   <a className="cmd-shop-name" href={'/don-hang?view='+shop.id}><strong>{shop.name}</strong><ArrowUpRight size={15} aria-hidden="true"/></a>
    <label>Vị trí <select aria-label={'Vị trí '+shop.name} value={position} onChange={event=>moveShop(shop.id,Number(event.target.value))}>
     {sourceChannels.map((_,index)=><option key={index} value={index}>{index+1}</option>)}
    </select></label>
   </div>

   <small className="shop-account">{account?.shopCode?account.name+' · '+account.shopCode:null}</small>
   <p className="cmd-shop-counts">Đơn chốt <b>{value(row?.confirmed)}</b> · SP bán <b>{value(row?.quantity)}</b></p>

   <dl>
    <div><dt>{shopeeNet?'Doanh thu sau khấu trừ POS':'Doanh thu'}</dt><dd>{value(review?.revenue??row?.revenue,money)}</dd></div>
    <div><dt>{shopeeNet?'Chi phí ngoài sàn':tiktokNet?'Chi phí trừ thêm':'Tổng chi phí'}</dt><dd>{projected?.active?(projected.expense===null?'Chưa đủ dữ liệu':money(projected.expense)+' · gồm QC tạm'):expenseLabel}</dd></div>
    {shop.id==='facebook'?<div><dt>{review?'Lợi nhuận sau chi phí':'Lãi tạm tính'}</dt><dd>{value(profit,money)}</dd></div>:<OrderCostTrial key={query+'|'+shop.id} query={query} data={data} shopId={shop.id} displayedProfit={projected?.profit??null} raw={qcTrial.rates[shop.id]??''} onChange={v=>qcTrial.changeRate(shop.id,v)} storageError={qcTrial.storageError} profitLabel={review?'Lợi nhuận sau chi phí':'Lãi tạm tính'}/>}
    {taxEnabled&&<div><dt>TNCN tạm tính · {num(incomeTaxRate)}% lãi</dt><dd>{value(shopIncomeTax,money)}</dd></div>}
    {taxEnabled&&shop.id!=='facebook'&&<div><dt>TNCN sàn đã khấu trừ</dt><dd>{value(data.costs?.[shop.id]?.withheldPit,money)}</dd></div>}
   </dl>
   {shop.id==='facebook'&&<div className="fb-count-totals" aria-label="Tổng số lượng xử lý Facebook" title="Nguồn: Doanh số đơn hàng · Số thành công xử lý, không phải trạng thái giao hàng POS"><a href="/don-hang?view=facebook"><span>SL ban đầu</span><strong>{data.counts?.rows>0?value(data.counts.initial):'Chờ nguồn'}</strong></a><a href="/don-hang?view=facebook"><span>SL thành công</span><strong>{data.counts?.rows>0?value(data.counts.completed):'Chờ nguồn'}</strong></a></div>}
   <details><summary>Chi tiết chi phí và đơn hoàn</summary>
   {tiktokNet&&<p>Lãi POS đã phản ánh phí sàn POS. Dòng phí sàn dùng để đối chiếu. PM trừ thêm quảng cáo, chi phí khác và thuế theo cấu hình.</p>}
   {shopeeNet&&<p>Lãi lấy từ POS sau phí sàn, thuế khấu trừ và giá vốn, rồi trừ quảng cáo và chi phí ngoài sàn.</p>}
   {estimatedShipping!=null&&<p>Cước tạm trừ trong lãi ngày: {num(row.confirmed)} đơn chốt × {money(facebookShippingPerOrder)} = {money(estimatedShipping)}. Chưa gồm phụ trội cân nặng.</p>}
   {shop.id==='facebook'&&!review&&costs?.shipping!=null&&<p>Cước đã ghi nhận trong chi phí khác: {money(costs.shipping)}.</p>}
   {shop.id==='facebook'&&data.shipping?.sent!=null&&<p>Theo ngày tạo đơn: {num(data.shipping.sent)} đơn đã gửi. Ship khách dự kiến trả trên đơn đã nhận/thu tiền: {num(data.shipping.single)} đơn 1 SP × 20.000 đ = {money(data.shipping.single*20000)}.</p>}
   <dl>{[
    ['Đơn hoàn / đơn chốt trong kỳ',Number.isFinite(row?.returnedOrders)&&row?.confirmed>0?num(row.returnedOrders)+' / '+num(row.confirmed)+' · '+(100*row.returnedOrders/row.confirmed).toLocaleString('vi-VN',{maximumFractionDigits:1})+'%':'—'],
    ...(shop.id==='facebook'&&!review?[['Tổng chi quảng cáo',value(costs?.ads,money)],['Lãi sau quảng cáo · tạm tính',Number.isFinite(row?.profit)&&Number.isFinite(costs?.ads)?money(row.profit-costs.ads):'Chờ nguồn']]:[]),
    ...(shop.id!=='facebook'?[[shopeeNet?'Doanh số POS trước giảm giá':'Doanh số POS trước phí',value(row?.sales,money)],[(shopeeNet||tiktokNet?'Phí sàn · đối chiếu':'Phí sàn')+(estimate!=null?' · '+(shopeeNet?shopeeFeeRate:policy.rate)+'% ước tính':''),value(costs?.platform??estimate,money)]]:[]),
    ...(shopeeNet?[['Cơ sở ước tính · doanh số POS sau giảm giá',value(shopeeBase,money)]]:[]),
    ...((shop.id==='tiktok1'||shop.id==='tiktok2')&&estimate!=null?[['Cơ sở phí tạm · doanh thu POS sau giảm giá và hoàn tiền',value(row?.revenue,money)]]:[]),
    ...(shop.id!=='facebook'?[['Quảng cáo',value(costs?.ads,money)]]:[]),
    ...(!review?[['Bao bì / đóng gói',value(costs?.packing,money)],[shop.id==='facebook'?'Phí hoàn · chỉ theo dõi':'Chi phí hàng hoàn',value(costs?.returnCost,money)]]:[]),
    [shopeeNet?(costs?.withheld!=null||costs?.tax!=null?'Thuế sàn khấu trừ · đối chiếu':'Thuế sàn khấu trừ · 1,5% ước tính'):costs?.tax!=null?'Thuế đã đối soát':shop.id==='facebook'?'Thuế tạm tính · '+rate+'%':'Thuế sàn khấu trừ · ước tính 1,5%',value(tax,money)],
    ...(included>0?[['Phần thuế đã tách khỏi phí sàn',money(included)]]:[]),
    ...(otherDisplay!=null&&otherDisplay!==0?[[review?'Chi phí khác đã đối soát':'Chi phí khác',money(otherDisplay)]]:[]),
   ].map(([label,amount])=><div key={label}><dt>{label}</dt><dd>{amount}</dd></div>)}</dl></details>
  </article>;
 })}</div>
 <HelpHint label="Cách đọc số liệu">Quảng cáo Facebook được phân bổ cho đơn ngày kế tiếp. Tỷ lệ hoàn so sánh đơn hoàn và đơn chốt phát sinh trong kỳ. Chi phí hoàn lấy theo phiếu đã xác nhận.</HelpHint>
 <IssueList data={data} query={query}/>
 {ops&&<section id="command-details" className="ov-group"><h3>Chi tiết kinh doanh</h3><div className="cmd-switch">{boards.map(([id,label])=><button type="button" key={id} className="btn" aria-expanded={detail===id} onClick={()=>setDetail(detail===id?'':id)}>{label}<ChevronDown size={15}/></button>)}</div>
 {detail==='pending-packing'&&<div>
  <p>{packingReady?'FB_MOI: '+num(packing.facebook)+' · TMĐT_CHỜ_XỬ_LÝ: '+num(packing.marketplace):'Chưa lưu tổng của hai bộ lọc.'}</p>
  <p><a href="https://pos.pancake.vn/shop/6111341/order" target="_blank" rel="noreferrer">Mở hai bộ lọc trong POS</a></p>
  <form className="cmd-switch" onSubmit={savePacking}>
   <label>FB_MOI <input name="facebook" type="number" min="0" max="1000000" required defaultValue={packingReady?packing.facebook:undefined}/></label>
   <label>TMĐT_CHỜ_XỬ_LÝ <input name="marketplace" type="number" min="0" max="1000000" required defaultValue={packingReady?packing.marketplace:undefined}/></label>
   <button className="btn" type="submit" disabled={savingPacking}>{savingPacking?'Đang lưu…':'Lưu số đối chiếu POS'}</button>
  </form>
  {packingMessage&&<p role="status">{packingMessage}</p>}
 </div>}
 {detail==='orders'&&<OrderSources data={data.orderSources}/>}
 {!hourly&&detail==='profit'&&<ShopProfit data={data.orderSources} costs={data.costs} reviews={data.reviews} range={data.range} canReview={data.canReviewProfit} refresh={load}/>}</section>}
<section className="ov-group"><h3>Nhập hàng và công nợ nhà cung cấp</h3><div className="cmd-grid">
{tile('Sản phẩm nhập',value(data.stock.quantity),value(data.stock.receipts)+' phiếu nhập','/nhap-hang')}
{tile('Tiền hàng nhập',value(data.purchasing.imported,money),'Phiếu nhập đã có giá','/nhap-hang?view=legacy')}
{tile('Nợ đầu kỳ',value(data.purchasing.opening,money),'Số dư chuyển sang','/nhap-hang?view=debt')}
{tile('Đã trả nhà cung cấp',value(data.purchasing.paid,money),'Thanh toán trong kỳ','/nhap-hang?view=payments')}
{tile('Còn nợ nhà cung cấp',value(data.purchasing.balance,money),'Số dư cuối kỳ','/nhap-hang?view=debt')}</div></section>
<section className="ov-group"><h3>Xử lý đơn và hàng hoàn</h3><div className="cmd-grid">
{tile('Thao tác xử lý đơn',data.counts.error?'Chờ nguồn':num(data.counts.initial)+' / '+num(data.counts.completed),'Ban đầu / hoàn thành','/don-hang?view=facebook')}
{tile('Hàng hoàn chưa về kho',value(data.returns?.awaitingAllTime),'Tất cả mã đang theo dõi','/don-hang?view=returns&report=awaiting&scope=awaitingAll',true)}
{tile('Hàng hoàn đã quét',value(data.returns?.total),'Mã về kho trong kỳ','/don-hang?view=returns')}</div></section>
<section className="ov-group"><h3>Chi phí và thuế</h3>
 <details><summary>Chi phí trong kỳ</summary><div className="cmd-grid">
 {tile('Phí sàn',partialCost(figures.map(f=>f.platform)),'Gồm phí đã ghi nhận và ước tính','#profit')}
 {tile('Quảng cáo',partialCost(figures.map(f=>f.costs?.ads)),'Tổng các shop đã có số liệu','#profit')}
 {tile('Thuế',total(figures.map(f=>f.tax)),'Theo kỳ và shop','#profit')}
 {tile('Chi phí khác phân bổ',cost('other'),'Theo đối soát lợi nhuận','#profit')}</div>
 </details><p className="cmd-links"><a href="/chi-phi">Sổ chi phí ↗</a><a href="/thue">Hồ sơ thuế ↗</a></p>
 {data.canReviewProfit&&data.overviewTax&&<details className="panel"><summary>Cài đặt thuế tạm tính</summary>
 <form onSubmit={saveTax}><label>Thuế Facebook dự kiến (% doanh số POS) <input required type="number" name="rate" min="0" max="100" step="0.0001" defaultValue={data.overviewTax.rate}/></label>
 <p>Chọn từng shop nếu số phí sàn đã gồm 1,5% thuế. PM tách phần thuế ước tính khỏi phí khi tính lãi. Thiết lập áp dụng cho các kỳ chưa chốt.</p>
 {sourceChannels.filter(c=>c.id!=='facebook').map(c=><label key={c.id}><input type="checkbox" name="inclusive" value={c.id} defaultChecked={data.overviewTax.inclusive.includes(c.id)}/> {c.name} </label>)}
 <button className="btn">Lưu cách tính thuế</button></form><p role="status">{feeMessage}</p>
 <h4>Thuế TNCN theo lãi tạm tính</h4>
 <form className="purch-toolbar" onSubmit={saveBusinessIncomeTax}>
 <label><input type="checkbox" name="enabled" defaultChecked={incomeTax?.enabled===true}/> Áp dụng toàn shop</label>
 <label>Thuế suất TNCN (%)<input required type="number" name="rate" min="0" max="100" step="0.01" defaultValue={incomeTaxRate}/></label>
 <button className="btn">Lưu cách tính TNCN</button>
 </form>
 {taxEnabled&&<p>TNCN toàn shop trong kỳ ước tính <strong>{value(allShopIncomeTax,money)}</strong></p>}
 <p>PM tự lấy lãi tạm tính của kỳ đang chọn. Từng shop hiển thị ước tính riêng. Thuế toàn shop tính trên tổng lãi sau khi cộng cả shop lỗ.</p>
 <p>TNCN đã khấu trừ hiển thị theo chứng từ để đối chiếu riêng khi quyết toán.</p>
 <p role="status">{incomeTaxStatus}</p></details>}
 {data.canReviewProfit&&<details className="panel"><summary>Cài đặt phí sàn (%)</summary>
 <p>TikTok 1 và TikTok 2 dùng doanh thu POS sau giảm giá và hoàn tiền để ước tính phí theo tỷ lệ của từng shop trong kỳ. Phí đã ghi nhận được ưu tiên. Nếu kỳ có nhiều tỷ lệ, chọn khoảng ngày theo từng mức.</p>
 {policies.map(r=><p key={r.channel+r.starts}>{sourceChannels.find(c=>c.id===r.channel)?.name} · {displayDate(r.starts)} · {r.rate}%</p>)}
 <form className="purch-toolbar" onSubmit={saveRate}><label>Shop<select name="channel">{sourceChannels.filter(c=>c.id!=='facebook').map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label><label>Áp dụng từ<input required type="date" name="starts"/></label><label>Phí sàn (%)<input required type="number" min="0" max="100" step="0.01" name="rate"/></label><button className="btn">Lưu tỷ lệ</button></form><p role="status">{feeMessage}</p></details>}
</section>

 </>}
<section className="ov-group"><h3>Nhân sự và lương</h3>
<div className="cmd-grid">
 {tile('Nhân sự đang làm',value(data.people.active),'Hồ sơ nhân viên','/?view=pay')}
 {tile('Chi phí lương',value(data.payroll.earned+data.payroll.employerInsurance,money),'Gồm bảo hiểm phần shop','/?view=pay')}
 {tile('Đã tạm ứng',value(data.payroll.advance,money),'Theo các kỳ lương','/?view=pay')}
 {tile('Lương còn nhận',value(data.payroll.net,money),'Sau tạm ứng và bảo hiểm','/?view=pay')}</div>
 <p className="cmd-links"><a href="/?view=clock">Chấm công · {num(data.people.clockRows)} dòng ↗</a><a href="/?view=insurance">Bảo hiểm ↗</a><a href="/?view=pay">{data.payroll.unlockedMonths.length} kỳ lương chưa chốt ↗</a></p>
 <details className="panel"><summary>Lương ngày lễ và lịch nghỉ</summary><p>Lương nghỉ lễ {money(data.payroll.holidayPay)} · Lương làm lễ {money(data.payroll.holidayWorkedPay)}</p><ul>{data.holidays.upcoming.map((h:any)=><li key={h.date}>{displayDate(h.date)} · {h.name}</li>)}</ul><a href="/?view=pay">Mở bảng lương ↗</a></details>
</section>
 {ops&&<details className="panel"><summary>Lần đồng bộ đơn thành công gần nhất</summary>{[['Facebook',data.sync,'facebook'],['TikTok và Shopee',data.marketplaceSync,'tiktok1']].map(([name,status,view])=><p key={name}><a href={'/don-hang?view='+view}>{name} ↗</a> · {status?.lastSuccess?new Date(status.lastSuccess).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}):'Chưa có mốc thành công'}{(status?.lastError||status?.error)&&<span> · {status.lastError||status.error}</span>}</p>)}</details>}
 </>}</div>;
}
