'use client';
import {useEffect,useRef,useState} from 'react';
import GlobalPeriodBar,{type GlobalPeriod} from './global-period';
import {rangeLabel} from '../lib/date-range';
import {periodPresets,presetRange,vietnamToday} from '../lib/period-presets';
export default function CompactPeriod({period}:{period:GlobalPeriod}){
 const [open,setOpen]=useState(false),root=useRef<HTMLDivElement>(null);
 const today=vietnamToday();
 useEffect(()=>{setOpen(false);},[period.range.from,period.range.to,period.range.fromTime,period.range.toTime]);
 useEffect(()=>{if(!open)return;const outside=(event:PointerEvent)=>{if(!root.current?.contains(event.target as Node))setOpen(false);};const key=(event:KeyboardEvent)=>{if(event.key==='Escape')setOpen(false);};document.addEventListener('pointerdown',outside);document.addEventListener('keydown',key);return()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',key);};},[open]);
 function choose(id:string){const range=presetRange(id,today);period.set({...period.selection,kind:range.from===range.to?'day':'custom',day:range.to,from:range.from,to:range.to,fromTime:'',toTime:''});setOpen(false);}
 return <div className="compact-period" ref={root} aria-label="Lọc thời gian Tổng quan">
  <div className="compact-period-row"><div className="compact-period-choices" role="group" aria-label="Khoảng thời gian">{periodPresets.map(([id,label])=>{const r=presetRange(id,today);const active=!period.range.fromTime&&!period.range.toTime&&r.from===period.range.from&&r.to===period.range.to;return <button key={id} type="button" aria-pressed={active} onClick={()=>choose(id)}>{label}</button>;})}</div><button className="compact-period-custom" type="button" aria-expanded={open} onClick={()=>setOpen(v=>!v)}>Tùy chọn</button><span className="compact-period-range">{!period.range.fromTime&&!period.range.toTime&&period.range.from&&period.range.from===period.range.to?period.range.from.split('-').reverse().join('/'):rangeLabel(period.range)}</span></div>
  {open&&<div className="compact-period-popover" role="dialog" aria-label="Chọn thời gian khác"><GlobalPeriodBar period={period} compact={false}/></div>}
 </div>;
}
