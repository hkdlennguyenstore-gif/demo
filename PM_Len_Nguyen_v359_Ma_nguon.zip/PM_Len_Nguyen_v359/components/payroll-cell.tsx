'use client';
import {useState} from 'react';
import type {PayrollEditField} from '../lib/payroll-edit';

export type PayrollCellField={field:PayrollEditField,label:string,value:number};
export default function PayrollCell({fields,display,employee,month,disabled,onSave}:{fields:PayrollCellField[],display:string|number,employee:string,month:string,disabled:boolean,onSave:(values:Record<string,number|null>)=>Promise<boolean>}){
 const [editing,setEditing]=useState(false),[draft,setDraft]=useState<Record<string,string>>({}),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const label=fields.map(f=>f.label).join(' + ')+' · '+employee+' · '+month;
 async function save(reset=false){
  const values:Record<string,number|null>={};
  for(const f of fields){const raw=draft[f.field]?.trim(),n=Number(raw);if(!reset&&(!raw||!Number.isFinite(n)||n<0)){setError('Nhập số từ 0 trở lên.');return;}values[f.field]=reset?null:n;}
  setBusy(true);setError('');try{if(await onSave(values))setEditing(false);else setError('Chưa lưu được. Kiểm tra thông báo rồi thử lại.');}catch(e){setError((e as Error).message);}finally{setBusy(false);}
 }
 if(!editing)return <button type="button" className="payroll-cell-value" disabled={disabled} aria-label={'Sửa '+label} title={disabled?'Kỳ lương đã chốt':'Bấm để sửa '+fields.map(f=>f.label.toLowerCase()).join(', ')} onClick={()=>{setDraft(Object.fromEntries(fields.map(f=>[f.field,String(f.value??0)])));setError('');setEditing(true);}}>{display}</button>;
 return <form className="payroll-cell-editor" aria-label={'Sửa '+label} onSubmit={e=>{e.preventDefault();void save();}} onKeyDown={e=>{if(e.key==='Escape'&&!busy)setEditing(false);}}>
  {fields.map((f,i)=><label key={f.field}>{f.label}<input autoFocus={i===0} type="number" inputMode="decimal" min="0" step={['days','overtime','holidayDays'].includes(f.field)?'any':'1'} aria-label={f.label+' · '+employee+' · '+month} value={draft[f.field]??''} disabled={busy||disabled} onChange={e=>setDraft({...draft,[f.field]:e.target.value})}/></label>)}
  {error&&<span role="alert" className="red">{error}</span>}
  <div className="payroll-cell-actions"><button type="submit" className="btn primary" disabled={busy||disabled}>{busy?'Đang lưu…':'Lưu'}</button><button type="button" className="btn" disabled={busy} onClick={()=>setEditing(false)}>Hủy</button></div>
  <button type="button" className="text-btn" disabled={busy||disabled} onClick={()=>void save(true)}>Theo công thức</button>
 </form>;
}
