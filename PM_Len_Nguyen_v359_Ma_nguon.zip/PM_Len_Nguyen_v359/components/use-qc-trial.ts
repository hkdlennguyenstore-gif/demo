'use client';
import {useEffect,useState} from 'react';
import {formatTrialInput} from '../lib/order-cost-trial';
const shops=['tiktok1','tiktok2','shopee'];
const prefix='ln-qc-trial-unit-v1:';
export function useQcTrial(){
 const [rates,setRates]=useState<Record<string,string>>({});
 const [storageError,setStorageError]=useState('');
 useEffect(()=>{
  const read=()=>{try{setRates(Object.fromEntries(shops.map(id=>[id,localStorage.getItem(prefix+id)??''])));setStorageError('');}catch{setStorageError('Trình duyệt chưa cho phép nhớ số QC.');}};
  const changed=(event:StorageEvent)=>{if(event.key===null||event.key.startsWith(prefix))read();};
  read();window.addEventListener('storage',changed);window.addEventListener('pageshow',read);
  return()=>{window.removeEventListener('storage',changed);window.removeEventListener('pageshow',read);};
 },[]);
 function changeRate(shopId:string,value:string){
  const next=formatTrialInput(value);setRates(old=>({...old,[shopId]:next}));
  try{if(next.trim())localStorage.setItem(prefix+shopId,next);else localStorage.removeItem(prefix+shopId);setStorageError('');}
  catch{setStorageError('Trình duyệt chưa cho phép nhớ số QC.');}
 }
 return {rates,changeRate,storageError};
}
