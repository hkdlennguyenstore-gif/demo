import {sourceChannels} from '../lib/order-source-summary';
import {useState} from 'react';
import type {DateRange} from '../lib/date-range';
const money=(v:number|null|undefined)=>v==null?'Chờ nguồn':v.toLocaleString('vi-VN')+' đ';
const labels={revenue:'Doanh thu thuần sau hoàn, trước phí',cogs:'Giá vốn hàng bán',platform:'Phí sàn',tax:'Thuế',ads:'Quảng cáo',other:'Chi phí còn lại phân bổ cho shop'};
export default function ShopProfit({data,costs,reviews,range,canReview,refresh}:{data:any,costs:any,reviews:any,range:DateRange,canReview:boolean,refresh:()=>Promise<void>}){
 const [editing,setEditing]=useState(''),[message,setMessage]=useState(''),[busy,setBusy]=useState(false);
 if(!data&&!canReview&&!reviews)return null;
 const shops:any[]=data?.rows??sourceChannels;
 async function save(event:React.FormEvent<HTMLFormElement>){event.preventDefault();const f=new FormData(event.currentTarget);setBusy(true);setMessage('');
 try{const amounts=Object.fromEntries(Object.keys(labels).map(k=>[k,Number(f.get(k))]));
 const res=await fetch('/api/shop-profit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...amounts,...range,channel:editing,version:reviews?.[editing]?.version??0,reference:f.get('reference')})});
 if(!res.ok)throw Error((await res.json() as any).error);setEditing('');await refresh();
 }catch(e){setMessage((e as Error).message);}finally{setBusy(false);}}
 return <section className="panel"><h2>Doanh số và lợi nhuận theo shop</h2><div className="table-scroll" tabIndex={0}><table><thead><tr>{['Shop','Lợi nhuận trước chi phí','Phí sàn','Thuế','Quảng cáo','Chi phí khác','Lợi nhuận sau chi phí','Đối soát'].map(label=><th key={label}>{label}</th>)}</tr></thead><tbody>
 {shops.map((row:any)=>{const review=reviews?.[row.id],c=review||costs?.[row.id];const gross=review?review.revenue-review.cogs:row.profit;
 const after=review?gross-review.platform-review.tax-review.ads-review.other:null;
 return <tr key={row.id}><th>{row.name}</th><td><strong>{money(gross)}</strong><small>{review?'Doanh thu thuần − giá vốn':'Theo POS'}</small></td><td>{money(c?.platform)}</td><td>{money(c?.tax)}</td><td>{money(c?.ads)}</td><td>{money(c?.other)}</td><td><strong>{after===null?'Chờ đối soát':money(after)}</strong></td><td>{review&&<details><summary>Đã đối soát</summary><p>{review.reference}</p><p>Doanh thu thuần {money(review.revenue)} · Giá vốn {money(review.cogs)}</p></details>}{canReview&&range.from&&range.to&&!reviews?.error&&<button className="text-btn" onClick={()=>{setMessage('');setEditing(row.id)}}>{review?'Cập nhật':'Đối soát kỳ này'}</button>}</td></tr>})}</tbody></table></div>
 <p className="muted">Trước đối soát, PM hiển thị lợi nhuận POS và chi phí đã ghi nhận. Sau đối soát, lợi nhuận trước chi phí bằng doanh thu thuần trừ giá vốn. Lợi nhuận sau chi phí trừ tiếp bốn cột chi phí của cùng shop và cùng kỳ.</p>{(costs?.error||reviews?.error)&&<p role="alert">{costs?.error||reviews.error}</p>}
 {editing&&<form className="panel" key={editing+range.from+range.to} onSubmit={save}><h3>Đối soát {shops.find((r:any)=>r.id===editing)?.name} · {range.from} – {range.to}</h3><p>Nhập số đã kiểm tra theo chứng từ. Mỗi khoản chỉ tính một lần. Nhập 0 khi xác nhận không phát sinh.</p>{Object.entries(labels).map(([k,l])=><label key={k}>{l} (đ)<input type="number" step="1" min={k==='revenue'?undefined:0} required defaultValue={reviews?.[editing]?.[k]??costs?.[editing]?.[k]??''} name={k}/></label>)}<label>Căn cứ đối soát<input name="reference" required maxLength={500} defaultValue={reviews?.[editing]?.reference}/></label><button className="btn" disabled={busy}>Lưu đối soát</button> <button className="text-btn" type="button" onClick={()=>setEditing('')}>Đóng</button>{message&&<p role="alert">{message}</p>}</form>}</section>
}
