import {useEffect,useState} from 'react';
export default function IssueList({data,query}:{data:any,query:string}){
 const [issue,setIssue]=useState(''),[page,setPage]=useState(1),[result,setResult]=useState<any>(null);
 useEffect(()=>{if(!issue)return;const controller=new AbortController();setResult(null);
 fetch('/api/overview?'+query+'&issue='+issue+'&page='+page,{signal:controller.signal,cache:'no-store'}).then(async r=>{const body=await r.json() as any;if(!r.ok)throw Error(body.error);return body;}).then(setResult).catch(e=>{if(!controller.signal.aborted)setResult({error:e.message});});
 return ()=>controller.abort();},[issue,page,query]);
 const counters=[['missing','Chấm công thiếu giờ',data.people.missing],['supplier','Phiếu nhập chờ nhà cung cấp',data.stock.pendingSupplier],['price','Phiếu nhập chờ đối chiếu giá',data.stock.unpriced],['leave','Đơn xin nghỉ chờ duyệt',data.leave.pending]];
 const waiting = data.returns?.awaitingAllTime;
 const renderCounter = ([id,label,n]: any[]) => (
   <button type="button" className="btn" data-pending={Number(n)>0} key={id}
     disabled={n==null} onClick={()=>{setPage(1);setIssue(id);}}>
     {label} <strong>{n??'Chờ nguồn'}</strong>
   </button>
 );
 const clear = counters.filter(([, , n])=>n===0);
 return <section className="ov-group ov-issues"><h2>Việc cần xử lý</h2>
 <div className="cmd-issues"><a className="btn" data-pending={Number(waiting)>0}
   href="/don-hang?view=returns&report=awaiting&scope=awaitingAll">
   Hoàn chưa về kho <strong>{waiting??'Chờ nguồn'}</strong></a>
   {counters.filter(([, , n])=>n!==0).map(renderCounter)}
 </div>
 {clear.length>0&&<details><summary>Không có việc chờ ({clear.length} mục)</summary>
   <div className="cmd-issues">{clear.map(renderCounter)}</div></details>}
 {issue&&<div><h3>{counters.find(r=>r[0]===issue)?.[1]}</h3>{!result?<p>Đang tải…</p>:result.error?<p role="alert">{result.error}</p>:result.rows.length?<ul>{result.rows.map((r:string[],i:number)=><li key={i}>{r.join(' · ')}</li>)}</ul>:<p>Không có dòng nào trong kỳ.</p>}
 {page>1&&<button onClick={()=>setPage(page-1)}>Trang trước</button>}{result?.more&&<button onClick={()=>setPage(page+1)}>Trang sau</button>} <button className="text-btn" onClick={()=>setIssue('')}>Đóng danh sách</button></div>}</section>
}
