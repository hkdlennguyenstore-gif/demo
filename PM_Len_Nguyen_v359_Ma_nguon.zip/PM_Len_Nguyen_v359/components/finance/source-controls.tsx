'use client';
import {useState} from 'react';
import type {Line} from '../../lib/expense-lines';
import {financeChannels} from '../../lib/finance';
type Source={key:string;name:string;url?:string;last?:string;rows:Line[];managed?:boolean;error?:boolean};
export default function SourceControls({data,group,rows,save,month}:{data:any;group:string;rows:Line[];save:(a:string,b:any)=>Promise<void>;month:string}){
 const [selected,setSelected]=useState(''),[mode,setMode]=useState(''),[name,setName]=useState(''),[reason,setReason]=useState(''),[message,report]=useState(''),[busy,working]=useState(false);
 const [file,setFile]=useState(''),[preview,setPreview]=useState<any>(null);
 async function checkReplacement(key:string){
  try{const response=await fetch('/api/finance',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'preview-source',version:data.version,requestId:crypto.randomUUID(),data:{key,file}})});const result=await response.json() as any;if(!response.ok)throw Error(result.error);setPreview(result);}catch(e){report((e as Error).message);}
 }
 const sources:Source[]=[];
 if(group==='ads'){
  for(const provider of ['giaminh','flagteam']){
   const sync=data.adsCosts.sync?.find((s:any)=>s.provider===provider);
   sources.push({key:provider,name:provider==='giaminh'?'Gia Minh':'Flagteam',managed:true,rows:rows.filter(r=>r.source===provider),last:sync?.lastSuccess,error:sync?.results?.some((r:any)=>r.error)});
  }
  const feeds=data.driveAds.sources||{};
  const files=Object.entries(feeds).map(([feed,c]:[string,any])=>({id:feed,fileId:c.file,tab:c.tab,...data.driveAds.readSources.find((r:any)=>r.id===feed)}));
  for(const r of data.driveAds.readSources)if(r.fileId&&r.lastSuccess&&!files.some(s=>s.id===r.id)&&!r.id.startsWith('issue:'))files.push(r);
  for(const file of files){
   const url='https://drive.google.com/open?id='+encodeURIComponent(file.fileId);
   sources.push({key:'drive:'+file.id.split(':')[0]+':'+file.fileId,name:file.tab||file.id,url,last:file.lastSuccess,managed:true,rows:rows.filter(r=>r.url===url)});
  }
 }
 const represented=new Set(sources.flatMap(s=>s.rows));
 for(const line of rows.filter(r=>!represented.has(r))){
  const key=line.source||'Nhập tay';let src=sources.find(s=>s.key===key);
  if(!src){src={key,name:key,rows:[]};sources.push(src);}src.rows.push(line);
 }
 async function change(action:string,payload:any){working(true);try{await save(action,payload);report('Đã lưu');setSelected('');}catch(e){report((e as Error).message);}finally{working(false);}}
 return <details><summary>Quản lý nguồn</summary>{!sources.length&&<p>Chưa có nguồn trong kỳ.</p>}
 {sources.map(s=>{const config=data.sourceSettings?.[s.key]||{},dates=s.rows.map(r=>r.date).sort(),status=config.mode==='removed'?'Đã gỡ':config.mode==='paused'?'Tạm dừng':s.error?'Lỗi':s.last?'Đang kết nối':s.managed?'Chờ nguồn':'Theo phiếu gốc';
 function configure(next:string){setSelected(s.key);setMode(next);setName(config.label||s.name);setReason('');setFile('');setPreview(null);report('');}
 return <details key={s.key}><summary>{config.label||s.name} · {status}</summary><p>{Array.from(new Set(s.rows.map(r=>financeChannels[r.shop]))).join(', ')} · {s.rows.length} dòng · {s.rows.reduce((n,r)=>n+r.amount,0).toLocaleString('vi-VN')} ₫</p><p>{dates.length?dates[0]+' → '+dates[dates.length-1]:'Chưa có dòng trong kỳ'} · Lần đồng bộ thành công {s.last?new Date(s.last).toLocaleString('vi-VN'):'chưa ghi nhận'}</p>
 {s.url&&<a href={s.url} target="_blank" rel="noreferrer">Xem nguồn</a>}
 {data.canSetPacking&&s.managed&&<div className="ceactions"><button onClick={()=>configure(config.mode||'active')}>Sửa cấu hình</button><button onClick={()=>configure(config.mode==='paused'||config.mode==='removed'?'active':'paused')}>{config.mode==='paused'||config.mode==='removed'?'Kết nối lại':'Tạm dừng'}</button>{s.key.startsWith('drive:')&&<button onClick={()=>configure('replace')}>Thay nguồn</button>}<button onClick={()=>configure('removed')}>Gỡ kết nối</button>{['giaminh','flagteam'].includes(s.key)&&<button disabled={busy||['paused','removed'].includes(config.mode)} onClick={()=>change('resync-provider',{provider:s.key,month})}>Đồng bộ lại</button>}</div>}
 {selected===s.key&&<section>{mode==='replace'&&<><label>ID tệp Drive đã xác minh<input value={file} onChange={e=>{setFile(e.target.value);setPreview(null);}}/></label><button onClick={()=>checkReplacement(s.key)}>Đối chiếu nguồn thay thế</button>{preview&&<p>{preview.accounts} · {preview.from} → {preview.to} · {preview.rows} dòng · {preview.duplicates} trùng</p>}</>}<label>Tên hiển thị<input value={name} onChange={e=>setName(e.target.value)}/></label><p>{mode==='removed'?'Gỡ kết nối và giữ các khoản đã nhập. Có thể loại từng khoản ở danh sách.':mode==='paused'?'Dừng nhận dữ liệu mới, giữ lịch sử đã nhập.':'Nguồn sẽ tiếp tục đồng bộ.'}</p><label>Lý do<input value={reason} onChange={e=>setReason(e.target.value)}/></label><button disabled={busy||!reason.trim()||(mode==='replace'&&!preview)} onClick={()=>mode==='replace'?change('replace-source',{key:s.key,file,preview,reason}):change('source-mode',{key:s.key,label:name,mode,reason})}>Xác nhận</button><button onClick={()=>setSelected('')}>Hủy</button></section>}</details>})}
 {data.canSetPacking&&<details><summary>Quyền của quản trị viên</summary>{[['edit','Sửa và điều chỉnh'],['exclude','Loại khỏi báo cáo'],['restore','Khôi phục']].map(([key,label])=><label key={key}><input type="checkbox" disabled={busy} checked={data.management.rights[key]===true} onChange={e=>change('expense-rights',{...data.management.rights,[key]:e.target.checked})}/>{label} </label>)}</details>}
 {message&&<p role="status">{message}</p>}</details>
}
