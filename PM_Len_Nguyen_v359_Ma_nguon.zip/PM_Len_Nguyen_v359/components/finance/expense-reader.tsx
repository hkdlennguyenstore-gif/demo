'use client';
import SettlementPreview from './settlement-preview';
import {fileDraft} from './file-draft';
import ZipReview from './zip-review';
import {useEffect,useState} from 'react';
import {loadReader} from './load-expense-reader';
type Entry={id:number;file:File;parsed?:any;pdfs?:any[];error?:string;done?:boolean};
export default function ExpenseReader({group,apply,blocked,queue,footer,owner,onFeesSaved}:any){
 const [entries,setEntries]=useState<Entry[]>(()=>queue?.entries||[]);
 const [busy,working]=useState(false);
 useEffect(()=>{blocked(entries.some(e=>e.parsed||e.pdfs));},[]);
 const draftKey=owner+'|'+group;
 const [draftMessage,setDraftMessage]=useState('');
 useEffect(()=>{if(!entries.length)return;const warn=(event:BeforeUnloadEvent)=>{event.preventDefault();event.returnValue='';};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);},[entries.length]);
 async function draft(restore:boolean){
  try{if(restore){const old=await fileDraft(draftKey,'read');if(!old?.length)throw Error('Chưa có nháp đã lưu trên máy này.');update(old);blocked(old.some((e:Entry)=>e.parsed||e.pdfs));setDraftMessage('Đã mở lại nháp.');}
   else{await fileDraft(draftKey,'save',entries);setDraftMessage('Đã lưu nháp kết quả đọc trên máy này.');}}
  catch(e){setDraftMessage((e as Error).message);}
 }
 function update(next:Entry[]){
   if(queue)queue.entries=next;
   setEntries(next);
 }
 function remove(id:number){
   const remaining=entries.filter(e=>e.id!==id);
   update(remaining);
   blocked(remaining.some(e=>e.parsed||e.pdfs));
 }
 async function read(files:File[]){
   if(!files.length||busy)return;
   const batch=files.map((file,i)=>({id:(entries.at(-1)?.id??0)+i+1,file} as Entry));
   const next=[...entries,...batch];
   update([...next]);working(true);blocked(true);
   try{
     for(const entry of batch){
       try{
         const reader=await loadReader();
         if(/\.zip$/i.test(entry.file.name)){
           await (window as any).pmReadExpenseZip(entry.file,(items:any[])=>{entry.pdfs=items;update([...next]);});
         }else{
           entry.parsed=await reader(entry.file,group);
           if(!entry.parsed?.rows?.length)throw Error('Không tìm thấy dòng chứng từ.');
         }
       }catch(e){entry.error=(e as Error).message||'Không đọc được tệp.';}
       entry.done=true;update([...next]);
     }
   }finally{working(false);blocked(next.some(e=>e.parsed||e.pdfs));}
 }
 async function retryPdf(entry:Entry,index:number){
   const item=entry.pdfs?.[index];
   if(busy||!item?.pdf||!item.error)return;
   working(true);
   try{
     await loadReader();
     const row=await (window as any).pmReadArchivedPdf(item.pdf);
     entry.pdfs![index]={name:item.name,pdf:item.pdf,row};
   }catch(e){item.error=(e as Error).message;}
   finally{update([...entries]);working(false);}
 }
 function pick(e:React.ChangeEvent<HTMLInputElement>){
   const files=Array.from(e.currentTarget.files||[]);
   e.currentTarget.value='';
   void read(files);
 }
 return <div className="cereader" onDragOver={e=>{if(e.dataTransfer.types.includes('Files'))e.preventDefault();}} onDrop={e=>{if(e.dataTransfer.files.length){e.preventDefault();void read(Array.from(e.dataTransfer.files));}}}>
 <label className="btn">Đọc PDF / Excel / ảnh / ZIP · Chọn hoặc kéo thả nhiều tệp<input type="file" multiple accept=".zip,.pdf,.xlsx,.csv,image/png,image/jpeg,image/webp" disabled={busy} onChange={pick}/></label>
 <label className="btn cecamera">Chụp chứng từ<input type="file" accept="image/*" capture="environment" disabled={busy} onChange={pick}/></label>
 {entries.length>0&&<button type="button" disabled={busy} onClick={()=>draft(false)}>Lưu nháp</button>}
 {!entries.length&&<button type="button" onClick={()=>draft(true)}>Mở nháp đã lưu</button>}<p role="status">{draftMessage}</p>
 {entries.length>0&&<p role="status">Đã đọc {entries.filter(e=>e.done).length}/{entries.length} tệp · Lỗi {entries.filter(e=>e.error).length}</p>}
 {!busy&&entries.some(e=>e.parsed?.rows?.[0]?.signedFee!==undefined)&&<SettlementPreview entries={entries} onSaved={onFeesSaved}/>}
 {entries.map(entry=><section key={entry.id}><strong>{entry.file.name}</strong>
 {entry.error?<p role="alert">{entry.error}</p>:entry.pdfs?<ZipReview retry={i=>retryPdf(entry,i)} footer={footer} filename={entry.file.name} items={entry.pdfs} busy={busy} close={()=>remove(entry.id)}/>:entry.parsed?.rows?.[0]?.signedFee!==undefined?<p>{entry.parsed.text}</p>:entry.parsed?
 <DocumentReview result={entry.parsed} busy={busy} applyRow={(i:number)=>{apply(entry.parsed.rows[i],entry.file,i);blocked(false);}}/>:<p>Chờ đọc…</p>}
 {!entry.pdfs&&<button type="button" disabled={busy} onClick={()=>remove(entry.id)}>Bỏ kết quả đọc</button>}
 </section>)}</div>;
}
function DocumentReview({result,busy,applyRow}:any){
 const [index,choose]=useState(0);
 return <>{result.rows.length>100?<label>Dòng phí (1–{result.rows.length})<input type="number" min="1" max={result.rows.length} value={index+1} onChange={e=>choose(Math.min(result.rows.length,Math.max(1,Math.floor(Number(e.target.value)||1)))-1)}/></label>:result.rows.length>1&&<label>Dòng chứng từ<select value={index} onChange={e=>choose(Number(e.target.value))}>{result.rows.map((r:any,i:number)=><option key={i} value={i}>{i+1} · {r.ref||r.type} · {r.amount||'Chờ số tiền'}</option>)}</select></label>}
 <p>{result.rows[index].excerpt}</p><details><summary>Xem chữ đã đọc</summary><pre>{result.text}</pre></details>
 <button type="button" disabled={busy} onClick={()=>applyRow(index)}>Chọn dòng này để kiểm tra và lưu phiếu</button></>;
}
