'use client';
import {useEffect,useState} from 'react';
import {parseEmail,previewType,previewMime,type PreviewFile} from '../../lib/document-preview';
import type {DetailDocument} from './detail-downloads';

function safeEmailHtml(html:string){
 const template=document.createElement('template');template.innerHTML=html;
 const links=Array.from(template.content.querySelectorAll('a[href]')).flatMap(node=>{try{const url=new URL(node.getAttribute('href')||'');return ['https:','http:'].includes(url.protocol)?[{url:url.href,label:node.textContent?.trim()||'Mở liên kết nguồn'}]:[];}catch{return [];}});
 template.content.querySelectorAll('script,iframe,object,embed,form,input,button,meta,base,link,svg,math').forEach(node=>node.remove());
 template.content.querySelectorAll('*').forEach(node=>{for(const attr of Array.from(node.attributes)){const name=attr.name.toLowerCase();if(name.startsWith('on')||['href','src','srcset','action','formaction','poster','background','target','ping','xlink:href'].includes(name))node.removeAttribute(attr.name);}});
 return {html:template.innerHTML,links:Array.from(new Map(links.map(link=>[link.url,link])).values())};
}
export default function DocumentLinks({documents,previewLabel='Xem tài liệu'}:{documents:DetailDocument[],previewLabel?:string}){
 const [selected,setSelected]=useState('');
 return <div className="document-list">{documents.map(doc=><div key={doc.url} className="document-item"><strong>{doc.label}</strong><div className="cedownload-actions">{doc.url.startsWith('/api/')?<><button type="button" className="btn" aria-expanded={selected===doc.url} onClick={()=>setSelected(selected===doc.url?'':doc.url)}>{previewLabel}</button><a className="btn" href={doc.url}>Tải xuống</a></>:<a className="btn" href={doc.url} target="_blank" rel="noreferrer">Xem tại nguồn</a>}</div>{selected===doc.url&&<SavedPreview document={doc} close={()=>setSelected('')}/>}</div>)}</div>;
}
function SavedPreview({document:doc,close}:{document:DetailDocument;close:()=>void}){
 const [file,setFile]=useState<PreviewFile|null>(null),[error,setError]=useState('');
 useEffect(()=>{const controller=new AbortController();setFile(null);setError('');
  fetch(doc.url,{cache:'no-store',signal:controller.signal}).then(async response=>{
   if(!response.ok)throw Error(response.status===403?'Tài khoản chưa có quyền xem tài liệu này.':'Chưa tải được tài liệu. Vui lòng thử lại.');
   if(Number(response.headers.get('Content-Length'))>20*1024*1024)throw Error('Tệp vượt 20 MB. Dùng Tải xuống để mở bản gốc.');
   const bytes=new Uint8Array(await response.arrayBuffer());if(bytes.length>20*1024*1024)throw Error('Tệp vượt 20 MB. Dùng Tải xuống để mở bản gốc.');
   let name=doc.label;const disposition=response.headers.get('Content-Disposition')||'',encoded=disposition.match(/filename\*=UTF-8''([^;]+)/i)?.[1];
   if(encoded){try{name=decodeURIComponent(encoded);}catch{}}else name=disposition.match(/filename="([^"]+)"/i)?.[1]||name;
   if(!controller.signal.aborted)setFile({name,mime:response.headers.get('Content-Type')||'',bytes});
  }).catch(e=>{if(!controller.signal.aborted)setError(e.message);});return()=>controller.abort();
 },[doc.url,doc.label]);
 return <section className="document-preview" aria-label={'Xem tài liệu · '+doc.label}><header><strong>Xem tài liệu</strong><button type="button" className="btn" onClick={close}>Đóng xem</button></header>{!file&&!error&&<p role="status">Đang mở tài liệu…</p>}{error&&<p role="alert">{error}</p>}{file&&<FilePreview file={file}/>}</section>;
}
function FilePreview({file,depth=0}:{file:PreviewFile;depth?:number}){
 const type=previewType(file),[url,setUrl]=useState(''),[text,setText]=useState(''),[error,setError]=useState('');
 const [email,setEmail]=useState<ReturnType<typeof parseEmail>|null>(null),[mailLinks,setMailLinks]=useState<{url:string;label:string}[]>([]);
 useEffect(()=>{let active=true;setError('');setEmail(null);setMailLinks([]);setText('');const objectUrl=URL.createObjectURL(new Blob([file.bytes as BlobPart],{type:previewMime(file)}));setUrl(objectUrl);
  try{if(type==='email'){if(depth>3)throw Error('Thư lồng nhiều cấp. Tải thư gốc để mở đầy đủ.');const parsed=parseEmail(file.bytes),safe=safeEmailHtml(parsed.html);parsed.html=safe.html;setMailLinks(safe.links);setEmail(parsed);}
   else if(type==='text')setText(new TextDecoder().decode(file.bytes));
   else if(type==='document'){const modulePath='/document-reader/read.mjs';import(/* @vite-ignore */modulePath).then(async reader=>reader.readDocument(new File([file.bytes as BlobPart],file.name,{type:file.mime}))).then(result=>{if(active)setText(result.text);}).catch(e=>{if(active)setError(e.message);});}
  }catch(e){setError((e as Error).message);}return()=>{active=false;URL.revokeObjectURL(objectUrl);};
 },[file,type,depth]);
 return <><p className="document-filename">{file.name}</p>{error?<p role="alert">{error}</p>:<>{type==='pdf'&&url&&<iframe src={url} title={'PDF · '+file.name} className="document-frame"/>}{type==='image'&&url&&<img src={url} alt={file.name} className="document-image"/>}{['text','document'].includes(type)&&<pre className="document-text">{text||'Đang đọc nội dung tài liệu…'}</pre>}{type==='unsupported'&&<p>Định dạng này chưa hỗ trợ xem trước. Chọn Tải xuống để mở bản gốc.</p>}{email&&<><dl><dt>Tiêu đề</dt><dd>{email.subject}</dd><dt>Người gửi</dt><dd>{email.from}</dd><dt>Ngày gửi</dt><dd>{email.date}</dd></dl>{email.html?<iframe title={'Nội dung thư · '+file.name} sandbox="" srcDoc={'<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; img-src data:; form-action \'none\'; base-uri \'none\'"><style>body{font:16px system-ui;margin:12px;overflow-wrap:anywhere}img{max-width:100%}table{max-width:100%}</style>'+email.html} className="document-frame"/>:<pre className="document-text">{email.text||'Thư không có phần nội dung văn bản.'}</pre>}{mailLinks.length>0&&<details><summary>Liên kết tài liệu trong thư · {mailLinks.length}</summary>{mailLinks.map(link=><p key={link.url}><a href={link.url} target="_blank" rel="noreferrer">{link.label} · Mở tại nguồn</a></p>)}</details>}{email.attachments.length>0&&<section aria-label="Tài liệu trong thư"><h4>Tài liệu đính kèm trong thư · {email.attachments.length}</h4>{email.attachments.map((attachment,i)=><Attachment key={i} file={attachment} depth={depth+1}/>)}</section>}</>}</>}
 </>;
}
function Attachment({file,depth}:{file:PreviewFile;depth:number}){
 const [url,setUrl]=useState(''),[open,setOpen]=useState(false);
 useEffect(()=>{const objectUrl=URL.createObjectURL(new Blob([file.bytes as BlobPart],{type:previewMime(file)}));setUrl(objectUrl);return()=>URL.revokeObjectURL(objectUrl);},[file]);
 return <div className="document-attachment"><strong>{file.name}</strong><div className="cedownload-actions"><button className="btn" type="button" aria-expanded={open} onClick={()=>setOpen(v=>!v)}>{open?'Đóng xem':'Xem tài liệu'}</button>{url&&<a className="btn" href={url} download={file.name}>Tải xuống</a>}</div>{open&&<FilePreview file={file} depth={depth}/>}</div>;
}
