'use client';
import {useEffect,useId,useRef,useState} from 'react';
import DetailDownloads from './detail-downloads';
import DocumentLinks from './document-links';
import type {PurchaseExpenseEntry as Entry,PurchaseExpenseDocument as Document} from '../../lib/historical-purchase-expenses';
const money=(value:number)=>value.toLocaleString('vi-VN')+' ₫';
const date=(value:string)=>value.split('-').reverse().join('/');
export default function HistoricalExpenses({from,to}:{from:string;to:string}){
 const [expanded,setExpanded]=useState(false),[rows,setRows]=useState<Entry[]>([]),[message,setMessage]=useState('Đang tải…');
 const [documents,setDocuments]=useState<Record<string,Document[]>>({}),[documentStatus,setDocumentStatus]=useState(''),[retry,setRetry]=useState(0);
 const detailId=useId(),closeRef=useRef<HTMLButtonElement>(null),opener=useRef<HTMLElement|null>(null);
 function open(e:React.MouseEvent<HTMLButtonElement>){opener.current=e.currentTarget;setExpanded(true);}
 function close(){setExpanded(false);opener.current?.focus();}
 useEffect(()=>{
  const signal=new AbortController();setRows([]);setMessage('Đang tải…');
  fetch('/api/purchases?'+new URLSearchParams({mode:'historical-expenses',from,to}),{signal:signal.signal,cache:'no-store'})
   .then(async r=>{if(!r.ok)throw Error('Chưa tải được chi phí mua hàng.');const data=await r.json() as {rows:Entry[]};if(!signal.signal.aborted){setRows(data.rows);setMessage('');}})
   .catch(e=>{if(!signal.signal.aborted)setMessage(e.message);});
  return ()=>signal.abort();
 },[from,to,retry]);
 useEffect(()=>{
  if(!expanded)return;
  const signal=new AbortController();setDocuments({});setDocumentStatus('Đang tải tài liệu…');
  fetch('/api/purchases?'+new URLSearchParams({mode:'historical-expenses',documents:'1',from,to}),{signal:signal.signal,cache:'no-store'})
   .then(async r=>{if(!r.ok)throw Error('Chưa tải được tài liệu. Bấm Tải lại để thử lại.');const data=await r.json() as {rows:Entry[];documents:Record<string,Document[]>};if(!signal.signal.aborted){setRows(data.rows);setMessage('');setDocuments(data.documents);setDocumentStatus('');}})
   .catch(e=>{if(!signal.signal.aborted)setDocumentStatus(e.message);});
  return ()=>signal.abort();
 },[expanded,from,to,retry]);
 useEffect(()=>{
  if(!expanded)return;closeRef.current?.focus();const previous=document.body.style.overflow;document.body.style.overflow='hidden';
  function key(e:KeyboardEvent){if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();close();}if(e.key==='Tab'){const nodes=Array.from(document.getElementById(detailId)?.querySelectorAll<HTMLElement>('button,a[href]')||[]);const first=nodes[0],last=nodes[nodes.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}}
  document.addEventListener('keydown',key,true);return()=>{document.body.style.overflow=previous;document.removeEventListener('keydown',key,true);};
 },[expanded,detailId]);
 const total=(kind:Entry['kind'])=>rows.filter(r=>r.kind===kind).reduce((sum,r)=>sum+r.amount,0),count=rows.filter(r=>r.kind==='payment').length;
 return <><div className="cegrid"><div className="cename"><button type="button" aria-haspopup="dialog" aria-expanded={expanded} aria-controls={detailId} onClick={open}>Chi phí mua hàng đã thanh toán</button></div>
 <button type="button" aria-label="Xem chi tiết chi phí mua hàng đã thanh toán" aria-haspopup="dialog" aria-expanded={expanded} aria-controls={detailId} onClick={open}>{message?'—':money(total('payment'))}</button>
 <small>{message||(rows.length?'Hợp lệ quản trị':'Không phát sinh')}</small></div>
 {expanded&&<div className="ceveil" onClick={e=>{if(e.target===e.currentTarget)close();}}><section id={detailId} className="cedrawer" role="dialog" aria-modal="true" aria-label="Chi phí mua hàng đã thanh toán"><header><button type="button" onClick={()=>setRetry(v=>v+1)}>Tải lại</button><button type="button" ref={closeRef} onClick={close}>Đóng chi tiết</button></header>
 <h2>Chi phí mua hàng đã thanh toán</h2><h3>{message?'Đang tải…':money(total('payment'))}</h3>
 <p>{count} khoản thanh toán · {rows.length-count} hóa đơn · {from||to?[from||'…',to||'…'].map(date).join(' – '):'Tất cả thời gian'}</p>
 <p>Thanh toán theo ngày trong A5. Hóa đơn theo ngày lập, hiển thị riêng để đối chiếu; không cộng thêm vào tổng thanh toán.</p>
 {message&&<p role="status">{message}</p>}{documentStatus&&<p role="status">{documentStatus}</p>}
 <DetailDownloads key={from+':'+to} title="Chi phí mua hàng đã thanh toán" scope={from||to?[from||'…',to||'…'].map(date).join(' – '):'Tất cả thời gian'} loading={Boolean(message||documentStatus)} columns={['Loại dữ liệu','Ngày','Nhà cung cấp','Số tiền (đ)','Tham chiếu','Mã nguồn']} rows={rows.map(r=>({values:[r.kind==='payment'?'Thanh toán A5':'Hóa đơn đối chiếu (không cộng vào thanh toán)',r.date,r.supplier,r.amount,r.reference,r.source_id],documents:documents[r.kind+':'+r.source_id]||[]}))}/>
 {(['payment','invoice'] as const).map(kind=><section key={kind}><h3>{kind==='payment'?'Thanh toán · A5':'Hóa đơn đối chiếu · Nguyễn Huy Minh'} · {money(total(kind))}</h3>
 {!message&&!rows.some(r=>r.kind===kind)&&<p>Không có {kind==='payment'?'khoản thanh toán':'hóa đơn'} trong kỳ đã chọn.</p>}
 {rows.filter(r=>r.kind===kind).map(r=>{const docs=documents[kind+':'+r.source_id]||[];return <article key={r.source_id} style={{padding:'12px 0',borderBottom:'1px solid #d7e0dc'}}><strong>{date(r.date)} · {r.supplier} · {money(r.amount)}</strong><p>{r.reference}</p><DocumentLinks documents={docs}/>{!documentStatus&&!docs.some(d=>d.kind==='file')&&<p>Chưa có tệp {kind==='payment'?'chứng từ thanh toán':'hóa đơn'} đính kèm đã lưu.</p>}</article>;})}</section>)}
 <p><a href="/nhap-hang?view=debt">Mở công nợ nhà cung cấp</a> · <a href="/nhap-hang/hoa-don">Xem danh sách hóa đơn gốc</a></p>
 </section></div>}</>;
}
