import {loadReader} from './load-expense-reader';
import {readTransfer} from '../../lib/trang-payment';

export async function readTransferBill(file:File){
 const reader=await loadReader();
 const result=await reader(file,'payment-date',(text:string)=>{
  const first=readTransfer(text);
  return !first.date||!first.amount||!first.recipient;
 });
 const data=readTransfer(result.text||'');
 if(result.second){
  const other=readTransfer(result.second);
  for(const field of ['date','recipient'] as const){
   if(!data[field])data[field]=other[field];
   else if(other[field]&&data[field].toLocaleLowerCase()!==other[field].toLocaleLowerCase())data[field]='';
  }
  if(!data.amount)data.amount=other.amount;
  else if(other.amount&&data.amount!==other.amount)data.amount=0;
 }
 const missing=[!data.date&&'ngày chuyển',!data.amount&&'số tiền',!data.recipient&&'người nhận'].filter(Boolean);
 const message=missing.length?'Chưa nhận diện được '+missing.join(', ')+'. Anh kiểm tra lại ảnh hoặc nhập các ô này.':'Đã đọc đủ ngày, số tiền và người nhận.';
 return {...data,message,excerpt:missing.length?(result.text||result.second||'').trim():''};
}
