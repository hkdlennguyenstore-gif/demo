'use client';
import {useEffect,useState,type ReactNode} from 'react';
type Row={shop:string;orders:number|null;quantity:number|null};
export default function StockReturns({from,to,shop,children}:{from:string;to:string;shop:string;children:ReactNode}){
 const [open,setOpen]=useState(false),[rows,setRows]=useState<Row[]>([]),[status,setStatus]=useState('Đang tải…');
 useEffect(()=>{
  if(!open)return;
  const controller=new AbortController();setStatus('Đang tải…');setRows([]);
  fetch('/api/finance?'+new URLSearchParams({mode:'stock-returns',from,to}),{signal:controller.signal,cache:'no-store'})
   .then(async r=>{if(!r.ok)throw Error();const data=await r.json();if(!controller.signal.aborted){setRows(data.rows);setStatus('');}})
   .catch(()=>{if(!controller.signal.aborted)setStatus('Chưa đọc được báo cáo hoàn POS');});
  return ()=>controller.abort();
 },[open,from,to]);
 const selected=rows.filter(r=>!shop||r.shop===shop);
 const sum=(key:'orders'|'quantity')=>selected.length&&selected.every(r=>Number.isSafeInteger(r[key])&&r[key]!>=0)?selected.reduce((n,r)=>n+r[key]!,0).toLocaleString('vi-VN'):'—';
 return <details onToggle={e=>setOpen(e.currentTarget.open)}><summary>Nguồn kho thực</summary>
 <p>Hoàn theo POS trong kỳ · {status||sum('orders')+' đơn hoàn · '+sum('quantity')+' sản phẩm hoàn'}</p>{children}</details>;
}
