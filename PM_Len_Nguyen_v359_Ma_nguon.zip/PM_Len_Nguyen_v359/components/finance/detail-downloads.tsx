'use client';
import {useEffect,useRef,useState} from 'react';
import {csvBytes,zipFiles} from '../../lib/data-export';
import DocumentLinks from './document-links';

export type DetailDocument={label:string;url:string;kind:'file'|'source'};
export type DetailExportRow={values:unknown[];documents?:DetailDocument[]};
type Props={title:string;scope:string;columns:string[];rows:DetailExportRow[];loading?:boolean};

// Fetch only the PM's authenticated download endpoints. External sources stay in the index.
export function isStoredDocument(doc:DetailDocument){
 return doc.url.startsWith('/api/')&&!doc.url.startsWith('//')&&(doc.kind==='file'||doc.url.startsWith('/api/gmail-evidence?id='));
}
export default function DetailDownloads({title,scope,columns,rows,loading=false}:Props){
 const active=useRef<AbortController|null>(null);
 useEffect(()=>()=>active.current?.abort(),[scope]);
 const [busy,setBusy]=useState(false),[message,setMessage]=useState(''),[error,setError]=useState('');
 const docs=Array.from(new Map(rows.flatMap(row=>row.documents||[]).filter(isStoredDocument).map(doc=>[doc.url,doc])).values());
 const missing=rows.filter(row=>!row.documents?.some(doc=>doc.kind==='file')).length;
 async function download(format:'csv'|'zip'){
  const controller=new AbortController();active.current=controller;
  setBusy(true);setError('');setMessage('');
  try{
   if(!rows.length)throw Error('Không có dữ liệu trong phạm vi đang xem.');
   const table=[[...columns,'Tài liệu / liên kết nguồn'],...rows.map(row=>[...row.values,(row.documents||[]).map(doc=>doc.label+' · '+doc.url).join(' | ')])];
   const index=[['Dòng dữ liệu','Tên tài liệu','Loại','Liên kết'],...rows.flatMap((row,i)=>(row.documents||[]).map(doc=>[i+1,doc.label,doc.kind==='file'?'Tệp đính kèm':'Nguồn đối chiếu',doc.url]))];
   const files=[{name:'du-lieu.csv',bytes:csvBytes(table)}];
   if(format==='zip'){
    if(!docs.length)throw Error('Chưa có tệp gốc đã lưu trong phạm vi đang xem. Có thể tải bảng CSV hoặc mở liên kết nguồn.');
    if(docs.length>200)throw Error('Có hơn 200 tệp. Chọn khoảng thời gian nhỏ hơn để tải đủ.');
    let size=files[0].bytes.length;
    for(const [i,doc] of docs.entries()){
     setMessage(`Đang chuẩn bị tài liệu ${i+1}/${docs.length}…`);
     const response=await fetch(doc.url,{cache:'no-store',signal:controller.signal});
     if(!response.ok)throw Error('Chưa tải được '+doc.label+'. Vui lòng thử lại; chưa tạo ZIP thiếu tệp.');
     const length=Number(response.headers.get('Content-Length'));
     if(length&&size+length>20*1024*1024)throw Error('Tệp vượt 20 MB. Chọn khoảng thời gian nhỏ hơn.');
     const bytes=new Uint8Array(await response.arrayBuffer());size+=bytes.length;
     if(size>20*1024*1024)throw Error('Tệp vượt 20 MB. Chọn khoảng thời gian nhỏ hơn.');
     const disposition=response.headers.get('Content-Disposition')||'';
     const encoded=disposition.match(/filename\*=UTF-8''([^;]+)/i)?.[1];
     let name=disposition.match(/filename="([^"]+)"/i)?.[1]||doc.label;
     if(encoded){try{name=decodeURIComponent(encoded);}catch{}}
     name=name.normalize('NFC').replace(/[^\p{L}\p{N}._-]/gu,'_').slice(-120)||'chung-tu';
     if(!/\.[a-z0-9]{2,5}$/i.test(name)){
      const mime=response.headers.get('Content-Type')||'';
      name+=mime.includes('pdf')?'.pdf':mime.includes('message/rfc822')?'.eml':mime.includes('xml')?'.xml':mime.includes('png')?'.png':mime.includes('jpeg')?'.jpg':'.bin';
     }
     files.push({name:`chung-tu/${i+1}_${name}`,bytes});
    }
    files.push({name:'danh-muc-tai-lieu.csv',bytes:csvBytes(index)});
    files.push({name:'pham-vi.txt',bytes:new TextEncoder().encode(`${title}\n${scope}\n${rows.length} dòng dữ liệu; ${docs.length} tệp gốc hoặc thư gốc; ${missing} dòng chưa có tệp chứng từ đính kèm.\nLiên kết ngoài PM chỉ được ghi trong danh mục, không nằm trong bộ tệp.\nThanh toán và hóa đơn đối chiếu là các loại riêng, không cộng chung.\n`)});
   }
   if(controller.signal.aborted)return;
   const bytes=format==='zip'?zipFiles(files):files[0].bytes;
   const blob=new Blob([bytes as BlobPart],{type:format==='zip'?'application/zip':'text/csv;charset=utf-8'});
   const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;
   a.download=('LN_'+title+'_'+scope).replace(/[^\p{L}\p{N}._-]/gu,'_').slice(0,160)+'.'+format;
   document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
   setMessage(`Đã tạo ${format.toUpperCase()} · ${rows.length} dòng${format==='zip'?' · '+docs.length+' tệp gốc':''}.`);
  }catch(e){if(!controller.signal.aborted){setError((e as Error).message);setMessage('');}}finally{if(!controller.signal.aborted)setBusy(false);}
 }
 return <section className="cedownloads" aria-label={'Tải tài liệu · '+title}>
  <strong>Tải dữ liệu &amp; tài liệu</strong><p>{scope}</p>
  <div className="cedownload-actions"><button className="btn" type="button" disabled={loading||busy||!rows.length} onClick={()=>void download('csv')}>Tải bảng dữ liệu CSV</button><button className="btn" type="button" disabled={loading||busy||!docs.length} onClick={()=>void download('zip')}>{busy?'Đang chuẩn bị…':'Tải bộ tài liệu ZIP'}</button></div>
  <small>{loading?'Đang kiểm tra tài liệu…':`${rows.length} dòng · ${docs.length} tệp gốc / thư gốc có thể tải · ${missing} dòng chưa có chứng từ đính kèm.`}</small>
  {docs.length>0&&<details><summary>Xem và tải từng tài liệu · {docs.length}</summary><DocumentLinks documents={docs}/></details>}
  <small>Chỉ tải dữ liệu đang xem. Liên kết Drive / Sheets được ghi trong danh mục ZIP; tệp chưa lưu cần mở từ nguồn.</small>
  {error&&<p role="alert">{error}</p>}{message&&<p role="status">{message}</p>}
 </section>;
}
