let readerReady:Promise<void>|undefined;
export async function loadReader(){
 if(!readerReady)readerReady=new Promise<void>((resolve,reject)=>{
   const script=document.createElement('script');script.type='module';script.src='/expense-ocr/read.mjs';
   script.onload=()=>resolve();script.onerror=()=>{readerReady=undefined;script.remove();reject(Error('Chưa tải được bộ đọc chứng từ.'));};
   document.head.appendChild(script);
 });
 await readerReady;
 return (window as any).pmReadExpense;
}
