'use client';
import {useState} from 'react';
import type {Line} from '../../lib/expense-lines';
import {expenseGroups,financeChannels} from '../../lib/finance';
const money=(v:number)=>v.toLocaleString('vi-VN')+' ₫';
export default function LineActions({line:l,data,save,edit}:{line:Line;data:any;save:(action:string,payload:any)=>Promise<void>;edit:()=>void}){
 const [op,choose]=useState(''),[target,setTarget]=useState(''),[reason,setReason]=useState(''),[error,report]=useState(''),[busy,working]=useState(false),[history,setHistory]=useState<any[]>([]);
 const doc=l.id?data.rows.find((r:any)=>r.id===l.id):null,m=data.management;
 const value=op==='exclude'?0:op==='original'?l.original:op==='restore'?l.control?.target??l.original:Number(target);
 async function apply(){
  working(true);report('');
  try{
   const common={reason,previous:l.amount};
   if(l.id)await save(op==='exclude'?'exclude-line':'restore-line',{...common,id:l.id,version:doc.version});
   else await save('auto-line',{...common,group:l.group,shop:l.shop,date:l.date,lineKey:l.lineKey,target:value,operation:op});
   choose('');setReason('');
  }catch(e){report((e as Error).message);}finally{working(false);}
 }
 async function loadHistory(){try{const response=await fetch('/api/finance?line-history='+encodeURIComponent(l.id||l.lineKey||''));const result=await response.json() as any;if(!response.ok)throw Error(result.error);setHistory(result.rows);choose('history');}catch(e){report((e as Error).message);}}
 return <details><summary>⋯ Thao tác</summary><div className="ceactions">
 {!l.excluded&&m.canEdit&&(doc?!doc.adjustment&&<button onClick={edit}>Sửa</button>:<button onClick={()=>{choose('adjust');setTarget(String(l.amount));}}>Điều chỉnh</button>)}
 {!l.excluded&&l.control?.target!==undefined&&m.canEdit&&<button onClick={()=>choose('original')}>Trở về số nguồn</button>}
 {!l.excluded&&m.canExclude&&<button onClick={()=>choose('exclude')}>Loại khỏi báo cáo</button>}
 {l.excluded&&m.canRestore&&<button onClick={()=>choose('restore')}>Khôi phục</button>}
 <button onClick={loadHistory}>Lịch sử</button></div>
 {op==='history'?<div>{history.length?history.map((a,i)=><p key={i}>{a.time} · {a.actor} · {a.operation||a.action} · {money(a.before?.status==='excluded'?0:a.before?.amount||0)} → {money(a.after?.status==='excluded'?0:a.after?.amount||0)} · {a.reason||a.after?.changeReason||''}</p>):'Chưa có chỉnh sửa'}</div>:op&&<section className="ceentry">
 <strong>{expenseGroups[l.group]} · {financeChannels[l.shop]} · {l.date}</strong>
 {op==='adjust'&&<label>Số mới (đ)<input type="number" min="0" value={target} onChange={e=>setTarget(e.target.value)}/></label>}
 <p>Số cũ {money(l.amount)} → số mới {money(value||0)} · Chênh lệch {money((value||0)-l.amount)}</p>
 <label>Lý do<input value={reason} onChange={e=>setReason(e.target.value)}/></label>
 <button disabled={busy||!reason.trim()||(op==='adjust'&&!target)} onClick={apply}>Xác nhận</button><button disabled={busy} onClick={()=>choose('')}>Hủy</button></section>}
 {error&&<p role="alert">{error}</p>}</details>
}
