'use client';
import {useState} from 'react';

export const fields:Record<string,string[]>={
 cogs:['Mã đơn gốc','Đối chứng hàng hoàn'],platform:['Mã đơn gốc','Loại phí','Mã quyết toán'],
 promotion:['Mã đơn gốc','Voucher / chương trình','Phần shop chịu'],ads:['Tài khoản quảng cáo','Loại khoản'],
 content:['Buổi livestream / nội dung','Người hoặc đơn vị thực hiện'],shipping:['Mã đơn gốc','Mã vận đơn','Hãng vận chuyển'],
 packing:[],returns:['Mã đơn gốc','Lý do hoàn / đổi','Mã vận đơn'],staff:['Nhân viên','Kỳ lương','Khoản bổ sung ngoài bảng lương'],
 operations:['Kỳ hóa đơn'],software:['Nhà cung cấp','Gói dịch vụ','Kỳ thanh toán'],
 equipment:['Thiết bị / vật tư','Số lượng','Thời gian sử dụng'],administration:['Loại phí / nghĩa vụ','Kỳ phát sinh']
};
export type Item={name:string;qty:string;price:string};
export const blankItem=():Item=>({name:'',qty:'',price:''});
export function GroupInputs({group,values,change,items,onItems,data,channel,date}:any){
 const [notice,message]=useState('');
 const itemized=group==='packing'||group==='cogs';
 async function lookupOrder(){
   try{
    if(channel==='shared')throw Error('Chọn shop của đơn trước khi đối chiếu.');
    const number=values['Mã đơn gốc']?.trim();if(!number)throw Error('Nhập mã đơn để đối chiếu.');
    const res=await fetch('/api/orders?'+new URLSearchParams({tab:channel,q:number}));
    const result=await res.json() as any;if(!res.ok)throw Error(result.error);
    const order=result.rows.find((r:any)=>r.number===number||r.sourceId===number);
    if(!order)throw Error('Chưa tìm thấy đúng mã trong dữ liệu của shop.');
    const updates:Record<string,string>={'Mã đơn gốc':order.number};
    if(fields[group].includes('Mã vận đơn')&&order.tracking)updates['Mã vận đơn']=order.tracking;
    if(group==='shipping'&&order.carrier)updates['Hãng vận chuyển']=order.carrier;
    if(group==='cogs')updates['Đối chứng hàng hoàn']=order.statusName;
    change({...values,...updates});message(order.number+' · '+order.statusName+' · '+order.quantity+' sản phẩm');
   }catch(e){message((e as Error).message);}
 }
 async function lookupPrice(i:number){
   try{
    const code=items[i].name.trim();if(!code)throw Error('Nhập mã hàng.');
    const res=await fetch('/api/a3?'+new URLSearchParams({mode:'expense-price',q:code,date}));
    const result=await res.json() as any;if(!res.ok)throw Error(result.error);
    if(!result.price)throw Error('Chưa có giá A3 của mã hàng tại ngày đã chọn.');
    onItems(items.map((item:Item,j:number)=>j===i?{...item,price:String(result.price)}:item));
    message('Giá nhập '+code+' · '+result.date);
   }catch(e){message((e as Error).message);}
 }
 return <section>{(fields[group]||[]).map(label=><label key={label}>{label}
 {label==='Loại khoản'?<select value={values[label]||''} onChange={e=>change({...values,[label]:e.target.value})}><option value="">Chọn loại</option><option>Chi tiêu thực chạy</option><option>Phí dịch vụ</option><option>Tiền nạp / tín dụng</option></select>:
 <input maxLength={150} list={label==='Nhân viên'?'ce-employees':undefined} value={values[label]||''} onChange={e=>change({...values,[label]:e.target.value})}/>}</label>)}
 {group==='staff'&&<><datalist id="ce-employees">{data.payrollCosts.rows.map((r:any)=><option key={r.id} value={r.name}/>)}</datalist><small>Xem lương và bảo hiểm đã chốt hoặc tạm tính trong chi tiết Nhân sự.</small></>}
 {fields[group]?.includes('Mã đơn gốc')&&<button type="button" onClick={lookupOrder}>Đối chiếu đơn PM</button>}
 {itemized&&items.map((item:Item,i:number)=><div key={i} className="ceitems">{(['name','qty','price'] as const).map((k,j)=><label key={k}>{[group==='cogs'?'Mã hàng':'Loại vật tư','Số lượng','Đơn giá (đ)'][j]}<input value={item[k]} maxLength={k==='name'?100:12} inputMode={k==='name'?'text':'numeric'} onChange={e=>onItems(items.map((it:Item,n:number)=>n===i?{...it,[k]:e.target.value}:it))}/></label>)}{group==='cogs'&&<button type="button" onClick={()=>lookupPrice(i)}>Lấy giá A3</button>}{items.length>1&&<button type="button" onClick={()=>onItems(items.filter((_:Item,n:number)=>n!==i))}>Bỏ dòng</button>}</div>)}
 {itemized&&items.length<30&&<button type="button" onClick={()=>onItems([...items,blankItem()])}>Thêm dòng</button>}
 {notice&&<p role="status">{notice}</p>}</section>
}
