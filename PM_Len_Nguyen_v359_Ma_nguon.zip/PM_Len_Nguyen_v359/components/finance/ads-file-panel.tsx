'use client';
import {financeChannels,expenseCategories,csvValue} from '../../lib/finance';
import {useEffect,useRef,useState} from 'react';

type Entry={ref?:string;type:string;date:string;number:string;amount:number;file:string;net?:number;tax?:number;status?:string;account?:string;shop?:string;method?:string};
type Group={evidence?:Entry & {supplier:string;spend?:boolean;category:string;excerpt:string;member?:string};ref:string;invoice:Entry|null;transactions:Entry[]};
const money=(n:number)=>n==null?'Chưa đọc được':n.toLocaleString('vi-VN')+' ₫';
const source=(row:Entry)=><a href={'/api/finance?ads-original='+row.file}>Tải bản gốc</a>;
function status(group:Group){
  if(group.evidence)return 'Chờ rà soát';
  if(!group.invoice)return group.ref.startsWith('GD ')?'Thiếu mã hóa đơn':'Chờ PDF';
  if(!group.transactions.length)return 'Chờ giao dịch';
  const paid=group.transactions.filter(t=>/^(thành công|success(?:ful)?|completed|成功)$/i.test(t.status||'')).reduce((n,t)=>n+t.amount,0);
  if(paid===group.invoice.amount)return 'Khớp số tiền';
  const external=group.transactions.filter(t=>/^(thành công|success(?:ful)?|completed|成功)$/i.test(t.status||'') && !/^(số dư|balance|余额|餘額)$/i.test(t.method||'')).reduce((n,t)=>n+t.amount,0);
  return external===group.invoice.amount?'Khớp phần trả ngoài ví · có dùng số dư':'Cần đối chiếu';
}
export default function AdsFilePanel({inputRef,onDraft}:{onDraft:(row:any)=>void;inputRef:React.RefObject<HTMLInputElement|null>}){
  const [groups,setGroups]=useState<Group[]>([]),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
  const lock=useRef(false);
  async function reload(){
    const response=await fetch('/api/finance?ads-import=1',{cache:'no-store'});
    const data=await response.json() as any;
    if(!response.ok)throw Error(data.error||'Chưa đọc được hồ sơ');
    setGroups(data);
  }
  useEffect(()=>{reload().catch(e=>setMessage(e.message));},[]);
  async function ingest(files:File[]){
    if(lock.current||!files.length)return;
    lock.current=true;setBusy(true);
    const summary:string[]=[];
    try{
      const path='/ads-import/read.mjs';
      const {parseFile}=await import(/* @vite-ignore */ path);
      for(const file of files){
        setMessage('Đang đọc '+file.name);
        try{
          if(file.size>12*1024*1024)throw Error('Vượt 12 MB');
          const rows=await parseFile(file);
          const form=new FormData();form.set('file',file);form.set('rows',JSON.stringify(rows));
          const response=await fetch('/api/finance?ads-import=1',{method:'POST',body:form});
          const result=await response.json() as any;
          if(!response.ok)throw Error(result.error||'Chưa lưu được');
          summary.push(file.name+' · thêm '+result.added+', trùng '+result.duplicate);
        }catch(e){summary.push(file.name+' · lỗi: '+(e as Error).message);}
      }
      await reload();
    }catch(e){summary.push((e as Error).message);}
    finally{setMessage(summary.join('\n'));lock.current=false;setBusy(false);}
  }
  async function linkAccount(account:string,shop:string){
    if(!shop||!window.confirm('Gán tài khoản '+account+' cho '+financeChannels[shop]+' ở các lần nhập sau?'))return;
    try{const r=await fetch('/api/finance?link-tiktok-account=1',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({account,shop})});if(!r.ok)throw Error(((await r.json()) as any).error);await reload();}catch(e){setMessage((e as Error).message);}
  }
  function exportCsv(){
    const rows=[['Mã chứng từ','Shop','Loại','Ngày','Số tiền VND','ID','Trạng thái']];
    for(const g of groups)for(const r of [g.evidence,g.invoice,...g.transactions])if(r)rows.push([g.evidence?.ref||g.ref,financeChannels[r.shop||'']||r.account||'',r.type,r.date,String(r.amount),r.number,status(g)]);
    const url=URL.createObjectURL(new Blob(['\uFEFF'+rows.map(r=>r.map(csvValue).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));
    const a=document.createElement('a');a.href=url;a.download='chung-tu-chi-phi.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  async function draft(row:NonNullable<Group['evidence']>){
    try{const res=await fetch('/api/finance?expense-receipt='+row.file,{method:'POST'}),receipt=await res.json() as any;
    if(!res.ok)throw Error(receipt.error);
    if(row.category==='ads'&&['shopee','tiktok1','tiktok2'].includes(row.shop||'')){
      if(!row.spend){setMessage('Chứng từ quảng cáo đã lưu để đối chiếu. Để ghi chi phí, chọn báo cáo có cột chi tiêu thực chạy.');return;}
      window.dispatchEvent(new CustomEvent('expense-ad-spend',{detail:{channel:row.shop,account:row.account,date:row.date,reference:row.ref,amount:row.amount,note:row.type,receipt}}));return;
    }
    onDraft({category:row.category,channel:row.shop||'unknown',date:row.date,reference:row.ref,description:row.type,counterparty:row.supplier,amount:row.amount,receipt,deductibility:'pending',note:row.member||''});
    }catch(e){setMessage((e as Error).message);}
  }
  return <section id="nhap-chung-tu-tiktok" className="panel"><h2>Nhập chứng từ chi phí</h2><p>Chọn PDF, Excel hoặc ZIP chứa nhiều chứng từ. PM đối chiếu ID tài khoản theo từng giao dịch. Khoản chưa rõ nguồn cần chọn shop khi lập phiếu. Có thể chọn nhiều tệp cùng lúc. Tối đa 12 MB/tệp.</p>
    <input ref={inputRef} aria-label="Chọn tệp chứng từ chi phí" type="file" multiple accept=".zip,.pdf,.xlsx" disabled={busy} onChange={e=>{const files=Array.from(e.target.files||[]);e.target.value='';void ingest(files);}}/>
    <p role="status" style={{whiteSpace:'pre-line'}}>{message}</p>
    {[...new Set(groups.flatMap(g=>g.transactions.filter(t=>!t.shop&&t.account).map(t=>t.account!)))].map(a=><label key={a}>Tài khoản TikTok Ads {a} <select value="" onChange={e=>void linkAccount(a,e.target.value)}><option value="">Chọn shop để ghi nhớ</option><option value="tiktok1">TikTok 1</option><option value="tiktok2">TikTok 2</option></select></label>)}
    <button className="btn" disabled={!groups.length} onClick={exportCsv}>Xuất danh sách CSV</button><details><summary>Hồ sơ đã lưu · {groups.length} mã chứng từ · {groups.filter(g=>status(g)==='Khớp số tiền').length} khớp số tiền</summary>
    <p>Hóa đơn và giao dịch dùng để đối chiếu. Chi tiêu thực chạy lấy theo báo cáo quảng cáo.</p>
    <div className="table-scroll"><table className="finance-table"><thead><tr><th>Mã chứng từ / Shop</th><th>Hóa đơn</th><th>Giao dịch</th><th>Đối chiếu</th></tr></thead>
    <tbody>{groups.map(g=>g.evidence?<tr key={g.ref}><td>{g.evidence.ref||g.evidence.member||g.evidence.type}<br/>{financeChannels[g.evidence.shop||'']||'Chờ chọn shop'}</td><td>{expenseCategories[g.evidence.category]} · {g.evidence.amount?money(g.evidence.amount):'Chờ kiểm tra số tiền'}<details><summary>Nội dung gốc</summary>{g.evidence.excerpt}</details>{source(g.evidence)}</td><td></td><td><button className="btn" onClick={()=>draft(g.evidence!)}>Rà soát và lập phiếu</button></td></tr>:<tr key={g.ref}><td>{g.ref}<br/>{[...new Set(g.transactions.map(t=>t.shop==='tiktok2'?'TikTok 2':t.shop==='tiktok1'?'TikTok 1':t.account))].join(', ')||'Chờ xác định shop'}</td>
    <td>{g.invoice&&<>{g.invoice.date} · {g.invoice.type}<br/>Trước thuế {money(g.invoice.net!)} · Thuế {money(g.invoice.tax!)}<br/>Tổng {money(g.invoice.amount)} · {source(g.invoice)}</>}</td>
    <td>{g.transactions.map(t=><div key={t.account+':'+t.number}>{t.date} · {t.type} · {t.method} · {t.status}<br/>{t.number} · {money(t.amount)} · {source(t)}</div>)}</td><td>{status(g)}</td></tr>)}</tbody></table></div>
    </details></section>;
}
