import {useMemo,useState} from 'react';
import {financeChannels,expenseGroups,csvValue} from '../../lib/finance';
import {rangeLabel} from '../../lib/date-range';
import type {GlobalPeriod} from '../global-period';

const shops=['facebook','tiktok1','tiktok2','shopee','shared'];
const shopName=(shop:string)=>shop==='shared'?'Chi phí chung':financeChannels[shop];
const taxLabels:Record<string,string>={eligible:'Đủ điều kiện',pending:'Chờ rà soát',ineligible:'Không được trừ'};
const money=(value:number)=>value.toLocaleString('vi-VN')+' ₫';
import {collect,type Line} from '../../lib/expense-lines';
export default function ShopCosts({data,period}:{data:any;period:GlobalPeriod}){
 const lines=useMemo(()=>collect(data),[data]);
 const groups={...expenseGroups,...(lines.some(l=>l.group==='unclassified')?{unclassified:'Phiếu cũ chờ phân nhóm'}:{})} as Record<string,string>;
 const [selection,select]=useState({group:'',shop:''});
 const selected=lines.filter(l=>(!selection.shop||l.shop===selection.shop)&&(!selection.group||l.group===selection.group));
 const totals=useMemo(()=>{
  const result=new Map<string,number>();
  for(const l of lines)for(const key of [l.group+'|'+l.shop,l.group+'|','|'+l.shop,'|'])result.set(key,(result.get(key)||0)+l.amount);
  return result;
 },[lines]);
 const [limit,setLimit]=useState(50);
 function show(group:string,shop:string){
  select({group,shop});setLimit(50);
  document.getElementById('ledger-detail')?.scrollIntoView({block:'start'});
 }
 function cell(group:string,shop:string){
  const n=totals.get(group+'|'+shop);
  return n===undefined?<span aria-label="Chưa có dòng ghi sổ">—</span>:<button type="button" className="text-btn" onClick={()=>show(group,shop)} aria-label={['Xem',groups[group]||'tất cả nhóm',shopName(shop)||'toàn shop',money(n)].join(' ')}>{money(n)}</button>;
 }
 const headings=['Ngày / kỳ','Shop','Nhóm','Khoản chi','Nguồn','Mã đối chiếu','Chứng từ','Ghi sổ','Điều kiện thuế','Số tiền'];
 const fields=(l:Line)=>[l.date,shopName(l.shop),groups[l.group],l.label,l.source,l.reference||'—',l.proof||'Chưa gắn tệp','Đã ghi sổ',taxLabels[l.tax]||'Chờ rà soát',l.amount];
 function download(){
  const content=[headings,...selected.map(fields)].map(row=>row.map(csvValue).join(',')).join('\r\n');
  const url=URL.createObjectURL(new Blob(['\uFEFF'+content],{type:'text/csv;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download='So-chi-phi-'+(period.range.from||'tat-ca')+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }
 return <section className="panel"><div className="returns-section-head"><div><h2>Sổ chi phí thực tế</h2><p>{rangeLabel(period.range)} · {lines.length} dòng đã ghi sổ</p></div><strong>{money(totals.get('|')||0)}</strong></div>
 <div className="table-scroll" tabIndex={0}><table className="finance-table"><thead><tr><th>Nhóm chi phí</th>{shops.map(s=><th key={s}>{shopName(s)}</th>)}<th>Tổng</th></tr></thead><tbody>{Object.entries(groups).map(([g,label])=><tr key={g}><th scope="row">{label}</th>{shops.map(s=><td key={s}>{cell(g,s)}</td>)}<td>{cell(g,'')}</td></tr>)}</tbody><tfoot><tr><th>Tổng ghi sổ</th>{shops.map(s=><td key={s}>{cell('',s)}</td>)}<td>{cell('','')}</td></tr></tfoot></table></div>
 <p>Dấu — cho biết chưa có dòng ghi sổ trong kỳ. Chi phí chung được giữ riêng khi chưa có căn cứ phân bổ.</p>
 <div id="ledger-detail" className="returns-section-head"><div><h3>{groups[selection.group]||'Tất cả nhóm'} · {shopName(selection.shop)||'Toàn shop'}</h3><p>{selected.length} dòng · {money(totals.get(selection.group+'|'+selection.shop)||0)}</p></div><div>{(selection.group||selection.shop)&&<button className="btn" onClick={()=>show('','')}>Xem toàn bộ</button>} <button className="btn" disabled={!selected.length} onClick={download}>Xuất CSV</button></div></div>
 <div className="table-scroll" tabIndex={0}><table className="finance-table"><thead><tr>{headings.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{selected.slice(0,limit).map((l,i)=><tr key={i}>{fields(l).map((v,j)=><td key={j}>{j===9?money(l.amount):v}</td>)}</tr>)}{!selected.length&&<tr><td colSpan={10}>Chưa có khoản đã ghi sổ trong kỳ này.</td></tr>}</tbody></table></div>
 {limit<selected.length&&<button className="btn" onClick={()=>setLimit(limit+50)}>Xem thêm 50 dòng</button>} <a href="/thue">Mở tab Thuế</a></section>;
}
