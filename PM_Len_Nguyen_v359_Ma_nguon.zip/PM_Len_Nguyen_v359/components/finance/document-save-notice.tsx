'use client';
import {useEffect,useState} from 'react';
import {expenseSaveKey,readSavedBatch,type SavedBatch} from '../../lib/expense-save-result';

export default function DocumentSaveNotice(){
 const [visible,setVisible]=useState(false);
 const [batch,setBatch]=useState<SavedBatch|null>(null);
 useEffect(()=>{
   if(new URLSearchParams(location.search).get('saved')!=='1')return;
   setVisible(true);
   try{setBatch(readSavedBatch(sessionStorage.getItem(expenseSaveKey)));}catch{}
 },[]);
 if(!visible)return null;
 return <section className="panel" role="status">
   <h2>{!batch?'Kết quả lưu chứng từ':batch.counts.failed?'Đã lưu một phần chứng từ':'Đã lưu chứng từ'}</h2>
   {batch?<><p>Lưu mới {batch.counts.added} · Đã có trong PM {batch.counts.duplicate} · Lỗi {batch.counts.failed}</p>
   <p><strong>Chi phí cộng thêm từ lượt lưu chứng từ: 0 ₫.</strong> Các PDF dùng để đối chiếu. Bảng chi phí bên dưới ghi nhận quảng cáo theo báo cáo chi tiêu thực chạy trong kỳ đang chọn.</p></>:<p>Mở danh sách chứng từ để kiểm tra các hồ sơ đã lưu.</p>}
   <a className="btn" href="/chi-phi/chung-tu?saved=1">Xem chứng từ đã lưu</a>
 </section>;
}
