'use client';
import {createPortal} from 'react-dom';
import {useRef,useState} from 'react';
import {documentKey,expenseSaveKey,type SaveSummary} from '../../lib/expense-save-result';
const labels:Record<string,string>={ref:'Số chứng từ',date:'Ngày',supplier:'Đơn vị phát hành',account:'Tài khoản',description:'Nội dung',type:'Loại',net:'Trước thuế',tax:'Thuế',amount:'Tổng tiền'};
export default function ZipReview({retry,items,busy,close,footer,filename}:{retry:(index:number)=>void;footer?:HTMLElement|null;filename?:string;items:any[];busy:boolean;close:()=>void}){
 const [selected,select]=useState<number[]>([]),[saving,setSaving]=useState(false),[messages,setMessages]=useState<Record<number,string>>({}),[saved,setSaved]=useState<number[]>([]);
 const dialog=useRef<HTMLDialogElement>(null),lock=useRef(false);
 const [progress,setProgress]=useState({done:0,total:0});
 const [results,setResults]=useState<{name:string;ref:string;status:string;amount?:number;failed:boolean}[]>([]);
 const savedKeys=useRef<string[]>([]);
 function viewSaved(summary:SaveSummary){
  try{sessionStorage.setItem(expenseSaveKey,JSON.stringify({counts:summary,keys:savedKeys.current,time:Date.now()}));}catch{}
  window.location.assign('/chi-phi?saved=1');
 }
 const [counts,setCounts]=useState({added:0,duplicate:0,failed:0});
 const ok=items.filter(e=>e.row).length,failed=items.filter(e=>e.error).length;
 const available=items.flatMap((e,i)=>e.row&&!saved.includes(i)?[i]:[]);
 async function save(){
  if(lock.current||!selected.length)return;
  lock.current=true;setSaving(true);savedKeys.current=[];
  const batch=[...selected],outcomes:typeof results=[],summary={added:0,duplicate:0,failed:0};
  setProgress({done:0,total:batch.length});
  try{
  for(const i of batch){const {pdf,row}=items[i];
   try{
    const payload=row.kind==='invoice'?Object.fromEntries(['kind','number','ref','account','date','type','net','tax','amount'].map(k=>[k,row[k]])):{...row,number:'1'};
    const body=new FormData();body.set('file',pdf);body.set('rows',JSON.stringify([payload]));
    const res=await fetch('/api/finance?ads-import=1',{method:'POST',body}),v=await res.json() as any;
    if(!res.ok)throw Error(v.error||'Lỗi lưu');
    if(!((v.added===1&&v.duplicate===0)||(v.added===0&&v.duplicate===1)))throw Error('Máy chủ chưa xác nhận kết quả lưu.');
    summary.added+=v.added;summary.duplicate+=v.duplicate;
    savedKeys.current.push(documentKey(payload));
    outcomes.push({name:items[i].name,ref:row.ref,amount:row.amount,status:v.duplicate?'Đã có trong PM':'Đã lưu mới',failed:false});
    setMessages(m=>({...m,[i]:v.duplicate?'Đã có chứng từ':'Đã lưu đối chứng'}));setSaved(s=>[...s,i]);select(s=>s.filter(k=>k!==i));
   }catch(e){const status=(e as Error).message;summary.failed++;
    outcomes.push({name:items[i].name,ref:row.ref,status,failed:true});setMessages(m=>({...m,[i]:status}));}
   setProgress({done:outcomes.length,total:batch.length});
  }
  setCounts(summary);setResults(outcomes);
  if(!summary.failed){viewSaved(summary);}else{dialog.current?.showModal();}
  }finally{lock.current=false;setSaving(false);}
 }
 const saveButton=<button className="btn primary" type="button" disabled={busy||saving||!selected.length} onClick={save}>{saving?'Đang lưu '+progress.done+'/'+progress.total+'…':'Lưu đối chứng đã chọn ('+selected.length+')'}</button>;
 return <section><p role="status">Đã đọc {ok+failed}/{items.length} PDF · Thành công {ok} · Lỗi {failed}</p><label><input type="checkbox" disabled={busy||saving||!available.length} checked={!!available.length&&selected.length===available.length} onChange={e=>select(e.target.checked?available:[])}/>Chọn tất cả chứng từ đọc được</label><div style={{maxHeight:380,overflow:'auto'}}>{items.map((entry,i)=><div key={i}><label><input type="checkbox" disabled={busy||saving||!available.includes(i)} checked={selected.includes(i)} onChange={e=>select(s=>e.target.checked?[...s,i]:s.filter(k=>k!==i))}/>{entry.name}</label>{entry.row?<details><summary>{entry.row.ref||'Chưa rõ mã'} · {entry.row.type} · {entry.row.amount?.toLocaleString('vi-VN')??'Chưa rõ tổng'}</summary>{Object.entries(labels).map(([key,label])=><p key={key}>{label} · {entry.row[key]===0?'0':entry.row[key]||'Chưa đọc được'}</p>)}</details>:<p>{entry.error||'Chờ đọc'} {entry.error&&entry.pdf&&<button type="button" disabled={busy||saving} onClick={()=>retry(i)}>Đọc lại PDF này</button>}</p>}{messages[i]&&<small>{messages[i]}</small>}</div>)}</div>{saveButton}{footer&&createPortal(<div><small>{filename}</small>{saveButton}</div>,footer)}<button type="button" disabled={busy||saving} onClick={close}>Đóng</button>
 <p>Lưu xong sẽ mở bảng chi phí và hiện kết quả lưu chứng từ.</p>
 <p role="status" aria-live="polite">{saving?'Đang xử lý '+progress.done+'/'+progress.total+' chứng từ':results.length?'Lưu mới '+counts.added+' · Đã có '+counts.duplicate+' · Lỗi '+counts.failed:''}</p>
 {results.length>0&&<button type="button" onClick={()=>dialog.current?.showModal()}>Xem kết quả lần lưu</button>}
 <dialog ref={dialog} aria-label="Kết quả lưu chứng từ" style={{position:'fixed',inset:0,margin:'auto',width:'min(680px,94vw)',maxHeight:'85vh',overflow:'auto',padding:'1rem'}}>
 <h2>Kết quả lưu chứng từ</h2><p role="status"><strong>Lưu mới {counts.added} · Đã có {counts.duplicate} · Lỗi {counts.failed}</strong></p>
 <button type="button" onClick={()=>dialog.current?.close()}>{counts.failed?'Quay lại các tệp cần thử lại':'Quay lại nhập liệu'}</button>{' '}<button type="button" disabled={!counts.added&&!counts.duplicate} onClick={()=>viewSaved(counts)}>Về bảng chi phí và xem kết quả</button>
 <ul>{results.map((r,i)=><li key={i} style={{overflowWrap:'anywhere'}}><strong>{r.ref||r.name}</strong> · {r.status}{r.amount!=null?' · '+r.amount.toLocaleString('vi-VN')+' ₫':''}</li>)}</ul></dialog></section>
}
