'use client';
import {useEffect,useState} from 'react';
type Invoice={id:string;supplier:string;date:string;number:string;printedTotal:string;status:string};
const money=(n:number)=>n.toLocaleString('vi-VN')+' ₫';
export default function InvoicePurchases({from,to}:{from:string;to:string}){
 const [rows,setRows]=useState<Invoice[]>([]),[message,setMessage]=useState('Đang tải…');
 useEffect(()=>{
  const controller=new AbortController();
  fetch('/api/gmail-evidence?purchases=1',{signal:controller.signal,cache:'no-store'}).then(async response=>{
   if(!response.ok)throw Error(response.status===403?'Cần quyền chủ shop để xem hóa đơn.':'Chưa tải được hóa đơn.');
   const data=await response.json() as {rows:Invoice[]};
   const invoices=new Map(data.rows.filter(r=>r.status==='documented').map(r=>[r.id,r]));
   setRows(Array.from(invoices.values()));setMessage('');
  }).catch(e=>{if(!controller.signal.aborted)setMessage(e.message);});
  return ()=>controller.abort();
 },[]);
 const [cash,setCash]=useState<string>('…');
 useEffect(()=>{
  const controller=new AbortController();
  setCash('…');
  fetch('/api/purchases?'+new URLSearchParams({mode:'cash-paid',from,to}),{signal:controller.signal,cache:'no-store'})
   .then(async r=>{if(!r.ok)throw Error();const data=await r.json();if(!controller.signal.aborted)setCash(money(data.paid));})
   .catch(()=>{if(!controller.signal.aborted)setCash('Chưa tải được');});
  return ()=>controller.abort();
 },[from,to]);
 const selected=rows.filter(r=>(!from||r.date>=from)&&(!to||r.date<=to));
 return <><p className="panel"><strong>Tiền đã chi mua hàng</strong> · {cash}<small className="purch-sub">Tiền thực trả trong kỳ, gồm cả khoản chờ đối chiếu.</small></p><details className="panel"><summary><strong>Mua hàng theo hóa đơn</strong> · {message||money(selected.reduce((sum,r)=>sum+Number(r.printedTotal),0))}</summary>
  <p>{selected.length} hóa đơn trong kỳ · Giá vốn hàng bán được tính theo đơn bán.</p>
  {selected.map(r=><p key={r.id}>{r.date.split('-').reverse().join('/')} · {r.supplier} · HĐ {r.number} · {money(Number(r.printedTotal))}</p>)}
  <a href="/nhap-hang/hoa-don">Xem chứng từ gốc</a></details></>;
}
