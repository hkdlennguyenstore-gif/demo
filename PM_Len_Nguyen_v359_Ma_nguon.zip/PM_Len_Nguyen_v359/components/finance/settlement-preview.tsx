'use client';
import {useMemo,useRef,useState} from 'react';

export default function SettlementPreview({entries,onSaved}:any){
 const [shop,setShop]=useState(''),[from,setFrom]=useState(''),[to,setTo]=useState(''),[type,setType]=useState('');
 const [checked,check]=useState<any>(null),[message,report]=useState(''),[busy,working]=useState(false),lock=useRef(false);
 const preview=useMemo(()=>{
  const rows=new Map<string,any>(),errors=new Set<string>(),types=new Set<string>();let duplicate=0,count=0;
  for(const entry of entries)for(const r of entry.parsed?.rows||[]){
   if(r.signedFee===undefined)continue;types.add(r.type);
   if((from&&r.date<from)||(to&&r.date>to)||(type&&r.type!==type))continue;
   count++;const k=JSON.stringify([r.date,r.ref,r.type]),prior=rows.get(k);
   if(!/^\d{12,24}$/.test(r.ref)||!/^20\d\d-\d\d-\d\d$/.test(r.date)||!Number.isSafeInteger(r.signedFee)||prior&&(prior.amount!==r.signedFee||prior.entry===entry.id))errors.add(k);
   if(prior){duplicate++;continue;}
   rows.set(k,{date:r.date,ref:r.ref,type:r.type,amount:r.signedFee,file:entry.file.name,entry:entry.id});
  }
  const unique=[...rows.values()];
  return {unique,count,duplicate,errors:errors.size,types:[...types] as string[],total:unique.reduce((n,r)=>n+r.amount,0)};
 },[entries,from,to,type]);
 const verified=checked?.preview===preview&&checked.shop===shop;
 async function run(commit:boolean){
  if(lock.current||!shop||!preview.count||preview.errors||(commit&&!verified))return;
  lock.current=true;working(true);report('');let done=0,delta=0,fresh=0;
  try{
   const groups=new Map<string,any[]>();for(const row of preview.unique){if(!groups.has(row.date))groups.set(row.date,[]);groups.get(row.date)!.push(row);}
   for(const [date,group] of groups)for(let start=0;start<group.length;start+=1000){
    const rows=group.slice(start,start+1000);
    const response=await fetch('/api/finance',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'settlement-import',commit,shop,date,rows})});
    const v=await response.json() as {n?:number;fresh?:number;delta?:number;error?:string};
    if(!response.ok||v?.n!==rows.length||typeof v.fresh!=='number'||typeof v.delta!=='number')throw Error(v?.error||'Máy chủ chưa xác nhận đủ dòng.');
    fresh+=v.fresh;delta+=v.delta;done+=rows.length;report((commit?'Đang ghi và đọc lại ':'Đang kiểm tra ')+done+'/'+preview.unique.length);
   }
   if(commit){
    const totals=new Map<string,number>();
    for(const row of preview.unique)totals.set(row.type,(totals.get(row.type)||0)+row.amount);
    const dates=[...groups.keys()].sort();
    await onSaved({shop,from:dates[0],to:dates[dates.length-1],fresh,existing:done-fresh,delta,total:preview.total,totals:[...totals]});
   }
   else{check({preview,shop});report('Chờ xác nhận · Mới '+fresh+' · Đã có trong sổ '+(done-fresh)+' · Số tiền tăng/giảm '+delta.toLocaleString('vi-VN')+' đ');}
  }catch(e){check(null);report((commit?'Lưu chưa hoàn tất':'Kiểm tra thất bại')+' · '+done+' dòng đã kiểm tra · '+(e as Error).message+' · Kiểm tra lại để tiếp tục.');}
  finally{lock.current=false;working(false);}
 }
 return <fieldset disabled={busy}><legend>Lưu phí sàn từ tệp</legend><label>Shop của lô tệp<select value={shop} onChange={e=>{setShop(e.target.value);report('');check(null)}}><option value="">Chọn shop…</option><option value="tiktok1">TikTok 1 · Len Nguyen Store</option><option value="tiktok2">TikTok 2 · Lên Nguyễn Store.</option></select></label><details><summary>Lọc theo ngày hoặc loại phí</summary><label>Từ ngày<input type="date" value={from} onChange={e=>{setFrom(e.target.value);report('')}}/></label><label>Đến ngày<input type="date" value={to} onChange={e=>{setTo(e.target.value);report('')}}/></label><label>Loại phí<select value={type} onChange={e=>{setType(e.target.value);report('')}}><option value="">Tất cả</option>{preview.types.map(t=><option key={t}>{t}</option>)}</select></label></details>
 <p>{preview.count} dòng · {preview.unique.length-preview.errors} hợp lệ · {preview.duplicate} lặp · {preview.errors} cần rà soát · Tổng sau loại trùng {preview.total.toLocaleString('vi-VN')} đ</p>
 <details><summary>Xem các dòng phí</summary><table><caption>10 dòng đầu sau khi lọc</caption><thead><tr><th>Ngày</th><th>Mã đơn</th><th>Loại phí</th><th>Phí / hoàn phí (đ)</th></tr></thead><tbody>{preview.unique.slice(0,10).map((r,i)=><tr key={i}><td>{r.date}</td><td>{r.ref}</td><td>{r.type}</td><td>{r.amount.toLocaleString('vi-VN')}</td></tr>)}</tbody></table></details>
 <p role="status">{message || (!shop ? 'Chọn shop áp dụng cho tất cả tệp để tiếp tục.' : preview.errors ? 'Có dòng cần rà soát trước khi lưu.' : !preview.count ? 'Bộ lọc chưa có dòng phí.' : 'Kiểm tra số tiền sẽ ghi vào sổ.')}</p>
 <button type="button" className="btn primary" disabled={!shop || !preview.count || !!preview.errors || (verified && checked.saved)} onClick={()=>run(verified === true)}>
 {busy ? 'Đang xử lý…' : verified ? checked.saved ? 'Đã lưu' : 'Lưu phí sàn' : 'Kiểm tra số tiền'}
 </button></fieldset>;
}
