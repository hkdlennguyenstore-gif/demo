'use client';
import {useState} from 'react';
import {amount,channels,reportTable,downloadBytes} from '../../lib/shop-expense-report';
import type {Line} from '../../lib/expense-lines';
const money=(n:number)=>n.toLocaleString('vi-VN')+' ₫';
export function ShopTotals({lines,select}:{lines:Line[],select:(shop:string)=>void}){
 return <div className="report-shops">{Object.entries(channels).map(([id,name])=>{const rows=lines.filter(l=>l.shop===id);return <button key={id} onClick={()=>select(id)}>{name}<strong>{rows.length?money(amount(rows)):'Chưa có dòng phù hợp'}</strong></button>})}</div>
}
export function Comparison({lines}:{lines:Line[]}){
 const [head,...rows]=reportTable(lines,true);
 return <section className="panel"><h2>So sánh theo shop</h2><div className="table-scroll"><table><thead><tr>{head.map(x=><th key={x}>{x}</th>)}</tr></thead><tbody>{rows.map(r=><tr key={r[0]}>{r.map((c,i)=><td key={i}>{typeof c==='number'?money(c):c||'—'}</td>)}</tr>)}</tbody><tfoot><tr><th>Tổng</th>{Object.keys(channels).map(k=>{const a=lines.filter(l=>l.shop===k);return <td key={k}>{a.length?money(amount(a)):'—'}</td>})}<th>{money(amount(lines))}</th></tr></tfoot></table></div></section>
}
export function ExportReport({lines,period}:{lines:Line[],period:string}){
 const [mode,setMode]=useState('detail'),[format,setFormat]=useState('csv');
 const table=reportTable(lines,mode==='summary');
 function save(){const xlsx=format==='xlsx',bytes=downloadBytes(table,xlsx),url=URL.createObjectURL(new Blob([new Uint8Array(bytes)],{type:xlsx?'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='Chi-phi-'+period+'-'+mode+'.'+format;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}
 return <div className="cebar"><select aria-label="Kiểu báo cáo" value={mode} onChange={e=>setMode(e.target.value)}><option value="detail">Chi tiết</option><option value="summary">Tổng hợp theo shop</option></select><select aria-label="Định dạng tải" value={format} onChange={e=>setFormat(e.target.value)}><option value="csv">CSV</option><option value="xlsx">Excel (.xlsx)</option></select><span>{table.length-1} dòng xuất · {money(amount(lines))}</span><button className="btn" onClick={save}>Tải theo bộ lọc</button></div>
}
function missingDates(dates:Set<string>,from:string,to:string){
 const start=Date.parse(from),end=Date.parse(to),chunks:string[]=[];let first='',last='';
 if(!Number.isFinite(start)||!Number.isFinite(end))return '';
 function flush(){if(first)chunks.push(first===last?first:first+' – '+last);first='';}
 for(let t=start;t<=end;t+=86400000){const d=new Date(t).toISOString().slice(0,10);if(dates.has(d))flush();else{if(!first)first=d;last=d;}}flush();return chunks.join(', ');
}
export function Coverage({data,lines,from,to,shop}:{data:any,lines:Line[],from:string,to:string,shop:string}){
 if(!data)return null;
 return <details><summary>Kiểm tra nguồn chi tiêu quảng cáo trong kỳ</summary>{Object.entries(data.accounts||{}).filter(([,k])=>!shop||k===shop).map(([account,id])=>{
 const channel=String(id),dates=new Set(lines.filter(l=>l.shop===channel&&l.account===account).map(l=>l.date)),missing=missingDates(dates,from,to);
 const feeds=channel==='shopee'?['shopee_daily','account_day_report']:['tiktok_daily','account_day_report'];
 const read=(data.readSources||[]).filter((s:any)=>feeds.includes(s.id.split(':')[0])&&s.lastSuccess).map((s:any)=>s.lastSuccess).sort().at(-1);
 return <p key={account}><b>{channels[channel as keyof typeof channels]} · {account}</b><br/>Báo cáo chi tiêu ngày · {dates.size} ngày có dòng trong kỳ. {missing?'Chưa có dòng ngày '+missing:from&&to?'Đã có dòng cho từng ngày trong khoảng kiểm tra.':'Chọn kỳ có ngày bắt đầu để kiểm tra khoảng thiếu.'}<br/>Đồng bộ nguồn báo cáo gần nhất · {read?new Date(read).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}):'Chưa ghi nhận'} · <a target="_blank" rel="noreferrer" href={'https://drive.google.com/drive/folders/'+data.folderId}>Bổ sung báo cáo đúng tài khoản</a></p>})}</details>
}
