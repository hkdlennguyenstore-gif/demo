export async function fileDraft(key:string,mode:'save'|'read',value?:any){
 const db=await new Promise<IDBDatabase>((resolve,reject)=>{
  const request=indexedDB.open('pm-expense-drafts',1);
  request.onupgradeneeded=()=>request.result.createObjectStore('drafts');
  request.onerror=()=>reject(request.error);
  request.onsuccess=()=>resolve(request.result);
 });
 try{return await new Promise<any>((resolve,reject)=>{
  const tx=db.transaction('drafts',mode==='save'?'readwrite':'readonly'),table=tx.objectStore('drafts');
  const req=mode==='save'?table.put(value,key):table.get(key);
  tx.oncomplete=()=>resolve(req.result);tx.onabort=()=>reject(tx.error);tx.onerror=()=>reject(tx.error);
 });}finally{db.close();}
}
