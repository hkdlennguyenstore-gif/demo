'use client';
import {Fragment,useState,useRef,useMemo,useEffect} from 'react';
import {ShopTotals,Comparison,ExportReport,Coverage} from './shop-report';
import HistoricalExpenses from './historical-purchases';
import InvoicePurchases from './invoice-purchases';
import LineActions from './line-actions';
import SourceControls from './source-controls';
import {collect,filterExpenses,taxBucket,type Line} from '../../lib/expense-lines';
import {expenseGroups,expenseCategories,financeChannels,csvValue} from '../../lib/finance';
import GlobalPeriodBar,{type GlobalPeriod} from '../global-period';
import {rangeLabel,withinRange} from '../../lib/date-range';
import ExpenseReader from './expense-reader';
import {GroupInputs,blankItem,type Item} from './expense-inputs';
import DataDownloads from './data-downloads';
import DetailDownloads,{type DetailDocument} from './detail-downloads';
import DocumentLinks from './document-links';
import './compact-expenses.css';
const money=(n:number)=>n.toLocaleString('vi-VN')+' ₫';
const total=(rows:Line[])=>rows.reduce((n,l)=>n+l.amount,0);
const shops:Record<string,string>={...financeChannels,shared:'Chi phí chung'};
const manualExpenseGroups=Object.entries(expenseGroups).filter(([id])=>id!=='cogs');
const groups:Record<string,string>={...expenseGroups,unclassified:'Chờ phân nhóm'};
const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}).format(new Date());
const pay=(l:Line)=>l.paid===undefined?'Theo nguồn':l.amount<0?'Điều chỉnh':l.paid===0?'Chưa trả':l.paid===l.amount?'Đã trả đủ':'Trả một phần';
type Props={data:any;period:GlobalPeriod;refresh:()=>Promise<void>;source:(group:string)=>React.ReactNode;detail:(r:any)=>void};
export default function CompactExpenses({data,period,refresh,source,detail}:Props){
 useEffect(()=>{if(window.location.hash==='#tai-du-lieu'){const el=document.getElementById('tai-du-lieu') as HTMLDetailsElement|null;if(el)el.open=true;}},[]);
 const [shop,setShop]=useState(''),[group,drawer]=useState(''),[entry,form]=useState(''),[compare,comparison]=useState(false),[empty,hide]=useState(false),[notice,report]=useState(''),[undo,setUndo]=useState(''),[edit,setEdit]=useState<any>(null);
 const complete=useMemo(()=>collect(data,true),[data]),all=complete.filter(l=>!l.excluded);
 const [query,setQuery]=useState(''),[tax,setTax]=useState(''),[state,setState]=useState(''),[origin,setOrigin]=useState('');
 const [mainGroup,setMainGroup]=useState(''),[invoice,setInvoice]=useState('');
 const filters=new URLSearchParams({shop,group:mainGroup,source:origin,query,tax,invoice});
 const lines=filterExpenses(complete,filters);
 const inGroup=complete.filter(l=>(!shop||l.shop===shop)&&(group==='all'||l.group===group));
 const params=new URLSearchParams({export:'csv',from:period.range.from||'',to:period.range.to||'',invoice,group:group==='all'?mainGroup:group,shop,query,tax,state,source:origin});
 const selected=filterExpenses(complete,params);
 function lineDocuments(line:Line):DetailDocument[]{
  const docs:DetailDocument[]=line.url?[{label:line.proof||'Tài liệu nguồn',url:line.url,kind:line.url.startsWith('/api/')?'file':'source'}]:[];
  const add=(receipt:any,id:string,flag='')=>{if(receipt?.key)docs.push({label:receipt.name||'Chứng từ đã lưu',url:'/api/finance?'+new URLSearchParams({id,file:receipt.key,...(flag?{[flag]:'1'}:{})}),kind:'file'});};
  if(line.id){const record=data.rows.find((r:any)=>r.id===line.id);add(record?.taxReassessment?.receipt,line.id);}
  if(line.group==='staff'&&line.reviewId)add(data.payrollCosts.rows.find((r:any)=>r.id===line.reviewId)?.review?.receipt,line.reviewId,'review');
  if(line.group==='ads'){
   const manual=data.driveAds?.manual?.find((r:any)=>r.active&&r.channel===line.shop&&r.account===line.account&&r.date===line.date);
   if(manual)add(manual.receipt,manual.id,'manualAds');
  }
  return Array.from(new Map(docs.map(doc=>[doc.url,doc])).values());
 }

 async function save(action:string,payload:any){await api(action,data.version,payload,crypto.randomUUID());await refresh();}
 function openList(g:string,bucket?:string){setFeeResult(null);if(bucket!==undefined)setTax(bucket);setState('');drawer(g);}
 const [feeResult,setFeeResult]=useState<any>(null);
 const [lastSaved,setLastSaved]=useState('');
 const [visited,setVisited]=useState<string[]>([]),[round,setRound]=useState<Record<string,number>>({});
 const readerQueues=useRef<Record<string,{entries:any[]}>>({});
 const [dirty,setDirty]=useState<Record<string,boolean>>({});
 const close=()=>{form('');setPicker(false);};
 const [picker,setPicker]=useState(false);
 const [adjust,adjusting]=useState(false);
 function start(g:string){if(mainGroup&&mainGroup!==g)setMainGroup('');setFeeResult(null);setVisited(v=>v.includes(g)?v:[...v,g]);setPicker(false);form(g);drawer('');setEdit(null);adjusting(false);report('');}
 useEffect(()=>{
   function key(e:KeyboardEvent){if(e.key==='Escape'){if(group)drawer('');else close();}}
   function outside(e:PointerEvent){if(!entry||dirty[entry]||edit||adjust)return;const target=e.target as Element;if(!target.closest('.ceentry,[data-entry-control]'))close();}
   document.addEventListener('keydown',key);document.addEventListener('pointerdown',outside);
   return ()=>{document.removeEventListener('keydown',key);document.removeEventListener('pointerdown',outside);};
 },[entry,group,dirty,edit,adjust]);
 const gaps=(data.driveAds?.shops||[]).filter((s:any)=>(!mainGroup||mainGroup==='ads')&&(!shop||shop===s.channel)&&['awaiting_source','partial'].includes(s.status));
 function status(g:string,rows:Line[]){if(g==='ads'&&gaps.length)return 'Thiếu nguồn';if(g==='staff'&&rows.some(l=>l.provisional))return 'Tạm tính';if(g==='staff'&&!rows.length&&(!shop||shop==='shared')&&data.payrollCosts.rows.some((r:any)=>r.salaryMissing||r.missing))return 'Thiếu dữ liệu lương';return rows.length?(rows.every(l=>l.amount===0)?'Không phát sinh':'Đã chốt'):'Chưa nhập';}
 async function reverse(id:string){const row=data.rows.find((r:any)=>r.id===id);if(!row)return;try{await api('undo-quick',data.version,{id,version:row.version},crypto.randomUUID());await refresh();setUndo('');report('Đã hoàn tác '+row.description);}catch(e){report((e as Error).message)}}
 const hasFilters=Boolean(mainGroup||shop||origin||tax||invoice||query);
 const savedRecord=lastSaved&&data.rows.find((row:any)=>row.id===lastSaved);
 useEffect(()=>{
   if(!Object.values(dirty).some(Boolean))return;
   function warn(event:BeforeUnloadEvent){event.preventDefault();event.returnValue='';}
   window.addEventListener('beforeunload',warn);
   return ()=>window.removeEventListener('beforeunload',warn);
 },[dirty]);
 return <div className="ce"><header className="ceheading"><div><h1>Chi phí</h1><span>{rangeLabel(period.range)}</span></div><button className="btn primary" onClick={()=>{start(mainGroup&&mainGroup!=='cogs'?mainGroup:'operations');setPicker(true)}}>+ Nhập chi phí</button></header><div className="cebar"><details><summary>{rangeLabel(period.range)}</summary><GlobalPeriodBar period={period}/></details><select aria-label="Lọc shop" value={shop} onChange={e=>setShop(e.target.value)}><option value="">Tất cả shop</option>{Object.entries(shops).map(([id,n])=><option key={id} value={id}>{n}</option>)}</select></div>
 <details className="cefilter-panel"><summary>Bộ lọc chi phí{hasFilters?" · Đang lọc":""}</summary><div className="cefilters"><label>Đầu chi<select value={mainGroup} onChange={e=>setMainGroup(e.target.value)}><option value="">Tất cả</option>{Object.entries(groups).map(([k,n])=><option key={k} value={k}>{n}</option>)}</select></label><label>Nguồn<select value={origin} onChange={e=>setOrigin(e.target.value)}><option value="">Tất cả</option>{Array.from(new Set(all.map(l=>l.source))).sort().map(n=><option key={n}>{n}</option>)}</select></label><label>Rà soát thuế<select value={tax} onChange={e=>setTax(e.target.value)}><option value="">Tất cả</option><option value="pending">Chờ rà soát</option><option value="eligible">Đủ điều kiện</option><option value="ineligible">Không được trừ</option></select></label><label>Hóa đơn<select value={invoice} onChange={e=>setInvoice(e.target.value)}><option value="">Tất cả</option><option value="yes">Có hóa đơn cho tài khoản/kỳ</option><option value="no">Chưa xác nhận hóa đơn</option></select></label><label>Từ khóa<input type="search" value={query} onChange={e=>setQuery(e.target.value)}/></label>{hasFilters&&<button type="button" onClick={()=>{setShop('');setMainGroup('');setOrigin('');setTax('');setInvoice('');setQuery('');}}>Xóa bộ lọc</button>}</div></details>
 <ShopTotals lines={lines} select={k=>{setShop(k);openList('all')}}/>
 {(!shop||shop==='shared')&&<InvoicePurchases from={period.range.from||''} to={period.range.to||''}/>}
 {picker&&<label data-entry-control>Chọn đầu chi <select value={entry} onChange={e=>{start(e.target.value);setPicker(true);}}>{[...manualExpenseGroups,['unclassified','Chờ phân nhóm / Chi phí khác']].map(([id,n])=><option key={id} value={id}>{n}</option>)}</select></label>}<section className="cesum"><span>Chi phí đã ghi nhận{lines.some(l=>l.provisional)?' (gồm lương tạm tính)':''}{gaps.length?' — chưa đầy đủ':''}</span><strong>{lines.length?money(total(lines)):'—'}</strong><small>{lines.length} dòng đã ghi nhận{gaps.length?' · '+gaps.map((s:any)=>s.name+(s.status==='partial'?' có một phần dữ liệu':' chờ báo cáo')).join(' · '):''}</small><div className="ceactions">{[['','Tổng chi phí'],['eligible','Hợp lệ'],['pending','Chờ rà soát'],['ineligible','Không hợp lệ']].map(([id,name])=><button key={name} onClick={()=>openList('all',id)}>{name} · {money(total(lines.filter(l=>!id||taxBucket(l)===id)))}</button>)}</div><ExportReport lines={lines} period={[period.range.from,period.range.to].filter(Boolean).join('_')}/>{(!mainGroup||mainGroup==='ads')&&<Coverage data={data.driveAds} lines={complete} from={period.range.from||''} to={[period.range.to||today(),today()].sort()[0]} shop={shop}/>}</section>
 {notice&&<p className="cesaved" role="status">{notice} {savedRecord&&<button onClick={()=>detail(savedRecord)}>Xem phiếu vừa lưu</button>} {undo&&<button onClick={()=>reverse(undo)}>Hoàn tác</button>}</p>}
 <nav className="ceroutes" aria-label="Tra cứu chi phí"><button onClick={()=>openList('all')}>Xem từng khoản chi</button><button onClick={()=>{openList('all');setState('excluded');}}>Khoản đã loại</button><a href="/chi-phi/gmail">Chứng từ Gmail</a><a href="#tai-du-lieu" onClick={()=>{const el=document.getElementById('tai-du-lieu') as HTMLDetailsElement|null;if(el)el.open=true;}}>Tải dữ liệu &amp; chứng từ</a><a href="/thue">Rà soát thuế</a></nav>
 <details id="tai-du-lieu" className="cefilter-panel"><summary>Tải dữ liệu &amp; chứng từ</summary><DataDownloads from={period.range.from} to={period.range.to} channel={shop||'all'}/></details>
 <div className="cebar"><h2>Chi phí theo đầu mục</h2><label><input type="checkbox" checked={empty} onChange={e=>hide(e.target.checked)}/> Gọn nhóm chưa nhập</label><button className="text-btn" onClick={()=>comparison(!compare)}>So sánh theo shop</button></div>
 <div className="cegrid"><b>Đầu chi</b><b>Số tiền trong kỳ</b><b>Trạng thái</b></div>
 {(!shop||shop==='shared')&&<HistoricalExpenses from={period.range.from||''} to={period.range.to||''}/>}
 {Object.entries(groups).map(([g,name])=>{if(g==='cogs'&&!(entry===g&&edit))return null;const rows=lines.filter(l=>l.group===g),state=status(g,rows);if(mainGroup&&g!==mainGroup)return null;if(!rows.length&&(empty&&state==='Chưa nhập'&&entry!==g&&!dirty[g]))return null;
 const special=Boolean(entry===g&&(edit||adjust));
 const saved=async(id:string,msg:string,again:boolean,meta:{date:string;channel:string;group?:string})=>{report('Đã lưu thành công. '+msg);setUndo(id);setLastSaved(id);
 setQuery('');setOrigin('');setTax('');setInvoice('');setState('');setMainGroup('');setShop(meta.channel);
 const changedPeriod=!withinRange(meta.date,period.range);if(changedPeriod)period.set({...period.selection,kind:'day',day:meta.date});
 if(!changedPeriod){try{await refresh();}catch{report('Đã lưu thành công. Chưa tải lại được danh sách; vui lòng tải lại trang để xem.');}}if(!special){setRound(v=>({...v,[g]:(v[g]||0)+1}));setDirty(v=>({...v,[g]:false}));}if(!again){close();drawer(meta.group||g);}};
 const onFeesSaved=async(result:any)=>{
  setFeeResult(result);setShop(result.shop);setMainGroup('');setQuery('');setOrigin('');setTax('');setState('');setInvoice('');setUndo('');setLastSaved('');
  report('Đã lưu phí sàn · '+shops[result.shop]+' · '+result.fresh.toLocaleString('vi-VN')+' dòng mới · '+result.existing.toLocaleString('vi-VN')+' dòng đã có · Thay đổi trong sổ '+money(result.delta));
  close();drawer(g);
  if(period.range.from!==result.from||period.range.to!==result.to)period.set({...period.selection,kind:'custom',from:result.from,to:result.to});
  else try{await refresh();}catch{report(v=>v+' · Chưa tải lại được danh sách chi phí.');}
 };
 const props={refresh,onFeesSaved,queue:readerQueues.current[g]??={entries:[]},group:g,data,period,shop,all,cancel:close,done:saved,openSource:()=>{close();openList(g);}};
 return <Fragment key={g}><div className="cegrid"><div className="cename"><button onClick={()=>{close();openList(g)}}>{name}</button>
 {g==='staff'&&<small>Từ bảng lương theo tháng · Chi phí chung</small>}{g!=='cogs'&&<button type="button" className="ceadd" data-entry-control aria-expanded={entry===g} aria-controls={'entry-'+g} aria-label={'Nhập '+name} onClick={()=>entry===g?close():start(g)}>{g==='staff'?'Nhập bổ sung':g==='unclassified'?'Thêm chi phí':'Nhập'}{dirty[g]&&entry!==g?' · nháp':''}</button>}{g==='unclassified'&&<><button type="button" className="ceadd" onClick={()=>{close();openList(g)}}>Xem / sửa</button><small>Thêm khoản chi khác hoặc chọn đầu mục để phân nhóm.</small></>}</div>
 <button onClick={()=>{close();openList(g)}}>{rows.length?money(total(rows)):'—'}</button><small>{state==='Thiếu nguồn'?'Báo cáo chi tiêu ngày chưa đầy đủ':state}</small></div>
 <div id={'entry-'+g} hidden={entry!==g}>{visited.includes(g)&&<div hidden={special}><Entry key={round[g]||0} {...props} mark={()=>setDirty(v=>v[g]?v:{...v,[g]:true})}/></div>}
 {special&&<Entry key={edit?.id||'adjust'} {...props} edit={edit} adjustment={adjust} mark={()=>{}}/>}</div></Fragment>})}
 {compare&&<Comparison lines={lines}/>}
 {group&&<div className="ceveil" onClick={event=>{if(event.target===event.currentTarget)drawer('');}}><section className="cedrawer" role="dialog" aria-modal="true" aria-label={groups[group]||'Tất cả chi phí'}><header style={{justifyContent:'flex-end'}}><button type="button" onClick={()=>drawer('')}>Đóng chi tiết</button></header><h2>{groups[group]||'Tất cả chi phí'}</h2>{notice&&<p role="status" aria-live="polite">{notice}</p>}<p>{shop?shops[shop]:'Tất cả shop'} · {rangeLabel(period.range)}</p>{feeResult&&group==='platform'&&feeResult.shop===shop&&<section aria-label="Kết quả lưu phí"><h3>Phí trong lô vừa lưu</h3><p>{rangeLabel(feeResult)} · Tổng {money(feeResult.total)}</p><table><thead><tr><th>Loại phí</th><th>Số tiền</th></tr></thead><tbody>{feeResult.totals.map(([type,amount]:[string,number])=><tr key={type}><td>{type}</td><td>{money(amount)}</td></tr>)}</tbody></table></section>}<h3>{selected.length?money(total(selected)):'Chưa có khoản ghi nhận'}</h3>
 {data.canSetPacking&&group!=='cogs'&&group!=='unclassified'&&group!=='all'&&<button onClick={()=>{start(group);adjusting(true)}}>Điều chỉnh tổng kỳ</button>}
 <div className="cefilters"><label>Tìm khoản chi<input value={query} onChange={e=>setQuery(e.target.value)}/></label><label>Shop<select value={shop} onChange={e=>setShop(e.target.value)}><option value="">Tất cả</option>{Object.entries(shops).map(([k,n])=><option key={k} value={k}>{n}</option>)}</select></label><label>Nguồn<select value={origin} onChange={e=>setOrigin(e.target.value)}><option value="">Tất cả</option>{Array.from(new Set(inGroup.map(l=>l.source))).map(s=><option key={s}>{s}</option>)}</select></label><label>Trạng thái<select value={state} onChange={e=>setState(e.target.value)}><option value="">Đang ghi nhận</option><option value="excluded">Đã loại khỏi báo cáo</option></select></label><label>Rà soát thuế<select value={tax} onChange={e=>setTax(e.target.value)}><option value="">Tất cả</option><option value="eligible">Hợp lệ</option><option value="pending">Chờ rà soát</option><option value="ineligible">Không hợp lệ</option></select></label></div>
 <DetailDownloads key={params.toString()} title={groups[group]||'Tất cả chi phí'} scope={(shop?shops[shop]:'Tất cả shop')+' · '+rangeLabel(period.range)} columns={['Ngày / tháng','Shop','Đầu mục','Nội dung','Nguồn','Tham chiếu','Số gốc (đ)','Số tiền trong báo cáo (đ)','Đã thanh toán','Trạng thái thuế','Trạng thái','Lý do điều chỉnh / loại']} rows={selected.map(l=>({values:[l.date,shops[l.shop]||l.shop,groups[l.group]||l.group,l.label,l.source,l.reference,l.original??l.amount,l.amount,l.paid??'Theo nguồn',{eligible:'Hợp lệ',pending:'Chờ rà soát',ineligible:'Không hợp lệ'}[taxBucket(l)],l.excluded?'Đã loại':l.provisional?'Tạm tính':'Đang ghi nhận',l.control?.reason||''],documents:lineDocuments(l)}))}/>
 {group==='all'&&tax==='eligible'&&!state&&(!shop||shop==='shared')&&<HistoricalExpenses from={period.range.from||''} to={period.range.to||''}/>}
 {group!=='all'&&<SourceControls group={group} rows={inGroup} data={data} month={(period.range.to||today()).slice(0,7)} save={save}/>}
 {selected.map(l=><details key={l.id||l.lineKey} open={l.id===lastSaved?true:undefined} style={l.id===lastSaved?{background:'#eaf3ef',padding:'12px',border:'2px solid #287958',borderRadius:8}:undefined}><summary><strong>{l.label}</strong> · {money(l.amount)}<small>{l.date} · {pay(l)} · {l.invoice?'Có hóa đơn cho tài khoản/kỳ':'Chưa xác nhận hóa đơn'}</small></summary><p>{shops[l.shop]} · {l.source} · {l.reference||'Chưa có mã đối chiếu'}</p><p>{l.lineKey?'Đã có dữ liệu nguồn':'Phiếu nhập tay'} · {l.reconciled?'Đã đối chiếu':'Chưa xác nhận đối chiếu'}</p><DocumentLinks documents={lineDocuments(l)}/>
 {(l.reviewId||l.id&&taxBucket(l)!=='eligible')&&<a className="btn" href={'/thue?'+new URLSearchParams({month:l.date.slice(0,7),review:l.reviewId||l.id!,type:l.reviewId?l.group:'expense'})}>Rà soát ngay</a>}<p>Rà soát thuế · {l.tax==="eligible"?"Đã duyệt":l.tax==="ineligible"?"Đã loại":"Chờ rà soát"}</p>{l.id&&Object.entries(data.rows.find((r:any)=>r.id===l.id)?.expenseDetails?.fields||{}).filter(([,v])=>v).map(([k,v])=><small key={k}>{k} · {String(v)}</small>)}{l.id&&data.rows.find((r:any)=>r.id===l.id)?.expenseDetails?.items?.map((it:Item,i:number)=><small key={i}>{it.name} · {it.qty} × {money(Number(it.price))}</small>)} <LineActions line={l} data={data} save={save} edit={()=>{start(l.group);setEdit(data.rows.find((r:any)=>r.id===l.id));}}/>{l.id&&<><button onClick={()=>detail(data.rows.find((r:any)=>r.id===l.id))}>Mở phiếu</button>{data.audit.filter((a:any)=>a.detail.id===l.id).map((a:any)=><p key={a.time}>{a.time.slice(0,10)} · {a.actor} · {a.detail.before?.status||'Tạo mới'} → {a.detail.after?.status} · {money(a.detail.after?.amount||0)}</p>)}</>}</details>)}
 {!selected.length&&<p>Chưa có khoản ghi nhận trong phạm vi đã chọn.</p>}{data.rows.filter((r:any)=>r.status==='draft'&&(!shop||shop===r.channel)&&(r.category===group||(group==='operations'&&['utilities','rent','services'].includes(r.category)))).map((r:any)=><button key={r.id} onClick={()=>detail(r)}>Phiếu nháp · {r.description}</button>)}{data.audit.some((a:any)=>a.detail.after?.kind==='expense'&&(!shop||a.detail.after.channel===shop)&&withinRange(a.detail.after.date,period.range)&&(a.detail.after.category===group||(group==='operations'&&['rent','utilities','services'].includes(a.detail.after.category))))&&<details><summary>Nhật ký gần đây</summary>{data.audit.filter((a:any)=>{const r=a.detail.after;return r?.kind==='expense'&&(!shop||shop===r.channel)&&withinRange(r.date,period.range)&&(r.category===group||(group==='operations'&&['utilities','services','rent'].includes(r.category)));}).map((a:any)=><p key={a.time}>{a.detail.after.description} · {a.detail.before?money(a.detail.before.amount):'Tạo mới'} → {a.detail.after.status==='void'?'Đã hủy':money(a.detail.after.amount)} · {a.detail.after.adjustment?.reason||a.detail.after.voidReason} · {a.actor}</p>)}</details>}{source(group)}<a href="/thue">Rà soát chứng từ tại tab Thuế</a></section></div>}</div>;
}
async function api(action:string,version:number,data:any,requestId:string){const response=await fetch('/api/finance',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,version,data,requestId,kind:'expense'})});const result=await response.json() as any;if(!response.ok)throw Object.assign(Error(result.error||'Chưa lưu được'),{duplicate:result.duplicate});return result;}
function Entry({refresh,onFeesSaved,group,data,period,shop,all,adjustment,edit,cancel,done,mark,openSource,queue}:any){
 const [channel,setChannel]=useState(edit?.channel||(adjustment?shop||'shared':'shared')),[payment,setPayment]=useState(edit?.paid?(edit.paid===edit.amount?'full':'part'):'none'),[value,setValue]=useState(edit?String(edit.amount):''),[error,setError]=useState(''),[busy,setBusy]=useState(false),[category,categorySet]=useState(edit?.category||(group==='unclassified'?'other':group));
 const [duplicate,setDuplicate]=useState<any>(null),[resolution,setResolution]=useState('');
 const [reviewFooter,setReviewFooter]=useState<HTMLDivElement|null>(null);
 const formRef=useRef<HTMLFormElement>(null);
 const [extra,setExtra]=useState<Record<string,string>>(edit?.expenseDetails?.fields||{});
 const [items,setItems]=useState<Item[]>(edit?.expenseDetails?.items||[blankItem()]);
 const [fileRead,attach]=useState<File|null>(null),[rowIndex,selectRow]=useState(0),[sourceCell,setSourceCell]=useState(''),[reading,setReading]=useState(false);
 const [day,setDay]=useState(edit?.date||today());
 const itemized=items.some(r=>r.name||r.qty||r.price);
 function replaceItems(rows:Item[]){mark();setItems(rows);setValue(String(rows.reduce((sum,r)=>sum+(Number(r.qty)*Number(r.price)||0),0)));}
 function apply(row:any,file:File,index:number){
   const el=formRef.current!;
   function put(name:string,v:string){if(v)(el.elements.namedItem(name) as HTMLInputElement).value=v;}
   attach(file);selectRow(index);setSourceCell(row.identity||String(index));mark();if(row.date)setDay(row.date);
   if(row.channel)setChannel(row.channel);
   put('reference',row.ref);put('counterparty',row.supplier);put('description',row.type);
   if(group!=='ads'||row.spend)setValue(row.amount?String(row.amount):'');
   setExtra({...extra,...row.meta,...(row.account&&group==='ads'?{'Tài khoản quảng cáo':row.account}:{})});
 }
 const request=useRef(''),guard=useRef(false);const previous=total(all.filter((l:Line)=>l.group===group&&l.shop===channel)),n=Number(value.replace(/[. ,]/g,'')),delta=n-previous;
 async function submit(e:React.FormEvent<HTMLFormElement>){e.preventDefault();if(guard.current)return;guard.current=true;setBusy(true);setError('');const el=e.currentTarget,f=new FormData(el);
 try{if(reading)throw Error('Kiểm tra kết quả đọc chứng từ.');
 if(!adjustment&&category==='ads'&&extra['Loại khoản']==='Tiền nạp / tín dụng')throw Error('Tiền nạp và tín dụng chỉ dùng đối chứng.');
 if(itemized&&items.some(it=>!it.name.trim()||!/^\d+$/.test(it.qty)||!/^\d+$/.test(it.price)||Number(it.qty)<=0||Number(it.price)<=0))throw Error('Điền đủ tên, số lượng và đơn giá từng dòng.');
 if(!Number.isSafeInteger(n)||(!adjustment&&n<=0)||n<0)throw Error('Nhập số tiền nguyên đồng');const paid=payment==='full'?n:payment==='part'?Number(f.get('paid')):0;if(payment==='part'&&!(paid>0&&paid<n))throw Error('Số đã trả phải nhỏ hơn khoản chi');if(adjustment&&!withinRange(String(f.get('date')),period.range))throw Error('Ngày điều chỉnh phải nằm trong kỳ');
 let receipt:any=edit?.receipt||null;const file=fileRead||f.get('file');if(file instanceof File&&file.size){const body=new FormData();body.set('file',file);body.set('purpose','expense');const res=await fetch('/api/receipt',{method:'POST',body});receipt=await res.json();if(!res.ok)throw Error(receipt.error);}
 request.current||=crypto.randomUUID();const existing=edit||(resolution?duplicate:null);await api(existing?'edit-quick':adjustment?'adjust':'quick',data.version,{...Object.fromEntries(f),id:existing?.id,version:existing?.version,reason:resolution?resolution+' · '+String(f.get('reason')||''):f.get('reason'),range:period.range,file:undefined,channel,category,amount:adjustment?delta:n,paid,receipt:resolution==='Cập nhật'?(existing?.receipt||receipt):receipt,documentRow:fileRead?rowIndex:edit?.documentRow,sourceCell:fileRead?sourceCell:edit?.sourceCell,expenseDetails:{fields:extra,items:itemized?items:[]},previous,target:n,scope:rangeLabel(period.range),source:group+'|'+channel},request.current);
 const again=(e.nativeEvent as SubmitEvent).submitter?.getAttribute('value')==='again';await done(existing?.id||request.current,'Đã ghi '+String(f.get('description'))+' · '+money(adjustment?delta:n)+' · '+shops[channel],again,{date:day,channel,group:['utilities','rent','services'].includes(category)?'operations':expenseGroups[category]?category:'unclassified'});if(again){request.current='';el.reset();setValue('');setPayment('none');}}
 catch(err){if((err as any).duplicate){setDuplicate((err as any).duplicate);setResolution('');}setError((err as Error).message)}finally{guard.current=false;setBusy(false)}}
 return <form ref={formRef} onChangeCapture={mark} className="ceentry" onSubmit={submit}><button className="ceclose" type="button" onClick={cancel}>Thu gọn ×</button><h3>{adjustment?'Điều chỉnh tổng kỳ':edit?'Sửa khoản chi':'Thêm khoản chi'} · {groups[group]}</h3><label>Shop<select value={channel} onChange={e=>setChannel(e.target.value)}>{Object.entries(shops).map(([id,n])=><option key={id} value={id}>{n}</option>)}</select></label>{group==='unclassified'&&<label>Đầu mục chi phí<select value={category} onChange={e=>categorySet(e.target.value)}>{Object.entries(expenseCategories).filter(([id])=>id!=='cogs').map(([id,name])=><option key={id} value={id}>{id==='other'?'Chờ phân nhóm / Chi phí khác':name}</option>)}</select></label>}{group==='operations'&&<label>Đầu chi con<select value={category} onChange={e=>categorySet(e.target.value)}>{['operations','utilities','rent','services'].map(id=><option key={id} value={id}>{expenseCategories[id]}</option>)}</select></label>}
 <label>Ngày<input required name="date" type="date" value={day} onChange={e=>setDay(e.target.value)}/></label><label>Nội dung<input required name="description" defaultValue={edit?.description} maxLength={250}/></label><label>{adjustment?'Tổng mới':'Số tiền'} (đ)<input inputMode="numeric" pattern="[0-9. ,]+" readOnly={itemized} required value={value} onChange={e=>setValue(e.target.value)}/></label>
 {!adjustment&&<>{['ads','staff'].includes(group)&&<button type="button" onClick={openSource}>{group==='ads'?'Xem chi tiêu theo nguồn / tài khoản':'Xem bảng lương và bảo hiểm theo nhân viên'}</button>}<details open={itemized||!!edit}><summary>Thông tin theo đầu chi</summary><GroupInputs group={group} values={extra} change={(v:any)=>{mark();setExtra(v);}} items={items} onItems={replaceItems} date={day} data={data} channel={channel}/></details>
 <ExpenseReader owner={data.draftOwner} onFeesSaved={onFeesSaved} footer={reading?reviewFooter:null} queue={edit?undefined:queue} group={group} blocked={setReading} apply={apply}/>{fileRead&&<p>Chứng từ sẽ lưu · {fileRead.name} · dòng {rowIndex+1}</p>}</>}
 {edit&&<><p>{groups[group]} · {shops[channel]} · {day} · {money(edit.amount)} → {money(n)} · Chênh lệch {money(n-edit.amount)}</p><label>Lý do sửa<input required name="reason"/></label></>}
 {edit?.receipt&&<p>Chứng từ hiện tại · {edit.receipt.name}</p>}
 {adjustment&&<><p>Tổng cũ {money(previous)} · Tổng mới {money(n)} · Chênh lệch {money(delta)}</p><label>Lý do<input required name="reason"/></label></>}
 <details><summary>Thêm thông tin · {payment==='none'?'Chưa trả':payment==='full'?'Đã trả đủ':'Trả một phần'}</summary><label>Mã chứng từ<input name="reference" defaultValue={edit?.reference}/></label><label>Bên nhận<input name="counterparty" defaultValue={edit?.counterparty}/></label>{!adjustment&&<label>Thanh toán<select value={payment} onChange={e=>setPayment(e.target.value)}><option value="none">Chưa trả</option><option value="full">Đã trả đủ</option><option value="part">Trả một phần</option></select></label>}{payment==='part'&&<label>Đã trả (đ)<input required name="paid" defaultValue={edit?.paid} type="number" min="1"/></label>}<label>Phương thức<select name="paymentMethod" defaultValue={edit?.paymentMethod||'bank'}><option value="cash">Tiền mặt</option><option value="bank">Chuyển khoản</option></select></label><label>Chứng từ<input name="file" type="file"/></label><label>Ghi chú<input name="note" defaultValue={edit?.note}/></label></details>
 {duplicate&&<div><strong>Trùng chứng từ · {shops[duplicate.channel]} · {duplicate.date} · {duplicate.description} · {money(duplicate.amount)}</strong><p>{money(duplicate.amount)} → {money(n)} · Chênh lệch {money(n-duplicate.amount)}</p><button type="button" onClick={cancel}>Bỏ qua</button>{duplicate.status==='confirmed'&&data.management.canEdit&&<><button type="button" onClick={()=>setResolution('Cập nhật')}>Cập nhật, giữ chứng từ cũ</button><button type="button" onClick={()=>setResolution('Thay thế')}>Thay thế bằng chứng từ mới</button></>}{resolution&&<label>{resolution} · Lý do<input name="reason" required/></label>}</div>}
 {error&&<p role="alert">{error}</p>}<footer><div ref={setReviewFooter} hidden={!reading}/>{!reading&&<button disabled={busy} className="btn primary">{busy?"Đang lưu…":fileRead?"Xác nhận và lưu":reading?"Xác nhận ghi nhận":"Lưu khoản chi"}</button>}{!reading&&!edit&&!adjustment&&<button disabled={busy||reading} value="again">Lưu và nhập tiếp</button>}<button type="button" disabled={busy} onClick={cancel}>Hủy</button></footer></form>
}
