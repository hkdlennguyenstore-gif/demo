'use client';
import TimePicker from './time-picker';
import HelpHint from './help-hint';
import CompactPeriod from './compact-period';
import {useEffect,useState} from 'react';
import {readDateRange,rangeLabel,type DateRange} from '../lib/date-range';
const key='ln-pm-global-period-v1',event='ln-pm-period-changed';
const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
type Selection={kind:string,day:string,month:string,year:string,from:string,to:string,fromTime?:string,toTime?:string};
const initial=(kind='month'):Selection=>({kind,day:today(),month:today().slice(0,7),year:today().slice(0,4),from:today().slice(0,7)+'-01',to:today()});
function bounds(v:Selection):DateRange{const p=new URLSearchParams(v.kind==='all'?{range:'all'}:v.kind==='month'?{month:v.month}:v.kind==='day'?{from:v.day,to:v.day}:v.kind==='year'?{from:v.year+'-01-01',to:v.year+'-12-31'}:{from:v.from,to:v.to,fromTime:v.fromTime||'',toTime:v.toTime||''});return readDateRange(p);}
export function useGlobalPeriod(monthly=false,defaultToday=false){const [selection,setSelection]=useState(()=>initial(defaultToday?'day':'month')),[ready,setReady]=useState(false);useEffect(()=>{if(monthly){setSelection(initial());setReady(true);return;}const read=()=>{try{const saved=localStorage.getItem(key);if(saved){const v=JSON.parse(saved);bounds(v);setSelection(v);}}catch{}setReady(true);};if(defaultToday){const v=initial('day');setSelection(v);try{localStorage.setItem(key,JSON.stringify(v));}catch{}setReady(true);}else read();window.addEventListener(event,read);window.addEventListener('storage',read);return()=>{window.removeEventListener(event,read);window.removeEventListener('storage',read);};},[monthly,defaultToday]);const range=bounds(selection);return {selection,range:defaultToday?range:{from:range.from,to:range.to},allowTime:defaultToday,ready,monthly,set:(v:Selection)=>{bounds(v);if(monthly){setSelection(v);return;}localStorage.setItem(key,JSON.stringify(v));setSelection(v);window.dispatchEvent(new Event(event));}};}
export type GlobalPeriod=ReturnType<typeof useGlobalPeriod>;
export default function GlobalPeriodBar({period,compact=true}:{period:GlobalPeriod;compact?:boolean}){
const [draft,setDraft]=useState(period.selection),[error,setError]=useState(''),[applied,setApplied]=useState(false);
useEffect(()=>{setDraft(period.selection);},[period.selection]);
const pending=JSON.stringify(draft)!==JSON.stringify(period.selection);
const change=(name:string,value:string)=>{setDraft(v=>({...v,[name]:value}));setError('');setApplied(false);};
function apply(){try{if((draft.kind==='day'&&!draft.day)||(draft.kind==='month'&&!draft.month)||(draft.kind==='year'&&!/^20[0-9]{2}$/.test(draft.year))||(draft.kind==='custom'&&(!draft.from||!draft.to)))throw Error('Nhập đủ thời gian để lọc.');period.set(draft);setError('');setApplied(true);}catch(e){setError((e as Error).message);}}
if(compact)return <CompactPeriod period={period}/>;
return <section className="global-period"><strong>{period.monthly?'Kỳ chi phí':'Thời gian chung cho PM'}</strong><div className="purch-toolbar"><label>Hiển thị<select aria-label="Thời gian chung" value={draft.kind} onChange={e=>change('kind',e.target.value)}><option value="day">Theo ngày</option><option value="month">Theo tháng</option><option value="year">Theo năm</option><option value="custom">Khoảng ngày tùy chọn</option><option value="all">Tất cả thời gian</option></select></label>{draft.kind==='day'&&<input aria-label="Ngày lọc chung" type="date" value={draft.day} onChange={e=>change('day',e.target.value)}/>} {draft.kind==='month'&&<><label>Tháng<select aria-label="Tháng lọc chung" value={draft.month.slice(5)} onChange={e=>change('month',(draft.month.slice(0,4)||today().slice(0,4))+'-'+e.target.value)}>{Array.from({length:12},(_,i)=>String(i+1).padStart(2,'0')).map(m=><option key={m} value={m}>{m}</option>)}</select></label><label>Năm<input aria-label="Năm của tháng lọc" type="number" min="2000" max="2099" value={draft.month.slice(0,4)} onChange={e=>change('month',e.target.value+'-'+(draft.month.slice(5)||'01'))}/></label></>} {draft.kind==='year'&&<input aria-label="Năm lọc chung" type="number" min="2000" max="2099" value={draft.year} onChange={e=>change('year',e.target.value)}/>} {draft.kind==='custom'&&(
 <div className="period-date-pairs">
  <div className="period-date-pair">
   <label>Từ ngày<input type="date" value={draft.from} onChange={e=>change('from',e.target.value)}/></label>
   {period.allowTime&&<TimePicker label="Từ giờ (tùy chọn)" value={draft.fromTime||''} onChange={value=>change('fromTime',value)}/>}
  </div>
  <div className="period-date-pair">
   <label>Đến hết ngày<input type="date" value={draft.to} onChange={e=>change('to',e.target.value)}/></label>
   {period.allowTime&&<TimePicker label="Đến hết giờ (tùy chọn)" value={draft.toTime||''} onChange={value=>change('toTime',value)}/>}
  </div>
 </div>
)}<button className="btn primary" onClick={apply}>Áp dụng</button><button className="text-btn" onClick={()=>{const all={...draft,kind:'all'};period.set(all);setDraft(all);setApplied(true);setError('');}}>Tất cả thời gian</button><span role="status" className={pending?'period-pending':'period-applied'}>{pending?'Chưa áp dụng thay đổi':applied?'✓ Đã áp dụng':'✓ Đang áp dụng'}</span></div><small>Đang áp dụng: {rangeLabel(period.range)}</small><HelpHint>{period.monthly?'Kỳ riêng của sổ chi phí.':'Bộ lọc thời gian dùng chung giữa các tab và phân hệ.'} Khoảng ngày tính cả ngày đầu và ngày cuối. {period.allowTime&&"Giờ Việt Nam. Bỏ trống giờ để xem trọn ngày."} Chọn thời gian rồi bấm Áp dụng.</HelpHint>{error&&<p role="alert">{error}</p>}</section>;}
