import {slipFields,type Payslip} from '../lib/payslip';
export default function PayslipOptions({slip,onChange,disabled}:{slip:Payslip,onChange:(s:Payslip)=>void,disabled:boolean}){
 const fields=[...slipFields(slip),{id:'note',label:'Ghi chú'}];
 const hidden=new Set(slip.hidden||[]);
 function toggle(id:string,checked:boolean){
  const next=new Set(hidden);
  if(checked)next.delete(id);else next.add(id);
  onChange({...slip,hidden:[...next]});
 }
 return <details className="slip-options"><summary>Chọn mục hiển thị khi gửi</summary>
 <fieldset disabled={disabled}><legend>Nội dung trên phiếu của {slip.name}</legend>
 <div className="slip-choices">{fields.map(f=><label key={f.id}><input type="checkbox" checked={!hidden.has(f.id)} onChange={e=>toggle(f.id,e.target.checked)}/>{f.label}</label>)}</div>
 <div className="slip-presets"><button type="button" className="text-btn" onClick={()=>onChange({...slip,hidden:[]})}>Hiện tất cả</button><button type="button" className="text-btn" onClick={()=>onChange({...slip,hidden:fields.filter(f=>f.id!=='net').map(f=>f.id)})}>Chỉ hiện còn nhận</button></div>
 </fieldset></details>;
}
