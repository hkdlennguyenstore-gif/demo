'use client';
import {useState,type ReactNode} from 'react';
import {Menu,ChevronRight} from 'lucide-react';
import PmSidebar from './pm-sidebar';
export default function PmShell({active,title,children,onSelect,standalone=false}:{active:string,title:string,children:ReactNode,standalone?:boolean,onSelect?:(id:string)=>boolean}){const [open,setOpen]=useState(false);return <div className={standalone?"shell pm-standalone":"shell"}>{!standalone&&<PmSidebar active={active} open={open} onClose={()=>setOpen(false)} onSelect={onSelect}/>}<div className="body pm-module-body"><header>{!standalone&&<button className="icon mobile" aria-label="Mở menu" onClick={()=>setOpen(true)}><Menu/></button>}<div className="breadcrumb">Lên Nguyễn Store <ChevronRight size={14}/><strong>{title}</strong></div></header><div className="pm-module-content">{children}</div></div></div>;}
