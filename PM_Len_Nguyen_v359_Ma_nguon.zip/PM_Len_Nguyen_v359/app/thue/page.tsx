import FinanceScreen from '../../components/finance/finance-screen';
export default function Page(){return <FinanceScreen kind="tax"/>;}
