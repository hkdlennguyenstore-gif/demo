'use client';
import {useEffect,useMemo,useRef,useState,type FormEvent} from 'react';
import PmShell from '../../components/pm-shell';
import type {staffStockView} from '../../lib/staff-stock';
import type {staffCatalogRows} from '../../lib/staff-catalog';
import './stock.css';
type Data=ReturnType<typeof staffStockView>;
type Catalog={rows:ReturnType<typeof staffCatalogRows>;stockUpdatedAt:string|null;stockStale?:boolean};
const filters=[['all','Tất cả'],['empty','0 · Hết hàng'],['low','1–10 · Sắp hết'],['medium','11–20'],['high','Trên 20'],['negative','Tồn âm'],['unknown','Chưa có số']];
const orderKey='ln.staff-stock.filters.v1';
const ids=filters.map(([key])=>key);
const labels=Object.fromEntries(filters);
const orderFrom=(value:unknown):string[]=>Array.isArray(value)?[...new Set([...value.filter((v):v is string=>typeof v==='string'&&ids.includes(v)),...ids])]:ids;
const norm=(x:string)=>x.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replaceAll('đ','d').trim();
const fmt=new Intl.NumberFormat('vi-VN');
const number=(n:number|null)=>n===null?'—':fmt.format(n);
export default function StaffStock(){
 const [code,setCode]=useState(''),[data,setData]=useState<Data|null>(null),[loading,setLoading]=useState(false),[error,setError]=useState(''),[pick,setPick]=useState<{color:string;size:string;qty:number|null}|null>(null);
 const pending=useRef<AbortController|null>(null);
 const [catalog,setCatalog]=useState<Catalog|null>(null),[catalogError,setCatalogError]=useState(''),[filter,setFilter]=useState('all'),[refresh,setRefresh]=useState(0),[catalogBusy,setCatalogBusy]=useState(true);
 const [order,setOrder]=useState(ids),[arrange,setArrange]=useState(false);
 const dragging=useRef<string|null>(null);
 useEffect(()=>{try{setOrder(orderFrom(JSON.parse(localStorage.getItem(orderKey)||'null')));}catch{}},[]);
 function saveOrder(next:string[]){setOrder(next);try{localStorage.setItem(orderKey,JSON.stringify(next));}catch{}}
 function move(from:string,to:string){const i=order.indexOf(from),j=order.indexOf(to);if(i<0||j<0||i===j)return;const next=[...order];next.splice(i,1);next.splice(j,0,from);saveOrder(next);}
 useEffect(()=>{
  const ctl=new AbortController();setCatalogBusy(true);setCatalogError('');
  let retry:ReturnType<typeof setTimeout>|undefined;
  async function load(repeated=false){try{
   const r=await fetch('/api/kho-nhan-vien?mode=catalog'+(refresh||repeated?'&refresh=1':''),{cache:'no-store',signal:ctl.signal});
   const body=await r.json();if(ctl.signal.aborted)return;if(!r.ok)throw Error(body.error);
   setCatalog(body);
   if(!body.stockUpdatedAt&&!repeated){retry=setTimeout(()=>void load(true),1800);return;}
   setCatalogBusy(false);
  }catch(e){if(!ctl.signal.aborted){setCatalogError((e as Error).message);setCatalogBusy(false);}}}
  void load();return()=>{ctl.abort();clearTimeout(retry);};
 },[refresh]);
 const shown=useMemo(()=>catalog?.rows.filter(r=>(!catalog?.stockUpdatedAt||filter==='all'||r.tone===filter)&&norm(r.code+' '+r.name).includes(norm(code)))??[],[catalog,code,filter]);
 async function search(event?:FormEvent,selected?:string){event?.preventDefault();const value=(selected??code).trim();if(!value)return;pending.current?.abort();const ctrl=new AbortController();pending.current=ctrl;setLoading(true);setData(null);setError('');setPick(null);
  try{const res=await fetch('/api/kho-nhan-vien?'+new URLSearchParams({code:value}),{cache:'no-store',signal:ctrl.signal});const body=await res.json();if(ctrl.signal.aborted)return;if(!res.ok)throw Error(body.error||'Chưa đọc được dữ liệu POS');setData(body);}
  catch(e){if(!ctrl.signal.aborted)setError((e as Error).message);}
  finally{if(!ctrl.signal.aborted)setLoading(false);}
 }
 return <PmShell active="a4" title="Tồn kho POS"><main className="staff-stock">
 <header className="staff-stock-head"><div><h1>Tra tồn kho & giá Facebook</h1><p>Số có thể bán theo màu và size, lấy từ POS.</p></div><a href="/cham-cong">Về Chấm công</a></header>
 <form className="staff-stock-search" onSubmit={e=>{const exact=catalog?.rows.find(r=>norm(r.code)===norm(code));if(exact||shown.length===1)void search(e,exact?.code??shown[0].code);else if(!catalog||!shown.length)void search(e);else e.preventDefault();}}><label>Tìm mã hoặc tên hàng<input value={code} onChange={e=>{pending.current?.abort();setLoading(false);setData(null);setError('');setCode(e.target.value);}} maxLength={80} placeholder="Ví dụ: B4" required/></label><button disabled={loading}>{loading?'Đang đọc POS…':'Tra tồn'}</button></form>
 {error&&<p role="alert" className="staff-stock-note">{error}</p>}
 {data&&<><div className="staff-stock-id"><strong>{data.code}</strong><div><h2>{data.name}</h2><p>{data.rows.length} màu · POS cập nhật lúc {new Date(data.updatedAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',hour12:false})}</p></div></div>
 <div className="staff-stock-price"><b>Giá bán Facebook</b><strong>{data.facebookPrice===null?'Chưa có giá':fmt.format(data.facebookPrice)+'đ'}</strong></div>
 {!data.complete&&<p className="staff-stock-note">POS thiếu thông tin ở một số biến thể. Không dùng các ô trống làm số tồn.</p>}
 <div className="staff-stock-scroll" role="region" aria-label="Tồn theo màu và size" tabIndex={0}><table className="staff-stock-grid"><thead><tr><th className="staff-stock-total">TOTAL {number(data.total)}</th><th>Tổng màu</th>{data.sizes.map(size=><th key={size} scope="col">{size}</th>)}</tr></thead><tbody>{data.rows.map(row=><tr key={row.color}><th scope="row">{row.color}</th><td className="staff-stock-color-total">{number(row.total)}</td>{data.sizes.map(size=>{const qty=row.cells[size]??null,active=pick?.color===row.color&&pick?.size===size;return <td key={size}><button type="button" className={qty===0?'sold-out':undefined} aria-pressed={active} aria-label={row.color+', size '+size+', '+(qty===null?'chưa có số tồn':qty+' sản phẩm')} onClick={()=>setPick({color:row.color,size,qty})}>{number(qty)}</button></td>;})}</tr>)}</tbody></table></div>
 {pick&&<p className="staff-stock-note" aria-live="polite">Đã chọn: <strong>{pick.color} · size {pick.size}</strong> · {pick.qty===null?'Chưa có số tồn':number(pick.qty)+' sản phẩm có thể bán'}. Đổi size tại đơn hàng trên POS; chọn ở đây không sửa tồn.</p>}</>}
 <section className="staff-catalog" aria-label="Danh sách mã hàng A3">
 <h2>Danh sách mã hàng A3</h2>
 {catalogError?<p role="alert">{catalogError}</p>:!catalog?<p>Đang tải toàn bộ mã hàng…</p>:<>
 <p>{shown.length}/{catalog.rows.length} mã · Tồn tổng theo A3; bấm mã để xem tồn màu–size từ POS.</p>
 {!catalog.stockUpdatedAt&&<p role="status">{catalogBusy?'Đang lấy lại tồn A3…':'Chưa lấy được tồn A3. Giữ danh sách mã và chưa lọc theo mức tồn.'}</p>}
 {catalog.stockStale&&catalog.stockUpdatedAt&&<p role="status">POS chưa trả số mới. Đang dùng tồn đã xác minh lúc {new Date(catalog.stockUpdatedAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',hour12:false})}.</p>}
 <div className="staff-filter-actions"><button type="button" disabled={catalogBusy} onClick={()=>setRefresh(n=>n+1)}>{catalogBusy?'Đang tải tồn…':'Tải lại tồn'}</button><button type="button" aria-pressed={arrange} onClick={()=>setArrange(!arrange)}>{arrange?'Xong sắp xếp':'Sắp xếp nút lọc'}</button>{arrange&&<button type="button" onClick={()=>saveOrder(ids)}>Về thứ tự mặc định</button>}</div>
 <div className="a3-stock-legend staff-stock-legend">{order.map((key,i)=>{
  const count=catalog.rows.filter(r=>key==='all'||r.tone===key).length;
  return <div className={'staff-filter-slot a3-stock-'+(key==='unknown'?'retired':key)} key={key} draggable={arrange} onDragStart={e=>{if(arrange){dragging.current=key;e.dataTransfer.setData('text/plain',key);}}} onDragEnd={()=>{dragging.current=null;}} onDragOver={e=>{if(arrange)e.preventDefault();}} onDrop={e=>{if(arrange){e.preventDefault();if(dragging.current)move(dragging.current,key);dragging.current=null;}}}>
   <button type="button" className="a3-stock-filter staff-filter-pill" aria-pressed={filter===key} disabled={arrange||(!catalog.stockUpdatedAt&&key!=='all'&&key!=='unknown')} onClick={()=>setFilter(key)}>{labels[key]} <span>({count})</span></button>
   {arrange&&<div className="staff-filter-move"><button type="button" disabled={i===0} aria-label={'Đưa '+labels[key]+' sang trái'} onClick={()=>move(key,order[i-1])}>‹</button><button type="button" disabled={i===order.length-1} aria-label={'Đưa '+labels[key]+' sang phải'} onClick={()=>move(key,order[i+1])}>›</button></div>}
  </div>;
 })}</div>
 <div className="staff-stock-scroll"><table><thead><tr><th>Mã hàng</th><th>Tên hàng</th><th>Tồn A3</th><th>Giá bán Facebook</th></tr></thead><tbody>{shown.map(row=><tr key={row.code} className={'a3-stock-row a3-stock-'+(row.tone==='unknown'?'retired':row.tone)}><td><button type="button" onClick={()=>{void search(undefined,row.code);}}>{row.code}</button></td><td>{row.name||'—'}</td><td><strong>{number(row.remaining)}</strong></td><td>{row.facebookPrice===null?'—':fmt.format(row.facebookPrice)+'đ'}</td></tr>)}</tbody></table>{!shown.length&&<p>Không có mã phù hợp.</p>}</div>
 </>}
 </section>
 </main></PmShell>;
}
