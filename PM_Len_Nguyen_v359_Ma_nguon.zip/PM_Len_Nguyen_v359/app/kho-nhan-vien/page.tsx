import {requireChatGPTUser} from '../chatgpt-auth';
import StaffStock from './stock';
export default async function Page(){await requireChatGPTUser('/kho-nhan-vien');return <StaffStock/>;}
