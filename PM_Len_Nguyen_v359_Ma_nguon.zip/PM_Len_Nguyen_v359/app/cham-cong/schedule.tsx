'use client';
import {useEffect,useLayoutEffect,useRef,useState} from 'react';
import {createAttendanceViewEpoch} from '../../lib/attendance-view-epoch';
import {attendancePanel,type AttendancePanel} from './attendance-sections';
import LeaveRangeFields from './leave-range-fields';
import {leaveRange} from '../../lib/attendance-leave-range';
import AttendanceCalendar from './attendance-calendar';

type RosterEntry={id:string;name:string};
export default function AttendanceSchedule({terminal,employees,initialPanel=null,onPanelChange}:{terminal:boolean;employees:RosterEntry[];initialPanel?:AttendancePanel;onPanelChange?:(panel:AttendancePanel)=>void}){
 return terminal?<KioskLeave employees={employees} initialPanel={initialPanel} onPanelChange={onPanelChange}/>:<AttendanceCalendar initialPanel={initialPanel} onPanelChange={onPanelChange} allowStaffIntake/>;
}

function KioskLeave({employees,initialPanel,onPanelChange}:{employees:RosterEntry[];initialPanel:AttendancePanel;onPanelChange?:(panel:AttendancePanel)=>void}){
 const [panel,setPanel]=useState<AttendancePanel>(initialPanel),[busy,setBusy]=useState(false),[notice,setNotice]=useState(''),[sent,setSent]=useState(false);
 const current=useRef(panel);current.current=panel;
 function show(next:AttendancePanel){setPanel(next);onPanelChange?.(next);}
 const [today]=useState(()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()));
 const form=useRef<HTMLFormElement>(null);
 const request=useRef<{requestId:string;data:{from:string;to:string;employee:string;reason:string}}|null>(null),active=useRef<AbortController|null>(null);
 function clearRequest(){active.current?.abort();active.current=null;request.current=null;form.current?.reset();setNotice('');setBusy(false);setSent(false);}
 function select(next:AttendancePanel){if(busy||next===panel)return;clearRequest();show(next);}
 useEffect(()=>{
  const opened=attendancePanel(new URLSearchParams(window.location.search).get('attendance'));if(opened)show(opened);
  const clear=()=>{if(current.current){clearRequest();show(null);}};
  const visibility=()=>{if(document.visibilityState==='hidden')clear();};
  const restored=(event:PageTransitionEvent)=>{if(event.persisted)clear();};
  window.addEventListener('pagehide',clear);window.addEventListener('pageshow',restored);window.addEventListener('blur',clear);document.addEventListener('visibilitychange',visibility);
  return()=>{active.current?.abort();window.removeEventListener('pagehide',clear);window.removeEventListener('pageshow',restored);window.removeEventListener('blur',clear);document.removeEventListener('visibilitychange',visibility);};
 },[]);
 async function send(e:React.FormEvent<HTMLFormElement>){
  e.preventDefault();if(active.current||panel!=='leave'||sent)return;
  const f=new FormData(e.currentTarget),field=(name:string)=>String(f.get(name)||'');
  const data={employee:field('employee'),from:field('from'),to:field('to'),reason:field('reason').trim()};
  if(!employees.some(x=>x.id===data.employee))return;
  try{leaveRange(data.from,data.to);if(!data.reason)throw Error('Ghi lý do xin nghỉ.');}catch(err){setNotice((err as Error).message);return;}
  if(request.current&&JSON.stringify(request.current.data)!==JSON.stringify(data)){setNotice('Lần gửi trước chưa rõ kết quả. Gửi lại với đúng thông tin cũ hoặc nhờ quản trị viên kiểm tra.');return;}
  request.current??={requestId:crypto.randomUUID(),data};
  const controller=new AbortController();active.current=controller;setBusy(true);setNotice('');
  try{
   const r=await fetch('/api/orders',{method:'POST',cache:'no-store',redirect:'error',signal:controller.signal,headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'kiosk-leave-range',...request.current})});
   const json:unknown=await r.json();if(controller.signal.aborted)return;
   if(!r.ok||!json||typeof json!=='object'||!('ok' in json)||json.ok!==true){if(r.status>=400&&r.status<500){request.current=null;setNotice('Chưa gửi được yêu cầu. Kiểm tra tên, khoảng ngày, lý do hoặc nhờ quản trị viên kiểm tra kỳ đã khóa.');return;}throw Error('Unconfirmed');}
   request.current=null;form.current?.reset();setSent(true);setNotice('Đã tiếp nhận · Chờ duyệt. Xem kết quả trong mục Xin nghỉ bằng tài khoản cá nhân hoặc hỏi quản trị viên.');
  }catch{if(!controller.signal.aborted)setNotice('Chưa xác nhận tiếp nhận. Có thể bấm Gửi lại với đúng thông tin cũ, hoặc nhờ quản trị viên kiểm tra.');}
  finally{if(active.current===controller){active.current=null;setBusy(false);}}
 }
 return <section aria-label="Lịch làm việc và xin nghỉ trên máy dùng chung">
  {panel==='schedule'&&<section className="panel a3-settings"><h2>Lịch làm việc tuần này</h2><KioskWorkSchedule employees={employees}/></section>}
  {panel==='leave'&&<section className="panel attendance-leave-form"><h2>Gửi yêu cầu nghỉ</h2><p>Chọn tên để gửi. Máy dùng chung không hiển thị lịch sử, lý do hoặc phản hồi riêng.</p>
   {!sent?<form ref={form} onSubmit={send} autoComplete="off"><label>Tên nhân viên <select name="employee" defaultValue="" required disabled={busy}><option value="" disabled>Chọn tên của bạn</option>{employees.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select></label>
    <LeaveRangeFields initialDay={today} busy={busy}/><div className="modal-actions"><button type="button" className="btn" disabled={busy} onClick={()=>select(null)}>Hủy</button><button className="btn primary" disabled={busy}>{busy?'Đang gửi…':'Gửi yêu cầu nghỉ'}</button></div></form>:<button type="button" className="btn" onClick={clearRequest}>Gửi yêu cầu khác</button>}
   {notice&&<p role="status">{notice}</p>}
  </section>}
 </section>;
}


function KioskWorkSchedule({employees}:{employees:RosterEntry[]}){
 const [chosen,setChosen]=useState(''),[notice,setNotice]=useState('');
 const [view,setView]=useState<{from:string;to:string;rows:{date:string;start:string;end:string;dayOnly?:true}[]}|null>(null);
 const [epoch]=useState(createAttendanceViewEpoch);
 const pane=useRef<HTMLDivElement>(null);
 const reveal=useRef<(()=>boolean)|null>(null);
 const conceal=()=>{if(pane.current)pane.current.hidden=true;reveal.current=null;};
 useLayoutEffect(()=>{if(pane.current)pane.current.hidden=!view||!reveal.current?.();},[view]);
 useEffect(()=>{const close=()=>{conceal();epoch.revoke();setChosen('');setNotice('');setView(null);};
  const visibility=()=>{if(document.visibilityState==='hidden')close();};
  const show=(event:PageTransitionEvent)=>{if(event.persisted)close();};
  window.addEventListener('pagehide',close);window.addEventListener('pageshow',show);window.addEventListener('blur',close);document.addEventListener('visibilitychange',visibility);
  return()=>{epoch.revoke();window.removeEventListener('pagehide',close);window.removeEventListener('pageshow',show);window.removeEventListener('blur',close);document.removeEventListener('visibilitychange',visibility);};
 },[epoch]);
 async function showSchedule(employee:string){
  conceal();const request=epoch.begin();setChosen(employee);setView(null);setNotice('');
  if(!employees.some(e=>e.id===employee))return;
  setNotice('Đang mở lịch…');
  try{
   const q=new URLSearchParams({tab:'kiosk-schedule',employee});
   const r=await fetch('/api/orders?'+q,{cache:'no-store',redirect:'error',signal:request.signal});
   if(!r.ok)throw Error('Not available');
   const v=await r.json() as {from:string;to:string;rows:{date:string;start:string;end:string;dayOnly?:true}[]};
   if(!request.current())return;
   if(typeof v.from!=='string'||typeof v.to!=='string'||!Array.isArray(v.rows))throw Error('Invalid schedule');
   reveal.current=request.current;setView(v);setNotice('');
  }catch{if(request.current())setNotice('Chưa đọc được lịch. Chọn lại tên hoặc nhờ quản trị viên kiểm tra.');}
 }
 return <div><label>Tên xem lịch <select value={chosen} onChange={e=>void showSchedule(e.target.value)}><option value="">Chọn tên của bạn</option>{employees.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}</select></label>{notice&&<p role="status">{notice}</p>}<div ref={pane} hidden={!view}>{view&&<><p>Lịch làm việc · {view.from} đến {view.to}</p>{view.rows.length?<ul>{view.rows.map(x=><li key={x.date}>{x.date} · {x.dayOnly?(x.start?'Bắt đầu '+x.start:'Đi làm'):x.start+' – '+x.end}</li>)}</ul>:<p>Chưa có ngày làm việc được xếp trong tuần này.</p>}</>}</div></div>;
}
