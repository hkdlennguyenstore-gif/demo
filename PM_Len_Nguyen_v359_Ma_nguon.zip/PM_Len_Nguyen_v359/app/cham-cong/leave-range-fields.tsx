'use client';
import {useState} from 'react';

export default function LeaveRangeFields({initialDay,busy}:{initialDay:string;busy:boolean}){
 const [from,setFrom]=useState(initialDay),[to,setTo]=useState(initialDay);
 return <fieldset className="attendance-leave-fields" disabled={busy}>
  <div className="form-grid"><label>Từ ngày <input name="from" type="date" min="2000-01-01" max="2099-12-31" value={from} required onChange={e=>{
   const x=e.target.value;setFrom(x);if(to===from||to<x)setTo(x);
  }}/></label><label>Đến ngày <input name="to" type="date" min={from||'2000-01-01'} max="2099-12-31" value={to} required onChange={e=>setTo(e.target.value)}/></label></div>
  <label>Lý do xin nghỉ <textarea name="reason" required maxLength={500} autoComplete="off" rows={3}/></label>
 </fieldset>;
}
