'use client';
import {useEffect,useLayoutEffect,useRef,useState,type FormEvent} from 'react';
import BulkScheduleFields,{bulkSummary} from './bulk-schedule-fields';
import {readBulkSchedule} from '../../lib/attendance-bulk';
import {attendancePanel,type AttendancePanel} from './attendance-sections';
import LeaveRangeFields from './leave-range-fields';
import {leaveRange,leaveRangeLabel} from '../../lib/attendance-leave-range';
import TimePicker from '../../components/time-picker';
import {currentAttendanceMonth,isAttendanceStart} from '../../lib/attendance-month';
import {createAttendanceViewEpoch} from '../../lib/attendance-view-epoch';
import AttendanceMonthPanels,{AttendanceMonthToolbar,type MonthlyAttendance} from './attendance-month-panels';

type Panel=NonNullable<AttendancePanel>;
type Props={initialPanel?:AttendancePanel;onPanelChange?:(panel:AttendancePanel)=>void;allowStaffIntake?:boolean};
type Intent={kind:string;value:any;requestId:string;sent?:string};
const dayNow=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());

export default function AttendanceCalendar({initialPanel=null,onPanelChange,allowStaffIntake=false}:Props={}){
 const [panel,setPanel]=useState<AttendancePanel>(initialPanel),[month,setMonth]=useState(currentAttendanceMonth),[data,setData]=useState<MonthlyAttendance|null>(null),[intent,setIntent]=useState<Intent|null>(null),[workKind,setWorkKind]=useState<'work'|'off'>('work'),[start,setStart]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const [epoch]=useState(createAttendanceViewEpoch), reveal=useRef<(()=>boolean)|null>(null), pane=useRef<HTMLElement>(null), form=useRef<HTMLFormElement>(null), sending=useRef(false), current=useRef({panel,month}), activeIntent=useRef<Intent|null>(null);
 current.current={panel,month};
 function showPanel(next:AttendancePanel){setPanel(next);onPanelChange?.(next);}
 function conceal(){if(pane.current)pane.current.hidden=true;form.current?.reset();reveal.current=null;}
 function resetView(){
  conceal();epoch.revoke();activeIntent.current=null;sending.current=false;
  setData(null);setIntent(null);setBusy(false);setError('');setNotice('');
 }
 useLayoutEffect(()=>{if(pane.current)pane.current.hidden=!reveal.current?.()||!data||data.month!==month||!panel;},[data,month,panel]);
 useEffect(()=>{
  const open=attendancePanel(new URLSearchParams(window.location.search).get('attendance'));
  if(open)showPanel(open);
  const close=()=>{if(current.current.panel){resetView();showPanel(null);}},visibility=()=>{if(document.visibilityState==='hidden')close();},show=(e:PageTransitionEvent)=>{if(e.persisted)close();};
  window.addEventListener('blur',close);window.addEventListener('pagehide',close);window.addEventListener('pageshow',show);document.addEventListener('visibilitychange',visibility);
  return()=>{if(pane.current)pane.current.hidden=true;epoch.revoke();window.removeEventListener('blur',close);window.removeEventListener('pagehide',close);window.removeEventListener('pageshow',show);document.removeEventListener('visibilitychange',visibility);};
 },[epoch]);
 async function read(next:Panel,nextMonth:string,after?:(data:MonthlyAttendance)=>void){
  conceal();setData(null);setError('');
  const request=epoch.begin();
  try{
   const r=await fetch('/api/orders?'+new URLSearchParams({tab:'attendance-month',month:nextMonth}),{cache:'no-store',redirect:'error',signal:request.signal});
   const v=await r.json();
   if(!request.current())return;
   if(!r.ok)throw Error(v.error||'Không đọc được lịch.');
   if(v.month!==nextMonth||current.current.panel!==next||current.current.month!==nextMonth)return;
   reveal.current=request.current;setData(v);
   if(next==='leave'&&!activeIntent.current){
    const today=dayNow(),date=today.startsWith(nextMonth+'-')?today:nextMonth+'-01';
    if(v.me)beginIntent('leave-range',{date,employee:v.me.id,name:v.me.name});
    else if(v.admin&&allowStaffIntake)beginIntent('staff-leave-range',{date});
   }
   after?.(v);
  }catch(e){if(request.current())setError((e as Error).message);}
 }
 useEffect(()=>{if(panel)void read(panel,month);},[panel,month]);
 const select=(next:AttendancePanel)=>{if(sending.current||next===panel)return;resetView();showPanel(next);};
 const changeMonth=(next:string)=>{if(sending.current||next===month)return;resetView();setMonth(next);};
 function open(kind:string,value:any={}){
  if(!data||data.month!==month||!reveal.current?.()||sending.current)return;
  if(['schedule-bulk','schedule-day','cancel-schedule-day','calendar-name','review-leave','staff-leave-range'].includes(kind)){if(!data.admin)return;}
  else if(kind!=='leave-range'||!data.me||data.me.id!==value.employee)return;
  setNotice('');beginIntent(kind,value);
 }
 function beginIntent(kind:string,value:any){
  setError('');
  setWorkKind(value.kind==='off'?'off':'work');setStart(isAttendanceStart(value.start)?value.start:'');
  const next={kind,value,requestId:crypto.randomUUID()};activeIntent.current=next;setIntent(next);
 }
 function closeIntent(){activeIntent.current=null;setIntent(null);setError('');}
 async function save(e:FormEvent<HTMLFormElement>){
  e.preventDefault();const item=activeIntent.current;if(!item||!data||!panel||!reveal.current?.()||sending.current)return;
  const entries=new FormData(e.currentTarget);
  const field=(key:string)=>String(entries.get(key)||'');
  if(item.kind==='schedule-day'&&workKind==='work'&&!isAttendanceStart(start)){setError('Chọn giờ bắt đầu theo định dạng 24 giờ.');return;}
  if(item.kind==='leave-range'||item.kind==='staff-leave-range'){
   try{leaveRange(field('from'),field('to'));if(!field('reason').trim())throw Error('Ghi lý do xin nghỉ.');if(item.kind==='staff-leave-range'&&!data.employees.some(e=>!e.scheduleOnly&&e.id===field('employee')))throw Error('Chọn tên nhân viên.');}
   catch(e){setError((e as Error).message);return;}
  }
  let bulkPayload;
  if(item.kind==='schedule-bulk'){
   try{bulkPayload=readBulkSchedule({month,days:entries.getAll('days'),employees:entries.getAll('employees'),start:field('start')});}
   catch(e){setError((e as Error).message);return;}
  }
  const payload=item.kind==='schedule-bulk'?bulkPayload:item.kind==='calendar-name'?{name:field('name')}:item.kind==='schedule-day'?{date:item.value.date,employee:item.value.employee,kind:workKind,...(workKind==='work'?{start}:{}),...(item.value.version!==undefined?{version:item.value.version}:{})}:item.kind==='cancel-schedule-day'?{id:item.value.id,date:item.value.date,employee:item.value.employee,version:item.value.version}:item.kind==='leave-range'||item.kind==='staff-leave-range'?{from:field('from'),to:field('to'),employee:item.kind==='staff-leave-range'?field('employee'):data.me?.id,reason:field('reason').trim()}:{id:item.value.id,approved:item.value.approved,note:field('note')};
  const body=JSON.stringify({action:item.kind,requestId:item.requestId,data:payload});
  if(item.sent&&item.sent!==body){setError('Lần gửi trước chưa rõ kết quả. Thử lại cùng nội dung hoặc đóng và tải lại lịch trước khi sửa.');return;}
  item.sent=body;sending.current=true;setBusy(true);setError('');
  const request=epoch.begin();
  try{
   const r=await fetch('/api/orders',{method:'POST',cache:'no-store',redirect:'error',signal:request.signal,headers:{'Content-Type':'application/json'},body});
   const result=await r.json();
   if(!request.current())return;
   if(!r.ok||result?.ok!==true){if(r.status>=400&&r.status<500)item.sent=undefined;throw Error(result?.error||'Chưa xác nhận đã lưu.');}
   closeIntent();setNotice(item.kind==='schedule-bulk'?bulkSummary(result):item.kind==='calendar-name'?'Đã thêm tên dùng xếp lịch.':item.kind==='cancel-schedule-day'?'Đã hủy lịch cho '+item.value.name+'.':(item.kind==='leave-range'||item.kind==='staff-leave-range')?'Đã gửi yêu cầu nghỉ · Chờ duyệt.':item.kind==='review-leave'?'Đã phản hồi yêu cầu nghỉ.':'Đã lưu.');
   setBusy(false);sending.current=false;
   if((item.kind==='leave-range'||item.kind==='staff-leave-range')&&field('from').slice(0,7)!==month){conceal();setData(null);setMonth(field('from').slice(0,7));return;}
   const date=item.kind==='calendar-name'&&panel==='schedule'&&typeof item.value.date==='string'&&item.value.date.startsWith(month+'-')?item.value.date:null;
   void read(panel,month,date?(view)=>{
    if(!view.admin)return;
    const person=view.employees.find(e=>e.scheduleOnly&&e.id===result.employee?.id);
    if(!person)return;
    const existing=view.rows.find(r=>r.date===date&&r.employee===person.id);
    if(existing?.kind==='leave')return;
    beginIntent('schedule-day',existing||{date,employee:person.id,name:person.name});
   }:undefined);
  }catch(err){if(request.current()){reveal.current=request.current;setError((err as Error).message||'Chưa xác nhận đã lưu.');}}
  finally{if(request.current()){setBusy(false);sending.current=false;}}
 }
 const employee=(id:string)=>data?.employees.find(p=>p.id===id);
 const title=intent?.kind==='schedule-bulk'?'Xếp lịch hàng loạt':intent?.kind==='calendar-name'?'Thêm tên nhân viên':intent?.kind==='schedule-day'?'Xếp lịch làm việc':intent?.kind==='cancel-schedule-day'?'Hủy lịch làm việc':intent?.kind==='leave-range'?'Yêu cầu nghỉ mới':intent?.value.approved?'Duyệt yêu cầu nghỉ':'Không duyệt yêu cầu nghỉ';
 return <section className="attendance-calendar" aria-label="Lịch làm việc và xin nghỉ">
  {panel&&<><AttendanceMonthToolbar month={month} busy={busy} onChange={changeMonth}/>
   {!intent&&error&&<p className="notice" role="alert">{error} <button type="button" className="text-btn" onClick={()=>void read(panel,month)}>Tải lại</button></p>}
   {notice&&<p role="status">{notice}</p>}{!data&&!error&&<p role="status">Đang tải lịch…</p>}
  </>}
  <section ref={pane} hidden={!data||!panel} className="attendance-calendar-private">{data&&panel&&data.month===month&&<>
   <AttendanceMonthPanels month={month} today={dayNow()} data={data} panel={panel} open={open} staffIntake={allowStaffIntake&&data.admin} leaveForm={intent&&(intent.kind==='leave-range'&&data.me||intent.kind==='staff-leave-range'&&data.admin&&allowStaffIntake)?<section className="panel attendance-leave-form" aria-label="Yêu cầu nghỉ mới"><h3>{intent.kind==='staff-leave-range'?'Gửi hộ yêu cầu nghỉ':'Yêu cầu nghỉ mới'}</h3><form ref={form} onSubmit={save} autoComplete="off">
    {intent.kind==='staff-leave-range'?<><label>Tên nhân viên <select name="employee" defaultValue="" required disabled={busy}><option value="" disabled>Chọn tên nhân viên</option>{data.employees.filter(e=>!e.scheduleOnly).map(e=><option key={e.id} value={e.id}>{e.name}</option>)}</select></label><p>Ghi nhận người gửi hộ. Đơn vẫn ở trạng thái Chờ duyệt.</p></>:<p>Nhân viên: <strong>{data.me?.name}</strong></p>}
    <LeaveRangeFields key={intent.requestId} initialDay={intent.value.date} busy={busy}/>{error&&<p role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="btn" disabled={busy} onClick={closeIntent}>Hủy</button><button className="btn primary" disabled={busy}>{busy?'Đang gửi…':'Gửi yêu cầu nghỉ'}</button></div></form></section>:undefined}/>
   {intent&&intent.kind!=='leave-range'&&intent.kind!=='staff-leave-range'&&<div className="overlay"><section className={'modal'+(intent.kind==='schedule-bulk'?' attendance-bulk-modal':'')} role="dialog" aria-modal="true" aria-label={title}><h2>{title}</h2><form ref={form} onSubmit={save}>
    {intent.kind==='schedule-bulk'&&<BulkScheduleFields key={intent.requestId} data={data} busy={busy}/>}
    {intent.kind==='calendar-name'&&<><label>Tên nhân viên <input name="name" autoComplete="off" maxLength={80} required disabled={busy}/></label><p>Chỉ dùng xếp lịch, không tạo tài khoản hay hồ sơ lương.</p>{intent.value.date&&<p>Sau khi thêm tên, tiếp tục xếp lịch ngày <strong>{intent.value.date.split('-').reverse().join('/')}</strong>.</p>}</>}
    {intent.kind==='schedule-day'&&<><p><strong>{employee(intent.value.employee)?.name||intent.value.name}</strong> · {intent.value.date.split('-').reverse().join('/')}</p>
     <fieldset disabled={busy}><label>Trạng thái <select name="kind" value={workKind} onChange={e=>setWorkKind(e.target.value==='off'?'off':'work')}><option value="work">Đi làm</option><option value="off">OFF</option></select></label>
     {workKind==='work'&&<TimePicker label="Giờ bắt đầu (24 giờ)" value={start} onChange={setStart}/>}</fieldset></>}
    {intent.kind==='cancel-schedule-day'&&<><p>Hủy lịch của <strong>{intent.value.name}</strong> ngày <strong>{intent.value.date.split('-').reverse().join('/')}</strong>?</p><p>Chỉ bỏ lịch Đi làm/OFF đã xếp, không thay đổi chấm công hay đơn nghỉ phép.</p></>}
    {intent.kind==='review-leave'&&<><p><strong>{intent.value.name}</strong> · {leaveRangeLabel(intent.value.from||intent.value.date,intent.value.to||intent.value.date)}</p>
     {intent.value.note&&<p className="attendance-note">Lý do: {intent.value.note}</p>}
     <label>Phản hồi của người duyệt <textarea name="note" maxLength={500} required={!intent.value.approved&&intent.value.requireResponse} disabled={busy}/></label></>}
    {error&&<p role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="btn" disabled={busy} onClick={closeIntent}>Đóng</button><button className="btn primary" disabled={busy||intent.kind==='schedule-bulk'&&data.locked}>{busy?'Đang lưu…':intent.kind==='schedule-bulk'?'Xác nhận xếp lịch':intent.kind==='cancel-schedule-day'?'Xác nhận hủy lịch':'Lưu'}</button></div>
   </form></section></div>}
  </>}</section>
 </section>;
}
