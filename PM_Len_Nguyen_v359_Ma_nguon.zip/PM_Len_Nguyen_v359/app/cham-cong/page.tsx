import ShopClock from './shop';
export default async function Page({searchParams}:{searchParams:Promise<{attendance?:string}>}){const {attendance}=await searchParams;return <ShopClock initialPanel={attendance==='schedule'||attendance==='leave'?attendance:null}/>;}
