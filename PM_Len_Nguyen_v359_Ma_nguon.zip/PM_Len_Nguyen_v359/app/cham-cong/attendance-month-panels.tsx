'use client';
import {type CSSProperties,type ReactNode} from 'react';
import {attendanceMonthLabel,attendanceMonthWeeks,attendanceWeekdays,isAttendanceMonth,isAttendanceStart,shiftAttendanceMonth} from '../../lib/attendance-month';
import {leaveRangeLabel,leaveStatus} from '../../lib/attendance-leave-range';
import {displayDate} from '../../lib/display-date';

export type SchedulePerson={id:string;name:string;scheduleOnly?:true};
export type MonthlyScheduleRow={id:string;version:number;employee:string;name:string;date:string;kind:'work'|'off'|'leave';start?:string;end?:string;note?:string};
export type MonthlyLeave={id:string;employee:string;name:string;date:string;status:'pending'|'approved'|'rejected';note?:string;source?:string;from?:string;to?:string;reviewNote?:string;requireResponse?:boolean};
export type MonthlyAttendance={month:string;locked?:boolean;admin:boolean;me:{id:string;name:string}|null;employees:SchedulePerson[];rows:MonthlyScheduleRow[];leaves:MonthlyLeave[]};
type Row={id:string;date:string};
const addNameOption=':add-name:';
export function employeeColors(people:SchedulePerson[]){
 const colors=new Map<string,number>();
 for(const person of people)if(!colors.has(person.id))colors.set(person.id,colors.size);
 return colors;
}
export function employeeBadgeStyle(index:number|undefined):CSSProperties{
 if(index===undefined)return {};
 // Golden-angle sequence: distinct for the whole supported roster, append-only names never change prior colors.
 const h=(index*137.50776405)%360;
 return {backgroundColor:`hsl(${h} 64% 87%)`,color:`hsl(${h} 74% 23%)`};
}
function StaffBadge({id,name,colors,off=false}:{id:string;name:string;colors:Map<string,number>;off?:boolean}){
 return <strong className={'attendance-staff-badge'+(off?' attendance-staff-off':'')} style={off?undefined:employeeBadgeStyle(colors.get(id))}>{name}</strong>;
}

function MonthCalendar<T extends Row>({month,title,rows,render,canAdd,add,addLabel,today,isOff,dayAction}:{month:string;title:string;rows:T[];render:(x:T)=>ReactNode;canAdd:boolean;add:(date:string)=>void;addLabel:string;today:string;isOff?:(row:T)=>boolean;dayAction?:(date:string,rows:T[])=>ReactNode}){
 const byDate=new Map<string,T[]>();
 for(const r of rows){const found=byDate.get(r.date);if(found)found.push(r);else byDate.set(r.date,[r]);}
 return <section className="panel attendance-month-panel"><h2>{title}</h2>
  <div className="attendance-month-scroll" tabIndex={0} role="region" aria-label={title+' · '+attendanceMonthLabel(month)}>
   <table className="attendance-month-grid" aria-label={title+' · '+attendanceMonthLabel(month)}>
    <thead><tr>{attendanceWeekdays.map((day,i)=><th key={day} scope="col" className={i===6?'attendance-sunday':''}>{day}</th>)}</tr></thead>
    <tbody>{attendanceMonthWeeks(month).map((week,index)=><tr key={index}>{week.map((d,i)=>{const dayRows=d?byDate.get(d.date)||[]:[];return d?<td key={d.date} className={(i===6?'attendance-sunday ':'')+(isOff&&dayRows.length&&dayRows.every(isOff)?'attendance-day-off':'')} data-date={d.date}>
     <div className="attendance-day-head"><time dateTime={d.date} aria-current={d.date===today?'date':undefined}>{String(d.day).padStart(2,'0')}/{month.slice(-2)}</time>{dayAction?dayAction(d.date,dayRows):canAdd&&<button type="button" className="text-btn" onClick={()=>add(d.date)} aria-label={addLabel+' '+displayDate(d.date)}>{addLabel}</button>}</div>
     {!!dayRows.length&&<ul>{dayRows.map(r=><li key={r.id} className={isOff?.(r)?'attendance-entry-off':undefined}>{render(r)}</li>)}</ul>}
    </td>:<td key={'blank-'+i} className="attendance-other-month" aria-hidden="true"/>;})}</tr>)}</tbody>
   </table>
  </div>
  {!rows.length&&<p className="attendance-month-empty">{title==='Lịch làm việc'?'Chưa xếp lịch trong tháng này.':'Chưa có yêu cầu nghỉ trong tháng này.'}</p>}
 </section>;
}
export function AttendanceMonthToolbar({month,onChange,busy}:{month:string;onChange:(month:string)=>void;busy:boolean}){
 const previous=shiftAttendanceMonth(month,-1),next=shiftAttendanceMonth(month,1);
 return <div className="purch-toolbar attendance-month-toolbar" aria-label="Chọn tháng cho hai bảng">
  <button type="button" className="btn" disabled={busy||previous===month} onClick={()=>onChange(previous)}>Tháng trước</button>
  <label>Tháng hiển thị <input type="month" min="2000-01" max="2099-12" required disabled={busy} value={month} onChange={e=>{if(isAttendanceMonth(e.target.value))onChange(e.target.value);}}/></label>
  <button type="button" className="btn" disabled={busy||next===month} onClick={()=>onChange(next)}>Tháng sau</button>
  <strong aria-live="polite">{attendanceMonthLabel(month)} · giờ Việt Nam</strong>
 </div>;
}
export default function AttendanceMonthPanels({month,today,data,panel,open,leaveForm,staffIntake=false}:{month:string;today:string;data:MonthlyAttendance;panel:'schedule'|'leave';open:(kind:string,value?:unknown)=>void;leaveForm?:ReactNode;staffIntake?:boolean}){
 const hasOwn=Boolean(data.me);
 const defaultDate=today.startsWith(month+'-')?today:month+'-01';
 const leave=(date:string)=>{if(data.me)open('leave-range',{date,employee:data.me.id,name:data.me.name});else if(staffIntake&&data.admin)open('staff-leave-range',{date});};
 const canSubmit=hasOwn||staffIntake&&data.admin;
 const colors=employeeColors(data.employees);
 const off=(r:MonthlyScheduleRow)=>r.kind==='off'||r.kind==='leave';
 return panel==='schedule'?<>
  {data.admin&&<section className="panel attendance-roster" aria-label="Danh sách tên xếp lịch"><div className="purch-toolbar"><h3>Nhân viên xếp lịch</h3><button type="button" className="btn" onClick={()=>open('calendar-name')}>Thêm tên</button><button type="button" className="btn primary" disabled={!data.employees.length} onClick={()=>open('schedule-bulk')}>Xếp lịch hàng loạt</button></div>
   {data.employees.length?<ul>{data.employees.map(e=><li key={e.id}><StaffBadge id={e.id} name={e.name} colors={colors}/>{e.scheduleOnly&&<small>Chỉ dùng xếp lịch</small>}</li>)}</ul>:<p>Chưa có tên để xếp lịch.</p>}
  </section>}
  <MonthCalendar month={month} today={today} title="Lịch làm việc" rows={data.rows} canAdd={false} add={()=>{}} addLabel="" isOff={off}
   dayAction={data.admin?(date,rows)=>{
    const existing=new Map(rows.map(r=>[r.employee,r]));
    return <select className="attendance-staff-picker" aria-label={'Chọn nhân viên '+displayDate(date)} value="" onChange={e=>{
     if(e.target.value===addNameOption){open('calendar-name',{date});return;}
     const person=data.employees.find(p=>p.id===e.target.value);if(!person)return;
     const row=existing.get(person.id);if(row?.kind==='leave')return;
     open('schedule-day',row||{date,employee:person.id,name:person.name});
    }}><option value="">Chọn nhân viên</option><option value={addNameOption}>+ Thêm tên mới</option>{data.employees.map(p=><option key={p.id} value={p.id} disabled={existing.get(p.id)?.kind==='leave'}>{p.name}</option>)}</select>;
   }:undefined} render={r=><><div className="attendance-work-line"><StaffBadge id={r.employee} name={r.name} colors={colors} off={off(r)}/>{r.kind==='work'?(isAttendanceStart(r.start)?<time aria-label={'Giờ bắt đầu '+r.start} dateTime={r.start}>{r.start}</time>:null):<span>{r.kind==='off'?'OFF':'Nghỉ phép đã duyệt'}</span>}</div>{r.note&&<span className="attendance-note">{r.note}</span>}{data.admin&&r.kind!=='leave'&&<div className="attendance-day-actions">{data.employees.some(e=>e.id===r.employee)&&<button type="button" className="text-btn" onClick={()=>open('schedule-day',r)}>Sửa lịch</button>}<button type="button" className="text-btn attendance-cancel" aria-label={'Hủy lịch của '+r.name+' '+displayDate(r.date)} onClick={()=>open('cancel-schedule-day',r)}>Hủy lịch</button></div>}</>}/>

 </>:<>
  {canSubmit&&(leaveForm||<div className="purch-toolbar"><button type="button" className="btn primary" onClick={()=>leave(defaultDate)}>{staffIntake&&!hasOwn?'Gửi hộ yêu cầu nghỉ':'Tạo yêu cầu nghỉ'}</button></div>)}
  <section className="panel attendance-leave-list" aria-label="Danh sách và trạng thái yêu cầu nghỉ"><h3>{data.admin?'Duyệt yêu cầu nghỉ':'Yêu cầu nghỉ của tôi'}</h3>
   {data.admin&&<p>{data.leaves.filter(r=>r.status==='pending').length} chờ duyệt · {data.leaves.filter(r=>r.status==='approved').length} đã duyệt · {data.leaves.filter(r=>r.status==='rejected').length} không được duyệt</p>}
   {data.leaves.length?<ul>{[...data.leaves].sort((a,b)=>Number(b.status==='pending')-Number(a.status==='pending')||b.date.localeCompare(a.date)).map(r=><li key={r.id}>
    <div className="attendance-work-line"><StaffBadge id={r.employee} name={r.name} colors={colors} off={r.status==='approved'}/><span>{leaveRangeLabel(r.from||r.date,r.to||r.date)}</span><strong className={'attendance-leave-status '+r.status}>{leaveStatus(r.status)}</strong></div>
    <p className="attendance-note">Lý do: {r.note||'Không ghi lý do'}</p>
    {r.status!=='pending'&&<p className="attendance-note">Phản hồi của người duyệt: {r.reviewNote||'Không có ghi chú'}</p>}
    {data.admin&&r.source==='shared-clock'&&<p>Máy chấm công chung · chưa xác minh danh tính</p>}{data.admin&&r.source==='admin-assisted'&&<p>Quản trị viên gửi hộ · chưa phải quyết định duyệt</p>}
    {data.admin&&r.status==='pending'&&<div className="attendance-review"><button type="button" className="btn" onClick={()=>open('review-leave',{...r,approved:true})}>Duyệt</button><button type="button" className="btn" onClick={()=>open('review-leave',{...r,approved:false})}>Không duyệt</button></div>}
   </li>)}</ul>:<p>Chưa có yêu cầu nghỉ trong tháng này.</p>}
  </section>
  <MonthCalendar month={month} today={today} title="Lịch yêu cầu nghỉ" rows={attendanceMonthWeeks(month).flat().flatMap(day=>day?data.leaves.filter(r=>r.date<=day.date&&(r.to||r.date)>=day.date).map(r=>({...r,id:r.id+':'+day.date,date:day.date})):[])} canAdd={canSubmit} add={leave} addLabel="Xin nghỉ" isOff={r=>r.status==='approved'} render={r=><><StaffBadge id={r.employee} name={r.name} colors={colors} off={r.status==='approved'}/><span>{leaveStatus(r.status)}</span></>}/>
 </>;
}
