'use client';
import {useState} from 'react';
import TimePicker from '../../components/time-picker';
import {attendanceMonthWeeks,attendanceWeekdays} from '../../lib/attendance-month';
import {bulkRosterLimit,type BulkOutcome} from '../../lib/attendance-bulk';
import {displayDate} from '../../lib/display-date';
import type {MonthlyAttendance} from './attendance-month-panels';

export function bulkPreview(data:MonthlyAttendance,days:string[],staff:string[]):BulkOutcome{
 const total=days.length*staff.length;
 const out={changed:0,leave:0,off:0,existing:0,locked:data.locked?total:0,total};
 if(data.locked)return out;
 const rows=new Map(data.rows.map(r=>[r.date+'|'+r.employee,r.kind]));
 const approved=new Map<string,typeof data.leaves>();
 for(const r of data.leaves)if(r.status==='approved'){const a=approved.get(r.employee)||[];a.push(r);approved.set(r.employee,a);}
 for(const date of days)for(const person of staff){
  const kind=rows.get(date+'|'+person);
  if(kind==='leave'||approved.get(person)?.some(r=>r.date<=date&&(r.to||r.date)>=date))out.leave++;
  else if(kind==='off')out.off++;
  else if(kind)out.existing++;
  else out.changed++;
 }
 return out;
}
export function bulkSummary(out:BulkOutcome){
 const n=out.leave+out.off+out.existing+out.locked;
 return 'Đã thêm '+out.changed+' lịch. Bỏ qua '+n+' (OFF '+out.off+', nghỉ đã duyệt '+out.leave+', đã có lịch '+out.existing+', kỳ khóa '+out.locked+').';
}
export default function BulkScheduleFields({data,busy}:{data:MonthlyAttendance;busy:boolean}){
 const [staff,setStaff]=useState<string[]>([]),[days,setDays]=useState<string[]>([]);
 const update=(x:string,selected:string[],change:(v:string[])=>void)=>change(selected.includes(x)?selected.filter(v=>v!==x):[...selected,x]);
 const preview=bulkPreview(data,days,staff);
 return <fieldset className="attendance-bulk-fields" disabled={busy}>
  <p>Chọn từ một đến nhiều người, chọn các ngày trong tháng đang mở và dùng cùng một giờ bắt đầu.</p>
  {data.locked&&<p className="notice">Kỳ đã khóa. Không thể thêm lịch trong tháng này.</p>}
  <h3>1. Nhân viên</h3>
  <div className="attendance-bulk-names" aria-label="Chọn nhân viên xếp lịch">
   {data.employees.map(p=><label key={p.id}><input type="checkbox" name="employees" value={p.id} checked={staff.includes(p.id)} disabled={!staff.includes(p.id)&&staff.length>=bulkRosterLimit} onChange={()=>update(p.id,staff,setStaff)}/><span>{p.name}{p.scheduleOnly?' · Chỉ dùng xếp lịch':''}</span></label>)}
  </div>
  <h3>2. Các ngày</h3>
  <div className="attendance-bulk-days" aria-label="Chọn nhiều ngày">{attendanceWeekdays.map((day,i)=><span key={day} title={day}>{i===6?'CN':'T'+(i+2)}</span>)}{attendanceMonthWeeks(data.month).flat().map((x,i)=>x?<label key={x.date} className={days.includes(x.date)?'selected':undefined}><input type="checkbox" name="days" value={x.date} checked={days.includes(x.date)} aria-label={displayDate(x.date)} onChange={()=>update(x.date,days,setDays)}/>{x.day}</label>:<span key={'blank'+i}/>)}</div>
  <h3>3. Giờ bắt đầu</h3><TimePicker label="Giờ bắt đầu (24 giờ)" name="start"/>
  <p role="status"><strong>{staff.length} người × {days.length} ngày</strong> · dự kiến thêm {preview.changed}, bỏ qua {preview.total-preview.changed} (OFF {preview.off}, nghỉ đã duyệt {preview.leave}, đã có lịch {preview.existing}, kỳ khóa {preview.locked}).</p>
  <p>Không ghi đè lịch đã có và không ghi giờ chấm công. Kết quả được đối chiếu lại khi lưu.</p>
 </fieldset>;
}
