'use client';
export type AttendancePanel='schedule'|'leave'|null;
export const attendancePanel=(value:unknown):AttendancePanel=>value==='schedule'||value==='leave'?value:null;
export default function AttendanceSections({panel,onChange,busy=false}:{panel:AttendancePanel;onChange:(next:AttendancePanel)=>void;busy?:boolean}){
 const items=[{id:null,label:'Chấm công'},{id:'schedule' as const,label:'Lịch làm việc'},{id:'leave' as const,label:'Xin nghỉ'}];
 return <nav className="purch-toolbar attendance-hr-tabs" aria-label="Mục nhân sự">{items.map(x=><button type="button" key={x.label} className={'btn'+(panel===x.id?' primary':'')} aria-pressed={panel===x.id} disabled={busy} onClick={()=>onChange(x.id)}>{x.label}</button>)}</nav>;
}
