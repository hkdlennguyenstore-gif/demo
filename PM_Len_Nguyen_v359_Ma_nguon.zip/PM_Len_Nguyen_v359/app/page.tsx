import App from './ui';
import {getChatGPTUser} from './chatgpt-auth';
import {env} from 'cloudflare:workers';
import {permission,hydrateState,type State} from '../lib/payroll';
import {monthView} from '../lib/month-view';
import {redirect} from 'next/navigation';
export async function generateMetadata({searchParams}:{searchParams:Promise<{view?:string}>}){
 const {view}=await searchParams;
 return {title:!view||view==='overview'?'Tổng quan kinh doanh | Lên Nguyễn Store':'Quản lý nội bộ | Lên Nguyễn Store',description:'Tổng quan doanh số, đơn chốt, chi phí, lợi nhuận và tồn kho theo kỳ của Lên Nguyễn Store.',robots:{index:false,follow:false}};
}
export const dynamic='force-dynamic';
export default async function Page({searchParams}:{searchParams:Promise<{view?:string;attendance?:string}>}){const {view,attendance}=await searchParams;const initialAttendance=(attendance==='leave'||attendance==='schedule')?attendance:null;const initialHrView=view==='clock'||view==='pay'||view==='insurance'?view:undefined;const u=await getChatGPTUser();if(u){const r=await env.DB?.prepare('SELECT value,version FROM app_state WHERE id=?').bind('main').first<{value:string,version:number}>();if(r){const s=hydrateState(JSON.parse(r.value) as State);if(permission(s,u.email)?.role==='terminal')redirect('/cham-cong');const data=monthView(s,u.email);if(data)return <App initialAttendance={initialAttendance} initialHrView={initialHrView} initialData={{...data,version:r.version}}/>;}}return <App initialAttendance={initialAttendance} initialHrView={initialHrView}/>;}
