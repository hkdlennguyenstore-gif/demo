'use client';
import {useEffect,useState} from 'react';
type Report={received:{source:string;quantity:number}[];issued:number|null;returned:number|null;orders:number|null;cost:number|null;missing:string[];reason:string};
function useReport(query:string){
 const [data,setData]=useState<Report|null>(null),[error,setError]=useState('');
 useEffect(()=>{const c=new AbortController();setData(null);setError('');
 fetch('/api/finance?mode=warehouse-overview&'+query,{signal:c.signal,cache:'no-store'}).then(async r=>{if(!r.ok)throw Error();const v=await r.json();if(!c.signal.aborted)setData(v);}).catch(()=>{if(!c.signal.aborted)setError('Chưa tải được số liệu kho');});
 return ()=>c.abort();},[query]);return {data,error};
}
const format=(n:number|null)=>n===null?'—':n.toLocaleString('vi-VN');
export function WarehouseCost({query}:{query:string}){
 const [cost,setCost]=useState<{known:number;matched:number;complete:boolean}|null>(null);
 useEffect(()=>{const c=new AbortController();setCost(null);fetch('/api/stock?mode=inventory-summary&'+query,{signal:c.signal,cache:'no-store'}).then(async r=>{if(r.ok){const data=await r.json();if(!c.signal.aborted)setCost(data.salesCost);}}).catch(()=>{});return ()=>c.abort();},[query]);
 return <>{cost&&(cost.complete||cost.matched)?format(cost.known)+' ₫'+(cost.complete?'':' · phần đã khớp'):'—'}</>;
}
export default function WarehouseOverview({query}:{query:string}){
 const {data:d,error}=useReport(query);
 return <section id="tong-quan-kho" className="panel"><h2>Tổng quan nhập hàng</h2>{!d?<p role="status">{error||'Đang đối chiếu kho, POS và A3…'}</p>:<>
 <div className="table-scroll"><table><thead><tr>{['Nhập kho','Xuất giao vận (POS)','Hoàn (POS)','Biến động tồn','Giá vốn theo A3'].map(s=><th key={s}>{s}</th>)}</tr></thead><tbody><tr>
 <td>{format(d.received.reduce((n,r)=>n+r.quantity,0))} SP</td><td>{format(d.issued)} SP</td><td>{format(d.returned)} SP · {format(d.orders)} đơn</td>
 <td>{d.issued!=null&&d.returned!=null?format(d.received.reduce((n,r)=>n+r.quantity,0)+d.returned-d.issued)+' SP':'—'}</td><td>{d.cost!=null?format(d.cost)+' ₫':'Chờ đối chiếu'}</td></tr></tbody></table></div>
 <small>{d.received.map(r=>r.source+' '+format(r.quantity)+' SP').join(' · ')} · Tồn cuối kỳ chờ mốc kiểm kê đầu kỳ.</small>
 {d.reason&&<p>{d.reason}{d.missing.length?' · '+d.missing.slice(0,12).join(', '):''}</p>}</>}</section>;
}
