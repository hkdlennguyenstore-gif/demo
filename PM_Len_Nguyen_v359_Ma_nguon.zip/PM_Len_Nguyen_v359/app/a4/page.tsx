import {env} from 'cloudflare:workers';
import {redirect} from 'next/navigation';
import {requireChatGPTUser} from '../chatgpt-auth';
import {permission,type State} from '../../lib/payroll';
import A4Workbench from './workbench';
export default async function Page(){
 const user=await requireChatGPTUser('/a4');
 const row=await env.DB!.prepare("SELECT json_object('owner',json_extract(value,'$.owner'),'owners',json_extract(value,'$.owners'),'members',json_extract(value,'$.members')) value FROM app_state WHERE id='main'").first<{value:string}>();
 if(row&&permission(JSON.parse(row.value) as State,user.email)?.role==='terminal')redirect('/kho-nhan-vien');
 return <A4Workbench/>;
}
