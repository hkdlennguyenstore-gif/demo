'use client';
import {useEffect,useRef,useState} from 'react';
import PmShell from '../../components/pm-shell';
import {A4_SIZES,validateA4Plan,a4Key} from '../../lib/a4';
import A4LiveView from './live-view';
import './a4.css';
import './approved.css';
const sum=(v:number[])=>v.reduce((a,b)=>a+b,0),money=(n:any)=>n==null?'Chưa có giá':new Intl.NumberFormat('vi-VN').format(n)+' đ';
const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}).format(new Date());
const date=(v:string)=>v?v.split('-').reverse().join('/'):'—';
const time=(v:string)=>v?new Date(v).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}):'';
const stageNames:Record<string,string>={draft:'Kế hoạch nháp',production:'Đã sản xuất',returned:'Đã trả'};
const blankColor=()=>({color:'',qty:A4_SIZES.map(()=> '')});
const blankPlan=()=>({date:today(),lot:'',supplier:'',type:'',code:'',due:'',note:'',colors:[blankColor()]} as any);
async function read(url:string){const r=await fetch(url,{cache:'no-store'}),d=await r.json() as any;if(!r.ok)throw Error(d.error||'Chưa tải được dữ liệu');return d;}
function SupplierInput({value,names,onChange}:{value:string,names:string[],onChange:(v:string)=>void}){
 const [open,setOpen]=useState(false),[all,setAll]=useState(true),[active,setActive]=useState(-1);
 const options=names.filter(n=>all||a4Key(n).includes(a4Key(value)));
 function show(){setOpen(true);setAll(true);setActive(-1);}
 return <div className="a4-supplier" onBlur={e=>{if(!e.currentTarget.contains(e.relatedTarget))setOpen(false);}}><label htmlFor="a4-supplier">Nhà cung cấp</label><div className="a4-combo"><input id="a4-supplier" role="combobox" aria-expanded={open} aria-controls="a4-supplier-list" aria-autocomplete="list" aria-activedescendant={open&&active>=0?'a4-sup-'+active:undefined} value={value} maxLength={120} placeholder="Chọn hoặc nhập tên mới" onFocus={show} onClick={show} onChange={e=>{onChange(e.target.value);setAll(false);setOpen(true);setActive(-1);}} onKeyDown={e=>{if(e.nativeEvent.isComposing)return;if(e.key==='Escape'){e.preventDefault();setOpen(false);}if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();if(!open)show();setActive(i=>options.length?(i+(e.key==='ArrowDown'?1:-1)+options.length)%options.length:-1);}if(e.key==='Enter'&&open){e.preventDefault();if(active>=0&&options[active])onChange(options[active]);setOpen(false);}}}/><button type="button" aria-label="Xem tất cả nhà cung cấp" onMouseDown={e=>e.preventDefault()} onClick={()=>{if(open&&all)setOpen(false);else show();}}>⌄</button></div>{open&&<div className="a4-supplier-options"><div role="listbox" id="a4-supplier-list" aria-label="Nhà cung cấp hiện có">{options.map((n,i)=><button type="button" id={'a4-sup-'+i} role="option" aria-selected={value===n} data-active={active===i} key={n} onMouseDown={e=>e.preventDefault()} onClick={()=>{onChange(n);setOpen(false);}}>{n}</button>)}</div><small>{options.length?'Hoặc gõ tên nhà cung cấp mới ngay trong ô trên.':'Tên mới được nhớ khi lưu kế hoạch.'}</small></div>}</div>;
}
export default function A4Workbench(){
 const [standalone,setStandalone]=useState(false),[tab,setTab]=useState('a1'),[catalog,setCatalog]=useState<any>(null),[query,setQuery]=useState(''),[code,setCode]=useState(''),[product,setProduct]=useState<any>(null),[loading,setLoading]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState(''),[busy,setBusy]=useState(false),[stage,setStage]=useState('draft'),[plans,setPlans]=useState<any>(null),[planQuery,setPlanQuery]=useState(''),[page,setPage]=useState(1),[draft,setDraft]=useState<any>(blankPlan),[action,setAction]=useState<any>(null),[presenter,setPresenter]=useState(false),[liveFocus,setLiveFocus]=useState(false);
 const [stockSyncError,setStockSyncError]=useState('');
 const frame=useRef<HTMLElement|null>(null),displayWindow=useRef<Window|null>(null);
 const viewport=useRef<HTMLElement|null>(null),content=useRef<HTMLDivElement|null>(null);
 useEffect(()=>{
  const element=viewport.current,body=content.current;
  if(!element||!body)return;
  let pending=0;
  const fit=()=>{
   const css=getComputedStyle(element),width=element.clientWidth-parseFloat(css.paddingLeft)-parseFloat(css.paddingRight),height=element.clientHeight-parseFloat(css.paddingTop)-parseFloat(css.paddingBottom);
   if(width<=0||height<=0)return;
   const scale=tab==='a1'?Math.min(width/820,(height-2)/Math.max(1,body.offsetHeight,body.scrollHeight)):width/820;
   element.style.setProperty('--a4-content-scale',String(Math.max(.01,scale)));
  };
  const schedule=()=>{cancelAnimationFrame(pending);pending=requestAnimationFrame(fit);};
  const observer=new ResizeObserver(schedule);
  observer.observe(element);observer.observe(body);schedule();
  return ()=>{observer.disconnect();cancelAnimationFrame(pending);};
 },[standalone,tab]);
 const productSeq=useRef(0),planSeq=useRef(0),saving=useRef(false),channel=useRef<BroadcastChannel|null>(null),request=useRef(crypto.randomUUID()),loaded=useRef(false);
 async function loadCatalog(){try{const d=await read('/api/a4?mode=catalog');setCatalog(d);return d;}catch(e){setError((e as Error).message);return null;}}
 async function loadProduct(fresh=false,background=false){if(!code){setLoading(false);return;}const seq=++productSeq.current;if(!background)setLoading(true);try{const d=await read('/api/a4?'+new URLSearchParams({mode:'product',code,...(fresh?{fresh:'1'}:{})}));if(seq===productSeq.current){setProduct((prev:any)=>prev?.code===d.code && prev.pos?.updatedAt && prev.pos.updatedAt>(d.pos?.updatedAt||'')?{...d,pos:prev.pos}:d);setError('');}}catch(e){if(seq===productSeq.current)setError((e as Error).message);}finally{if(seq===productSeq.current)setLoading(false);}}
 async function loadPlans(){const seq=++planSeq.current;try{const d=await read('/api/a4?'+new URLSearchParams({mode:'plans',status:stage,page:String(page),q:planQuery}));if(seq===planSeq.current)setPlans(d);}catch(e){setError((e as Error).message);}}
 function changed(){channel.current?.postMessage({changed:true});}
 useEffect(()=>{const q=new URLSearchParams(window.location.search);setStandalone(q.get('standalone')==='1');setPresenter(q.get('presenter')==='1');setLiveFocus(q.get('presenter')==='1');if(['a1','a2','cut'].includes(q.get('tab')||''))setTab(q.get('tab')!);void loadCatalog().then(d=>{if(!d)return;setDraft((v:any)=>({...v,supplier:v.supplier||d.suppliers.find((n:string)=>a4Key(n)==='trang')||d.suppliers[0]||''}));const c=q.get('code')||d.products.find((p:any)=>p.code==='B4')?.code||d.products[0]?.code||'';setCode(c);setQuery(c);loaded.current=true;});return()=>{productSeq.current++;planSeq.current++;};},[]);
 useEffect(()=>{if(!loaded.current)return;const u=new URL(window.location.href);u.searchParams.set('tab',tab);if(code)u.searchParams.set('code',code);window.history.replaceState(null,'',u);},[tab,code]);
 useEffect(()=>{setProduct(null);void loadProduct();return()=>{productSeq.current++;};},[code]);
 useEffect(()=>{const t=setTimeout(()=>void loadPlans(),150);return()=>{clearTimeout(t);planSeq.current++;};},[stage,page,planQuery]);
 useEffect(()=>{
  setStockSyncError('');
  if(!code || tab==='cut')return;
  let active=true, reading=false;
  async function refreshStock(){
   if(!active || reading || document.visibilityState!=='visible')return;
   reading=true;
   try{
    const pos=await read('/api/a4?'+new URLSearchParams({mode:'stock',code}));
    if(active)setStockSyncError('');
    if(active)setProduct((prev:any)=>prev?.code===code && pos.code===code && (!prev.pos?.updatedAt || pos.updatedAt>=prev.pos.updatedAt)?{...prev,pos,stockIssue:''}:prev);
   }catch(e){
    if(active)setStockSyncError('Chưa cập nhật được tồn POS: '+(e as Error).message);
   }finally{reading=false;}
  }
  const timer=setInterval(refreshStock,3000);
  document.addEventListener('visibilitychange',refreshStock);
  window.addEventListener('focus',refreshStock);
  return ()=>{active=false;clearInterval(timer);document.removeEventListener('visibilitychange',refreshStock);window.removeEventListener('focus',refreshStock);};
 },[code,tab]);
 useEffect(()=>{const poll=setInterval(()=>{if(document.visibilityState==='visible'&&!saving.current){void loadProduct(false,true);void loadPlans();}},30000);const focus=()=>{if(!saving.current){void loadProduct(false,true);void loadPlans();}};window.addEventListener('focus',focus);let bc:BroadcastChannel|null=null;try{bc=new BroadcastChannel('ln-a4');channel.current=bc;bc.onmessage=()=>{void loadPlans();void loadProduct(false,true);void loadCatalog();};}catch{}return()=>{clearInterval(poll);window.removeEventListener('focus',focus);bc?.close();channel.current=null;};},[code,stage,page,planQuery]);
 async function post(kind:string,data:any,id?:string){const response=await fetch('/api/a4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:kind,data,requestId:id||crypto.randomUUID()})}),result=await response.json() as any;if(!response.ok)throw Error(result.error||'Chưa lưu được');return result;}
 async function savePlan(){if(saving.current)return;setError('');setNotice('');try{const data=validateA4Plan({...draft,colors:draft.colors.map((c:any)=>({color:c.color,qty:c.qty.map((q:string)=>Number(q||0))}))});saving.current=true;setBusy(true);await post('save',{...data,...(draft.id?{id:draft.id,version:draft.version}:{})},request.current);request.current=crypto.randomUUID();setDraft((v:any)=>({...blankPlan(),supplier:v.supplier,date:v.date,type:v.type,code:v.code}));setStage('draft');setPage(1);await loadPlans();await loadCatalog();setNotice('Đã lưu '+data.code+' · '+sum(data.qty)+' sản phẩm vào danh sách nháp.');changed();document.getElementById('a4-plan-list')?.scrollIntoView({block:'start',behavior:'smooth'});}catch(e){setError((e as Error).message);}finally{saving.current=false;setBusy(false);}}
 async function confirmAction(){if(!action||saving.current)return;saving.current=true;setBusy(true);setError('');try{const result=await post(action.kind,{id:action.row.id,version:action.row.version,date:action.date,note:action.note,quantity:Number(action.quantity)},action.requestId);const next=action.kind==='production'?'production':Number(action.quantity)+action.row.received===sum(action.row.qty)?'returned':'production';setAction(null);setStage(next);setPage(1);setNotice('Đã cập nhật lô '+(result.lot||action.row.lot)+'.');changed();await loadPlans();}catch(e){setError((e as Error).message);}finally{saving.current=false;setBusy(false);}}
 async function deletePlan(row:any){
  if(saving.current||!window.confirm('Xóa lô '+row.lot+' · '+row.code+' khỏi '+stageNames[row.status]+'?'))return;
  saving.current=true;setBusy(true);setError('');
  try{
   await post('delete',{id:row.id,version:row.version});
   if(draft.id===row.id){setDraft(blankPlan());request.current=crypto.randomUUID();}
   setNotice('Đã xóa lô '+row.lot+'.');changed();
   if(page>1&&plans?.rows.length===1)setPage(page-1);
   else await loadPlans();
  }catch(e){setError((e as Error).message);}
  finally{saving.current=false;setBusy(false);}
 }
 async function pdf(row:any){setError('');try{const path='/a4/pdf.mjs?v=lot-number';const module=await import(/* @vite-ignore */ path);await module.downloadCutPdf(row);}catch(e){setError('Chưa xuất được PDF: '+(e as Error).message);}}
 function edit(row:any){setDraft({...row,colors:row.colors.map((c:any)=>({...c,qty:c.qty.map((q:number)=>q?String(q):'')}))});request.current=crypto.randomUUID();setError('');setNotice('');const form=document.getElementById('a4-plan-form') as HTMLDetailsElement|null;if(form)form.open=true;form?.scrollIntoView({block:'start',behavior:'smooth'});}
 async function csv(){try{const data=await read('/api/a4?mode=export'),rows=[['LÊN NGUYỄN STORE · KẾ HOẠCH CẮT HÀNG'],['Trạng thái','Lô','Ngày','Nhà cung cấp','Loại hàng','Mã','Màu',...A4_SIZES,'Tổng màu','Tổng lô','Đã trả','Còn','Hẹn giao','Ghi chú'],...data.rows.flatMap((p:any)=>p.colors.map((c:any,i:number)=>[stageNames[p.status],p.lot,p.date,p.supplier,p.type,p.code,c.color,...c.qty,sum(c.qty),...(i===0?[sum(p.qty),p.received,sum(p.qty)-p.received]:['','','']),p.due,p.note]))];const escape=(v:unknown)=>{let s=String(v??'');if(/^[=+@\-\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};const url=URL.createObjectURL(new Blob(['\uFEFF'+rows.map(r=>r.map(escape).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download='A4-ke-hoach-cat-hang.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(e){setError((e as Error).message);}}
 useEffect(()=>{
  const element=frame.current;if(!element)return;
  if(standalone){
   const fit=()=>{element.style.width='calc(100% - 16px)';element.style.height='calc(100dvh - 16px)';};
   fit();window.addEventListener('resize',fit);return()=>window.removeEventListener('resize',fit);
  }
  try{const v=JSON.parse(localStorage.getItem('LN_A4_APPROVED_FRAME')||'null');if(v&&Number.isFinite(v.width)&&Number.isFinite(v.height)){element.style.width=v.width+'px';element.style.height=v.height+'px';}}catch{}
 },[standalone]);
 useEffect(()=>{let bc:BroadcastChannel|null=null;try{bc=new BroadcastChannel('ln-a4-display');bc.onmessage=e=>{if(presenter&&e.data?.lookup&&typeof e.data.code==='string'){setCode(e.data.code);setQuery(e.data.code);}};}catch{}return()=>bc?.close();},[presenter]);
 useEffect(()=>{if(code&&!presenter){try{const bc=new BroadcastChannel('ln-a4-display');bc.postMessage({lookup:true,code});bc.close();}catch{}}},[code,presenter]);
 useEffect(()=>{if(!loaded.current)return;const timer=setTimeout(()=>setCode(query.trim().toUpperCase()),180);return()=>clearTimeout(timer);},[query]);
 function changeCode(value:string){productSeq.current++;setProduct(null);setLoading(!!value.trim());setQuery(value);}
 function openWindow(forPresenter=false){const u=new URL('/a4',window.location.origin);u.searchParams.set('standalone','1');u.searchParams.set('tab',forPresenter?'a1':tab);if(code)u.searchParams.set('code',code);if(forPresenter)u.searchParams.set('presenter','1');const win=window.open(u.toString(),forPresenter?'LN_A4_PRESENTER':'LN_A4_WINDOW','popup,width=760,height=440,resizable=yes,scrollbars=yes');if(forPresenter)displayWindow.current=win;if(!win)setNotice('Trình duyệt đang chặn cửa sổ. Cho phép mở cửa sổ cho PM rồi bấm lại.');}
 function resize(e:React.PointerEvent<HTMLButtonElement>){if(!frame.current)return;e.preventDefault();const target=e.currentTarget,box=frame.current.getBoundingClientRect(),x=e.clientX,y=e.clientY;target.setPointerCapture(e.pointerId);const move=(ev:PointerEvent)=>{if(!frame.current)return;const maxWidth=Math.max(320,window.innerWidth-box.left-12),maxHeight=Math.max(220,window.innerHeight-box.top-12);frame.current.style.width=Math.max(Math.min(340,maxWidth),Math.min(maxWidth,box.width+ev.clientX-x))+'px';frame.current.style.height=Math.max(Math.min(220,maxHeight),Math.min(maxHeight,box.height+ev.clientY-y))+'px';};const end=()=>{target.removeEventListener('pointermove',move);target.removeEventListener('pointerup',end);target.removeEventListener('pointercancel',end);if(frame.current)try{const b=frame.current.getBoundingClientRect();localStorage.setItem('LN_A4_APPROVED_FRAME',JSON.stringify({width:b.width,height:b.height}));}catch{}};target.addEventListener('pointermove',move);target.addEventListener('pointerup',end);target.addEventListener('pointercancel',end);}
 function leaveLive(){setLiveFocus(false);setPresenter(false);const u=new URL(window.location.href);u.searchParams.delete('presenter');window.history.replaceState(null,'',u);}
 useEffect(()=>{if(!liveFocus&&!presenter)return;const exit=(e:KeyboardEvent)=>{if(e.key==='Escape')leaveLive();};window.addEventListener('keydown',exit);return()=>window.removeEventListener('keydown',exit);},[liveFocus,presenter]);
 useEffect(()=>{if(action)document.querySelector('.cut-action-panel')?.scrollIntoView({block:'nearest'});},[action?.requestId]);
 const navigation=presenter?null:<nav className="a4-module-tabs" aria-label="Ba bảng A4">{[{id:'a1',label:'A1',name:'Tra kho & giá'},{id:'a2',label:'A2',name:'Facebook'},{id:'cut',label:'Đặt hàng',name:'Kế hoạch cắt'}].map(t=><button type="button" key={t.id} className={tab===t.id?'active':''} aria-pressed={tab===t.id} onClick={()=>{setTab(t.id);setError('');setNotice('');}}><span className="a4-tab-code">{t.label}</span> <span>{t.name}</span></button>)}</nav>;
 return <PmShell active="a4" title="A4 · Kho & kế hoạch hàng" standalone={standalone}><section ref={frame} id="a4Frame" className={'a4-approved '+(tab==='a1'?'a1-active':tab==='a2'?'a2-active':'')+(presenter?' a1-presenter':'')+(liveFocus?' live-focus':'')}><header><div className="brand"><img className="a4-store-logo" src="/len-nguyen-logo.webp" alt="Lên Nguyễn Store" width={48} height={48}/><div><h1>A4 · Kho & kế hoạch hàng</h1><small>Ba bảng làm việc trong một không gian</small></div></div>{tab!=='cut'&&<>{navigation}<div className="actions"><button type="button" aria-pressed={liveFocus||presenter} onClick={()=>{if(liveFocus||presenter)leaveLive();else setLiveFocus(true);}}>{liveFocus||presenter?'Quay lại':'Khung live'}</button>{!presenter&&<button type="button" id="popout" onClick={()=>openWindow()}>Mở cửa sổ riêng</button>}</div></>}</header><main ref={viewport}>{tab==='cut'&&navigation}<div ref={content} className="a4-scaled-content">
 {(error||stockSyncError)&&<div className="notice a4-error" role="alert">{error||stockSyncError}</div>}{notice&&<div className="notice" role="status">{notice}</div>}{!catalog&&<p>Đang đọc dữ liệu PM…</p>}
 {tab!=='cut'&&catalog&&<A4LiveView tab={tab} product={product} catalog={catalog} code={code} query={query} onCode={changeCode} loading={loading} presenter={presenter} liveFocus={liveFocus}/>}
 {tab==='cut'&&catalog&&<section id="cut" data-stage={stage}><h2>Đặt hàng · Theo dõi theo lô</h2><div className="a4-stage-tabs cut-stage-tabs" role="group" aria-label="Trạng thái kế hoạch">{Object.keys(stageNames).map(s=><button type="button" key={s} data-stage={s} aria-pressed={stage===s} onClick={()=>{setStage(s);setPage(1);}}>{stageNames[s]} <b>{plans?.counts?.[s]||0}</b></button>)}</div>
 {stage==='draft'&&catalog.canManage&&<details className="card a4-plan-form" id="a4-plan-form"><summary>{draft.id?'Sửa kế hoạch nháp':'Thêm kế hoạch nháp'}</summary><div className="toolbar a4-plan-fields"><label>Ngày kế hoạch<input type="date" value={draft.date} onChange={e=>setDraft({...draft,date:e.target.value})}/></label><SupplierInput value={draft.supplier} names={catalog.suppliers} onChange={supplier=>setDraft({...draft,supplier})}/><label>Loại hàng<input list="a4-types" value={draft.type} placeholder="Chọn / nhập loại hàng" maxLength={60} onChange={e=>setDraft({...draft,type:e.target.value})}/></label><label>Mã hàng<input list="a4-cut-products" value={draft.code} maxLength={30} onChange={e=>setDraft({...draft,code:e.target.value.toUpperCase()})}/></label><label>Ngày hẹn giao<input type="date" value={draft.due} onChange={e=>setDraft({...draft,due:e.target.value})}/></label></div><datalist id="a4-types">{['Jean suông','Jean đứng','Jean ôm','Jean loe','Jean baggy','Jean lửng','Short'].map(v=><option key={v} value={v}/>)}</datalist><datalist id="a4-cut-products">{catalog.products.map((p:any)=><option key={p.code} value={p.code}>{p.name}</option>)}</datalist>
 <div className="a4-color-heading cut-colors-heading"><strong>Màu sắc & số lượng theo size</strong><button type="button" className="btn" disabled={draft.colors.length>=30||busy} onClick={()=>setDraft({...draft,colors:[...draft.colors,blankColor()]})}>+ Thêm màu</button></div><div className="a4-grid-scroll"><table className="a4-color-entry cut-color-inputs"><thead><tr><th>Màu sắc</th>{A4_SIZES.map(s=><th key={s}>Size {s}</th>)}<th>Tổng màu</th><th/></tr></thead><tbody>{draft.colors.map((c:any,i:number)=><tr key={i}><td><input aria-label={'Màu sắc dòng '+(i+1)} value={c.color} maxLength={80} placeholder="Nhập màu" onChange={e=>setDraft({...draft,colors:draft.colors.map((v:any,j:number)=>j===i?{...v,color:e.target.value}:v)})}/></td>{A4_SIZES.map((s,k)=><td key={s}><input type="number" min="0" max="1000000" step="1" aria-label={'Số lượng dòng màu '+(i+1)+' size '+s} value={c.qty[k]} onChange={e=>setDraft({...draft,colors:draft.colors.map((v:any,j:number)=>j===i?{...v,qty:v.qty.map((q:string,index:number)=>index===k?e.target.value:q)}:v)})}/></td>)}<td><b>{c.qty.reduce((n:number,q:string)=>n+(Number(q)||0),0)||'—'}</b></td><td><button type="button" className="btn" disabled={busy||draft.colors.length===1} aria-label={'Bỏ màu '+(i+1)} onClick={()=>setDraft({...draft,colors:draft.colors.filter((_:any,j:number)=>j!==i)})}>Bỏ màu</button></td></tr>)}</tbody></table></div><p className="a4-total">Tổng lô: <b>{draft.colors.reduce((n:number,c:any)=>n+c.qty.reduce((a:number,q:string)=>a+(Number(q)||0),0),0)} sản phẩm</b> · {draft.colors.length} màu</p><label>Ghi chú<textarea value={draft.note} rows={2} maxLength={1000} onChange={e=>setDraft({...draft,note:e.target.value})} placeholder="Yêu cầu hàng, wash, mẫu, lưu ý cho nhà cung cấp…"/></label><div className="a4-form-actions cut-form-actions"><small>Ô SL trống = không đặt size này.</small><div>{draft.id&&<button type="button" className="btn" disabled={busy} onClick={()=>{setDraft(blankPlan());request.current=crypto.randomUUID();}}>Hủy sửa</button>}<button type="button" className="btn primary" disabled={busy} onClick={()=>void savePlan()}>{busy?'Đang lưu…':draft.id?'Lưu kế hoạch nháp':'Thêm kế hoạch nháp'}</button></div></div></details>}
 <section className="card a4-plan-list cut-list" id="a4-plan-list"><div className="a4-list-heading"><h2>{stageNames[stage]}</h2><input aria-label="Tìm lô hoặc mã hàng" placeholder="Tìm lô / mã hàng" value={planQuery} onChange={e=>{setPlanQuery(e.target.value);setPage(1);}}/><button type="button" className="btn" onClick={()=>void csv()}>Xuất CSV 3 danh sách</button></div><p>{plans?.total||0} kế hoạch</p><div className="draft-lots">
 {plans?.rows.map((p:any)=><article key={p.id} className="draft-lot">
  <header><strong>Lô {p.lot} · {p.code}</strong><span>{p.supplier} · {p.type}</span><time>{date(p.date)}</time><b>{sum(p.qty)} SP</b>{p.status!=='draft'&&<span>Đã trả {p.received} · Còn {sum(p.qty)-p.received}</span>}</header>
  <div className="draft-size-scroll"><table aria-label={'Số lượng theo size lô '+p.lot}><thead><tr><th>Màu</th>{A4_SIZES.map(size=><th key={size} scope="col">{size}</th>)}<th>Tổng</th></tr></thead>
  <tbody>{p.colors.map((c:any,i:number)=><tr key={i}><th scope="row">{c.color}</th>{c.qty.map((q:number,j:number)=><td key={j} className={q===0?'a4-zero-qty':undefined} aria-label={q===0?'0 sản phẩm':undefined}>{q===0?null:q}</td>)}<td><b>{sum(c.qty)}</b></td></tr>)}</tbody></table></div>
  {(p.note||p.due||p.productionDate||p.returns?.length>0)&&<details className="lot-details"><summary>Chi tiết lô</summary>
   {p.productionDate&&<p>Ngày sản xuất {date(p.productionDate)} · {p.productionNote}</p>}
   {p.due&&<p>Hẹn giao {date(p.due)}</p>}{p.note&&<p>{p.note}</p>}
   {p.returns?.map((r:any,i:number)=><p key={i}>Giao {date(r.date)} · {r.qty} SP {r.note}</p>)}
   {!p.returns?.length&&p.returnedDate&&<p>Ngày trả {date(p.returnedDate)}</p>}
  </details>}
  <footer><button type="button" onClick={()=>void pdf(p)}>Xuất PDF</button>{catalog.canManage&&<>
   {p.status==='draft'&&<><button type="button" disabled={busy} onClick={()=>edit(p)}>Sửa nháp</button>
   <button type="button" className="cut-status-button" disabled={busy} onClick={()=>{setError('');setAction({kind:'production',row:p,date:today(),note:'',requestId:crypto.randomUUID()});}}>Chuyển sang đã sản xuất</button></>}
   {p.status==='production'&&<button type="button" className="cut-status-button" disabled={busy} onClick={()=>{setError('');setAction({kind:'return',row:p,date:today(),quantity:sum(p.qty)-p.received,note:'',requestId:crypto.randomUUID()});}}>Ghi nhận hàng trả</button>}
   <button type="button" className="delete-plan" disabled={busy} onClick={()=>void deletePlan(p)}>{p.status==='draft'?'Xóa nháp':'Xóa lô'}</button>
  </>}</footer>
 </article>)}
 {plans&&!plans.rows.length&&<p>Chưa có lô trong {stageNames[stage].toLowerCase()}.</p>}
 </div><div className="a4-pagination"><button type="button" className="btn" disabled={page===1} onClick={()=>setPage(v=>v-1)}>Trước</button><span>Trang {page} · 50 lô/trang</span><button type="button" className="btn" disabled={!plans||page*50>=plans.total} onClick={()=>setPage(v=>v+1)}>Sau</button></div></section><p className="a4-source-note">Kế hoạch cắt và ghi nhận hàng trả được lưu trên PM. Khi hàng thực nhận, lập phiếu tại Nhập hàng để cập nhật tồn và công nợ.</p></section>}
 {action&&<div className="card cut-action-panel"><section className="a4-action" role="dialog" aria-modal="false" aria-label={action.kind==='production'?'Báo cắt':'Ghi nhận hàng trả'}><h2>{action.kind==='production'?'Chuyển sang đã sản xuất':'Ghi nhận hàng đã giao về shop'}</h2><p><b>LÔ SỐ: {action.row.lot}</b> · {action.row.code} · Còn {sum(action.row.qty)-action.row.received} SP</p><label>Ngày ghi nhận<input type="date" value={action.date} onChange={e=>setAction({...action,date:e.target.value})}/></label>{action.kind==='return'&&<label>Số lượng trả<input type="number" min="1" max={sum(action.row.qty)-action.row.received} step="1" value={action.quantity} onChange={e=>setAction({...action,quantity:e.target.value})}/></label>}<label>Ghi chú<input value={action.note} maxLength={500} onChange={e=>setAction({...action,note:e.target.value})}/></label>{error&&<p role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="btn" disabled={busy} onClick={()=>setAction(null)}>Hủy</button><button type="button" className="btn primary" disabled={busy} onClick={()=>void confirmAction()}>Xác nhận</button></div></section></div>}
 </div></main><div className="a4-frame-edge"><span>Kéo góc phải để đổi kích thước</span><button type="button" id="a4ResizeHandle" aria-label="Đổi kích thước khung A4" onPointerDown={resize}>◢</button></div></section></PmShell>;
}
