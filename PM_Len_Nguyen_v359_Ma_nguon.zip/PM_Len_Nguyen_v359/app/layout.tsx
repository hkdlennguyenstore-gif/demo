import type { Metadata, Viewport } from "next";
import "./globals.css";
import "./brand-ui.css";
import MobileApp from "../components/mobile-app";

export const metadata: Metadata = {
  title: "Lên Nguyễn Store",
  description: "Phần mềm quản lý nội bộ Lên Nguyễn Store",
  manifest: "/manifest.webmanifest",
  appleWebApp: {capable:true,title:"PM LN",statusBarStyle:"default"},
  icons: {
    apple: "/app-icons/ln-180.png",
    icon: "/len-nguyen-logo.webp",
    shortcut: "/len-nguyen-logo.webp",
  },
};

export const viewport: Viewport = {width:"device-width",initialScale:1,viewportFit:"cover",themeColor:"#214c43"};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi">
      <body className="antialiased">{children}<MobileApp/></body>
    </html>
  );
}
