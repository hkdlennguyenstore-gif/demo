import A3Prices from './prices';
export default function Page(){return <A3Prices/>;}
