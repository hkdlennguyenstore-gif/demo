import FinanceScreen from '../../components/finance/finance-screen';
export default function Page(){return <><FinanceScreen kind="expense"/><nav style={{padding:"1rem"}}><a href="/chi-phi/gmail">Chứng từ Gmail</a></nav></>;}
