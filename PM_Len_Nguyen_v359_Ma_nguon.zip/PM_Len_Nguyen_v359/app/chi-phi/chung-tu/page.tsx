'use client';
import {useEffect,useState} from 'react';
import {documentKey,expenseSaveKey,readSavedBatch,type SavedBatch} from '../../../lib/expense-save-result';
type DocumentRow={kind:string;number:string;account?:string;file:string;ref:string;date:string;type:string;amount:number|null};
export default function Documents(){
 const [rows,setRows]=useState<DocumentRow[]>([]),[loading,setLoading]=useState(true),[error,setError]=useState(''),[query,search]=useState('');
 const [batch,setBatch]=useState<SavedBatch|null>(null),[recentOnly,setRecentOnly]=useState(false);
 async function load(){setLoading(true);setError('');try{
   const response=await fetch('/api/finance?ads-import=1',{cache:'no-store'});
   const data=await response.json() as any;
   if(!response.ok||!Array.isArray(data))throw Error(data.error||'Chưa đọc được hồ sơ');
   setRows(data.flatMap(group=>[group.evidence,group.invoice,...group.transactions].filter(Boolean)));
 }catch(e){setError((e as Error).message);}finally{setLoading(false);}}
 useEffect(()=>{if(new URLSearchParams(window.location.search).has('saved')){try{const saved=readSavedBatch(sessionStorage.getItem(expenseSaveKey));setBatch(saved);setRecentOnly(!!saved?.keys.length);}catch{}}void load();},[]);
 const keys=new Set(batch?.keys||[]),recent=rows.filter(row=>keys.has(documentKey(row)));
 const visible=(recentOnly?recent:rows).filter(row=>(row.ref+' '+row.type).toLowerCase().includes(query.toLowerCase()));
 return <main className="panel"><a className="btn primary" href={batch?"/chi-phi?saved=1":"/chi-phi"}>Đóng và về bảng chi phí</a><h1>Chứng từ đã lưu</h1>
 {batch&&<section role="status" aria-live="polite" style={{background:'#eaf3ef',border:'1px solid #287958',padding:'1rem',borderRadius:12,margin:'1rem 0'}}><h2>{batch.counts.failed?'Đã lưu một phần chứng từ':'Đã lưu chứng từ thành công'}</h2><p>Lưu mới {batch.counts.added} · Đã có trong PM {batch.counts.duplicate} · Lỗi {batch.counts.failed}</p>{!loading&&!error&&<p>Đã đọc lại từ hệ thống: {recent.length} dòng thuộc lần lưu vừa rồi.</p>}</section>}
 <p>Hóa đơn và giao dịch được lưu để đối chiếu. Chi phí quảng cáo được ghi nhận theo chi tiêu thực chạy.</p>
 <div style={{display:'flex',gap:12,flexWrap:'wrap',alignItems:'center',margin:'1rem 0'}}><label>Tìm theo mã hoặc loại chứng từ <input type="search" value={query} onChange={e=>search(e.target.value)}/></label>{!!batch?.keys.length&&<label><input type="checkbox" checked={recentOnly} onChange={e=>setRecentOnly(e.target.checked)}/>Chỉ xem lần lưu vừa rồi</label>}<button type="button" disabled={loading} onClick={()=>void load()}>Tải lại danh sách</button></div>
 {loading?<p role="status">Đang tải hồ sơ…</p>:error?<p role="alert">{error}</p>:<><p>{visible.length} dòng chứng từ{recentOnly?' trong lần lưu vừa rồi':' đã lưu'}</p>{!visible.length&&<p>Không có chứng từ phù hợp. Bỏ bộ lọc hoặc tải lại danh sách để kiểm tra.</p>}<div className="table-scroll"><table className="finance-table"><thead><tr><th>Mã chứng từ</th><th>Ngày</th><th>Loại</th><th>Số tiền (đ)</th><th>Bản gốc</th></tr></thead><tbody>{visible.map((row,i)=><tr key={documentKey(row)+':'+i}><td><strong>{row.ref||row.type}</strong></td><td>{row.date}</td><td>{row.type}</td><td>{row.amount?.toLocaleString('vi-VN')??'Chưa rõ số tiền'}</td><td><a href={'/api/finance?ads-original='+row.file}>Tải bản gốc</a></td></tr>)}</tbody></table></div></>}<footer style={{position:"sticky",bottom:0,background:"white",padding:8}}><a className="btn primary" href={batch?"/chi-phi?saved=1":"/chi-phi"}>Đóng và về bảng chi phí</a></footer></main>
}
