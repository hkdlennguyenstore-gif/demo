'use client';
import {useState} from 'react';
export function Crosscheck({refresh}:{refresh:()=>void}){
 const [sources,setSources]=useState<{number:string;issued:string;day:string;total:number;fee:number}[]>([]);
 async function loadSources(){
  const res=await fetch('/api/gmail-evidence?flagSources=1');
  if(res.ok)setSources(await res.json());
 }
 const [input,setInput]=useState(''),[busy,setBusy]=useState(false),[status,setStatus]=useState('');
 async function send(action:string,body?:string,after=''){
  const res=await fetch('/api/gmail-evidence?crosscheck='+action+'&after='+encodeURIComponent(after),{method:'POST',body});
  const data=await res.json() as {page:number;total:number;done:boolean;count:number;cursor:string;posted:number;error?:string};
  if(!res.ok)throw Error(data.error||'Chưa hoàn thành đối chiếu');
  return data;
 }
 async function work(action:string){
  setBusy(true);setStatus('Đang xử lý…');
  try{
   if(action==='pos'){
    let result;
    do{
     result=await send('pos');setStatus('Đã rà trang '+(result.page-1)+' / '+result.total+' từ POS.');
    }while(!result.done);
    let checked,after='';
    do{checked=await send('check',undefined,after);after=checked.cursor;}while(!checked.done);
    setStatus('Đã rà đủ '+result.total+' trang POS và đối chiếu '+checked.count+' bảng kê J&T.');
   }else if(action==='ship'||action==='settle'){
    let after='',r;do{r=await send(action,undefined,after);after=r.cursor;setStatus('Đã rà và ghi cước đủ căn cứ '+r.count+'/'+r.total+' bảng kê.');}while(!r.done);
   }else if(action==='classify'){
    const r=await send(action);setStatus('Đã phân loại '+r.count+' hóa đơn, ghi mới '+r.posted+' khoản chi.');
   }else{
    const r=await send(action,input);
    setStatus('Đã lưu '+r.count+' hồ sơ đối chiếu.');setInput('');
   }
   if(action==='flag-source')await loadSources();
   refresh();
  }catch(e){setStatus(e instanceof Error?e.message:'Chưa hoàn thành đối chiếu');}
  finally{setBusy(false);}
 }
 return <details className="gm-card" onToggle={e=>{if(e.currentTarget.open)void loadSources();}}><summary>Đối chiếu chi tiết vận đơn và hóa đơn</summary>
  <label>Dữ liệu đối chiếu từ chứng từ gốc<textarea aria-label="Dữ liệu đối chiếu từ chứng từ gốc" rows={3} value={input} onChange={e=>setInput(e.target.value)}/></label>
  <div className="gm-links"><button disabled={busy||!input} onClick={()=>work('jt')}>Lưu dòng vận đơn J&T</button>
  <button disabled={busy||!input} onClick={()=>work('flag-source')}>Lưu PDF gốc từ bảng phí Flagteam</button>
  <button disabled={busy||!input} onClick={()=>work('flagpdf')}>Liên kết PDF phí Flagteam</button>
  <button disabled={busy||!input} onClick={()=>work('monthly')}>Liên kết hóa đơn tháng J&amp;T</button>
  <button disabled={busy||!input} onClick={()=>work('returns')}>Lưu đối chiếu cước đơn chuyển hoàn</button>
  <button disabled={busy||!input} onClick={()=>work('freight')}>Lưu đối chiếu doanh thu và cước POS</button>
  <button disabled={busy||!input} onClick={()=>work('invoice')}>Lưu dòng hóa đơn Fintab / MISA</button>
  <button disabled={busy} onClick={()=>work('ship')}>Ghi cước giao và hoàn đã khớp từng vận đơn</button>
  <button disabled={busy} onClick={()=>work('settle')}>Ghi cước thực trừ theo bảng kê J&T</button>
  <button disabled={busy} onClick={()=>work('classify')}>Phân loại hóa đơn và ghi khoản đủ căn cứ</button>
  <button disabled={busy} onClick={()=>work('pos')}>Đối chiếu phí với POS</button></div><p role="status">{status}</p>
  {sources.length>0&&<><h3>Hóa đơn từ bảng phí Flagteam</h3><table><thead><tr><th>PDF gốc</th><th>Ngày hóa đơn</th><th>Ngày phí</th><th>Hóa đơn</th><th>Phí đại lý</th><th>Chênh lệch</th></tr></thead><tbody>{sources.map(r=><tr key={r.number}><td><a href={'/api/gmail-evidence?flagSourcePdf='+encodeURIComponent(r.number)}>{r.number}</a></td><td>{r.issued}</td><td>{r.day}</td>{[r.total,r.fee,r.total-r.fee].map((n,i)=><td key={i}>{n.toLocaleString('vi-VN')}đ</td>)}</tr>)}</tbody></table></>}
 </details>;
}
