'use client';

import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import {expenseGroups} from '../../../lib/finance';
import './gmail.css';
import {Crosscheck} from './crosscheck';

const labels = {
  pending: 'Chờ phân loại',
  posted: 'Đã ghi nhận',
  linked: 'Đã liên kết khoản có sẵn',
  evidence: 'Chỉ đối chứng',
  error: 'Lỗi xử lý',
};
type State = keyof typeof labels;
type Filters = { month: string; source: string; state: string; query: string };
type Entry = {
  id: string; mailId: string; received: string; subject: string; source: string;
  document: string; reference: string; date: string; month: string; category: string;
  channel: string; currency: string; amount: number | null; state: State; reason: string;
  targetType: string; targetId: string; hasLinkFile?: number; invoiceLines?:string; jtCheck?:string; facts?:string;
};
type Summary = {
  month: string; source: string; currency: string; documents: number;
  waybillExpense?:number; amount: number | null; knownAmounts: number; posted: number; postedAmount: number | null;
  linked: number; duplicates?:number; pending: number; evidence: number; errors: number;
};
type Activity = { lane: string; success: string | null; detail: string; error: string | null };
type Handoff = {month:string;scanned:number;candidates:number;verified:number};
type Clock = {finished:string;lane:string;reviewed:number;saved:number;newCount:number;postHandoff:number};
type Data = { supplierApproval?:{approvedAt:string;rules:string;report:string}; firstNew?:{finished:string;postHandoff:number}; clock?:Clock[]; handoff?:Handoff[]; rows: Entry[]; total: number; monthly: Summary[]; activity: Activity[] };
const empty: Filters = { month: '', source: '', state: '', query: '' };
const zone = {timeZone: 'Asia/Ho_Chi_Minh'};
function money(value: number | null, currency: string) {
  if (value == null || !Number.isFinite(value)) return 'Chưa xác định';
  return value.toLocaleString('vi-VN') + ' ' + (currency || '(chưa rõ loại tiền)');
}
function period(month: string) {
  if (!month) return 'Chưa rõ kỳ';
  const [year, number] = month.split('-');
  return number && year ? number + '/' + year : month;
}

function Facts({value}: {value?:string}) {
  if (!value) return null;
  const data=JSON.parse(value);
  const reading=data.reading || {}, invoice=data.invoice || {};
  const lines=[
    ['Số chứng từ',invoice.number],['Ngày chứng từ',invoice.date],['Bên mua',invoice.buyerName],
    ['Kỳ đối soát',reading.fromDate && reading.toDate ? reading.fromDate+' – '+reading.toDate : null],
    ['Số vận đơn',reading.rows],['Tiền COD',reading.cod],['Phí vận chuyển',reading.shipping],
    ['Phí thu hộ',reading.collection],['Phí chuyển hoàn',reading.returns],['Phí giao một phần',reading.partial],
    ['Tiền thực chuyển',reading.remitted],['Tiền trước thuế',reading.net],['Thuế trên chứng từ',reading.tax],
  ].filter(([,v])=>v!==undefined&&v!==null&&v!=='');
  return lines.length ? <details><summary>Thông tin từ chứng từ gốc</summary>
    <dl>{lines.map(([label,v])=><div key={label}><dt>{label}</dt><dd>{typeof v==='number'?v.toLocaleString('vi-VN'):String(v)}</dd></div>)}</dl></details> : null;
}

function OriginalMail({id}: {id: string}) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function download() {
    if (busy) return;
    setBusy(true);
    try {
      const res = await fetch('/api/gmail-evidence?id=' + encodeURIComponent(id), {cache:'no-store'});
      if (!res.ok) throw new Error('Chưa tải được thư gốc. Vui lòng kiểm tra phiên chủ shop.');
      const bytes = await res.arrayBuffer();
      const digest = await crypto.subtle.digest('SHA-256', bytes);
      const hash = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2,'0')).join('');
      if (bytes.byteLength !== Number(res.headers.get('X-Original-Size')) || hash !== res.headers.get('X-Original-SHA256')) {
        throw new Error('Bản tải về chưa khớp bản gốc trong PM. Vui lòng thử lại.');
      }
      const url = URL.createObjectURL(new Blob([bytes], {type:'message/rfc822'}));
      const link = document.createElement('a');
      link.download = 'gmail-' + id + '.eml';
      link.href = url;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      setMessage('Đã đọc lại ' + bytes.byteLength.toLocaleString('vi-VN') + ' byte, SHA-256 khớp bản gốc. Đã gửi tệp cho trình duyệt tải xuống.');
    } catch (e) {
      setMessage(e instanceof Error ? e.message : 'Tải thư gốc thất bại');
    } finally { setBusy(false); }
  }
  return <><button type="button" disabled={busy} onClick={download}>{busy?'Đang kiểm tra…':'Tải thư gốc (.eml)'}</button>
    {message && <small role="status">{message}</small>}</>;
}

export default function GmailEvidence() {
  const [bills,setBills]=useState('');
  const [billStatus,setBillStatus]=useState('');
  const [importing,setImporting]=useState(false);
  const [draft, setDraft] = useState<Filters>(empty);
  const [filters, setFilters] = useState<Filters>(empty);
  const [page, setPage] = useState(0);
  const [groupBy,setGroupBy]=useState('source');
  const [refresh, setRefresh] = useState(0);
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams({ items:'1', groupBy, offset:String(page*50) });
    for (const [key, value] of Object.entries(filters)) if (value.trim()) params.set(key, value.trim());
    setData(null);
    setError('');
    fetch('/api/gmail-evidence?' + params, {signal: controller.signal, cache:'no-store'})
      .then(async res => {
        if (!res.ok) throw new Error(res.status === 403 ? 'Vui lòng đăng nhập bằng tài khoản chủ shop để xem chứng từ.' : 'Chưa tải được chứng từ từ PM.');
        const result: Data = await res.json();
        if (!Array.isArray(result.monthly) || !Array.isArray(result.rows)) throw new Error('PM chưa trả về kết quả phân loại.');
        if (!controller.signal.aborted) setData(result);
      })
      .catch(e => { if (!controller.signal.aborted) setError(e.message); });
    return () => controller.abort();
  }, [page, filters, refresh, groupBy]);

  function apply(event: FormEvent) {
    event.preventDefault();
    setPage(0);
    setFilters({...draft});
  }
  function reset() {
    setDraft(empty); setFilters(empty); setPage(0);
  }
  return <main className="gmail-page">
    <a href="/chi-phi">Quay lại Chi phí</a>
    <div className="gm-bar"><h1>Chứng từ Gmail</h1><button onClick={() => setRefresh(v => v + 1)}>Tải lại trạng thái</button></div>
    <p className="gm-meta">owner@example.invalid</p>
    <Crosscheck refresh={()=>setRefresh(n=>n+1)}/>
    <details className="gm-card"><summary>Đối chiếu hóa đơn đầu vào Fintab</summary>
      <label>Dán bốn cột từ bảng hóa đơn: ngày (dd/mm/yyyy), số hóa đơn, nhà cung cấp và tổng tiền VND
        <textarea aria-label="Bảng hóa đơn Fintab" rows={4} value={bills} onChange={e=>setBills(e.target.value)}/></label>
      <button disabled={importing||!bills.trim()} onClick={async()=>{
        setImporting(true);setBillStatus('');
        try{const res=await fetch('/api/gmail-evidence?fintab=1',{method:'POST',body:bills});
         const result=await res.json() as {matched:number;error?:string};if(!res.ok)throw Error(result.error||'Chưa lưu được bảng đối chiếu');
         setBillStatus('Đã đối chiếu '+result.matched+' mục Gmail với hóa đơn Fintab.');setBills('');setRefresh(v=>v+1);
        }catch(e){setBillStatus(e instanceof Error?e.message:'Chưa lưu được bảng đối chiếu');}finally{setImporting(false);}
      }}>Đối chiếu với Gmail</button><p role="status">{billStatus}</p>
    </details>
    <form className="gm-form gm-card" onSubmit={apply}>
      <label>Kỳ phát sinh<input type="month" value={draft.month} onChange={e => setDraft({...draft, month:e.target.value})}/></label>
      <label>Nguồn chứng từ<input placeholder="Tên nhà cung cấp" value={draft.source} onChange={e => setDraft({...draft, source:e.target.value})}/></label>
      <label>Trạng thái<select value={draft.state} onChange={e => setDraft({...draft, state:e.target.value})}>
        <option value="">Tất cả</option>{Object.entries(labels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
      <label>Tìm chứng từ<input type="search" placeholder="Mã hoặc nội dung" value={draft.query} onChange={e => setDraft({...draft, query:e.target.value})}/></label>
      <button className="gm-primary" type="submit">Tra cứu</button>
      {Object.values({...draft}).some(Boolean) || Object.values(filters).some(Boolean) ? <button type="button" onClick={reset}>Xóa bộ lọc</button> : null}
    </form>
    {error && <p role="alert">{error}</p>}
    {!data && !error && <p role="status">Đang tải chứng từ…</p>}
    {data && <>
      {data.supplierApproval && <section className="gm-card"><h2>Nhà cung cấp đã duyệt đầu chi</h2>
        <p>Chủ shop duyệt ngày {new Date(data.supplierApproval.approvedAt).toLocaleDateString('vi-VN',zone)}. Quy tắc áp dụng cho chứng từ đã có và các lượt Gmail tiếp theo.</p>
        <details><summary>Xem 11 tên nhà cung cấp và đầu chi</summary><div className="gm-table"><table><thead><tr><th>Nhà cung cấp</th><th>Đầu chi</th><th>Căn cứ còn cần đối chiếu</th></tr></thead><tbody>
          {(JSON.parse(data.supplierApproval.rules) as {id:string;names:string[];label:string;note:string}[]).flatMap(r=>r.names.map(name=><tr key={name}><td>{name}</td><td>{r.label}</td><td>{r.note}</td></tr>))}
        </tbody></table></div></details>
      </section>}
      <section className="gm-card"><div className="gm-bar"><h2>Tổng hợp theo tháng phát sinh</h2><label>Nhóm theo <select value={groupBy} onChange={e=>setGroupBy(e.target.value)}><option value="source">Nhà cung cấp</option><option value="category">Đầu chi</option></select></label></div>
        {data.monthly.length ? <div className="gm-table" tabIndex={0} aria-label="Báo cáo chứng từ theo tháng và nguồn"><table>
          <thead><tr>{['Kỳ phát sinh',groupBy==='category'?'Đầu chi':'Nguồn','Mục đã lưu','Tổng tiền đã xác định','Đã ghi nhận','Chi phí đã ghi nhận','Cước đã ghi từng vận đơn','Đã liên kết khoản có sẵn','Mục trùng','Chờ phân loại','Chỉ đối chứng','Lỗi'].map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
          <tbody>{data.monthly.map(r => <tr key={JSON.stringify([r.month,r.source,r.currency])}>
            <td>{period(r.month)}</td><td>{groupBy==='category'?(expenseGroups[r.source]||'Chưa xác định đầu chi'):(r.source || 'Chưa rõ nguồn')}</td><td>{r.documents}</td>
            <td>{r.knownAmounts ? money(r.amount,r.currency) : 'Chưa xác định'}{r.knownAmounts > 0 && <small> · {r.knownAmounts} khoản sau loại trùng</small>}</td>
            <td>{r.posted}</td><td>{r.posted ? money(r.postedAmount,r.currency) : '—'}</td>
            <td>{r.waybillExpense?money(r.waybillExpense,'VND'):'—'}</td><td>{r.linked}</td><td>{r.duplicates||0}</td><td>{r.pending}</td><td>{r.evidence}</td><td>{r.errors}</td>
          </tr>)}</tbody></table></div> : <p>Chưa có chứng từ khớp bộ lọc.</p>}
      </section>
      <section className="gm-card"><h2>Danh sách chứng từ · {data.total.toLocaleString('vi-VN')}</h2>
        {data.rows.map(r => <article key={r.id} className="gm-result">
          <div className="gm-bar"><strong>{r.document || r.subject || 'Chứng từ Gmail'}</strong><span className="gm-status">{labels[r.state] || 'Chưa xác định trạng thái'}</span></div>
          <p>{r.source || 'Chưa rõ nguồn'} · {period(r.month)} · {money(r.amount,r.currency)}</p>
          <p className="gm-meta">{[r.reference, r.date, r.category, r.channel].filter(Boolean).join(' · ')}</p>
          {r.reason && <p className={['pending','error'].includes(r.state)?'gm-problem':''}>{r.reason}</p>}
          {r.invoiceLines && <details><summary>Dòng hàng từ hóa đơn đầu vào Fintab</summary><p>{JSON.parse(r.invoiceLines).lines.join(' · ')}</p></details>}
          {r.jtCheck && (()=>{const c=JSON.parse(r.jtCheck!);return <p>Đối chiếu J&T với POS · {c.matched}/{c.rows} vận đơn khớp duy nhất · {c.positiveShipping??0} đơn POS có phí giao hàng lớn hơn 0 · đã ghi {c.booked??0} vận đơn ({(c.bookedAmount??0).toLocaleString('vi-VN')}đ) · {c.bothSettled} đơn khớp cả COD và cước quyết toán.</p>})()}
          <Facts value={r.facts}/>
          {r.targetId && <p>Khoản liên quan · {r.targetType} · {r.targetId}</p>}
          {r.subject && r.document && <p className="gm-meta">{r.subject}</p>}
          {r.received && <small>Thư nhận ngày {new Date(r.received).toLocaleDateString('vi-VN',zone)}</small>}
          <div className="gm-links">{Boolean(r.hasLinkFile) && <a href={'/api/gmail-evidence?linkFile='+encodeURIComponent(r.id)}>Tải chứng từ từ liên kết</a>}<OriginalMail id={r.mailId}/>
            <a href={'https://mail.google.com/mail/u/?authuser=hkdlennguyenstore%40gmail.com#all/'+encodeURIComponent(r.mailId)} target="_blank" rel="noreferrer">Mở trong Gmail</a></div>
        </article>)}
        {!data.rows.length && <p>Chưa có chứng từ trong danh sách này.</p>}
        {(page > 0 || (page+1)*50 < data.total) && <nav className="gm-links" aria-label="Phân trang">
          <button disabled={!page} onClick={() => setPage(v => v-1)}>Trang trước</button><span>Trang {page+1} / {Math.ceil(data.total/50)}</span>
          <button disabled={(page+1)*50>=data.total} onClick={() => setPage(v => v+1)}>Trang sau</button>
        </nav>}
      </section>
      <section className="gm-card"><h2>Bàn giao dữ liệu đến hết 19/11/2026</h2>
        {data.handoff?.length ? <div className="gm-table"><table><thead><tr><th>Tháng nhận thư</th><th>Thư đã rà</th><th>Thư cần lưu</th><th>Bản gốc khớp PM</th></tr></thead>
          <tbody>{data.handoff.map(h=><tr key={h.month}><td>{period(h.month)}</td><td>{h.scanned}</td><td>{h.candidates}</td><td>{h.verified}</td></tr>)}</tbody></table></div> :
          <p>Đang đối chiếu bản gốc theo tháng.</p>}
      </section>
      <section className="gm-card"><h2>Trạng thái đồng bộ</h2>
        <p>{data.firstNew?'Lượt theo lịch đầu tiên lưu được thư mới sau bàn giao: '+new Date(data.firstNew.finished).toLocaleString('vi-VN',zone):'Đang chờ lượt theo lịch lưu thư chứng từ mới sau bàn giao.'}</p>
        {(data.clock||[]).map(c=><p key={c.finished+c.lane}>Lượt theo lịch · {new Date(c.finished).toLocaleString('vi-VN',zone)} · Đã rà {c.reviewed} thư · PM xác nhận {c.saved} · Lưu mới {c.newCount} · Thư mới sau bàn giao {c.postHandoff}</p>)}
        {!data.activity.length && <p>Chưa có lượt đồng bộ được xác nhận.</p>}
        {data.activity.map(a => <div className="gm-result" key={a.lane}><strong>{a.lane==='recent'?'Thư mới':'Quét lịch sử'}</strong>
          <p>{a.success?'Thành công gần nhất · '+new Date(a.success).toLocaleString('vi-VN',zone):'Chưa có lượt thành công'}</p>
          <small>{a.detail}</small>{a.error && <p className="gm-problem">{a.error}</p>}
        </div>)}
      </section>
    </>}
  </main>;
}
