import Orders from './orders';
import {redirect} from 'next/navigation';
export default async function Page({searchParams}:{searchParams:Promise<{view?:string}>}){
 if((await searchParams).view==='schedule')redirect('/?view=clock&attendance=schedule');
 return <Orders/>;
}
