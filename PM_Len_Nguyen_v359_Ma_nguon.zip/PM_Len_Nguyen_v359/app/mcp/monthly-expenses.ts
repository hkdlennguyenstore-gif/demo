import {GET as overview} from '../api/overview/route';
import {POST as saveReview} from '../api/shop-profit/route';
import {readDateRange} from '../../lib/date-range';

const channels=['facebook','tiktok1','tiktok2','shopee'];
const amounts=['revenue','cogs','platform','tax','ads','other'];
const month={type:'string',pattern:'^20[0-9]{2}-(0[1-9]|1[0-2])$'};
export const monthlyTools=[
 {name:'get_monthly_expense_review',description:'Đọc nguồn, phiên bản và số đã đối soát từng shop cho tháng vừa kết thúc. Số nguồn có thể thiếu hoặc tạm tính.',inputSchema:{type:'object',required:['month'],properties:{month},additionalProperties:false}},
 {name:'save_monthly_expense_review',description:'Chỉ chủ shop. Ghi số thực tế đã kiểm đủ chứng từ cho một shop trong tháng vừa kết thúc từ ngày 03. Truyền phiên bản vừa đọc, đủ mọi khoản và căn cứ; không dùng số tạm tính hay thay số thiếu bằng 0.',inputSchema:{type:'object',required:['month','channel','version','reference',...amounts],properties:{month,channel:{type:'string',enum:channels},version:{type:'integer',minimum:0},reference:{type:'string'},...Object.fromEntries(amounts.map(k=>[k,{type:'integer'}]))},additionalProperties:false}}
];
export async function monthlyExpenseTool(name:string,args:Record<string,unknown>,url:string){
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 const prior=new Date(today.slice(0,7)+'-01T12:00:00Z');prior.setUTCMonth(prior.getUTCMonth()-1);
 if(args.month!==prior.toISOString().slice(0,7))throw Error('Chọn trọn tháng vừa kết thúc');
 const range=readDateRange(new URLSearchParams({month:String(args.month)}));
 if(name==='get_monthly_expense_review'){
   const target=new URL('/api/overview',url);target.search=new URLSearchParams(range).toString();
   const response=await overview(new Request(target));const body:any=await response.json();
   if(!response.ok||!body.canReviewProfit)throw Error(body.error||'Chỉ chủ shop được đối soát');
   return {range,costs:body.costs,reviews:body.reviews,orders:body.orderSources?.rows,payroll:{earned:body.payroll?.earned,employerInsurance:body.payroll?.employerInsurance,unlockedMonths:body.payroll?.unlockedMonths}};
 }
 if(today.slice(-2)<'03')throw Error('Chưa đến ngày 03 để ghi đối soát');
 const target=new URL('/api/shop-profit',url);
 const payload={...range,channel:args.channel,version:args.version,reference:args.reference,...Object.fromEntries(amounts.map(k=>[k,args[k]]))};
 const response=await saveReview(new Request(target,{method:'POST',headers:{origin:target.origin,'Content-Type':'application/json'},body:JSON.stringify(payload)}));
 const result:any=await response.json();if(!response.ok)throw Error(result.error);return result;
}
