import {posGet} from '../../../lib/orders-store';
import {marketplaceAccounts,recentOrderStart} from '../../../lib/marketplace-orders';
import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {permission,type State} from '../../../lib/payroll';

export async function POST(req:Request){
 if(req.headers.get('origin')!==new URL(req.url).origin)return Response.json({error:'Nguồn yêu cầu không hợp lệ'},{status:403});
 const user=await getChatGPTUser();
 if(!user)return Response.json({error:'Cần đăng nhập'},{status:401});
 const db=env.DB!;
 const state=await db.prepare("SELECT value FROM app_state WHERE id='main'").first<{value:string}>();
 const role=state&&permission(JSON.parse(state.value) as State,user.email)?.role;
 if(role!=='owner'&&role!=='admin')return Response.json({error:'Cần quyền chủ shop hoặc quản trị'},{status:403});
 const body=await req.json().catch(()=>null) as {facebook?:number;marketplace?:number}|null;
 const valid=(value:unknown)=>typeof value==='number'&&Number.isSafeInteger(value)&&value>=0&&value<=1000000;
 if(!body||!valid(body.facebook)||!valid(body.marketplace))return Response.json({error:'Nhập hai số nguyên từ 0 đến 1.000.000'},{status:400});
 const snapshot={facebook:body.facebook,marketplace:body.marketplace,observedAt:new Date().toISOString()};
 await db.prepare("INSERT INTO app_state(id,value,version) VALUES('packing-pos-snapshot',?,0) ON CONFLICT(id) DO UPDATE SET value=excluded.value,version=app_state.version+1").bind(JSON.stringify(snapshot)).run();
 return Response.json(snapshot);
}


export async function GET(){
 const respond=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
 const user=await getChatGPTUser();
 if(!user)return respond({error:'Cần đăng nhập'},401);
 const state=await env.DB!.prepare("SELECT value FROM app_state WHERE id='main'").first<{value:string}>();
 const role=state&&permission(JSON.parse(state.value) as State,user.email)?.role;
 if(role!=='owner'&&role!=='admin')return respond({error:'Cần quyền chủ shop hoặc quản trị'},403);
 if(!env.PANCAKE_API_KEY||!env.PANCAKE_SHOP_ID)return respond({error:'Chưa có kết nối POS'},503);
 try{
  return respond(await readLivePacking(env.PANCAKE_API_KEY,env.PANCAKE_SHOP_ID));
 }catch{return respond({error:'Chưa lấy được tổng trực tiếp từ POS'},502);}
}

type PackingTotal = {facebook:number;marketplace:number;observedAt:string};
let lastLive: PackingTotal|undefined;
let pendingRead: Promise<PackingTotal>|undefined;

function readLivePacking(key:string,shop:string){
 if(lastLive&&Date.now()-Date.parse(lastLive.observedAt)<3000)return Promise.resolve(lastLive);
 if(pendingRead)return pendingRead;
 pendingRead=(async()=>{
  const [facebook,marketplace]=await Promise.all([
   readOrderCount(key,shop,{
    'order_sources[]':JSON.stringify([['-3'],['-9']]),
    is_filter_exclude_source:'true','filter_status[]':['0'],updateStatus:'inserted_at',
    startDateTime:String(Date.parse(recentOrderStart()+'T00:00:00+07:00')/1000),
    endDateTime:String(Math.ceil(Date.now()/1000))
   },row=>Number(row.status)===0&&Number(row.total_quantity)>0&&!['-3','-9'].includes(String(row.marketplace_id))),
   readOrderCount(key,shop,{
    'order_sources[]':JSON.stringify(marketplaceAccounts.map(account=>[account.source,account.account])),
    'filter_status[]':['1','8','9','12'],printing_count:'notPrinted'
   },row=>{
    const tracking=row.partner?.extend_code||row.partner?.order_number_vtp||'';
    const tags=Array.isArray(row.tags)?row.tags:[];
    return !String(tracking).trim()&&![6,7].includes(Number(row.status))&&
     !tags.some((tag:unknown)=>{
      const value=tag&&typeof tag==='object'?('name' in tag?tag.name:'label' in tag?tag.label:'') : tag;
      return String(value??'').normalize('NFC').trim().toUpperCase()==='TMĐT CŨ - CẦN KIỂM TRA';
     });
   })
  ]);
  const snapshot={facebook,marketplace,observedAt:new Date().toISOString()};
  await env.DB!.prepare("INSERT INTO app_state(id,value,version) VALUES('packing-pos-snapshot',?,0) ON CONFLICT(id) DO UPDATE SET value=excluded.value,version=app_state.version+1 WHERE json_extract(app_state.value,'$.observedAt')<json_extract(excluded.value,'$.observedAt')").bind(JSON.stringify(snapshot)).run();
  lastLive=snapshot;
  return snapshot;
 })().finally(()=>{pendingRead=undefined;});
 return pendingRead;
}

async function readOrderCount(key:string,shop:string,query:Record<string,string|string[]>,matches:(row:any)=>boolean){
 const page=(number:number)=>posGet(key,shop,'orders',{...query,page_size:'100',page_number:String(number)});
 const first=await page(1);
 if(!Number.isSafeInteger(first.total_entries)||first.total_entries<0||!Number.isSafeInteger(first.total_pages)||first.total_pages<0||first.total_pages>10)throw Error('POS chưa trả phạm vi hợp lệ');
 const rest=await Promise.all(Array.from({length:Math.max(0,first.total_pages-1)},(_,i)=>page(i+2)));
 const rows=[first,...rest].flatMap(result=>result.data);
 const ids=new Set(rows.map(row=>String(row.id??'')));
 if(ids.has('')||ids.size!==rows.length||rows.length!==first.total_entries)throw Error('Danh sách đơn thay đổi khi đang đọc');
 return rows.filter(matches).length;
}
