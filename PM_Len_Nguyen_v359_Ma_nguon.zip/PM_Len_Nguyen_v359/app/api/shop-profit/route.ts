import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {permission} from '../../../lib/payroll';
import {checkedDate} from '../../../lib/date-range';

const json=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'no-store'}});
const fields=['revenue','cogs','platform','tax','ads','other'] as const;
export async function POST(req:Request){
 if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Nguồn yêu cầu không hợp lệ'},403);
 try{
 const db=env.DB!,user=await getChatGPTUser();
 if(!user)return json({error:'Cần đăng nhập'},401);
 const state=await db.prepare("SELECT value FROM app_state WHERE id='main'").first<{value:string}>();
 if(!state||permission(JSON.parse(state.value),user.email)?.role!=='owner')return json({error:'Chỉ chủ shop được ghi số đối soát'},403);
 const b:any=await req.json();
 if(b.action==='overview-tax'){
  if(!Number.isFinite(b.rate)||b.rate<0||b.rate>100||!Array.isArray(b.inclusive)||b.inclusive.some((c:unknown)=>!['tiktok1','tiktok2','shopee'].includes(String(c))))return json({error:'Kiểm tra tỷ lệ và shop'},400);
  await db.prepare("INSERT INTO app_state(id,value,version) VALUES('overview-tax',?,0) ON CONFLICT(id) DO UPDATE SET value=excluded.value,version=app_state.version+1").bind(JSON.stringify({rate:b.rate,inclusive:b.inclusive})).run();
  return json({ok:true});
 }
 if(b.action==='business-income-tax'){
  const {enabled,rate}=b;
  if(typeof enabled!=='boolean'||!Number.isFinite(rate)||rate<0||rate>100)return json({error:'Chọn phạm vi áp dụng và nhập thuế suất từ 0 đến 100%.'},400);
  await db.prepare("INSERT INTO app_state(id,value,version) VALUES('business-income-tax',?,0) ON CONFLICT(id) DO UPDATE SET value=excluded.value,version=app_state.version+1").bind(JSON.stringify({enabled,rate})).run();
  return json({ok:true});
 }
 if(b.action==='packing-rate'){
  if(!Number.isSafeInteger(b.rate)||b.rate<0||b.rate>10000000)return json({error:'Nhập số đồng hợp lệ cho một đơn'},400);
  await db.prepare("INSERT INTO app_state(id,value,version) VALUES('packing-rate',?,0) ON CONFLICT(id) DO UPDATE SET value=excluded.value,version=app_state.version+1").bind(String(b.rate)).run();
  return json({ok:true});
 }
 if(b.action==='fee-rate'){
  if(!['tiktok1','tiktok2','shopee'].includes(b.channel)||!Number.isFinite(b.rate)||b.rate<0||b.rate>100||!b.starts)return json({error:'Kiểm tra shop, ngày và tỷ lệ từ 0 đến 100%'},400);
  const starts=checkedDate(b.starts);
  await db.prepare('INSERT INTO pm_fee_rates(channel,starts,rate,actor) VALUES(?,?,?,?) ON CONFLICT(channel,starts) DO UPDATE SET rate=excluded.rate,actor=excluded.actor').bind(b.channel,starts,b.rate,user.email).run();
  return json({ok:true});
 }
 const from=checkedDate(b.from),to=checkedDate(b.to);
 if(from>to||!['facebook','tiktok1','tiktok2','shopee'].includes(b.channel)||!Number.isSafeInteger(b.version)||b.version<0)return json({error:'Kiểm tra shop và kỳ báo cáo'},400);
 if(fields.some(k=>!Number.isSafeInteger(b[k])||(k!=='revenue'&&b[k]<0)||Math.abs(b[k])>1e14)||typeof b.reference!=='string'||!b.reference.trim()||b.reference.length>500)return json({error:'Nhập đủ các khoản và căn cứ đối soát'},400);
 const record={...Object.fromEntries(fields.map(k=>[k,b[k]])),reference:b.reference.trim(),actor:user.email,time:new Date().toISOString()};
 const res=await db.prepare('INSERT OR IGNORE INTO pm_profit_reviews(channel,start_day,end_day,revision,record) SELECT ?,?,?,?,? WHERE (SELECT COALESCE(MAX(revision),0) FROM pm_profit_reviews WHERE channel=? AND start_day=? AND end_day=?)=?').bind(b.channel,from,to,b.version+1,JSON.stringify(record),b.channel,from,to,b.version).run();
 return res.meta.changes?json({ok:true}):json({error:'Số đối soát đã đổi. Tải lại báo cáo.'},409);
 }catch(e){return json({error:(e as Error).message},400);}
}
