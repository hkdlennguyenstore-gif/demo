import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {permission,type State} from '../../../lib/payroll';
export const dynamic='force-dynamic';
export async function GET(){const u=await getChatGPTUser();if(!u)return Response.json({error:'Cần đăng nhập'},{status:401});const row=await env.DB!.prepare('SELECT value FROM app_state WHERE id=?').bind('main').first<{value:string}>();const role=row?permission(JSON.parse(row.value) as State,u.email)?.role:null;return role?Response.json({role},{headers:{'Cache-Control':'no-store'}}):Response.json({error:'Chưa được cấp quyền'},{status:403});}
