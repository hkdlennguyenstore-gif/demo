const closed=()=>Response.json({error:'Shop đang dùng phân quyền theo tài khoản nội bộ.'},{status:403,headers:{'Cache-Control':'no-store'}});
export const GET=closed;
export const POST=closed;
