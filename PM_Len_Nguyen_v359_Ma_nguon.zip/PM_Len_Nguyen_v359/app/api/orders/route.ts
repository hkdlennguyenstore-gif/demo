import {attendanceAccess,unlockedSchedule,submitOwnLeave,attendanceBatch,submitKioskLeave,readKioskSchedule,readAttendanceMonth} from '../../../lib/attendance-access';
import {saveAttendanceBulk} from '../../../lib/attendance-bulk-store';
import {readBulkSchedule} from '../../../lib/attendance-bulk';
import {leaveReason,reviewAttendanceLeave,submitLeaveRange} from '../../../lib/attendance-leave-store';
import {addScheduleName,cancelScheduleDay,saveScheduleDay} from '../../../lib/attendance-day-store';
import {readCountStaffLinks,saveCountStaffLink} from '../../../lib/facebook-count-staff';
import {applyReturnBaseline} from '../../../lib/return-baseline';
import {syncMarketplaces,marketplaceStatus,syncFacebookExpected} from '../../../lib/marketplace-store';
import {marketplaceAccounts,recentOrderStart} from '../../../lib/marketplace-orders';
import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {permission,type State} from '../../../lib/payroll';
import {text,validDate} from '../../../lib/purchasing';
import {readDateRange} from '../../../lib/date-range';
import {isAttendanceMonth,isAttendanceStart} from '../../../lib/attendance-month';
import {orderRoles,validateCounts,trackingCode,vnDay} from '../../../lib/orders';
import {digest} from '../../../lib/a3-access';
import {prepareOrders,syncFacebook,syncStatus} from '../../../lib/orders-store';
import {receiveReturn,receiveReturnBatch,importExpected,migrateReturnRules,readReturnBoards} from '../../../lib/return-store';
export const dynamic='force-dynamic';
const json=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'no-store'}});
export async function ordersUser(){const u=await getChatGPTUser();if(!u)throw Error('Cần đăng nhập PM');const r=await env.DB!.prepare('SELECT value FROM app_state WHERE id=?').bind('main').first<{value:string}>();if(!r)throw Error('Chưa có dữ liệu PM');const s=JSON.parse(r.value) as State,member=permission(s,u.email);if(!member||!orderRoles.includes(member.role))throw Error('Chưa có quyền Đơn hàng');return {u,s,authValue:r.value,admin:['owner','admin'].includes(member.role),owner:member.role==='owner'};}
import {pendingPackingFilter} from '../../../lib/orders';
export async function GET(req:Request){try{const {s,admin,u,authValue}=await ordersUser(),db=env.DB!,url=new URL(req.url),tab=url.searchParams.get('tab')||'facebook';
if(tab==='attendance-month'){
 attendanceAccess(s,u.email);
 const month=url.searchParams.get('month')||'';
 if([...url.searchParams.keys()].sort().join(',')!=='month,tab'||!isAttendanceMonth(month))return json({error:'Chọn đúng một tháng lịch làm việc.'},400);
 await prepareOrders(db);
 return json(await readAttendanceMonth(db,s,u.email,month,authValue));
}
if(tab==='kiosk-schedule'){
 if(permission(s,u.email)?.role!=='terminal')return json({error:'Chỉ tài khoản chấm công dùng chung được dùng tại đây.'},403);
 if([...url.searchParams.keys()].sort().join(',')!=='employee,tab')return json({error:'Chọn đúng tên nhân viên đang làm việc.'},400);
 return json(await readKioskSchedule(db,s,u.email,url.searchParams.get('employee'),authValue));
}
await prepareOrders(db);const range=readDateRange(url.searchParams),page=Math.max(1,Math.floor(Number(url.searchParams.get('page'))||1)),q=text(url.searchParams.get('q'),100),clauses:string[]=[],args:any[]=[];if(range.from){clauses.push('date>=?');args.push(range.from);}if(range.to){clauses.push('date<=?');args.push(range.to);}const where=clauses.length?' WHERE '+clauses.join(' AND '):'',and=clauses.length?' AND '+clauses.join(' AND '):'';const pendingPacking=url.searchParams.get('pendingConfirmation')==='1';
const orderDateFilter=pendingPacking?' AND date>=?':and;
const orderDateArgs=pendingPacking?[recentOrderStart()]:args;
const employees=s.employees.filter(e=>e.active).map(e=>({id:e.id,name:e.name}));if(tab==='facebook'){const pendingFilter=pendingPacking?' AND '+pendingPackingFilter('facebook'):'',search=q?' AND (instr(number,?)>0 OR instr(tracking,?)>0 OR instr(lower(staff),lower(?))>0)':'',queryArgs=[...orderDateArgs,...(q?[q,q,q]:[])];const rows=await db.prepare("SELECT record FROM pm_orders WHERE channel='facebook'"+orderDateFilter+pendingFilter+search+' ORDER BY date DESC,id DESC LIMIT 50 OFFSET ?').bind(...queryArgs,(page-1)*50).all<{record:string}>();const total=await db.prepare("SELECT COUNT(*) AS n,COALESCE(SUM(quantity),0) AS quantity,SUM(CASE WHEN status IN (3,16) THEN 1 ELSE 0 END) AS delivered,SUM(CASE WHEN status IN (4,5,15) THEN 1 ELSE 0 END) AS return_count FROM pm_orders WHERE channel='facebook'"+orderDateFilter+pendingFilter+search).bind(...queryArgs).first();const counts=await db.prepare('SELECT id,version,record FROM pm_order_counts'+where+' ORDER BY date DESC,employee LIMIT 50 OFFSET ?').bind(...args,(page-1)*50).all<{id:string,version:number,record:string}>();const countTotal=await db.prepare('SELECT COUNT(*) AS n,COALESCE(SUM(initial),0) AS initial,COALESCE(SUM(completed),0) AS completed FROM pm_order_counts'+where).bind(...args).first();const stored=await db.prepare("SELECT COUNT(*) AS n,MIN(date) AS earliest,MAX(date) AS latest FROM pm_orders WHERE channel='facebook'").first();const sourceIssues=await db.prepare('SELECT record FROM pm_order_source_issues LIMIT 100').all<{record:string}>();const countStaff=await readCountStaffLinks(db,s.employees,range);return json({...countStaff,sourceIssues:sourceIssues.results.map(r=>JSON.parse(r.record)),rows:rows.results.map(r=>JSON.parse(r.record)),counts:counts.results.map(r=>{const original=JSON.parse(r.record),linked=countStaff.countSources.find((v:any)=>v.sourceEmployee===original.employee);return {...original,id:r.id,version:r.version,shopEmployee:linked?.employee||'',shopEmployeeName:linked?.employeeName||''};}),stats:total,countStats:countTotal,stored,sync:await syncStatus(db),connected:Boolean((env as any).PANCAKE_API_KEY),employees,admin,page});}
if(tab==='tiktok1'||tab==='tiktok2'||tab==='shopee'){
 const pendingFilter=pendingPacking?' AND '+pendingPackingFilter(tab):'';
 const search=pendingFilter+(q?' AND (instr(number,?)>0 OR instr(tracking,?)>0)':''),queryArgs=[tab,...orderDateArgs,...(q?[q,q]:[])];
 const rows=await db.prepare('SELECT record FROM pm_orders WHERE channel=?'+orderDateFilter+search+' ORDER BY date DESC,updated DESC,id DESC LIMIT 50 OFFSET ?').bind(...queryArgs,(page-1)*50).all<{record:string}>();
 const stats=await db.prepare('SELECT COUNT(*) AS n,COALESCE(SUM(quantity),0) AS quantity,SUM(CASE WHEN status IN (3,16) THEN 1 ELSE 0 END) AS delivered,SUM(CASE WHEN status IN (4,5,15) THEN 1 ELSE 0 END) AS return_count FROM pm_orders WHERE channel=?'+orderDateFilter+search).bind(...queryArgs).first();
 const sync=await marketplaceStatus(db);return json({rows:rows.results.map(r=>JSON.parse(r.record)),stats,sync,account:marketplaceAccounts.find(a=>a.channel===tab),connected:Boolean((env as any).PANCAKE_API_KEY),admin,page});
}
if(tab==='returns')return json({...await readReturnBoards(db,range,page,q,Date.now(),url.searchParams.has('detailMetric')?{group:url.searchParams.get('detailGroup')||'all',metric:url.searchParams.get('detailMetric')||'',allTime:url.searchParams.get('detailScope')==='allTime'}:undefined),employees,admin,page});
if(tab==='schedule'){const access=attendanceAccess(s,u.email);const scopedWhere=where+(access.admin?'':(where?' AND ':' WHERE ')+'employee=?'),scopedArgs=access.admin?args:[...args,access.employee!.id];const rows=await db.prepare('SELECT id,version,record FROM pm_order_schedule'+scopedWhere+' ORDER BY date DESC,employee LIMIT 50 OFFSET ?').bind(...scopedArgs,(page-1)*50).all<any>();const leaves=await db.prepare('SELECT id,status,record FROM pm_order_leave'+scopedWhere+' ORDER BY date DESC LIMIT 100').bind(...scopedArgs).all<any>();const total=await db.prepare('SELECT COUNT(*) AS n FROM pm_order_schedule'+scopedWhere).bind(...scopedArgs).first();return json({rows:rows.results.map(r=>({...JSON.parse(r.record),id:r.id,version:r.version})),leaves:leaves.results.map(r=>({...JSON.parse(r.record),id:r.id,status:r.status})),stats:total,employees:access.admin?employees:employees.filter(e=>e.id===access.employee!.id),admin,me:access.employee?{id:access.employee.id,name:access.employee.name}:null,page});}return json({rows:[],waiting:true,employees,admin,page});}catch(e){return json({error:(e as Error).message},403);}}
export async function POST(req:Request){try{if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Nguồn yêu cầu không hợp lệ'},403);const {u,s,admin,authValue}=await ordersUser(),db=env.DB!;const body:any=await req.json(),x=body.data||{},now=new Date().toISOString();
if(body.action==='schedule-bulk'){
 if(!admin)return json({error:'Chỉ Chủ shop hoặc Quản trị viên được xếp lịch hàng loạt.'},403);
 if(typeof body.requestId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(body.requestId))return json({error:'Yêu cầu xếp lịch không hợp lệ.'},400);
 const request=readBulkSchedule(body.data);await prepareOrders(db);
 return json(await saveAttendanceBulk(db,s,u.email,body.requestId,request,now,authValue));
}
if(['leave-range','kiosk-leave-range','staff-leave-range','review-leave'].includes(body.action)){
 const member=permission(s,u.email),kiosk=body.action==='kiosk-leave-range',assisted=body.action==='staff-leave-range',review=body.action==='review-leave';
 if(review||assisted?!admin:kiosk?member?.role!=='terminal':member?.role!=='employee')return json({error:'Không có quyền thực hiện yêu cầu nghỉ này.'},403);
 if(typeof body.requestId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(body.requestId)||!body.data||typeof x!=='object'||Array.isArray(x))return json({error:'Yêu cầu không hợp lệ.'},400);
 const keys=Object.keys(x).sort().join(',');
 if(review){
  if(!['approved,id','approved,id,note'].includes(keys)||typeof x.approved!=='boolean'||typeof x.id!=='string'||!x.id||x.id.length>150)return json({error:'Chọn đúng yêu cầu nghỉ và trạng thái duyệt.'},400);
  const note=leaveReason(x.note??'',false);await prepareOrders(db);
  return json(await reviewAttendanceLeave(db,s,u.email,body.requestId,{id:x.id,approved:x.approved,note},now,authValue));
 }
 if(keys!=='employee,from,reason,to'||typeof x.employee!=='string'||!x.employee||x.employee.length>100)return json({error:'Chọn đúng tên, từ ngày, đến ngày và lý do nghỉ.'},400);
 await prepareOrders(db);
 return json(await submitLeaveRange(db,s,u.email,body.requestId,{employee:x.employee,from:x.from,to:x.to,reason:x.reason},now,authValue,assisted?'admin-assisted':kiosk));
}
if(['calendar-name','schedule-day','cancel-schedule-day'].includes(body.action)){
 if(!admin)return json({error:'Chỉ Chủ shop hoặc Quản trị viên được sửa danh sách hoặc lịch làm việc.'},403);
 if(typeof body.requestId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(body.requestId)||!body.data||typeof x!=='object'||Array.isArray(x))return json({error:'Yêu cầu xếp lịch không hợp lệ.'},400);
 const keys=Object.keys(x).sort().join(',');
 if(body.action==='calendar-name'){
  if(keys!=='name')return json({error:'Chỉ cần nhập tên dùng để xếp lịch.'},400);
  await prepareOrders(db);
  return json(await addScheduleName(db,s,u.email,body.requestId,x.name,now,authValue));
 }
 if(body.action==='cancel-schedule-day'){
  if(keys!=='date,employee,id,version'||typeof x.id!=='string'||!x.id||x.id.length>150||typeof x.employee!=='string'||!x.employee||x.employee.length>100||!Number.isSafeInteger(x.version)||x.version<0)return json({error:'Chọn đúng lịch làm việc cần hủy.'},400);
  const date=validDate(x.date);await prepareOrders(db);
  return json(await cancelScheduleDay(db,s,u.email,body.requestId,{id:x.id,date,employee:x.employee,version:x.version},now,authValue));
 }
 if(!['date,employee,kind','date,employee,kind,version','date,employee,kind,start','date,employee,kind,start,version'].includes(keys)||typeof x.employee!=='string'||!x.employee||x.employee.length>100||!['work','off'].includes(x.kind)||('version' in x&&(!Number.isSafeInteger(x.version)||x.version<0)))return json({error:'Chọn ngày, nhân viên và Đi làm hoặc OFF.'},400);
 if('start' in x&&(x.kind!=='work'||!isAttendanceStart(x.start)))return json({error:'Chọn giờ bắt đầu theo định dạng 24 giờ.'},400);
 const date=validDate(x.date);
 await prepareOrders(db);
 return json(await saveScheduleDay(db,s,u.email,body.requestId,{date,employee:x.employee,kind:x.kind,start:x.start,version:x.version},now,authValue));
}
if(body.action==='kiosk-leave'){
 if(permission(s,u.email)?.role!=='terminal')return json({error:'Chỉ tài khoản chấm công dùng chung được gửi tại đây.'},403);
 if(typeof body.requestId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(body.requestId)||!body.data||typeof x!=='object'||Array.isArray(x)||Object.keys(x).sort().join(',')!=='date,employee')return json({error:'Chọn ngày và tên nhân viên hợp lệ.'},400);
 const date=validDate(x.date);await prepareOrders(db);
 return json(await submitKioskLeave(db,s,u.email,body.requestId,{date,employee:x.employee},now,authValue));
}
await prepareOrders(db);if(body.action==='sync-marketplaces'){if(!admin)throw Error('Chỉ Chủ shop/Quản trị viên được đồng bộ sàn');return json(await syncMarketplaces(db,env as any,2));}if(body.action==='sync'){const state=await syncFacebook(db,env as any,3);return json({...state,returns:await syncFacebookExpected(db)});}if(!/^[0-9a-f-]{36}$/.test(body.requestId||''))throw Error('Thiếu mã yêu cầu');if(['schedule','review-leave'].includes(body.action)&&!admin)throw Error('Chỉ Chủ shop/Quản trị viên được xếp lịch hoặc duyệt nghỉ');if(body.action==='leave')return json(await submitOwnLeave(db,s,u.email,body.requestId,{date:validDate(x.date),employee:x.employee,note:text(x.note)},now,authValue));if(await db.prepare('SELECT id FROM pm_order_actions WHERE id=?').bind(body.requestId).first())return json({ok:true,replayed:true});const actor=u.email,recordAudit=(action:string,record:any)=>db.prepare('INSERT INTO pm_order_actions VALUES(?,?,?,?,?)').bind(body.requestId,now,actor,action,JSON.stringify(record));
if(body.action==='link-count-staff'){const result=await saveCountStaffLink(db,x,s.employees,admin,actor,body.requestId,now);return json(result,result.conflict?409:200);}
if(body.action==='import-counts'){if(!admin)throw Error('Chỉ Chủ shop/Quản trị viên nhập bảng cũ');if(!Array.isArray(x.rows)||x.rows.length<1||x.rows.length>500)throw Error('Dán từ 1 đến 500 dòng');const statements:D1PreparedStatement[]=[];let valid=0,issues=0;for(const row of x.rows){const date=validDate(row.date),name=text(row.name,80);if(date<'2026-04-01'||!name)throw Error('Kiểm tra ngày từ 01/04/2026 và tên nhân viên');const employee=s.employees.find(e=>[e.name,e.alias].some(n=>n?.toLocaleLowerCase('vi')===name.toLocaleLowerCase('vi'))),employeeId=employee?.id||'legacy:'+name.toLocaleLowerCase('vi'),id=await digest('facebook-counts:'+date+':'+employeeId);let counts;try{if(row.initial===null)throw Error('Thiếu số lượng ban đầu');counts=validateCounts(row);}catch(e){issues++;statements.push(db.prepare('INSERT OR REPLACE INTO pm_order_source_issues VALUES(?,?)').bind(id,JSON.stringify({date,name,sourceRow:row.sourceRow,initial:row.initial,completed:row.completed,reason:(e as Error).message})));continue;}valid++;const value={date,employee:employeeId,name,...counts,note:'Nhập từ bảng Doanh Số Đơn Hàng',source:'Doanh Số Đơn Hàng',sourceRow:row.sourceRow,actor,updatedAt:now};statements.push(db.prepare('INSERT OR IGNORE INTO pm_order_counts VALUES(?,?,?,?,?,0,?)').bind(id,date,employeeId,counts.initial,counts.completed,JSON.stringify(value)),db.prepare('DELETE FROM pm_order_source_issues WHERE id=?').bind(id));}for(let offset=0;offset<statements.length;offset+=70)await db.batch(statements.slice(offset,offset+70));await recordAudit('Nhập số lượng Facebook từ bảng cũ',{valid,issues}).run();return json({ok:true,valid,issues});}
if(body.action==='counts'){const date=validDate(x.date);let employee:any=s.employees.find(e=>e.id===x.employee);if(!employee&&admin){const legacy=await db.prepare('SELECT record FROM pm_order_counts WHERE date=? AND employee=?').bind(date,text(x.employee,100)).first<{record:string}>();if(legacy){const v=JSON.parse(legacy.record);employee={id:v.employee,name:v.name};}}if(!employee)throw Error('Chọn nhân viên');const counts=validateCounts(x),old=await db.prepare('SELECT id,version,record FROM pm_order_counts WHERE date=? AND employee=?').bind(date,employee.id).first<any>();if(old&&old.version!==x.version)return json({error:'Số lượng đã đổi. Tải lại trước khi sửa.'},409);if(old&&!text(x.reason))throw Error('Ghi lý do chỉnh số lượng');const id=old?.id||body.requestId,value={date,employee:employee.id,name:employee.name,...counts,note:text(x.note),updatedAt:now,actor};if(old){const result=await db.batch([db.prepare('INSERT INTO pm_order_actions SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM pm_order_counts WHERE id=? AND version=?)').bind(body.requestId,now,actor,'Sửa số lượng Facebook',JSON.stringify({before:JSON.parse(old.record),after:value,reason:text(x.reason)}),id,old.version),db.prepare('UPDATE pm_order_counts SET initial=?,completed=?,version=version+1,record=? WHERE id=? AND version=?').bind(counts.initial,counts.completed,JSON.stringify(value),id,old.version)]);if(!result[1].meta.changes)return json({error:'Có người vừa sửa. Tải lại.'},409);}else await db.batch([db.prepare('INSERT INTO pm_order_counts VALUES(?,?,?,?,?,0,?)').bind(id,date,employee.id,counts.initial,counts.completed,JSON.stringify(value)),recordAudit('Nhập số lượng Facebook',value)]);return json({ok:true});}
if(body.action==='set-return-baseline'){if(!admin)throw Error('Chỉ Chủ shop/Quản trị viên chốt mốc');const result=await applyReturnBaseline(db,x.rows,actor);return json({ok:true,...result});}
if(body.action==='import-return-expected'){if(!admin)throw Error('Chỉ Chủ shop/Quản trị viên nhập đối chứng');const result=await importExpected(db,x.rows,actor),migration=await migrateReturnRules(db);await recordAudit('Nhập đối chứng và sửa nhóm bắn hoàn',{...result,...migration}).run();const report=await readReturnBoards(db,{from:'',to:''},1);return json({ok:true,...result,corrected:migration.corrected,awaitingAllTime:report.stats.awaitingAllTime});}
if(body.action==='import-returns'){if(!admin)throw Error('Chỉ Chủ shop/Quản trị viên nhập lịch sử');const summary=await receiveReturnBatch(db,x.rows,actor);await recordAudit('Nhập lịch sử bắn hoàn',summary).run();return json({ok:true,...summary});}
if(body.action==='scan'){const result=await receiveReturn(db,x,actor);await recordAudit('Nhận đơn hoàn',result).run();return json({ok:true,...result});}
if(body.action==='void-return'){if(!admin)throw Error('Chỉ Chủ shop/Quản trị viên được hủy lần bắn hoàn');const reason=text(x.reason);if(!reason)throw Error('Ghi lý do hủy');await db.batch([db.prepare('UPDATE pm_order_returns SET active=0 WHERE id=?').bind(text(x.id,100)),recordAudit('Hủy nhận hoàn',{id:x.id,reason})]);return json({ok:true});}
if(body.action==='schedule'){unlockedSchedule(s,validDate(x.date));if(!admin)throw Error('Chủ shop/Quản trị viên mới được xếp lịch');const date=validDate(x.date),employee=s.employees.find(e=>e.id===x.employee);if(!employee)throw Error('Chọn nhân viên');const kind=['work','off','leave'].includes(x.kind)?x.kind:'work',start=kind==='work'?String(x.start||''):'',end=kind==='work'?String(x.end||''):'';if(kind==='work'&&(!/^([01]\d|2[0-3]):[0-5]\d$/.test(start)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(end)||end<=start))throw Error('Nhập giờ ca hợp lệ, giờ ra sau giờ vào');const old=await db.prepare('SELECT id,version FROM pm_order_schedule WHERE date=? AND employee=?').bind(date,employee.id).first<any>();if(old&&old.version!==x.version)return json({error:'Lịch đã thay đổi. Mở lại lịch trước khi sửa.'},409);const value={date,employee:employee.id,name:employee.name,kind,start,end,note:text(x.note),actor,updatedAt:now};if(old){const r=await attendanceBatch(db,authValue,date,[db.prepare('INSERT INTO pm_order_actions SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM pm_order_schedule WHERE id=? AND version=?)').bind(body.requestId,now,actor,'Sửa lịch làm việc',JSON.stringify(value),old.id,old.version),db.prepare('UPDATE pm_order_schedule SET version=version+1,record=? WHERE id=? AND version=?').bind(JSON.stringify(value),old.id,old.version)]);if(!r[1].meta.changes)return json({error:'Lịch vừa đổi. Tải lại.'},409);}else await attendanceBatch(db,authValue,date,[db.prepare('INSERT INTO pm_order_schedule VALUES(?,?,?,0,?)').bind(body.requestId,date,employee.id,JSON.stringify(value)),recordAudit('Xếp lịch làm việc',value)]);return json({ok:true});}
throw Error('Thao tác không hợp lệ');}catch(e){return json({error:(e as Error).message},400);}}
