import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {permission,type State} from '../../../lib/payroll';
import {stockRoles} from '../../../lib/stock';
import {a4Code,a4Key} from '../../../lib/a4';
import {readA4Product} from '../../../lib/a4-source';
import {saveA4Plan,A4Conflict,numberedPlans} from '../../../lib/a4-store';
import {facebookFormulaPrice} from '../../../lib/facebook-price';
import {a4Prices,a4Size} from '../../../lib/a4-display';
import {readStockOverview} from '../../../lib/stock-overview';
export const dynamic='force-dynamic';
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
async function context(){const user=await getChatGPTUser();if(!user)throw Error('Cần đăng nhập PM');const db=env.DB!,row=await db.prepare("SELECT json_object('owner',json_extract(value,'$.owner'),'owners',json_extract(value,'$.owners'),'members',json_extract(value,'$.members')) value FROM app_state WHERE id='main'").first<{value:string}>(),member=row&&permission(JSON.parse(row.value) as State,user.email);if(!member||member.role==='terminal'||!stockRoles.includes(member.role))throw Error('Tài khoản chưa có quyền sử dụng A4');return {db,email:user.email.toLowerCase(),canManage:['owner','admin','manager'].includes(member.role),canCost:['owner','admin'].includes(member.role)};}
async function existingTables(db:D1Database){return new Set((await db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all<{name:string}>()).results.map(r=>r.name));}
export async function GET(req:Request){try{
 const c=await context(),url=new URL(req.url),mode=url.searchParams.get('mode')||'catalog';
 if(mode==='catalog'){
  const tables=await existingTables(c.db),products=new Map<string,string>(),suppliers:string[]=[];
  if(tables.has('pm_price_history')){const rows=await c.db.prepare('SELECT sku,record FROM pm_price_history'+(tables.has('pm_a3_deleted')?' p WHERE NOT EXISTS(SELECT 1 FROM pm_a3_deleted d WHERE d.id=p.id)':'')+' ORDER BY date DESC,rowid DESC').all<{sku:string,record:string}>();for(const r of rows.results){const v=JSON.parse(r.record);if(!products.has(a4Code(r.sku)))products.set(a4Code(r.sku),v.name||'');}}
  if(tables.has('pm_stock_catalog'))for(const r of (await c.db.prepare('SELECT code FROM pm_stock_catalog').all<{code:string}>()).results)if(!products.has(a4Code(r.code)))products.set(a4Code(r.code),'');
  if(tables.has('pm_purchase_suppliers'))for(const r of (await c.db.prepare('SELECT name FROM pm_purchase_suppliers ORDER BY name').all<{name:string}>()).results)suppliers.push(r.name);
  for(const r of (await c.db.prepare("SELECT DISTINCT json_extract(record,'$.supplier') name FROM pm_a4_plans").all<{name:string}>()).results)if(r.name&&!suppliers.some(n=>a4Key(n)===a4Key(r.name)))suppliers.push(r.name);
  return json({products:[...products].map(([code,name])=>({code,name})).sort((a,b)=>a.code.localeCompare(b.code)),suppliers,canManage:c.canManage,canCost:c.canCost,updatedAt:new Date().toISOString()});
 }
 if(mode==='export'){const count=await c.db.prepare("SELECT COUNT(*) n FROM pm_a4_plans WHERE status<>'archived'").first<{n:number}>();if((count?.n||0)>5000)throw Error('Danh sách quá 5.000 lô, cần xuất theo kỳ');const rows=await c.db.prepare(numberedPlans+" SELECT version,json_set(record,'$.lot',lot) AS record FROM numbered ORDER BY date DESC,seq DESC").all<{version:number,record:string}>();return json({rows:rows.results.map(r=>({...JSON.parse(r.record),version:r.version}))});}
 if(mode==='plans'){const status=url.searchParams.get('status')||'draft';if(!['draft','production','returned'].includes(status))throw Error('Danh sách không hợp lệ');const page=Math.max(1,Math.floor(Number(url.searchParams.get('page'))||1)),q=String(url.searchParams.get('q')||'').slice(0,80),where="status=? AND (instr(lower(lot),lower(?))>0 OR instr(lower(json_extract(record,'$.code')),lower(?))>0)",args=[status,q,q];const rows=await c.db.prepare(numberedPlans+" SELECT id,version,json_set(record,'$.lot',lot) AS record FROM numbered WHERE "+where+' ORDER BY date DESC,seq DESC LIMIT 50 OFFSET ?').bind(...args,(page-1)*50).all<{id:string,version:number,record:string}>(),total=await c.db.prepare(numberedPlans+' SELECT COUNT(*) n FROM numbered WHERE '+where).bind(...args).first<{n:number}>(),counts=await c.db.prepare("SELECT status,COUNT(*) n FROM pm_a4_plans WHERE status<>'archived' GROUP BY status").all<{status:string,n:number}>();return json({rows:rows.results.map(r=>({...JSON.parse(r.record),version:r.version})),total:total?.n||0,page,counts:Object.fromEntries(counts.results.map(r=>[r.status,r.n]))});}
 if(mode==='product'||mode==='stock'){
  const code=a4Code(url.searchParams.get('code'));if(!/^[A-Z0-9][A-Z0-9._+ -]{0,29}$/.test(code))throw Error('Nhập mã hàng để tra cứu');
  if(mode==='stock')return json(await readA4Product(env,code));
  const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}).format(new Date()),tables=await existingTables(c.db);
  let price:any=null,priceIssue='',pos:any=null,stockIssue='',pmRemaining:number|null=null;
  if(tables.has('pm_price_history')){const active=tables.has('pm_a3_deleted')?' AND NOT EXISTS(SELECT 1 FROM pm_a3_deleted d WHERE d.id=p.id)':'';const result=await c.db.prepare('SELECT date,record FROM pm_price_history p WHERE upper(sku)=? AND date<=?'+active+' ORDER BY date DESC,rowid DESC').bind(code,today).all<{date:string,record:string}>();const date=result.results[0]?.date,latest=result.results.filter(r=>r.date===date).map(r=>JSON.parse(r.record));if(latest.length){if(new Set(latest.map(r=>JSON.stringify([r.price,r.fbPrice,r.calculated]))).size>1)priceIssue='A3 có nhiều mức giá khác nhau cùng ngày, cần đối chiếu';else{const v=latest[0];const display=a4Prices(v);price={display:{facebook:display.facebook,listing:display.listing,readLive:display.readLive},...(c.canCost?{ownerPrices:display}:{}),name:v.name||'',date:v.date||'',fbPrice:v.fbPrice??null,formulaPrice:facebookFormulaPrice(v.fbPrice),...(c.canCost?{cost:v.price,calculated:v.calculated||[],calculatedHeaders:v.calculatedHeaders||[],calculatedPending:v.calculatedPending===true}:{}),updatedAt:v.updatedAt||null,source:'A3 · price_tt'};}}else priceIssue='Chưa có giá A3 áp dụng cho mã này';}
  try{pos=await readA4Product(env,code,url.searchParams.get('fresh')==='1');}catch(e){stockIssue=(e as Error).message;}
  let pmIssue='';try{const pm=await readStockOverview(c.db,env,{from:'',to:''},false,false,true);pmRemaining=pm.rows.find((r:any)=>r.code===code)?.remaining??null;pmIssue=pm.movementIssue||'';}catch(e){pmIssue=(e as Error).message;}
  const live=await c.db.prepare('SELECT version,record FROM pm_a4_live WHERE id=?').bind(code).first<{version:number,record:string}>();
  return json({code,price,priceIssue,pos,stockIssue,pmRemaining,pmIssue,live:{version:live?.version??0,...(live?JSON.parse(live.record):{inputs:{},salePrices:[]})}});
 }
 throw Error('Chức năng A4 không hợp lệ');
}catch(e){return json({error:(e as Error).message},403);}}
export async function POST(req:Request){try{
 if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Nguồn yêu cầu không hợp lệ'},403);
 const c=await context(),body:any=await req.json(),x=body.data||{},requestId=body.requestId;if(!/^[0-9a-f-]{36}$/.test(requestId||''))throw Error('Thiếu mã yêu cầu');
 if(['save','production','return','delete'].includes(body.action)){if(!c.canManage)throw Error('Chỉ chủ shop, quản trị hoặc quản lý được ghi kế hoạch cắt');return json(await saveA4Plan(c.db,c.email,requestId,body.action,x));}
 if(!['live-set','live-reset','live-prices'].includes(body.action))throw Error('Thao tác không hợp lệ');
 const replay=await c.db.prepare('SELECT record FROM pm_a4_requests WHERE id=? AND actor=?').bind(requestId,c.email).first<{record:string}>();if(replay)return json({...JSON.parse(replay.record).response,replayed:true});
 const code=a4Code(x.code);if(!/^[A-Z0-9][A-Z0-9._+ -]{0,29}$/.test(code))throw Error('Chọn mã hàng');
 await c.db.prepare('INSERT OR IGNORE INTO pm_a4_live(id,version,record) VALUES(?,0,?)').bind(code,JSON.stringify({inputs:{},salePrices:[]})).run();
 const old=(await c.db.prepare('SELECT version,record FROM pm_a4_live WHERE id=?').bind(code).first<{version:number,record:string}>())!;if(x.version!==old.version)throw new A4Conflict('Phiên Facebook đã cập nhật ở cửa sổ khác. Tải lại để thao tác tiếp.');
 const value=JSON.parse(old.record),now=new Date().toISOString();
 if(body.action==='live-set'){
 const source=await readA4Product(env,code,true);if(!source.complete)throw Error('Chưa đủ màu–size POS để tính số nhận');
 const variants=x.cell?source.variants.filter((v:any)=>a4Key(v.color)===a4Key(x.cell.color)&&a4Size(v.size)===a4Size(x.cell.size)):source.variants.filter((v:any)=>v.id===x.variation);
 if(!variants.length||variants.some((v:any)=>v.remain===null))throw Error('Không tìm thấy màu–size POS');
 const capacity=variants.reduce((n:number,v:any)=>n+Math.max(0,v.remain),0);if(!Number.isSafeInteger(x.quantity)||x.quantity<0||x.quantity>capacity)throw Error('Số trừ ảo phải từ 0 đến '+capacity);
 let left=x.quantity;value.inputs={...value.inputs};for(const v of variants){const q=Math.min(left,Math.max(0,v.remain));value.inputs[v.id]=q;left-=q;}
 }
 else if(body.action==='live-reset')value.inputs={};
 else{if(!Array.isArray(x.salePrices)||x.salePrices.length!==3||x.salePrices.some((p:any)=>typeof p.label!=='string'||p.label.length>24||(p.value!==null&&(!Number.isSafeInteger(p.value)||p.value<0||p.value>1e10))))throw Error('Nhập tối đa 3 mức giá sale hợp lệ');value.salePrices=x.salePrices;}
 Object.assign(value,{updatedAt:now,updatedBy:c.email});const response={ok:true,version:old.version+1};
 const result=await c.db.batch([c.db.prepare('UPDATE pm_a4_live SET version=version+1,record=? WHERE id=? AND version=?').bind(JSON.stringify(value),code,old.version),c.db.prepare('INSERT INTO pm_a4_requests(id,actor,record) SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM pm_a4_live WHERE id=? AND version=? AND record=?)').bind(requestId,c.email,JSON.stringify({time:now,action:body.action,code,response}),code,old.version+1,JSON.stringify(value))]);if(!result[0].meta.changes||!result[1].meta.changes)throw new A4Conflict('Có người vừa cập nhật phiên Facebook. Tải lại.');return json(response);
}catch(e){return json({error:(e as Error).message},e instanceof A4Conflict?409:400);}}
