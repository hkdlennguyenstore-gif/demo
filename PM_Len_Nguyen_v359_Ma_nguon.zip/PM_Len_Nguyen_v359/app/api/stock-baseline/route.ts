import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {permission,type State} from '../../../lib/payroll';
import {stockRoles,privateStockRole} from '../../../lib/stock';
import {readStockBaseline,saveStockBaseline} from '../../../lib/stock-baseline';
import {vnDay} from '../../../lib/orders';
const json=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
async function authorize(){const user=await getChatGPTUser();if(!user)throw Error('Cần đăng nhập');const r=await env.DB!.prepare("SELECT json_object('owner',json_extract(value,'$.owner'),'owners',json_extract(value,'$.owners'),'members',json_extract(value,'$.members')) AS value FROM app_state WHERE id='main'").first<{value:string}>();const member=r&&permission(JSON.parse(r.value) as State,user.email);if(!member||!stockRoles.includes(member.role))throw Error('Chưa có quyền Nhập kho');return {user,member};}
export async function GET(){try{const {member}=await authorize();return json({baseline:await readStockBaseline(env.DB!),canManage:privateStockRole(member.role)});}catch(e){return json({error:(e as Error).message},403);}}
export async function POST(req:Request){try{if(req.headers.get('origin')!==new URL(req.url).origin)throw Error('Nguồn yêu cầu không hợp lệ');const {user,member}=await authorize();if(!privateStockRole(member.role))throw Error('Chỉ Chủ shop hoặc Quản trị viên được thay mốc kiểm kê');const input:any=await req.json();if(!/^[0-9a-f-]{36}$/.test(input.requestId||''))throw Error('Thiếu mã lưu');if(input.date>vnDay())throw Error('Không dùng mốc kiểm kê trong tương lai');return json({baseline:await saveStockBaseline(env.DB!,input,input.requestId,user.email)});}catch(e){return json({error:(e as Error).message},400);}}
