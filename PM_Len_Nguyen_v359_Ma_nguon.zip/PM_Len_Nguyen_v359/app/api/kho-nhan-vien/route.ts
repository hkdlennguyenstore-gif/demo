import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {permission,type State} from '../../../lib/payroll';
import {a4Code} from '../../../lib/a4';
import {a4Prices} from '../../../lib/a4-display';
import {readA4Product} from '../../../lib/a4-source';
import {readStockOverview} from '../../../lib/stock-overview';
import {staffCatalogRows} from '../../../lib/staff-catalog';
import {staffStockRoles,staffStockView} from '../../../lib/staff-stock';
export const dynamic='force-dynamic';
const json=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(req:Request){
 const user=await getChatGPTUser();if(!user)return json({error:'Cần đăng nhập PM'},401);
 const db=env.DB!;
 const state=await db.prepare("SELECT json_object('owner',json_extract(value,'$.owner'),'owners',json_extract(value,'$.owners'),'members',json_extract(value,'$.members')) value FROM app_state WHERE id='main'").first<{value:string}>();
 const role=state&&permission(JSON.parse(state.value) as State,user.email)?.role;
 if(!role||!staffStockRoles.includes(role))return json({error:'Tài khoản chưa có quyền tra tồn POS'},403);
 const params=new URL(req.url).searchParams;
 if(params.get('mode')==='catalog'){
  try{
   const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}).format(new Date());
   const deleted=await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='pm_a3_deleted'").first();
   const active=deleted?' WHERE NOT EXISTS(SELECT 1 FROM pm_a3_deleted d WHERE d.id=p.id)':'';
   const catalog=await db.prepare("SELECT sku,date,json_extract(record,'$.name') name,json_extract(record,'$.fbPrice') fbBase,json_extract(record,'$.calculatedPending') pending,json_extract(record,'$.calculated[0]') fbCalculated FROM pm_price_history p"+active+' ORDER BY date DESC,rowid DESC').all<{sku:string;date:string;name:string|null;fbBase:number|null;pending:number|null;fbCalculated:number|null}>();
   type StockRow={code:string;remaining:number|null};
   let rows:StockRow[]|null=null,stockUpdatedAt:string|null=null,stockStale=false;
   const bucket=env.BUCKET;
   const cacheKey='pm-safe-derived-cache/employee-a3-stock-v1.json';
   let cached:{rows:StockRow[];updatedAt:string}|null=null;
   try{
    const object=await bucket?.get(cacheKey);
    if(object){const x=await object.json<{rows:StockRow[];updatedAt:string}>();if(x&&Array.isArray(x.rows)&&Number.isFinite(Date.parse(x.updatedAt)))cached=x;}
   }catch{}
   if(cached&&Date.now()-Date.parse(cached.updatedAt)<60_000&&params.get('refresh')!=='1'){
    rows=cached.rows;stockUpdatedAt=cached.updatedAt;
   }else{
    try{
     const stock=await readStockOverview(db,env,{from:'',to:''},false,false,true);
     if(!stock.movementIssue&&stock.rows.length){
      rows=stock.rows.map(({code,remaining}:StockRow)=>({code,remaining}));stockUpdatedAt=stock.updatedAt;
      try{await bucket?.put(cacheKey,JSON.stringify({rows,updatedAt:stockUpdatedAt}));}catch{}
     }
    }catch{}
    if(!rows&&cached){rows=cached.rows;stockUpdatedAt=cached.updatedAt;stockStale=true;}
   }
   return json({rows:staffCatalogRows(catalog.results,rows,today),stockUpdatedAt,stockStale});
  }catch{return json({error:'Chưa tải được danh sách mã A3. Vui lòng tải lại.'},502);}
 }
 const code=a4Code(params.get('code'));
 if(!/^[A-Z0-9][A-Z0-9._+ -]{0,29}$/.test(code))return json({error:'Nhập đúng mã hàng để tra cứu'},400);
 try{
  const pos=await readA4Product(env,code);
  if(!pos.variants.length)return json({error:'Không tìm thấy biến thể đang dùng trên POS cho mã này'},404);
  let facebook:number|null=null,name='';
  try{
   const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}).format(new Date());
   const deleted=await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='pm_a3_deleted'").first();
   const active=deleted?' AND NOT EXISTS(SELECT 1 FROM pm_a3_deleted d WHERE d.id=p.id)':'';
   const rs=await db.prepare('SELECT date,record FROM pm_price_history p WHERE upper(sku)=? AND date<=?'+active+' ORDER BY date DESC,rowid DESC').bind(code,today).all<{date:string;record:string}>();
   const latest=rs.results.filter(r=>r.date===rs.results[0]?.date).map(r=>JSON.parse(r.record));
   const choices=new Set(latest.map(r=>JSON.stringify([r.name??'',a4Prices(r).facebook])));
   if(choices.size===1){facebook=a4Prices(latest[0]).facebook;name=latest[0].name||'';}
  }catch{/* No confirmed Facebook price; do not substitute any other price. */}
  return json(staffStockView(code,name,facebook,pos));
 }catch{return json({error:'Chưa đọc được tồn kho POS. Vui lòng thử tải lại.'},502);}
}
