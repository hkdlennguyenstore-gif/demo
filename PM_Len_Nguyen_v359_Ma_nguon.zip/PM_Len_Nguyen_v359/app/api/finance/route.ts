import {warehouseOverview} from '../../../lib/warehouse-overview';
import {readReturnedStock} from '../../../lib/pos-source-report';
import {settlementImport} from '../../../lib/settlement-import';
import {settings,overridePrefix,sourcePrefix,putSetting} from '../../../lib/expense-controls';
import {collect,filterExpenses,taxBucket} from '../../../lib/expense-lines';
import {assignTikTokAccount,storeAdsFile,adsFileReport} from '../../../lib/ads-file-store';
import {refreshFacebookAds} from '../../../lib/ads-costs';
import {driveAdsStatus,writeManualAds} from '../../../lib/drive-marketplace-ads';
import {readOperatingCosts,taxResult} from '../../../lib/tax-costs';
import {readAdsCosts,validateAdsReview,syncGiaMinh,syncFlagteam} from '../../../lib/ads-costs';
import {readPayrollCosts,validatePayrollReview} from '../../../lib/payroll-costs';
import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {permission,type State} from '../../../lib/payroll';
import {readDateRange,withinRange} from '../../../lib/date-range';
import {csvValue,financeChannels,expenseGroups,taxPeriod,validateFinance,financeBalance} from '../../../lib/finance';
import {amount,validDate,text} from '../../../lib/purchasing';
import {digest} from '../../../lib/a3-access';
export const dynamic='force-dynamic';
const json=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'no-store'}});
async function authorize(){const user=await getChatGPTUser();if(!user)throw Error('Cần đăng nhập');const row=await env.DB!.prepare('SELECT value FROM app_state WHERE id=?').bind('main').first<any>(),member=row&&permission(JSON.parse(row.value) as State,user.email);if(!member||!['owner','admin'].includes(member.role))throw Error('Chỉ Chủ shop và Quản trị viên được vào Chi phí / Thuế');return {...user,role:member.role};}
async function duplicateExpense(db:D1Database,id:string){
 const row=await db.prepare("SELECT id,record,status,version FROM pm_finance_docs WHERE id=? AND kind='expense'").bind(id).first<any>();
 return json({error:'Chứng từ đã có trong PM',duplicate:row?{...JSON.parse(row.record),id,status:row.status,version:row.version}:null},409);
}
async function management(db:D1Database,role:string){
 const row=await db.prepare('SELECT value FROM app_state WHERE id=?').bind('expense-manager-rights').first<{value:string}>();
 const rights=row?JSON.parse(row.value):{};
 return {rights,canEdit:role==='owner'||rights.edit===true,canExclude:role==='owner'||rights.exclude===true,canRestore:role==='owner'||rights.restore===true};
}
export async function GET(req:Request){try{const user=await authorize();const db=env.DB!,url=new URL(req.url),kind=url.searchParams.get('kind')==='tax'?'tax':'expense';
 if(url.searchParams.get('mode')==='warehouse-overview')return json(await warehouseOverview(db,env as any,readDateRange(url.searchParams)));
 if(url.searchParams.get('mode')==='stock-returns')return json({rows:await readReturnedStock(env as any,readDateRange(url.searchParams))});
 if(url.searchParams.has('line-history')){
   const id=text(url.searchParams.get('line-history'),250);
   const result=await db.prepare("SELECT time,actor,action,record FROM pm_finance_audit WHERE json_extract(record,'$.id')=? ORDER BY rowid DESC").bind(id).all<any>();
   return json({rows:result.results.map(a=>({...JSON.parse(a.record),time:a.time,actor:a.actor,action:a.action}))});
 }
 if(url.searchParams.has('ads-import'))return json(await adsFileReport(db));
 if(url.searchParams.has('ads-original')){const hash=url.searchParams.get('ads-original');if(!/^[a-f0-9]{64}$/.test(hash||''))throw Error('Mã tệp sai');const row=await db.prepare('SELECT name FROM ads_import_files WHERE hash=?').bind(hash).first<{name:string}>();if(!row)throw Error('Thiếu tệp');const original=await env.BUCKET?.get('ads-import/'+hash);if(!original)throw Error('Thiếu bản gốc');return new Response(original.body,{headers:{'Content-Type':'application/octet-stream','Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(row.name),'Cache-Control':'private, no-store'}});}
 if(url.searchParams.has('file')){const id=url.searchParams.get('id'),row=await db.prepare(url.searchParams.has('manualAds')?"SELECT record FROM pm_drive_ads_sources WHERE id=? AND id LIKE 'manual:%'":url.searchParams.has('adsReview')?'SELECT record FROM pm_ads_reviews WHERE id=?':url.searchParams.has('review')?'SELECT record FROM pm_payroll_cost_reviews WHERE id=?':'SELECT record FROM pm_finance_docs WHERE id=?').bind(id).first<any>();if(!row)throw Error('Không tìm thấy chứng từ');const document=JSON.parse(row.record),receipt=[document.receipt,document.taxReassessment?.receipt].find(r=>r?.key===url.searchParams.get('file'));if(!receipt)throw Error('Chứng từ không thuộc phiếu');if(receipt.key.startsWith('gmail-evidence/')&&user.role!=='owner')return json({error:'Chỉ chủ shop được tải thư Gmail gốc'},403);const file=await env.BUCKET?.get(receipt.key);if(!file)return json({error:'Không tìm thấy tệp'},404);return new Response(file.body,{headers:{'Content-Type':file.httpMetadata?.contentType||'application/octet-stream','Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(receipt.name),'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"sandbox; default-src 'none'"}});}
 if(url.searchParams.get('mode')==='payroll-tax'){const period=taxPeriod(url.searchParams.get('period'));const range={from:period.date,to:period.endDate};return json({...await readPayrollCosts(db,range),adsCosts:await readAdsCosts(db,range),operatingCosts:await readOperatingCosts(db,range)});}
 const range=readDateRange(url.searchParams),where=['kind=?'],args:any[]=[kind];if(range.from){where.push('end_date>=?');args.push(range.from);}if(range.to){where.push('date<=?');args.push(range.to);}const data=await db.prepare('SELECT * FROM pm_finance_docs WHERE '+where.join(' AND ')+' ORDER BY date DESC,id DESC LIMIT 5001').bind(...args).all<any>();if(data.results.length>5000)throw Error('Chọn khoảng thời gian nhỏ hơn để xem dưới 5.000 phiếu');const rows=data.results.map(r=>({...JSON.parse(r.record),id:r.id,status:r.status,version:r.version})).map(r=>({...r,balance:financeBalance(r),taxResult:r.kind==='tax'?taxResult(r):null}));const confirmed=rows.filter(r=>r.status==='confirmed');const version=await db.prepare('SELECT COUNT(*) AS n FROM pm_finance_requests').first<any>();const audit=await db.prepare('SELECT time,actor,action,record FROM pm_finance_audit ORDER BY rowid DESC LIMIT 30').all<any>();const payrollCosts=await readPayrollCosts(db,range),adsCosts=await readAdsCosts(db,range),operatingCosts=kind==='tax'?await readOperatingCosts(db,range):null;const driveAds=await driveAdsStatus(db);if(url.searchParams.has('export')&&kind==='expense'){
 const list=filterExpenses(collect({rows,adsCosts,payrollCosts,driveAds},true),url.searchParams);
 const sub=url.searchParams.get('sub'),group=url.searchParams.get('group');
 const values=list.filter(l=>!sub||(group==='staff'?l.label.split(' · ').slice(1).join(' · '):group==='ads'?(l.shop==='shared'?'Chi phí chung':financeChannels[l.shop])+' · '+l.source:l.category||l.group)===sub);
 const headings=['Ngày','Shop','Đầu chi','Nội dung','Nguồn','Mã đối chiếu','Chứng từ','Số gốc','Số trong báo cáo','Đã trả','Rà soát thuế','Trạng thái','Lý do'];
 const csv=[headings,...values.map(l=>[l.date,financeChannels[l.shop],expenseGroups[l.group],l.label,l.source,l.reference,l.proof,l.original??l.amount,l.amount,l.paid??'',{eligible:'Hợp lệ',pending:'Chờ rà soát',ineligible:'Không hợp lệ'}[taxBucket(l)],l.excluded?'Đã loại':'Đang ghi nhận',l.control?.reason||''])].map(a=>a.map(csvValue).join(',')).join('\r\n');
 return new Response('\uFEFF'+csv,{headers:{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="Chi-phi-'+(range.from||'tat-ca')+'-'+(range.to||'')+'.csv"','Cache-Control':'private, no-store'}});
 }
 const changed=kind==='tax'?await settings<string>(db,'expense-changed:'):{};
 for(const r of rows)if(kind==='tax'&&r.status==='confirmed')r.needsExpenseReview=Object.entries(changed).some(([d,t])=>d>=r.date&&d<=r.endDate&&t>(r.confirmedAt||r.createdAt||''));
 const physicalReceipts=kind==='expense'?await db.prepare("SELECT COUNT(*) AS receipts,SUM(quantity) AS received FROM pm_stock_receipts WHERE active=1 AND date BETWEEN ? AND ?").bind(range.from||'0000',range.to||'9999').first().catch(()=>null):null;
 return json({physicalReceipts,draftOwner:user.email,management:await management(db,user.role),sourceSettings:await settings(db,sourcePrefix),canSetPacking:user.role==='owner',packingRate:kind==='expense'?(await db.prepare("SELECT value FROM app_state WHERE id='packing-rate'").first<{value:string}>())?.value??null:null,rows,payrollCosts,adsCosts,operatingCosts,driveAds,version:version.n,summary:{vat:confirmed.reduce((n,r)=>n+(r.vat||0),0),pit:confirmed.reduce((n,r)=>n+(r.pit||0),0),deductible:confirmed.filter(r=>r.kind==='expense'&&r.deductibility==='eligible').reduce((n,r)=>n+r.amount,0),draft:rows.filter(r=>r.status==='draft').length,amount:confirmed.reduce((n,r)=>n+r.amount,0),paid:confirmed.reduce((n,r)=>n+r.paid,0),withheld:confirmed.reduce((n,r)=>n+(r.withheldVat||0)+(r.withheldPit||0),0),due:confirmed.reduce((n,r)=>n+r.balance.due,0),credit:confirmed.reduce((n,r)=>n+r.balance.credit,0),missing:confirmed.filter(r=>!r.receipt).length},audit:audit.results.map(r=>({...r,detail:JSON.parse(r.record)}))});
 }catch(e){return json({error:(e as Error).message},403);}}
export async function POST(req:Request){try{if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Nguồn yêu cầu không hợp lệ'},403);const user=await authorize(),db=env.DB!;if(new URL(req.url).searchParams.has('link-tiktok-account')){const b:any=await req.json();return json(await assignTikTokAccount(db,String(b.account),String(b.shop),user.email));}if(new URL(req.url).searchParams.has('expense-receipt')){
 const hash=new URL(req.url).searchParams.get('expense-receipt')||'';
 if(!/^[a-f0-9]{64}$/.test(hash))throw Error('Mã tệp không hợp lệ');
 const meta=await db.prepare('SELECT name FROM ads_import_files WHERE hash=?').bind(hash).first<{name:string}>();
 const original=await env.BUCKET?.get('ads-import/'+hash);
 if(!meta||!original)throw Error('Thiếu bản gốc');
 const key='receipts/'+await digest(user.email.toLowerCase()+':'+hash),mime='application/octet-stream';
 await env.BUCKET!.put(key,original.body,{customMetadata:{uploadedBy:user.email.toLowerCase(),name:meta.name},httpMetadata:{contentType:mime}});
 return json({key,name:meta.name,mime});}
 if(new URL(req.url).searchParams.has('ads-import'))return json(await storeAdsFile(db,env.BUCKET!,req,user.email));const b:any=await req.json();if(b.action==='settlement-import')return json(await settlementImport(db,b,user.email));if(b.action==='refresh-facebook-ads')return json({results:await refreshFacebookAds(db,env as any,user.email)});if(b.action==='sync-ads'){const period=String(b.period||'');const sources=await Promise.allSettled([syncGiaMinh(db,(env as any).GIAMINH_ADS_LEDGER_URL||'',period,user.email,b.force===true),syncFlagteam(db,(env as any).FLAGTEAM_ADS_LEDGER_URL||'',period,user.email,b.force===true)]);const providers=sources.map((r,i)=>r.status==='fulfilled'?r.value:{provider:i?'flagteam':'giaminh',busy:false,results:[{error:(r.reason as Error).message}]});return json({busy:providers.some(r=>r.busy),results:providers.flatMap(r=>r.results||[]),providers});}if(!/^[0-9a-f-]{36}$/.test(b.requestId||''))throw Error('Thiếu mã yêu cầu');if(await db.prepare('SELECT id FROM pm_finance_requests WHERE id=?').bind(b.requestId).first())return json({ok:true,replayed:true});const current=await db.prepare('SELECT COUNT(*) AS n FROM pm_finance_requests').first<any>();if(current.n!==b.version)return json({error:'Dữ liệu vừa thay đổi. Tải lại rồi thực hiện lại.'},409);const x=b.data||{};if(['manual-ads','release-manual-ads'].includes(b.action)){if(x.receipt){const file=await env.BUCKET?.head(String(x.receipt.key||''));if(!file||file.customMetadata?.uploadedBy?.toLowerCase()!==user.email.toLowerCase())throw Error('Chứng từ không thuộc tài khoản tải lên');}return json(await writeManualAds(db,x,user.email,b.requestId,b.version,b.action==='release-manual-ads'));}if(b.action==='review-ads'){const month=taxPeriod(x.month);if(month.period.includes('Q'))throw Error('Rà soát quảng cáo theo tháng nguồn');const costs=await readAdsCosts(db,{from:month.date,to:month.endDate}),row=costs.rows.find((r:any)=>r.id===x.id);if(!row||row.fingerprint!==x.fingerprint)throw Error('Sổ chi nguồn đã đổi; tải lại để rà soát');if(row.review?.version!==x.reviewVersion&&!(row.review==null&&x.reviewVersion===undefined))throw Error('Hồ sơ vừa đổi. Tải lại');const value=validateAdsReview(row,x);if(value.receipt&&value.receipt.key!==row.review?.receipt?.key){const file=await env.BUCKET?.head(value.receipt.key);if(!file||file.customMetadata?.uploadedBy?.toLowerCase()!==user.email.toLowerCase())throw Error('Chứng từ không thuộc tài khoản tải lên');}await db.batch([db.prepare('INSERT INTO pm_finance_requests VALUES(?,?)').bind(b.requestId,b.version),db.prepare('INSERT INTO pm_ads_reviews VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET record=excluded.record,version=excluded.version').bind(row.id,JSON.stringify({...value,actor:user.email,time:new Date().toISOString()}),(row.review?.version??-1)+1),db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),new Date().toISOString(),user.email,'review-ads:expense',JSON.stringify({id:row.id,before:row.review,after:value}))]);return json({ok:true});}if(b.action==='review-payroll'){const month=taxPeriod(x.month);if(month.period.includes('Q'))throw Error('Rà soát theo tháng lương');const costs=await readPayrollCosts(db,{from:month.date,to:month.endDate}),row=costs.rows.find((r:any)=>r.id===x.id);if(!row||row.fingerprint!==x.fingerprint)throw Error('Nguồn lương đã thay đổi; tải lại trước khi rà soát');if(row.review?.version!==x.reviewVersion&&!(row.review==null&&x.reviewVersion===undefined))throw Error('Có người vừa rà soát. Tải lại');const value=validatePayrollReview(row,x);if(value.receipt&&value.receipt.key!==row.review?.receipt?.key){const file=await env.BUCKET?.head(value.receipt.key);if(!file||file.customMetadata?.uploadedBy?.toLowerCase()!==user.email.toLowerCase())throw Error('Chứng từ không thuộc tài khoản tải lên');}await db.batch([db.prepare('INSERT INTO pm_finance_requests VALUES(?,?)').bind(b.requestId,b.version),db.prepare('INSERT INTO pm_payroll_cost_reviews VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET record=excluded.record,version=excluded.version').bind(row.id,JSON.stringify({...value,actor:user.email,time:new Date().toISOString()}),(row.review?.version??-1)+1),db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),new Date().toISOString(),user.email,'review-payroll:expense',JSON.stringify({id:row.id,before:row.review,after:value}))]);return json({ok:true});}
 const access=await management(db,user.role);
 const nowChange=new Date().toISOString();
 async function commitControl(statements:D1PreparedStatement[],info:any){
   await db.batch([db.prepare('INSERT INTO pm_finance_requests VALUES(?,?)').bind(b.requestId,b.version),...statements,
    db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),nowChange,user.email,b.action+':expense',JSON.stringify(info))]);
   return json({ok:true});
 }
 if(b.action==='expense-rights'){
   if(user.role!=='owner')throw Error('Chỉ chủ shop được phân quyền');
   const rights={edit:x.edit===true,exclude:x.exclude===true,restore:x.restore===true};
   return commitControl([putSetting(db,'expense-manager-rights',rights)],{id:'expense-manager-rights',before:access.rights,after:rights});
 }
 if(b.action==='resync-provider'){
  if(user.role!=='owner'||!['giaminh','flagteam'].includes(x.provider))throw Error('Nguồn hoặc quyền không hợp lệ');
  const config=env as any;
  const result=x.provider==='giaminh'?await syncGiaMinh(db,config.GIAMINH_ADS_LEDGER_URL||'',x.month,user.email,true):await syncFlagteam(db,config.FLAGTEAM_ADS_LEDGER_URL||'',x.month,user.email,true);
  if(result.busy)throw Error('Nguồn đang chạy');const error=result.results?.find((r:any)=>r.error);if(error)throw Error((error as any).error);
  return json(result);
 }
 if(b.action==='replace-source'||b.action==='preview-source'){
   if(user.role!=='owner')throw Error('Chỉ chủ shop thay nguồn');
   const src=await driveAdsStatus(db),feed=String(x.key||'').split(':')[1];
   const oldFile=String(x.key||'').split(':')[2],newFile=String(x.file||'').trim();
   if(!src.sources[feed as keyof typeof src.sources]||oldFile===newFile)throw Error('Chọn tệp khác đã được PM xác minh');
   function find(file:string){return src.readSources.find((r:any)=>r.fileId===file&&(r.id===feed||r.id===feed+':'+file)&&r.lastSuccess&&r.folderId===src.folderId);}
   const from=find(oldFile),to=find(newFile);
   if(!from||!to||from.tab!==to.tab)throw Error('Tệp cần được xác minh đúng thư mục, cấu trúc và loại nguồn trước khi thay');
   const active=await db.prepare('SELECT source,record FROM pm_drive_ads_rows WHERE active=1 AND source IN (?,?)').bind(from.id,to.id).all<any>();
   const scope=(key:string)=>active.results.filter(r=>r.source===key).map(r=>JSON.parse(r.record));
   const a=scope(from.id),z=scope(to.id);
   const identities=(v:any[])=>[...new Set(v.map(r=>r.channel+'|'+r.account))].sort().join(', ');
   if(!a.length||!z.length||identities(a)!==identities(z))throw Error('Chưa đủ dòng đã xác minh cùng shop và tài khoản để thay nguồn');
   const dates=(v:any[])=>v.map(r=>r.date).sort(),ad=dates(a),zd=dates(z);
   if(ad[0]>zd.at(-1)||zd[0]>ad.at(-1))throw Error('Hai nguồn chưa có kỳ giao nhau để đối chiếu');
   const keys=new Map(a.map(r=>[r.channel+'|'+r.account+'|'+r.date,r.amount]));
   let duplicates=0;for(const r of z){const k=r.channel+'|'+r.account+'|'+r.date;if(keys.has(k)){duplicates++;if(keys.get(k)!==r.amount)throw Error('Cùng tài khoản/ngày nhưng số tiền khác, cần đối chiếu');}}
   const report={accounts:identities(z),from:zd[0],to:zd.at(-1),rows:z.length,duplicates,hash:to.hash,oldHash:from.hash};
   if(b.action==='preview-source')return json(report);
   if(JSON.stringify(report)!==JSON.stringify(x.preview)||!text(x.reason,250))throw Error('Đọc lại bản đối chiếu hoặc bổ sung lý do');
   const after={mode:'removed',replacement:newFile,reason:x.reason,time:nowChange,actor:user.email};
   return commitControl([putSetting(db,sourcePrefix+x.key,after),putSetting(db,sourcePrefix+'drive:'+feed+':'+newFile,{...after,mode:'active',replacement:null})],{id:x.key,before:oldFile,after:newFile,report,reason:x.reason});
 }
 if(b.action==='source-mode'){
   if(user.role!=='owner')throw Error('Chỉ chủ shop quản lý kết nối');
   const key=String(x.key||''),mode=x.mode;
   if(!['active','paused','removed'].includes(mode)||!(/^(giaminh|flagteam)$/.test(key)||/^drive:(tiktok_daily|shopee_daily|account_day_report|invoice_catalog):[\w-]{15,120}$/.test(key)))throw Error('Nguồn không hợp lệ');
   const old=(await settings<any>(db,sourcePrefix))[key];
   const after={mode,label:text(x.label,120),reason:text(x.reason,250),time:nowChange,actor:user.email};
   if(!after.reason)throw Error('Nhập lý do thay đổi nguồn');
   return commitControl([putSetting(db,sourcePrefix+key,after)],{id:key,before:old||{mode:'active'},after});
 }
 if(b.action==='auto-line'){
   const op=x.operation;
   if(!(op==='exclude'?access.canExclude:op==='restore'?access.canRestore:access.canEdit))throw Error('Thiếu quyền thao tác khoản chi');
   if(!['adjust','exclude','restore','original'].includes(op)||!text(x.reason,500))throw Error('Chọn thao tác và ghi lý do');
   const range=readDateRange(new URLSearchParams({from:x.date.length===7?x.date+'-01':x.date,to:x.date.length===7?taxPeriod(x.date).endDate:x.date}));
   const lines=collect({rows:[],adsCosts:await readAdsCosts(db,range),payrollCosts:await readPayrollCosts(db,range)},true);
   const line=lines.find(l=>l.lineKey===x.lineKey&&l.group===x.group&&l.shop===x.shop&&l.date===x.date);
   if(!line||line.amount!==x.previous||Boolean(line.excluded)!==(op==='restore'))throw Error('Khoản nguồn đã thay đổi. Mở lại để kiểm tra');
   const target=op==='adjust'?x.target:op==='original'?undefined:line.control?.target;
   if(target!==undefined&&(!Number.isSafeInteger(target)||target<0))throw Error('Số tiền không hợp lệ');
   const excluded=op==='exclude',value=excluded?0:target??line.original;
   const after={target,excluded,actor:user.email,time:nowChange,reason:text(x.reason,500)};
   return commitControl([putSetting(db,overridePrefix+line.lineKey,after),putSetting(db,'expense-changed:'+range.from,nowChange)],
    {id:line.lineKey,group:line.group,shop:line.shop,date:line.date,before:{amount:line.amount},after:{amount:value},reason:after.reason,operation:op});
 }
 const oldRow=x.id?await db.prepare('SELECT * FROM pm_finance_docs WHERE id=?').bind(text(x.id,100)).first<any>():null,old=oldRow?{...JSON.parse(oldRow.record),id:oldRow.id,status:oldRow.status,version:oldRow.version}:null,now=new Date().toISOString();if(x.id&&!old)throw Error('Không tìm thấy phiếu');if(old&&x.version!==old.version)throw Error('Phiếu đã thay đổi. Mở lại phiếu');let next:any,id=old?.id||crypto.randomUUID(),fingerprint:string|null=oldRow?.fingerprint||null;
 if(old?.supplierPayment && !['exclude-line','restore-line'].includes(b.action))throw Error('Sửa hoặc hủy thanh toán từ Công nợ nhà cung cấp.');
 if(['exclude-line','restore-line'].includes(b.action)){
   const restore=b.action==='restore-line';
   if(!(restore?access.canRestore:access.canExclude)||!old||old.kind!=='expense'||old.status!==(restore?'excluded':'confirmed'))throw Error('Kiểm tra quyền và trạng thái phiếu');
   if(!text(x.reason,500)||x.previous!==(restore?0:old.amount))throw Error('Kiểm tra số cũ và lý do');
   next={...old,status:restore?'confirmed':'excluded',version:old.version+1,updatedAt:now,changeReason:text(x.reason,500)};
 }else if(['quick','adjust','edit-quick'].includes(b.action)){
 const editing=b.action==='edit-quick';
 if(editing&&!text(x.reason,500))throw Error('Ghi lý do sửa khoản chi');
 if(editing&&(!old||old.kind!=='expense'||old.status!=='confirmed'||old.adjustment||!access.canEdit))throw Error('Phiếu cần đối soát trước khi sửa');
 if(b.kind!=='expense'||(!editing&&old))throw Error('Chỉ lập khoản chi mới');
 const adjustment=b.action==='adjust';
 if(adjustment&&user.role!=='owner')throw Error('Chỉ chủ shop được điều chỉnh tổng kỳ');
 const delta=Number(x.amount);
 if(!Number.isSafeInteger(delta)||!delta||(!adjustment&&delta<0))throw Error('Số tiền không hợp lệ');
 if(adjustment&&(!text(x.reason)||!Number.isSafeInteger(x.previous)||!Number.isSafeInteger(x.target)||x.target<0||x.target-x.previous!==delta))throw Error('Kiểm tra tổng và lý do điều chỉnh');
 if(!adjustment&&x.category==='ads'&&/gia\s*minh|flagteam/i.test(x.counterparty||''))throw Error('Dùng nguồn quảng cáo đối tác');
 if(!adjustment&&x.category==='ads'&&['tiktok1','tiktok2','shopee'].includes(x.channel))throw Error('Nhập tại nguồn quảng cáo sàn để đối chiếu theo tài khoản/ngày');
 if(adjustment){
  const range=readDateRange(new URLSearchParams({from:String(x.range?.from||''),to:String(x.range?.to||'')}));
  if(!withinRange(validDate(x.date),range))throw Error('Ngày điều chỉnh ngoài kỳ');
  const docs=await db.prepare("SELECT record FROM pm_finance_docs WHERE kind='expense' AND status='confirmed' AND channel=? AND (?='' OR date>=?) AND (?='' OR date<=?)").bind(x.channel,range.from,range.from,range.to,range.to).all<any>();
  const grouped=collect({rows:docs.results.map(d=>({...JSON.parse(d.record),status:'confirmed'})),adsCosts:await readAdsCosts(db,range),payrollCosts:await readPayrollCosts(db,range)});
  const g=['utilities','rent','services'].includes(x.category)?'operations':x.category;
  const sum=grouped.filter(l=>l.shop===x.channel&&l.group===g).reduce((n,l)=>n+l.amount,0);
  if(sum!==x.previous)throw Error('Tổng nguồn vừa đổi. Tải lại trước khi điều chỉnh');
 }
 id=editing?old.id:b.requestId;
 next={...validateFinance('expense',{...x,deductibility:'pending',amount:Math.abs(delta),paid:adjustment?0:x.paid}),amount:delta,id,status:'confirmed',version:editing?old.version+1:0,createdAt:old?.createdAt||now,updatedAt:now,confirmedAt:now,actor:user.email,quick:true};
 if(editing){
  if(old.payments?.length&&(old.paid!==next.paid||old.channel!==next.channel))throw Error('Phiếu có lịch sử thanh toán. Giữ nguyên số đã trả và shop.');
  next.payments=old.payments||[];next.changeReason=text(x.reason,500);next.actor=old.actor;next.quick=old.quick;
  if(old.taxReassessment)next.previousTaxReassessment=old.taxReassessment;
 }
 if(!adjustment&&x.expenseDetails){
   const fields=Object.fromEntries(Object.entries(x.expenseDetails.fields||{}).slice(0,12).map(([k,v])=>[text(k,80),text(v,150)]));
   if(next.category==='ads'&&fields['Loại khoản']==='Tiền nạp / tín dụng')throw Error('Tiền nạp và tín dụng chỉ dùng đối chứng');
   const items=x.expenseDetails.items||[];
   if(!Array.isArray(items)||items.length>30)throw Error('Tối đa 30 dòng vật tư');
   const clean=items.map((it:any)=>({name:text(it.name,100),qty:Number(it.qty),price:Number(it.price)}));
   if(clean.some((it:any)=>!it.name||!Number.isSafeInteger(it.qty)||it.qty<1||!Number.isSafeInteger(it.price)||it.price<1)||clean.length&&clean.reduce((n:number,it:any)=>n+it.qty*it.price,0)!==delta)throw Error('Tổng dòng vật tư không khớp');
   next.expenseDetails={fields,items:clean.map((it:any)=>({...it,qty:String(it.qty),price:String(it.price)}))};
 }
 if(!adjustment&&next.reference)fingerprint=await digest('expense:'+next.counterparty.toLowerCase()+':'+next.reference.toLowerCase());
 if(x.documentRow!=null){
   if(!Number.isSafeInteger(x.documentRow)||x.documentRow<0||!next.receipt)throw Error('Thiếu dòng chứng từ');
   const proof=await env.BUCKET?.head(next.receipt.key);
   if(!proof?.customMetadata?.sha256)throw Error('Chứng từ chưa có dấu đối chiếu');
   next.documentRow=x.documentRow;next.documentHash=proof.customMetadata.sha256;
   next.sourceCell=text(x.sourceCell,180)||String(x.documentRow);
   fingerprint=await digest('expense-file:'+proof.customMetadata.sha256+':'+next.sourceCell);
 }
 if(!adjustment&&next.reference){
   const ref=await db.prepare(`SELECT id FROM pm_finance_docs WHERE kind='expense' AND status!='void' AND id!=?
     AND lower(json_extract(record,'$.reference'))=lower(?) AND lower(json_extract(record,'$.counterparty'))=lower(?)
     AND (?='' OR COALESCE(json_extract(record,'$.documentHash'),'')!=?) LIMIT 1`).bind(id,next.reference,next.counterparty,next.documentHash||'',next.documentHash||'').first();
   if(ref)return duplicateExpense(db,(ref as any).id);
 }
 if(adjustment)next.adjustment={previous:x.previous,target:x.target,reason:text(x.reason),scope:text(x.scope),source:text(x.source)};
 if(next.receipt&&next.receipt.key!==old?.receipt?.key){const file=await env.BUCKET?.head(next.receipt.key);if(file?.customMetadata?.uploadedBy?.toLowerCase()!==user.email.toLowerCase())throw Error('Chứng từ không thuộc tài khoản tải lên');}
 }else if(b.action==='save'){if(old&&old.kind!==b.kind)throw Error('Không được đổi loại phiếu');if(old&&old.status!=='draft')throw Error('Chỉ sửa phiếu nháp. Phiếu xác nhận cần hủy có lý do rồi lập thay thế');let payrollLink:any=null,adsLink:any=null,operatingLink:any=null;if(b.kind==='tax'&&x.method==='profit'){const period=taxPeriod(x.period),costs=await readPayrollCosts(db,{from:period.date,to:period.endDate});if(x.payrollSnapshot!==costs.snapshot)throw Error('Dữ liệu lương đã thay đổi; lấy lại chi phí lương trước khi lưu');const ads=await readAdsCosts(db,{from:period.date,to:period.endDate});if(x.adsSnapshot!==ads.snapshot)throw Error('Chi phí quảng cáo đã đổi; lấy lại theo kỳ trước khi lưu');const operating=await readOperatingCosts(db,{from:period.date,to:period.endDate});if(x.operatingSnapshot!==operating.snapshot)throw Error('Chi phí hoạt động đã đổi; lấy lại theo kỳ trước khi lưu');x.operatingCost=operating.summary.eligible;operatingLink={snapshot:operating.snapshot,total:operating.summary.eligible,pending:operating.summary.pending};x.adsCost=ads.summary.eligible;adsLink={snapshot:ads.snapshot,total:ads.summary.eligible,pending:ads.summary.pending};x.payrollCost=costs.summary.eligible;payrollLink={snapshot:costs.snapshot,total:costs.summary.eligible,pending:costs.summary.pending,sourceVersion:costs.sourceVersion};}next={payrollLink,adsLink,operatingLink,...validateFinance(b.kind,x),id,status:'draft',version:old?old.version+1:0,createdAt:old?.createdAt||now,updatedAt:now,actor:user.email};if(next.kind==='expense'&&next.category==='ads'&&['tiktok1','tiktok2','shopee'].includes(next.channel))throw Error('Dùng Nhập quảng cáo thủ công trong Nguồn quảng cáo sàn để tránh cộng trùng với Drive');if(next.kind==='expense'&&next.category==='ads'&&/gia\s*minh|flagteam/i.test(next.counterparty))throw Error('Chi quảng cáo đối tác dùng phần tự liên kết, không lập phiếu trùng');if(next.kind==='tax')fingerprint=await digest('tax:'+next.channel+':'+next.period);else fingerprint=next.reference?await digest('expense:'+next.counterparty.toLowerCase()+':'+next.reference.toLowerCase()):null;
 if(next.receipt&&next.receipt.key!==old?.receipt?.key){const file=await env.BUCKET?.head(next.receipt.key);if(!file||!file.customMetadata?.uploadedBy||file.customMetadata.uploadedBy.toLowerCase()!==user.email.toLowerCase())throw Error('Chứng từ không thuộc phiên tải lên của tài khoản này');}
 }else{if(!old||old.status==='void')throw Error('Phiếu không còn hiệu lực');next={...old,version:old.version+1,updatedAt:now,actor:user.email};if(b.action==='undo-quick'){if(!old.quick||old.status!=='confirmed'||old.payments.length||old.taxReassessment||(user.role!=='owner'&&old.actor!==user.email))throw Error('Phiếu cần chủ shop đối soát trước khi hoàn tác');next.status='void';next.voidReason='Hoàn tác nhập nhanh';fingerprint=null;}else if(b.action==='confirm'){if(old.status!=='draft')throw Error('Phiếu đã được xác nhận');if(!old.reference)throw Error('Bổ sung mã chứng từ / mã đối soát trước khi xác nhận');if(old.kind==='expense'&&!old.counterparty)throw Error('Bổ sung bên nhận tiền');if(old.kind==='tax'){if(old.payrollLink){const costs=await readPayrollCosts(db,{from:old.date,to:old.endDate});if(costs.snapshot!==old.payrollLink.snapshot)throw Error('Lương hoặc rà soát đã đổi; sửa bản nháp và cập nhật lương trước khi xác nhận');}if(old.adsLink){const ads=await readAdsCosts(db,{from:old.date,to:old.endDate});if(ads.snapshot!==old.adsLink.snapshot)throw Error('Chi quảng cáo hoặc rà soát đã đổi; cập nhật bản nháp trước khi xác nhận');}if(old.operatingLink){const operating=await readOperatingCosts(db,{from:old.date,to:old.endDate});if(operating.snapshot!==old.operatingLink.snapshot)throw Error('Phiếu chi đã đổi; cập nhật bản nháp trước khi xác nhận');}if(!old.basis||x.reviewed!==true)throw Error('Cần căn cứ và xác nhận kiểm tra phương pháp, doanh thu, giảm trừ và thuế sàn nộp thay');const overlap=await db.prepare("SELECT id FROM pm_finance_docs WHERE kind='tax' AND status='confirmed' AND date<=? AND end_date>=? AND (channel=? OR channel='shared' OR ?='shared') LIMIT 1").bind(old.endDate,old.date,old.channel,old.channel).first();if(overlap)throw Error('Kỳ thuế chồng với hồ sơ đã xác nhận cùng nguồn / toàn shop');}next.status='confirmed';next.confirmedAt=now;
 }else if(b.action==='pay'){if(old.status!=='confirmed')throw Error('Xác nhận phiếu trước khi ghi thanh toán');const date=validDate(x.date),reference=text(x.reference,120);if(!reference)throw Error('Nhập mã giao dịch / giấy nộp tiền');if(old.payments.some((p:any)=>p.reference.toLowerCase()===reference.toLowerCase()))throw Error('Mã thanh toán đã có trong phiếu');const vat=old.kind==='tax'?amount(x.vat):0,pit=old.kind==='tax'?amount(x.pit):0,value=old.kind==='tax'?vat+pit:amount(x.amount);if(!value)throw Error('Số thanh toán phải lớn hơn 0');if(old.kind==='expense'&&value>old.amount-old.paid)throw Error('Vượt số còn phải chi');next.payments=[...old.payments,{id:crypto.randomUUID(),date,reference,amount:value,vat,pit,note:text(x.note),actor:user.email,createdAt:now}];next.paid+=value;
 }else if(b.action==='void'){const reason=text(x.reason);if(!reason)throw Error('Nhập lý do hủy');if(old.status==='confirmed'&&old.paid>0)throw Error('Phiếu đã có thanh toán. Cần đối soát khoản tiền đã chi / nộp trước khi hủy');next.status='void';next.voidReason=reason;fingerprint=null;}else throw Error('Thao tác không hợp lệ');}
 const duplicate=fingerprint&&await db.prepare('SELECT id FROM pm_finance_docs WHERE fingerprint=? AND id!=?').bind(fingerprint,id).first();if(duplicate&&b.action==='quick')return duplicateExpense(db,(duplicate as any).id);if(duplicate)throw Error('Trùng mã chứng từ của cùng bên nhận, hoặc trùng kỳ thuế / nguồn');const statements=[db.prepare('INSERT INTO pm_finance_requests VALUES(?,?)').bind(b.requestId,b.version),db.prepare('INSERT INTO pm_finance_docs VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET date=excluded.date,end_date=excluded.end_date,channel=excluded.channel,status=excluded.status,record=excluded.record,version=excluded.version,fingerprint=excluded.fingerprint').bind(id,next.kind,next.date,next.endDate,next.channel,next.status,JSON.stringify(next),next.version,fingerprint),db.prepare('INSERT INTO pm_finance_audit VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),now,user.email,b.action+':'+next.kind,JSON.stringify({id,before:old,after:next}))];if(next.kind==='expense'){
  statements.push(putSetting(db,'expense-changed:'+next.date,now));
  if(old?.date&&old.date!==next.date)statements.push(putSetting(db,'expense-changed:'+old.date,now));
 }
 try{await db.batch(statements);}catch(e){if(await db.prepare('SELECT id FROM pm_finance_requests WHERE id=?').bind(b.requestId).first())return json({ok:true,replayed:true});throw Error('Dữ liệu vừa thay đổi hoặc chứng từ trùng. Tải lại trước khi lưu');}return json({ok:true,id});
 }catch(e){return json({error:(e as Error).message},400);}}
