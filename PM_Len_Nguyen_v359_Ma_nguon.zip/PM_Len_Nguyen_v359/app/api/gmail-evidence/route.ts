import {managementAdsMonths,flagteamApprovalKey,type ApprovedFee} from '../../../lib/flagteam-management';
import {approveHistoricalFlagteamFees,flagteamSourceSchema,saveFlagteamSource,linkFlagteamPdfs} from '../../../lib/gmail-flagteam-invoices';
import {linkMonthlyFreight} from '../../../lib/gmail-monthly-freight';
import {applyInvoiceDetails} from '../../../lib/gmail-invoice-classification';
import {receiveReturns,receiveFreight,crossTables,receiveStatements,receiveInvoices,loadFees,checkStatements,resolveStatementCopies} from '../../../lib/gmail-crosscheck';
import {reviewSchema,reviewGmail,parseBills} from '../../../lib/gmail-review';
import {supplierSnapshot,supplierApproval,applySupplierApproval,approvedSupplierRules,approvalId} from '../../../lib/gmail-supplier-rules';
import {env} from 'cloudflare:workers';
import {verifyHistoricalMonth} from '../../../lib/gmail-handoff';
import {gmailSchema,saveGmailDocuments,reportGmailDocuments,type Manifest} from '../../../lib/gmail-documents';
import {ordersUser} from '../orders/route';
import {constantEqual} from '../../../lib/a3-access';
export const dynamic='force-dynamic';
const mailbox='owner@example.invalid';
const cache={'Cache-Control':'private, no-store'};
let correctedLegacyErrors=false;
async function tables(){
 const db=env.DB!;
 await db.batch([
  db.prepare('CREATE TABLE IF NOT EXISTS gmail_evidence(id TEXT PRIMARY KEY, received TEXT NOT NULL, subject TEXT NOT NULL, sender TEXT NOT NULL, digest TEXT NOT NULL, size INTEGER NOT NULL, saved TEXT DEFAULT CURRENT_TIMESTAMP)'),
  db.prepare('CREATE TABLE IF NOT EXISTS gmail_handoff(month TEXT PRIMARY KEY,scanned INTEGER NOT NULL,candidates INTEGER NOT NULL,verified INTEGER NOT NULL,checked TEXT NOT NULL)'),
  db.prepare('CREATE TABLE IF NOT EXISTS gmail_sync_runs(runId TEXT NOT NULL,lane TEXT NOT NULL,finished TEXT NOT NULL,execution TEXT NOT NULL,reviewed INTEGER,saved INTEGER,newCount INTEGER,postHandoff INTEGER,PRIMARY KEY(runId,lane))'),
  db.prepare(flagteamSourceSchema),
  ...crossTables.map(sql=>db.prepare(sql)),
  db.prepare(reviewSchema),
  ...gmailSchema.map(sql=>db.prepare(sql)),
  db.prepare('CREATE TABLE IF NOT EXISTS gmail_link_files(itemId TEXT PRIMARY KEY,blobKey TEXT NOT NULL,name TEXT NOT NULL)'),
  db.prepare('CREATE TABLE IF NOT EXISTS gmail_activity(lane TEXT PRIMARY KEY, success TEXT, detail TEXT, error TEXT)')
 ]);
 if(!correctedLegacyErrors){
  const {results}=await db.prepare(`SELECT d.id,d.document,d.reason,d.amount,e.subject,f.facts
   FROM gmail_documents d JOIN gmail_evidence e ON e.id=d.mailId
   LEFT JOIN gmail_document_facts f ON f.itemId=d.id WHERE d.state='error'`).all<{
   id:string;document:string;reason:string;amount:number|null;subject:string;facts:string|null
  }>();
  for(const item of results){
   let state='',reason='';
   if(/\.xlsx$/i.test(item.document) && item.reason.startsWith('XML không phân tích được Đối chiếu PM:')){
    const reading=item.facts && JSON.parse(item.facts).reading;
    if(reading?.kind==='jt-statement' && reading.orderReconciliation?.valid===true){
     state='pending';reason=item.reason.slice('XML không phân tích được '.length);
    }
   }else if(item.document.toLowerCase()==='icon.png' && item.amount==null &&
    /^biểu tượng hệ thống báo lỗi gửi thư\.?$/i.test(item.reason) &&
    /^(?:re:\s*)*delivery status notification \(failure\)$/i.test(item.subject.trim())){
    state='evidence';reason='Biểu tượng thông báo gửi thư thất bại. Không phát sinh chi phí.';
   }
   if(state)await db.prepare("UPDATE gmail_documents SET state=?,reason=? WHERE id=? AND state='error' AND reason=?")
    .bind(state,reason,item.id,item.reason).run();
  }
  await db.prepare(`UPDATE gmail_documents SET channel='facebook'
   WHERE source='HỘ KINH DOANH HOÀNG NGỌC LỢI' AND category='ads' AND channel=''
   AND state IN ('pending','linked')`).run();
  // Historical owner approval applies to this MISA invoice and its two verified originals.
  await db.prepare(`UPDATE gmail_documents SET state='linked',targetType='gmail',targetId=mailId||':0',reason=?
   WHERE id='1a05c22676e03d8f:2' AND state='pending' AND channel='facebook' AND category='ads'
   AND source='HỘ KINH DOANH HOÀNG NGỌC LỢI' AND reference='00006809' AND date='2026-09-01'
   AND currency='VND' AND amount=299912
   AND EXISTS(SELECT 1 FROM gmail_link_files WHERE itemId=gmail_documents.mailId||':0' AND blobKey=?)
   AND EXISTS(SELECT 1 FROM gmail_link_files WHERE itemId=gmail_documents.mailId||':1' AND blobKey=?)`)
   .bind('Chủ shop duyệt hóa đơn hợp lệ ngày 20/11/2026. Đã xác minh bản PDF và XML MISA. Chưa xác định ngày phí trên bảng đại lý; không ghi chi phí lần hai.',
    'gmail-links/399580ff87ccd622bd73b42b15853daa6c66f87b77b227fa5abc71ba0d41ed93',
    'gmail-links/19bf58c0cc0d4a231d74f9e620ae41330d127f82e74e744d307807d81e67b0c5').run();
  await db.batch([
   db.prepare(`UPDATE gmail_purchase_notices SET status='documented' WHERE status='awaiting_receipt'
    AND date(date)=date AND printedTotal<>'' AND printedTotal NOT GLOB '*[^0-9]*' AND CAST(printedTotal AS INTEGER)>0
    AND EXISTS(SELECT 1 FROM gmail_purchase_sources s JOIN gmail_evidence e ON e.id=s.mailId WHERE s.noticeId=gmail_purchase_notices.id)`),
   db.prepare(`UPDATE gmail_documents SET reason='Đã ghi nhận mua hàng theo hóa đơn' WHERE targetType='purchase-notice'
    AND targetId IN (SELECT id FROM gmail_purchase_notices WHERE status='documented') AND reason LIKE '%Chờ khớp phiếu nhập%'`)
  ]);
  correctedLegacyErrors=true;
 }
 return db;
}
export async function POST(request:Request){
 const action=new URL(request.url).searchParams.get('crosscheck');
 if(action){
  if(request.headers.get('origin')!==new URL(request.url).origin)return new Response(null,{status:403});
  try{if(!(await ordersUser()).owner)return new Response(null,{status:403});}catch{return new Response(null,{status:403});}
  try{
   const db=await tables();
   if(action==='classify')return Response.json(await applyInvoiceDetails(db,(await ordersUser()).u.email,env as any),{headers:cache});
   if(action==='pos')return Response.json(await loadFees(db,env as any),{headers:cache});
   if((action==='ship'||action==='settle')&&!new URL(request.url).searchParams.get('after'))await resolveStatementCopies(db);
   if(action==='check'||action==='ship'||action==='settle')return Response.json(await checkStatements(db,undefined,new URL(request.url).searchParams.get('after')||'',action!=='check',(await ordersUser()).u.email,action==='settle'),{headers:cache});
   const body=await request.text();
   if(body.length>3000000)return new Response(null,{status:413});
   if(action==='flag-source')return Response.json(await saveFlagteamSource(db,env as any,JSON.parse(body)),{headers:cache});
   if(action==='flagpdf')return Response.json(await linkFlagteamPdfs(db,env as any,JSON.parse(body)),{headers:cache});
   if(action==='monthly')return Response.json(await linkMonthlyFreight(db,JSON.parse(body)),{headers:cache});
   if(action==='returns')return Response.json(await receiveReturns(db,JSON.parse(body)),{headers:cache});
   if(action==='freight')return Response.json(await receiveFreight(db,JSON.parse(body)),{headers:cache});
   if(action==='jt')return Response.json(await receiveStatements(db,JSON.parse(body)),{headers:cache});
   if(action==='invoice')return Response.json(await receiveInvoices(db,JSON.parse(body)),{headers:cache});
   return new Response(null,{status:400});
  }catch(e){return Response.json({error:(e as Error).message},{status:400});}
 }
 if(new URL(request.url).searchParams.has('fintab')){
  if(request.headers.get('origin')!==new URL(request.url).origin)return new Response(null,{status:403});
  try{if(!(await ordersUser()).owner)return new Response(null,{status:403});}catch{return new Response(null,{status:403});}
  try{
   const input=await request.text();
   if(input.length>500000)return new Response(null,{status:413});
   const bills=parseBills(input),db=await tables();
   for(let i=0;i<bills.length;i+=40)await db.batch(bills.slice(i,i+40).map(b=>db.prepare('INSERT OR IGNORE INTO gmail_fintab_bills VALUES(?,?,?,?)').bind(b.vendor,b.number,b.day,b.total)));
   return Response.json(await reviewGmail(db),{headers:cache});
  }catch(e){return Response.json({error:(e as Error).message},{status:400});}
 }
 const keys=[(env as any).GMAIL_IMPORT_TOKEN,(env as any).GMAIL_PIPELINE_TOKEN];
 const token=request.headers.get('Authorization')?.replace(/^Bearer /,'')||'';
 if(!token||!keys.some(key=>typeof key==='string'&&key.length>0&&constantEqual(key,token))||request.headers.has('origin'))return new Response(null,{status:403});
 try{
  const db=await tables();
  const url=new URL(request.url);
  if(url.searchParams.has('flagteamManagementApproval')){
   await approveHistoricalFlagteamFees(db);
   const approval=await db.prepare('SELECT value FROM app_state WHERE id=?').bind(flagteamApprovalKey).first<{value:string}>();
   if(!approval)return Response.json({error:'Bộ chứng từ đã thay đổi'},{status:409});
   const charges:ApprovedFee[]=JSON.parse(approval.value);
   const raw=await db.prepare("SELECT id,record FROM pm_ads_months WHERE id LIKE 'flagteam:%'").all<{id:string;record:string}>();
   const report=await managementAdsMonths(db,raw.results);
   const fees=new Map<string,number>();
   for(const row of report)for(const day of JSON.parse(row.record).days)fees.set(day.date,day.fee);
   return Response.json({items:charges.length,verified:charges.filter(c=>fees.get(c.day)===c.fee).length,
    management:charges.reduce((sum,c)=>sum+(fees.get(c.day)??0),0),invoices:charges.reduce((sum,c)=>sum+c.total,0)});
  }
  if(url.searchParams.has('supplierApproval')){
   const body=await request.json() as {apply?:boolean;expectedHash?:string};
   const previous=await supplierApproval(db);
   if(previous){
    const current=await supplierSnapshot(db);
    return Response.json({ok:true,unchanged:true,approval:previous,rules:approvedSupplierRules,remainingChanges:current.changes,finance:current.finance,counts:current.counts});
   }
   const snapshot=await supplierSnapshot(db);
   if(!body.apply)return Response.json({ok:true,hash:snapshot.hash,counts:snapshot.counts,changes:snapshot.changes,finance:snapshot.finance,rules:approvedSupplierRules});
   if(body.expectedHash!==snapshot.hash)return Response.json({error:'Dữ liệu đã thay đổi. Đọc lại trước khi cập nhật'},{status:409});
   if(snapshot.changes.some(c=>c.state==='posted'))return Response.json({error:'Có khoản đã ghi sổ cần điều chỉnh có lịch sử'},{status:409});
   const backupKey='gmail-backups/'+approvalId+'/'+snapshot.hash+'.json';
   const backup=JSON.stringify(snapshot);
   await env.BUCKET!.put(backupKey,backup);
   if(await (await env.BUCKET!.get(backupKey))?.text()!==backup)throw Error('Chưa xác minh sao lưu');
   const report=await applySupplierApproval(db,backupKey,snapshot);
   return Response.json({ok:true,report,approval:await supplierApproval(db)});
  }
  if(url.searchParams.has('verifyOriginals')){
   const req=await request.json() as {items:{id:string;size:number;sha256:string}[]};
   if(!Array.isArray(req.items)||!req.items.length||req.items.length>12)return new Response(null,{status:400});
   let verified=0;
   for(const item of req.items){
    if(!item||!/^\w{8,40}$/.test(item.id)||!/^[a-f0-9]{64}$/.test(item.sha256)||!Number.isSafeInteger(item.size)||item.size<1)return new Response(null,{status:400});
    const meta=await db.prepare('SELECT size,digest FROM gmail_evidence WHERE id=?').bind(item.id).first<{size:number;digest:string}>();
    if(meta?.size!==item.size||meta?.digest!==item.sha256)return Response.json({ok:false,id:item.id,verified},{status:409});
    const obj=await env.BUCKET!.get('gmail-evidence/'+meta.digest);
    if(!obj||obj.size!==meta.size)return Response.json({ok:false,id:item.id,verified},{status:409});
    const bytes=await crypto.subtle.digest('SHA-256',await obj.arrayBuffer());
    if(Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('')!==meta.digest)return Response.json({ok:false,id:item.id,verified},{status:409});
    verified++;
   }
   return Response.json({ok:true,verified});
  }
  if(url.searchParams.has('handoff')){
   const verification=await verifyHistoricalMonth(db,await request.json());
   return Response.json(verification,{status:verification.ok?200:409});
  }
  if(url.searchParams.has('progress')){
   const p=await request.json() as {lane:string;actualLane?:string;detail:string;error?:string;execution?:string;runId?:string;reviewed?:number;saved?:number;newOriginals?:{id:string;digest:string}[]};
   if(!['recent','history'].includes(p.lane)||typeof p.detail!=='string')return new Response(null,{status:400});
   if(!p.error && p.runId && /^[a-zA-Z0-9-]{1,64}$/.test(p.runId) && ['clock','manual'].includes(p.execution||'')){
    const list=p.newOriginals||[], reviewed=Number(p.reviewed), saved=Number(p.saved);
    if(!Array.isArray(list)||list.length>100||!Number.isSafeInteger(reviewed)||!Number.isSafeInteger(saved)||saved<list.length||reviewed<saved)return new Response(null,{status:400});
    const actual=p.actualLane||p.lane;
    if(!['recent','history','catchup'].includes(actual))return new Response(null,{status:400});
    const check=await db.prepare(`SELECT COUNT(*) n,COALESCE(SUM(e.received>='2026-11-19T17:00:00.000Z'),0) future
     FROM gmail_evidence e JOIN json_each(?) r ON e.id=json_extract(r.value,'$.id') AND e.digest=json_extract(r.value,'$.digest')`)
      .bind(JSON.stringify(list)).first<{n:number;future:number}>();
    if(!check||check.n!==list.length)return new Response(null,{status:409});
    await db.prepare('INSERT INTO gmail_sync_runs VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(runId,lane) DO NOTHING')
      .bind(p.runId,actual,new Date().toISOString(),p.execution,reviewed,saved,check.n,check.future).run();
   }
   await db.prepare('INSERT INTO gmail_activity(lane,success,detail,error) VALUES(?,?,?,?) ON CONFLICT(lane) DO UPDATE SET success=COALESCE(excluded.success,gmail_activity.success), detail=excluded.detail,error=excluded.error').bind(p.lane,p.error?null:new Date().toISOString(),p.detail.slice(0,300),p.error?.slice(0,300)||null).run();
   return Response.json({ok:true});
  }
  const form=await request.formData(), file=form.get('original'), id=String(form.get('id')), received=String(form.get('received'));
  if(form.get('mailbox')!==mailbox||!/^\w{8,40}$/.test(id)||!file||typeof file==='string'||!file.size||file.size>40*1024*1024||!Number.isFinite(Date.parse(received)))return Response.json({error:'Thư hoặc ngày nhận không hợp lệ'},{status:400});
  const hash=await crypto.subtle.digest('SHA-256',await file.arrayBuffer());
  const digest=Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('');
  const prior=await db.prepare('SELECT digest FROM gmail_evidence WHERE id=?').bind(id).first<{digest:string}>();
  if(prior&&prior.digest!==digest)return Response.json({error:'Thư cùng mã nhưng khác nội dung'},{status:409});
  const key='gmail-evidence/'+digest;
  if(!await env.BUCKET!.head(key))await env.BUCKET!.put(key,file.stream());
  const written=await db.prepare('INSERT INTO gmail_evidence(id,received,subject,sender,digest,size) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING').bind(id,new Date(received).toISOString(),String(form.get('subject')||'').slice(0,500),String(form.get('sender')||'').slice(0,500),digest,file.size).run();
  const persisted=await db.prepare('SELECT digest FROM gmail_evidence WHERE id=?').bind(id).first<{digest:string}>();
  const object=await env.BUCKET!.get(key);
  if(!object||persisted?.digest!==digest||object.size!==file.size)throw Error('Chưa xác minh được bản gốc');
  const storedDigest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await object.arrayBuffer())),byte=>byte.toString(16).padStart(2,'0')).join('');
  if(storedDigest!==digest)throw Error('Dữ liệu đọc lại không khớp bản gốc');
  const rawManifest=form.get('manifest');
  if(typeof rawManifest==='string'){
   const manifest=JSON.parse(rawManifest) as Manifest;
   if(!Array.isArray(manifest.attachments)||!Array.isArray(manifest.links))throw Error('Danh mục chứng từ không hợp lệ');
   for(const [index,link] of manifest.links.entries()){
    const entry=link as typeof link&{originalField?:string;size?:number;sha256?:string;name?:string};
    if(!entry.originalField)continue;
    const part=form.get(entry.originalField);
    if(entry.originalField!=='link_'+index||!part||typeof part==='string'||!part.size||part.size>4*1024*1024||part.size!==entry.size)throw Error('Tệp liên kết không khớp kích thước');
    const calculated=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await part.arrayBuffer())),b=>b.toString(16).padStart(2,'0')).join('');
    if(calculated!==entry.sha256)throw Error('Tệp liên kết không khớp mã kiểm tra');
    const blobKey='gmail-links/'+calculated, itemId=id+':'+(manifest.attachments.length+index);
    const stored=await db.prepare('SELECT blobKey FROM gmail_link_files WHERE itemId=?').bind(itemId).first<{blobKey:string}>();
    if(stored&&stored.blobKey!==blobKey){entry.error='Bản ở liên kết đã đổi. Cần rà soát với bản tải lần đầu';continue;}
    if(!await env.BUCKET!.head(blobKey))await env.BUCKET!.put(blobKey,part.stream());
    await db.prepare('INSERT INTO gmail_link_files VALUES(?,?,?) ON CONFLICT(itemId) DO NOTHING').bind(itemId,blobKey,String(entry.name||'Chứng từ').slice(0,200)).run();
   }
   await saveGmailDocuments(db,{id,subject:String(form.get('subject')||''),sender:String(form.get('sender')||''),digest},manifest);
   await reviewGmail(db,id);
  }
  return Response.json({ok:true,id,digest,size:file.size,created:written.meta.changes===1,readBack:true});
 }catch{return Response.json({error:'Lưu chưa hoàn tất, chạy lại từ thư này'},{status:503});}
}
export async function GET(req:Request){
 try{if(!(await ordersUser()).owner)return new Response(null,{status:403});}catch{return new Response(null,{status:403});}
 const db=await tables(),url=new URL(req.url),id=url.searchParams.get('id');
 if(url.searchParams.has('flagSourcePdf')){
  const number=url.searchParams.get('flagSourcePdf');
  const row=await db.prepare('SELECT sha,number FROM pm_flagteam_source_invoices WHERE number=?').bind(number).first<{sha:string;number:string}>();
  const file=row&&await env.BUCKET!.get('agency-invoices/'+row.sha);
  return file&&row?new Response(file.body,{headers:{...cache,'Content-Type':'application/pdf','Content-Disposition':'attachment; filename="Flagteam-'+row.number+'.pdf"'}}):new Response(null,{status:404});
 }
 if(url.searchParams.has('flagSources'))return Response.json((await db.prepare('SELECT number,issued,day,total,fee FROM pm_flagteam_source_invoices ORDER BY issued DESC').all()).results,{headers:cache});
 if(url.searchParams.has('purchases')){
  const data=await db.prepare(`SELECT p.*,s.mailId,e.received,(SELECT json_extract(f.facts,'$.invoice.descriptions') FROM gmail_document_facts f JOIN gmail_documents doc ON doc.id=f.itemId WHERE doc.targetId=p.id AND json_type(f.facts,'$.invoice.descriptions')='array' ORDER BY f.quality DESC LIMIT 1) originalLines,(SELECT l.itemId FROM gmail_link_files l JOIN gmail_documents d ON d.id=l.itemId WHERE d.mailId=s.mailId AND d.targetId=p.id LIMIT 1) originalFile FROM gmail_purchase_notices p JOIN gmail_purchase_sources s ON s.noticeId=p.id JOIN gmail_evidence e ON e.id=s.mailId ORDER BY p.date DESC,p.id,e.received`).all();
  return Response.json({rows:data.results},{headers:cache});
 }
 if(url.searchParams.has('linkFile')){
  const f=await db.prepare('SELECT blobKey,name FROM gmail_link_files WHERE itemId=?').bind(url.searchParams.get('linkFile')).first<{blobKey:string;name:string}>();
  const content=f&&await env.BUCKET!.get(f.blobKey);
  return f&&content?new Response(content.body,{headers:{...cache,'Content-Type':'application/octet-stream','X-Content-Type-Options':'nosniff','Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(f.name)}}):new Response(null,{status:404});
 }
 if(url.searchParams.has('items')){
  const [report,handoff,clock,firstNew]=await Promise.all([reportGmailDocuments(db,url.searchParams),db.prepare('SELECT * FROM gmail_handoff ORDER BY month').all(),db.prepare("SELECT * FROM gmail_sync_runs WHERE execution='clock' ORDER BY finished DESC LIMIT 8").all(),db.prepare("SELECT finished,postHandoff FROM gmail_sync_runs WHERE execution='clock' AND postHandoff>0 ORDER BY finished LIMIT 1").first()]);
  return Response.json({...report,handoff:handoff.results,clock:clock.results,firstNew,supplierApproval:await supplierApproval(db)},{headers:cache});
 }
 if(id){
  const record=await db.prepare('SELECT digest,size FROM gmail_evidence WHERE id=?').bind(id).first<{digest:string;size:number}>();
  const file=record&&await env.BUCKET!.get('gmail-evidence/'+record.digest);
  return file&&record?new Response(file.body,{headers:{...cache,'X-Original-SHA256':record.digest,'X-Original-Size':String(record.size),'Content-Type':'application/octet-stream','Content-Disposition':'attachment; filename="gmail-'+id+'.eml"'}}):new Response(null,{status:404});
 }
 const offset=Math.max(0,Number.parseInt(url.searchParams.get('offset')||'0')||0);
 const [rows,activity,count]=await Promise.all([db.prepare('SELECT id,received,subject,sender FROM gmail_evidence ORDER BY received DESC,id LIMIT 50 OFFSET ?').bind(offset).all(),db.prepare('SELECT * FROM gmail_activity').all(),db.prepare('SELECT COUNT(*) AS n FROM gmail_evidence').first()]);
 return Response.json({rows:rows.results,activity:activity.results,total:count?.n||0},{headers:cache});
}
