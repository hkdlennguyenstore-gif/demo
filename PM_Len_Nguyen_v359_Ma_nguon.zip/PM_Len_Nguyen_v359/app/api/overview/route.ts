import {shopCosts,profitReviews,feePolicies} from '../../../lib/shop-profit';
import {readPosSourceReport} from '../../../lib/pos-source-report';
import {marketplaceStatus} from '../../../lib/marketplace-store';
import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {permission,hydrateState,payroll,payrollEmployees,type State} from '../../../lib/payroll';
import {readDateRange,withinRange} from '../../../lib/date-range';
import {periodView,currentMonth} from '../../../lib/month-view';
import {readPurchasing} from '../../../lib/purchasing-store';
import {readReturnBoards} from '../../../lib/return-store';
import {syncStatus} from '../../../lib/orders-store';
import {holidayCalendar,holidayToday,HOLIDAY_NOTE} from '../../../lib/holidays';
export const dynamic='force-dynamic';
const json=(d:unknown,status=200)=>Response.json(d,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(req:Request){try{
 const user=await getChatGPTUser();if(!user)return json({error:'Cần đăng nhập'},401);
 const db=env.DB!;const stored=await db.prepare('SELECT value,version FROM app_state WHERE id=?').bind('main').first<{value:string,version:number}>();if(!stored)return json({error:'Chưa có dữ liệu PM'},404);
 const s=hydrateState(JSON.parse(stored.value) as State),role=permission(s,user.email)?.role;if(!role||!['owner','admin','payroll'].includes(role))return json({error:'Không có quyền xem tổng quan'},403);
 const url=new URL(req.url),range=readDateRange(url.searchParams),view=periodView(s,user.email,range,currentMonth())!;
 const rows=view.payrollMonths.flatMap(month=>{const pay=s.locked.includes(month)&&s.closedPayroll?.[month]?s.closedPayroll[month]:payrollEmployees(s,month).map(e=>payroll(s,e,month));return pay.map(r=>({...r,month,locked:s.locked.includes(month)}));});
 const sum=(k:string)=>rows.reduce((n,r)=>n+Number((r as any)[k]||0),0),clocks=s.clocks.filter(c=>withinRange(c.date,range));
 const issue=url.searchParams.get('issue');
 if(issue){
  if(!['owner','admin'].includes(role))return json({error:'Không có quyền'},403);
  const page=Math.max(1,Math.floor(Number(url.searchParams.get('page'))||1)),offset=(page-1)*50;
  if(issue==='missing'){
   const found=clocks.filter(c=>!c.start||!c.end).sort((a,b)=>b.date.localeCompare(a.date));
   return json({rows:found.slice(offset,offset+50).map(c=>[c.date,s.employees.find(e=>e.id===c.employee)?.name||c.employee,c.start||'Thiếu giờ vào',c.end||'Thiếu giờ ra']),more:offset+50<found.length});
  }
  const sources:Record<string,string>={
   supplier:"SELECT date,id,quantity FROM pm_stock_receipts WHERE active=1 AND json_extract(record,'$.supplierPending')=1",
   price:"SELECT date,id,quantity FROM pm_stock_receipts WHERE active=1 AND purchase_id IS NULL AND json_extract(record,'$.supplierPending') IS NOT 1",
   leave:"SELECT date,employee,id FROM pm_order_leave WHERE status='pending'"};
  if(!Object.hasOwn(sources,issue))return json({error:'Bộ lọc không hợp lệ'},400);
  const found=await db.prepare(sources[issue]+" AND (?='' OR date>=?) AND (?='' OR date<=?) ORDER BY date DESC,id LIMIT 51 OFFSET ?").bind(range.from,range.from,range.to,range.to,offset).all<any>();
  return json({rows:found.results.slice(0,50).map(r=>issue==='leave'?[r.date,s.employees.find(e=>e.id===r.employee)?.name||r.employee,r.id]:[r.date,r.id,String(r.quantity)+' sản phẩm']),more:found.results.length>50});
 }
 const year=Number(holidayToday().slice(0,4));
 const result:any={range,updatedAt:new Date().toISOString(),version:stored.version,people:{active:s.employees.filter(e=>e.active).length,clockRows:clocks.length,missing:clocks.filter(c=>!c.start||!c.end).length},payroll:{earned:sum('earned'),advance:sum('advance'),net:sum('net'),employerInsurance:sum('employerInsurance'),employeeInsurance:sum('employeeInsurance'),holidayPay:sum('holidayPay'),holidayDays:sum('holidayDays'),holidayWorkedPay:sum('holidayWorkedPay'),rows,unlockedMonths:view.payrollMonths.filter(m=>!s.locked.includes(m))},holidays:{note:HOLIDAY_NOTE,upcoming:[...holidayCalendar(year),...holidayCalendar(year+1)].filter(d=>d.date>=holidayToday()).slice(0,8)}};
 if(['owner','admin'].includes(role)){
  const filter=' WHERE (?=\'\' OR date>=?) AND (?=\'\' OR date<=?)',args=[range.from,range.from,range.to,range.to];
  const safe=async(fn:()=>Promise<unknown>)=>{try{return await fn();}catch(e){return {error:'Chưa đọc được dữ liệu: '+(e as Error).message};}};
  const market=await safe(()=>marketplaceStatus(db));
  const [orders,pendingConfirmation,counts,returns,stock,purchasing,sync,leave,orderSources,costs,reviews]=await Promise.all([
   safe(()=>db.prepare('SELECT channel,COUNT(*) AS orders,COALESCE(SUM(quantity),0) AS quantity FROM pm_orders'+filter+' GROUP BY channel').bind(...args).all()),
   safe(async()=>{
    const row=await db.prepare("SELECT value FROM app_state WHERE id='packing-pos-snapshot'").first<{value:string}>();
    return row?JSON.parse(row.value):null;
   }),
   safe(()=>db.prepare('SELECT COUNT(*) AS rows,COALESCE(SUM(initial),0) AS initial,COALESCE(SUM(completed),0) AS completed FROM pm_order_counts'+filter).bind(...args).first()),
   safe(async()=>{const r=await readReturnBoards(db,range,1);return {total:r.stats.received,awaiting:r.stats.awaiting,awaitingAllTime:r.stats.awaitingAllTime,autoMatched:r.stats.autoMatched};}),
   safe(()=>db.prepare("SELECT COUNT(*) AS receipts,COALESCE(SUM(quantity),0) AS quantity,SUM(CASE WHEN json_extract(record,'$.supplierPending')=1 THEN 1 ELSE 0 END) AS pendingSupplier,SUM(CASE WHEN purchase_id IS NULL AND json_extract(record,'$.supplierPending') IS NOT 1 THEN 1 ELSE 0 END) AS unpriced FROM pm_stock_receipts"+filter+' AND active=1').bind(...args).first()),
   safe(async()=>{const u=new URL(url);u.searchParams.set('tab','debt');const p=await readPurchasing(db,u);return {suppliers:p.balances.length,opening:p.balances.reduce((n,b)=>n+(b.periodOpening??b.opening),0),imported:p.balances.reduce((n,b)=>n+b.imported,0),paid:p.balances.reduce((n,b)=>n+b.paid,0),balance:p.balances.reduce((n,b)=>n+b.balance,0)};}),
   safe(()=>syncStatus(db)),safe(()=>db.prepare("SELECT COUNT(*) AS pending FROM pm_order_leave"+filter+" AND status='pending'").bind(...args).first()),
   safe(()=>readPosSourceReport(env as any,range)),safe(()=>shopCosts(db,range)),safe(()=>profitReviews(db,range))
  ]);
  const packingSetting=await db.prepare("SELECT value FROM app_state WHERE id='packing-rate'").first<{value:string}>();
  const packingRate=packingSetting?Number(packingSetting.value):null;
  if(packingRate!==null && costs && typeof costs==='object' && !('error' in costs)){
   const rows=(orderSources as Awaited<ReturnType<typeof readPosSourceReport>>)?.rows;
   for(const [channel, cost] of Object.entries(costs as Awaited<ReturnType<typeof shopCosts>>)){
    const count=rows?.find(row=>row.id===channel)?.confirmed;
    const other=(cost.other??0)-(cost.packing??0);
    cost.packing=count==null?null:count*packingRate;
    cost.other=cost.packing===null?null:other+cost.packing;
   }
  }
  const shipping=await safe(()=>db.prepare("SELECT COUNT(*) sent,COUNT(CASE WHEN quantity=1 AND status IN (3,16) THEN 1 END) single FROM pm_orders"+filter+" AND channel='facebook' AND tracking<>'' AND status IN (2,3,16,4,15,5)").bind(...args).first());
  const taxSetting=await db.prepare("SELECT value FROM app_state WHERE id='overview-tax'").first<{value:string}>();
  if(role==='owner'){
   const incomeTax=await db.prepare("SELECT value FROM app_state WHERE id='business-income-tax'").first<{value:string}>();
   result.businessIncomeTax=incomeTax?JSON.parse(incomeTax.value):null;
  }
  Object.assign(result,{packingRate,shipping,overviewTax:taxSetting?JSON.parse(taxSetting.value):{rate:3,inclusive:[]}});
  Object.assign(result,{feePolicies:await safe(()=>feePolicies(db)),marketplaceSync:market,orders,pendingConfirmation,counts,returns,stock,purchasing,sync,leave,orderSources,costs,reviews,canReviewProfit:role==='owner'});
 }
 return json(result);
}catch(e){return json({error:(e as Error).message},500);}}
