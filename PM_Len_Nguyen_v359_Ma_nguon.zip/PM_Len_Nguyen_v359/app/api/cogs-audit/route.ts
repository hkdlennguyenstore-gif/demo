import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {permission,type State} from '../../../lib/payroll';
import {posGet} from '../../../lib/orders-store';
import {analyticsQuery} from '../../../lib/pos-source-report';
import {marketplaceAccounts} from '../../../lib/marketplace-orders';

export async function GET(){
 const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
 const user=await getChatGPTUser();
 if(!user)return json({error:'Cần đăng nhập'},401);
 const state=await env.DB!.prepare("SELECT value FROM app_state WHERE id='main'").first<{value:string}>();
 if(!state||!['owner','admin'].includes(permission(JSON.parse(state.value) as State,user.email)?.role||''))return json({error:'Cần quyền quản trị'},403);
 const key=env.PANCAKE_API_KEY,shop=env.PANCAKE_SHOP_ID;
 if(!key||!shop)return json({error:'Chưa kết nối POS'},503);
 const acct=marketplaceAccounts.find(a=>a.channel==='tiktok1')!;
 const day='2026-11-25',period=analyticsQuery({from:day,to:day});
 const source=JSON.stringify([[acct.source,acct.account]]);
 const params={page_size:'100','order_sources[]':source,updateStatus:'inserted_at',startDateTime:String(Date.parse(period.since)/1000),endDateTime:String(Date.parse(period.until)/1000)};
 try{
  const first=await posGet(key,shop,'orders',{...params,page_number:'1'});
  if(!Number.isSafeInteger(first.total_pages)||first.total_pages>5)return json({error:'Phạm vi quá lớn'},502);
  const remaining=await Promise.all(Array.from({length:Math.max(0,first.total_pages-1)},(_,i)=>posGet(key,shop,'orders',{...params,page_number:String(i+2)})));
  const orders=[first,...remaining].flatMap(p=>p.data).filter(row=>String(row.account)===acct.account);
  function details(item:Record<string,any>){
   const cost=(o:Record<string,any>)=>Object.fromEntries(Object.entries(o).filter(([k,v])=>/cost|import_price|purchase_price|cogs|^quantity$|^return_quantity$/i.test(k)&&(v===null||typeof v==='number'||typeof v==='string'&&/^\d+(\.\d+)?$/.test(v))));
   const v=item.variation_info??item.variation??{};
   const product=v.product??item.product??{};
   return {sku:v.custom_id??item.custom_id??item.sku??product.custom_id??null,productCode:product.custom_id??null,item:cost(item),variation:cost(v),product:cost(product)};
  }
  const report=await posGet(key,shop,'analytics/sale',{...period,'split_by[]':['Order.source','Variation.product_id'],'select_fields[]':['profit','revenue','cost','cost_of_goods','product_count']}).catch(()=>null);
  const grouped=report?.data.filter((row:any)=>String(row.account)===acct.account).map((row:any)=>({productId:row['Variation.product_id'],result:row.result,quantity:row.success?.product_count}))??[];
  return json({reportedOrders:first.total_entries,orderCount:orders.length,grouped,orders:orders.map(row=>({id:String(row.marketplace_order_id||row.marketplace_id_order||row.system_id||row.id),status:row.status,items:(Array.isArray(row.items)?row.items:[]).map(details)}))});
 }catch{return json({error:'POS chưa trả đủ dữ liệu'},502);}
}
