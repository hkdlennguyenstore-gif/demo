import {env} from 'cloudflare:workers';
import {constantEqual} from '../../../lib/a3-access';
import {syncA3Snapshot} from '../../../lib/a3-sync';
export const dynamic='force-dynamic';
export async function POST(req:Request){const expected=(env as any).A3_SYNC_TOKEN||'',given=req.headers.get('Authorization')?.replace(/^Bearer /,'')||'';if(!expected||!constantEqual(expected,given)||req.headers.has('origin'))return Response.json({error:'Không có quyền đồng bộ A3'},{status:403});try{if(Number(req.headers.get('content-length')||0)>2000000)throw Error('Nguồn quá lớn');const raw=await req.text();if(raw.length>2000000)throw Error('Nguồn quá lớn');return Response.json(await syncA3Snapshot(env.DB!,JSON.parse(raw)),{headers:{'Cache-Control':'no-store'}});}catch(e){return Response.json({error:(e as Error).message},{status:400});}}
