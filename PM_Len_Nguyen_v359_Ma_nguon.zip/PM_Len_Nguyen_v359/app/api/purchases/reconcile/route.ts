import {env} from 'cloudflare:workers';
import {purchasingUser} from '../route';
import {text,amount} from '../../../../lib/purchasing';
export const dynamic='force-dynamic';
const prefix='trang-invoice-review:';
const json=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(req:Request){try{
 await purchasingUser();const id=text(new URL(req.url).searchParams.get('id'),180);
 const row=await env.DB!.prepare('SELECT value,version FROM app_state WHERE id=?').bind(prefix+id).first<{value:string;version:number}>();
 return json(row?{...JSON.parse(row.value),version:row.version}:{version:0});
}catch{return json({error:'Chưa đọc được hồ sơ.'},403);}}
export async function POST(req:Request){try{
 if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Nguồn yêu cầu không hợp lệ.'},403);
 const u=await purchasingUser(),x=await req.json() as any,db=env.DB!;
 const id=text(x.id,180),invoice=await db.prepare("SELECT printedTotal FROM gmail_purchase_notices WHERE id=? AND status='documented'").bind(id).first<{printedTotal:string}>();
 if(!invoice)throw Error('Hóa đơn không còn hiệu lực.');
 const review={period:text(x.period,100),goods:text(x.goods,250),quantity:amount(Number(x.quantity)),value:amount(Number(x.value)),basis:text(x.basis,500),actor:u.email,time:new Date().toISOString()};
 if(!review.period||!review.goods||!review.quantity||!review.value||!review.basis)throw Error('Bổ sung đợt giao, nhóm hàng, số lượng, giá trị và căn cứ từ nhà cung cấp.');
 const result=await db.prepare('INSERT INTO app_state(id,value,version) SELECT ?,?,1 WHERE ?=0 OR EXISTS(SELECT 1 FROM app_state WHERE id=? AND version=?) ON CONFLICT(id) DO UPDATE SET value=excluded.value,version=app_state.version+1 WHERE app_state.version=?')
 .bind(prefix+id,JSON.stringify(review),x.version,prefix+id,x.version,x.version).run();
 if(!result.meta.changes)return json({error:'Hồ sơ vừa thay đổi. Mở lại trước khi lưu.'},409);
 return json({...review,version:x.version+1});
}catch(e){return json({error:(e as Error).message},400);}}
