import {preparePurchasing} from '../../../../lib/purchasing-store';
import {env} from 'cloudflare:workers';
import {purchasingUser} from '../route';
import {type PurchasingState} from '../../../../lib/purchasing';
export const dynamic='force-dynamic';
export async function GET(req:Request){try{await purchasingUser();await preparePurchasing(env.DB!);const key=new URL(req.url).searchParams.get('key')||'';const allowed=await env.DB!.prepare('SELECT id FROM pm_purchase_docs WHERE receipt_key=? LIMIT 1').bind(key).first();if(!allowed)return Response.json({error:'Không tìm thấy chứng từ'},{status:404});const file=await env.BUCKET?.get(key);if(!file)return Response.json({error:'Tệp không tồn tại'},{status:404});return new Response(file.body,{headers:{'Content-Type':file.httpMetadata?.contentType||'application/octet-stream','Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(file.customMetadata?.name||'chung-tu'),'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"sandbox; default-src 'none'"}});}catch(e){return Response.json({error:(e as Error).message},{status:403});}}
