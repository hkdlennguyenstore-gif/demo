import {env} from 'cloudflare:workers';
import {importAttendance,summary} from '../../../lib/attendance-import';
import type {State} from '../../../lib/payroll';
export const dynamic='force-dynamic';
export async function POST(req:Request){
 const expected=(env as any).ATTENDANCE_IMPORT_TOKEN||'',given=req.headers.get('Authorization')?.replace(/^Bearer /,'')||'';let diff=expected.length^given.length;for(let i=0;i<expected.length;i++)diff|=expected.charCodeAt(i)^(given.charCodeAt(i)||0);
 if(!expected||diff||req.headers.has('origin'))return Response.json({error:'Không có quyền'},{status:403});
 try{const input:any=await req.json(),row=await env.DB!.prepare('SELECT value,version FROM app_state WHERE id=?').bind('main').first<{value:string,version:number}>();if(!row)throw Error('Chưa có dữ liệu');const current=JSON.parse(row.value) as State;
 if(input.action==='status')return Response.json({version:row.version,employees:current.employees,locked:current.locked,clocks:current.clocks,adjustments:current.adjustments,summary:summary(current)});
 if(!['preview','apply'].includes(input.action))throw Error('Thao tác không hợp lệ');const {s,report}=importAttendance(current,input);
 if(input.action==='apply'&&!report.replayed){if(input.version!==row.version)return Response.json({error:'Dữ liệu thay đổi, cần đối chiếu lại'},{status:409});const written=await env.DB!.prepare('UPDATE app_state SET value=?,version=version+1 WHERE id=? AND version=?').bind(JSON.stringify(s),'main',row.version).run();if(!written.meta.changes)return Response.json({error:'Dữ liệu vừa thay đổi'},{status:409});}
 return Response.json({ok:true,version:row.version,applied:input.action==='apply',...report});
 }catch(e){return Response.json({error:(e as Error).message},{status:400});}
}
