'use client';
import {useEffect,useRef,useState} from 'react';
import {trangId,afterPayment,directRecipient} from '../../lib/trang-payment';
import {readTransferBill} from '../../components/finance/read-transfer-bill';
import {PaymentSupplier} from './payment-supplier';
const money=(v:number)=>v.toLocaleString('vi-VN')+' đ';
export default function TrangPayment({suppliers,onSupplier,onFile,onReading}:any){
 const [excerpt,setExcerpt]=useState('');
 const [day,date]=useState(''),[sum,amount]=useState(''),[who,name]=useState(''),[confirmed,confirm]=useState(false),[msg,status]=useState('');
 const seq=useRef(0);useEffect(()=>()=>{seq.current++;},[]);
 const before=suppliers.find((s:{id:string})=>s.id===trangId)?.currentBalance??null;
 async function read(file?:File){const n=++seq.current;onFile();setExcerpt('');onReading(!!file);date('');amount('');name('');confirm(false);status('');if(!file)return;
 try{status('Đang đọc chứng từ…');const data=await readTransferBill(file);if(n!==seq.current)return;
 date(v=>v||data.date);amount(v=>v||(data.amount?String(data.amount):''));name(v=>v||data.recipient);status(data.message);setExcerpt(data.excerpt);
 }catch(e){if(n===seq.current)status('Chưa đọc được chứng từ. '+(e instanceof Error?e.message:'Vui lòng chọn lại ảnh.'));}finally{if(n===seq.current)onReading(false);}}
 const applied=directRecipient(who)||confirmed, paid=Number(sum)||0, next=afterPayment(before??0,paid,applied);
 return <><PaymentSupplier suppliers={suppliers} value={trangId} change={onSupplier}/><label>Ảnh chuyển khoản / PDF<input type="file" name="file" accept="image/png,image/jpeg,image/webp,application/pdf" onChange={e=>void read(e.target.files?.[0])}/></label>
 {msg&&<small className="full" role="status">{msg}</small>}
 {excerpt&&<details className="full"><summary>Xem chữ PM đọc được từ bill</summary><p style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{excerpt}</p></details>}
 <label>Ngày chuyển<input type="date" name="date" required value={day} onChange={e=>date(e.target.value)}/></label><label>Số tiền đã chuyển (đ)<input type="number" min="1" step="1" required name="amount" value={sum} onChange={e=>amount(e.target.value)}/></label>
 <label className="full">Người nhận<input name="recipient" required value={who} onChange={e=>{name(e.target.value);confirm(false);}}/></label>
 {who&&!directRecipient(who)&&<label className="full pay-check"><input type="checkbox" name="confirmTrang" checked={confirmed} onChange={e=>confirm(e.target.checked)}/>Xác nhận khoản chuyển cho {who} dùng trả nợ Trang</label>}
 <div className="full purch-total" aria-live="polite">Nợ trước {before===null?'—':money(Math.max(before,0))}{before!==null&&before<0?' · Trả trước '+money(-before):''} → Trả lần này {money(paid)} → Nợ còn lại {before===null?'—':money(next.debt)}{before!==null&&next.advance>0?' · Trả trước '+money(next.advance):''}{who&&!applied?' · Chờ đối chiếu':''}</div>
 <details className="full"><summary>Ghi chú và mã giao dịch</summary><label>Mã giao dịch<input name="transaction"/></label><textarea name="note" aria-label="Ghi chú"/></details></>;
}
