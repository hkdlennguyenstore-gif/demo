import {redirect} from 'next/navigation';
import Warehouse from '../nhap-kho/warehouse';
import Purchasing from './purchasing';
export default async function Page({searchParams}:{searchParams:Promise<Record<string,string|undefined>>}){const q=await searchParams;if(q.view==='suppliers'){const params=new URLSearchParams();for(const [key,value] of Object.entries(q))if(typeof value==='string')params.set(key,value);params.set('view','debt');redirect('/nhap-hang?'+params.toString()+'#danh-sach-nha-cung-cap');}if(q.view==='prices')redirect('/gia-nhap');return q.view&&['debt','payments','audit','prices','legacy'].includes(q.view)?<Purchasing/>:<Warehouse/>;}
