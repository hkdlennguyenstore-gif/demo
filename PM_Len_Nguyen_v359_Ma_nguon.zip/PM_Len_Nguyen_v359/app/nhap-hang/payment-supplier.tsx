export function PaymentSupplier({suppliers,value,change}:{suppliers:{id:string;name:string}[];value:string;change:(v:string)=>void}){
 return <label>Nhà cung cấp<select name="supplier" value={value} onChange={e=>change(e.target.value)}>{suppliers.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>;
}
