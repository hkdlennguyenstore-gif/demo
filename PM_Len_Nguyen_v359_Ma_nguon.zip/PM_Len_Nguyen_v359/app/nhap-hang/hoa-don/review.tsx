'use client';
import {useState} from 'react';
export default function Review({id,total}:{id:string;total:number}){
 const [record,setRecord]=useState<any>(null),[msg,message]=useState(''),[busy,working]=useState(false);
 async function load(){try{const r=await fetch('/api/purchases/reconcile?id='+encodeURIComponent(id),{cache:'no-store'});if(!r.ok)throw Error();setRecord(await r.json());}catch{message('Chưa tải được hồ sơ.');}}
 async function save(e:React.FormEvent<HTMLFormElement>){e.preventDefault();working(true);const f=new FormData(e.currentTarget);
 try{const r=await fetch('/api/purchases/reconcile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...Object.fromEntries(f),id,version:record.version})});
 const data=await r.json();if(!r.ok)throw Error(data.error);setRecord(data);message('Đã lưu đối chiếu.');}catch(e){message((e as Error).message);}finally{working(false);}}
 return <details onToggle={e=>{if(e.currentTarget.open&&!record)void load();}}><summary>Đối chiếu theo đợt giao / kỳ chốt nợ</summary>{record&&<form className="form-grid" onSubmit={save}>
 <label>Đợt giao / kỳ chốt<input name="period" defaultValue={record.period} required/></label><label>Nhóm hàng theo chứng từ<input name="goods" defaultValue={record.goods} required/></label>
 <label>Số lượng đối chiếu<input name="quantity" type="number" min="1" defaultValue={record.quantity} required/></label><label>Giá trị theo bảng giao (đ)<input name="value" type="number" min="1" defaultValue={record.value} required/></label>
 <label className="full">Bảng giao hàng / xác nhận của nhà cung cấp<textarea name="basis" defaultValue={record.basis} required placeholder="Số bảng giao, ngày xác nhận hoặc đường dẫn chứng từ"/></label>
 {record.version>0&&<p>Chênh so với hóa đơn: {(record.value-total).toLocaleString('vi-VN')} đ</p>}<button className="btn" disabled={busy}>Lưu đối chiếu</button></form>}{msg&&<p role="status">{msg}</p>}</details>;
}
