'use client';
import Review from './review';
import {useEffect,useState} from 'react';
type Row={id:string;supplier:string;series:string;number:string;date:string;printedTotal:string;status:string;related:string;mailId:string;received:string;originalLines?:string;originalFile?:string};
export default function PurchaseInvoices(){
 const [rows,setRows]=useState<Row[]|null>(null),[error,setError]=useState('');
 useEffect(()=>{fetch('/api/gmail-evidence?purchases=1',{cache:'no-store'}).then(async r=>{
  if(!r.ok)throw Error(r.status===403?'Cần đăng nhập bằng tài khoản chủ shop.':'Chưa tải được danh sách hóa đơn.');
  const data=await r.json() as {rows:Row[]};setRows(data.rows);
 }).catch(e=>setError(e.message));},[]);
 const invoices=new Map<string,Row[]>();
 for(const row of rows||[])invoices.set(row.id,[...(invoices.get(row.id)||[]),row]);
 return <main style={{maxWidth:900,margin:'auto',padding:20}}><a href="/nhap-hang">Quay lại Nhập hàng</a><h1>Hóa đơn nhà cung cấp từ Gmail</h1>
 {error||(!rows?'Đang tải…':!rows.length?'Chưa có hóa đơn nhập hàng từ Gmail.':'')}
 {Array.from(invoices.values()).map(group=>{const p=group[0];return <section key={p.id} style={{padding:'12px 0',borderBottom:'1px solid #ddd'}}>
 <strong>{p.supplier} · Hóa đơn số {p.number}</strong><p>{p.series} · {p.date} · Tổng trên thông báo {Number(p.printedTotal).toLocaleString('vi-VN')}</p>
 <p>{p.status==='superseded'?'Đã được thay thế bằng hóa đơn số '+p.related.split('|').pop():(p.related?'Thay thế hóa đơn số '+p.related.split('|').pop()+'. ':'')+(p.status==='documented'?'Đã ghi nhận mua hàng theo hóa đơn':'Chờ bổ sung thông tin hóa đơn')}</p>
 {p.originalLines&&<p>Tên hàng trên hóa đơn · {(JSON.parse(p.originalLines) as string[]).join(' · ')}</p>}
 {p.status==='documented'&&<Review id={p.id} total={Number(p.printedTotal)}/>}
 {group.some(r=>r.originalFile)&&<p><a href={'/api/gmail-evidence?linkFile='+encodeURIComponent(group.find(r=>r.originalFile)!.originalFile!)}>Tải bản hóa đơn từ cổng phát hành</a></p>}
 {group.map((r,i)=><div key={r.mailId}><a href={'/api/gmail-evidence?id='+encodeURIComponent(r.mailId)}>Tải thư gốc · lần gửi {i+1}</a></div>)}</section>})}</main>
}
