'use client';
import {useEffect,useRef,useState} from 'react';
import DocumentLinks from '../../components/finance/document-links';
import {rangeLabel} from '../../lib/date-range';
import {displayDate} from '../../lib/display-date';
import type {Payment,Receipt} from '../../lib/purchasing';
type Selection={id:string,name:string,from:string,to:string,total:number};
type Entry=Payment&{purchaseReceipt?:Receipt,invoiceId?:string,invoiceNumber?:string};
type Result={rows:Entry[],more:boolean,documents:Record<string,{label:string,url:string}[]>};
const money=(v:number)=>v.toLocaleString('vi-VN')+' đ';
function receiptUrl(key:string){return '/api/purchases/receipt?key='+encodeURIComponent(key);}
export default function PaymentHistory({selection,onClose}:{selection:Selection,onClose:()=>void}){
 const dialog=useRef<HTMLDialogElement>(null);
 const [page,setPage]=useState(1),[data,setData]=useState<Result|null>(null),[error,setError]=useState('');
 useEffect(()=>{dialog.current?.showModal();},[]);
 useEffect(()=>{
  const ctrl=new AbortController();
  setData(null);setError('');
  const query=new URLSearchParams({mode:'payment-history',supplier:selection.id,from:selection.from,to:selection.to,page:String(page)});
  fetch('/api/purchases?'+query,{cache:'no-store',signal:ctrl.signal}).then(async response=>{
   const value=await response.json();if(!response.ok)throw Error(value.error||'Chưa tải được lịch sử');
   if(!ctrl.signal.aborted)setData(value);
  }).catch(e=>{if(!ctrl.signal.aborted)setError(e.message);});
  return ()=>ctrl.abort();
 },[selection,page]);
 return <dialog ref={dialog} className="payment-history-dialog" onClose={onClose} aria-labelledby="payment-history-title">
 <header><h2 id="payment-history-title">Lịch sử thanh toán · {selection.name}</h2><button type="button" className="btn" onClick={()=>dialog.current?.close()}>Đóng</button></header>
 <p>{rangeLabel(selection)} · <b>{money(selection.total)}</b></p>
 {error?<p role="alert">{error}</p>:!data?<p role="status">Đang tải thanh toán…</p>:<>
 {data.rows.length===0&&<p>Chưa có thanh toán trong khoảng này.</p>}
 {data.rows.map(row=>{
  const invoiceIds=new Set([row.invoiceId,...(row.allocations||[]).map(a=>a.id)].filter(Boolean));
  const links=new Map<string,string>();
  if(row.receipt?.key)links.set(receiptUrl(row.receipt.key),'Bill thanh toán · '+row.receipt.name);
  if(row.purchaseReceipt?.key)links.set(receiptUrl(row.purchaseReceipt.key),'Chứng từ nhập hàng · '+row.purchaseReceipt.name);
  for(const id of invoiceIds){for(const doc of data.documents['invoice:'+id]||[])links.set(doc.url,doc.label);}
  return <article key={row.id}><header><strong>{displayDate(row.date)}</strong><b>{money(row.amount)}</b></header>
  <p>{[row.method,row.recipient,row.transaction].filter(Boolean).join(' · ')}</p>
  {row.note&&<p>{row.note}</p>}{row.invoiceNumber&&<p>Hóa đơn {row.invoiceNumber}</p>}
  {links.size>0&&<DocumentLinks previewLabel="Xem bill" documents={Array.from(links,([url,label])=>({url,label,kind:url.startsWith('/api/')?'file':'source'}))}/>}
  {!links.size&&<small>Chưa có tệp đính kèm cho khoản này.</small>}</article>;
 })}
 {(page>1||data.more)&&<footer><button disabled={page===1} onClick={()=>setPage(page-1)}>Trước</button> Trang {page} <button disabled={!data.more} onClick={()=>setPage(page+1)}>Sau</button></footer>}
 </>}</dialog>;
}
