'use client';
import {useEffect,useRef,useState} from 'react';
import {readTransferBill} from '../../components/finance/read-transfer-bill';
import './payment-fields.css';
import TrangPayment from './trang-payment';
import {trangId,afterPayment} from '../../lib/trang-payment';

type Invoice={id:string;number:string;supplier:string;date:string;remaining:number};
type Props={suppliers:{id:string;name:string;currentBalance?:number}[];initial:string;onReading:(busy:boolean)=>void;onFile:()=>void};
const money=(amount:number)=>amount.toLocaleString('vi-VN')+' đ';
export default function PaymentFields({suppliers,initial,onReading,onFile}:Props){
 const [excerpt,setExcerpt]=useState('');
 const [supplier,setSupplier]=useState(initial||suppliers[0]?.id||''),[options,setOptions]=useState<Invoice[]>([]);
 const [optionError,setOptionError]=useState(''),[selected,select]=useState<Record<string,number>>({});
 const [mode,setMode]=useState('expense'),[review,setReview]=useState('pending'),[date,setDate]=useState(''),[status,setStatus]=useState('');
 const [manual,setManual]=useState(''),[hasFile,setFile]=useState(false),[paid,setPaid]=useState('');
 const [recipient,setRecipient]=useState('');
 const readSeq=useRef(0);
 useEffect(()=>{const ctrl=new AbortController();fetch('/api/purchases?mode=invoice-options',{cache:'no-store',signal:ctrl.signal}).then(async r=>{
  if(!r.ok)throw Error();setOptions((await r.json() as Invoice[]).filter(i=>i.remaining>0));
 }).catch(()=>{if(!ctrl.signal.aborted)setOptionError('Chưa tải được hóa đơn. Đóng và mở lại phiếu để thử lại.');});return()=>{ctrl.abort();readSeq.current++;};},[]);
 const chosen=options.filter(i=>i.id in selected),sum=chosen.reduce((n,i)=>n+selected[i.id],0);
 const name=suppliers.find(s=>s.id===supplier)?.name||'';
 const before=suppliers.find(s=>s.id===supplier)?.currentBalance;
 const next=afterPayment(before??0,Number(paid)||sum,true);
 const aliases=[...new Set(chosen.filter(i=>i.supplier.toLowerCase()!==name.toLowerCase()).map(i=>i.supplier))];
 const toggle=(i:Invoice)=>select(prev=>{const next={...prev};if(i.id in next)delete next[i.id];else next[i.id]=paid?Math.min(i.remaining,Math.max(0,Number(paid)-Object.values(prev).reduce((a,b)=>a+b,0))):i.remaining;return next;});
 async function read(file?:File){
  const seq=++readSeq.current;onFile();setExcerpt('');setFile(Boolean(file));setStatus('');onReading(Boolean(file));
  if(hasFile){setDate('');setPaid('');setRecipient('');}
  if(!file)return;
  setStatus('Đang đọc chứng từ…');
  try{
   const data=await readTransferBill(file);
   if(seq!==readSeq.current)return;
   setDate(v=>v||data.date);setPaid(v=>v||(data.amount?String(data.amount):''));setRecipient(v=>v||data.recipient);
   setStatus(data.message);setExcerpt(data.excerpt);
  }catch(e){if(seq===readSeq.current)setStatus('Chưa đọc được chứng từ. '+(e instanceof Error?e.message:'Vui lòng chọn lại ảnh.'));}
  finally{if(seq===readSeq.current)onReading(false);}
 }
 if(supplier===trangId)return <TrangPayment suppliers={suppliers} onSupplier={(v:string)=>{onReading(false);setSupplier(v);onFile();setExcerpt('');}} onFile={onFile} onReading={onReading}/>;
 return <>
 <label>Nhà cung cấp<select name="supplier" value={supplier} onChange={e=>{readSeq.current++;onReading(false);onFile();setExcerpt('');setFile(false);setDate('');setPaid('');setRecipient('');setStatus('');setSupplier(e.target.value);select({});setReview('pending');}}>{suppliers.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
 <label>Hình thức<select name="method"><option>Chuyển khoản</option><option>Tiền mặt</option></select></label>
 <label className="full">Ảnh chuyển khoản hoặc hóa đơn thanh toán<input key={supplier} name="file" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={e=>void read(e.target.files?.[0])}/></label>
 {excerpt&&<details className="full"><summary>Xem chữ PM đọc được từ bill</summary><p style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{excerpt}</p></details>}
 <label>Ngày thanh toán<input required type="date" name="date" value={date} onChange={e=>setDate(e.target.value)}/>{status&&<small role="status">{status}</small>}</label>
 <label>Người nhận<input name="recipient" maxLength={160} value={recipient} onChange={e=>setRecipient(e.target.value)}/></label>
 <label>Mã giao dịch / số phiếu<input name="transaction" required={hasFile&&mode==='expense'} maxLength={120}/></label>
 <details className="full pay-invoices"><summary>Đính kèm hóa đơn (tùy chọn){chosen.length?' · '+chosen.length+' đã chọn':''}</summary>
 {optionError&&<small role="alert">{optionError}</small>}
 <div className="pay-invoice-list">{options.map(i=><div key={i.id} className="pay-invoice-line"><label><input type="checkbox" checked={i.id in selected} onChange={()=>toggle(i)}/><span><strong>HĐ {i.number}</strong> · {i.date.split('-').reverse().join('/')}<small>{i.supplier} · còn {money(i.remaining)}</small></span></label>
 {i.id in selected&&<label className="pay-share">Trả kỳ này (đ)<input aria-label={'Số tiền trả hóa đơn '+i.number} type="number" required min="1" max={i.remaining} value={selected[i.id]||''} onChange={e=>select({...selected,[i.id]:Number(e.target.value)})}/></label>}</div>)}</div>
 {!chosen.length&&<label>Số hóa đơn nhập tay (nếu có)<input name="invoiceNumber" value={manual} onChange={e=>setManual(e.target.value)}/></label>}
 </details>
 <input type="hidden" name="allocations" value={JSON.stringify(chosen.map(i=>({id:i.id,amount:selected[i.id]})))}/>
 {aliases.length>0&&<label key={supplier+aliases.join('|')} className="full pay-check"><input type="checkbox" name="confirmSource" required/>Hóa đơn của {aliases.join(', ')} thuộc nguồn {name}</label>}
 <label>Số tiền thanh toán (đ)<input name="amount" type="number" required min="1" value={paid||(chosen.length?sum:'')} onChange={e=>setPaid(e.target.value)}/>{chosen.length>0&&<small>Đã phân bổ {money(sum)} cho {chosen.length} hóa đơn{paid&&Number(paid)!==sum?' · kiểm tra phần chênh lệch':''}</small>}</label>
 {before!==undefined&&<div className="full purch-total" aria-live="polite">Nợ hiện tại {money(Math.max(before,0))}{before<0&&' · Trả trước '+money(-before)} → Trả lần này {money(Number(paid)||sum)} → Nợ còn lại {money(next.debt)}{next.advance>0&&' · Trả trước '+money(next.advance)}</div>}
 <label>Ghi nhận<select value={mode} onChange={e=>{setMode(e.target.value);setReview('pending');}}><option value="expense">Công nợ + chi phí khi có chứng từ</option><option value="debt">Chỉ công nợ</option></select></label>
 {mode==='expense'&&<input type="hidden" name="bookExpense" value="on"/>}
 {(chosen.length>0||manual.trim())&&<label className="full">Duyệt chứng từ<select value={review} onChange={e=>setReview(e.target.value)}><option value="pending">Chưa duyệt</option><option value="invoice">Hóa đơn hợp lệ</option>{mode==='expense'&&<option value="both">Hóa đơn và chi phí hợp lệ</option>}</select>
 {review!=='pending'&&<input type="hidden" name="invoiceValid" value="on"/>}{review==='both'&&<input type="hidden" name="expenseValid" value="on"/>}</label>}
 <details className="full"><summary>Ghi chú</summary><textarea name="note" maxLength={500} aria-label="Ghi chú"/></details>
 </>;
}
