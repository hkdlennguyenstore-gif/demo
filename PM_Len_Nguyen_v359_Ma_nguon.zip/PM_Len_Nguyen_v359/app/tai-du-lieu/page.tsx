import PmShell from '../../components/pm-shell';
import DataDownloads from '../../components/finance/data-downloads';
export default function DownloadPage(){return <PmShell active="expenses" title="Chi phí · Tải dữ liệu & chứng từ"><main className="warehouse-main"><div className="page-heading"><div><a href="/chi-phi#tai-du-lieu">Chi phí</a><h1>Tải dữ liệu & chứng từ</h1></div></div><section className="panel"><DataDownloads/></section></main></PmShell>;}
