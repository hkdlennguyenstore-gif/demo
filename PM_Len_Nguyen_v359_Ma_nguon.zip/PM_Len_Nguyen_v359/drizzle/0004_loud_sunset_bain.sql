CREATE TABLE `pm_drive_ads_rows` (
	`id` text PRIMARY KEY NOT NULL,
	`source` text NOT NULL,
	`channel` text NOT NULL,
	`date` text NOT NULL,
	`amount` integer NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`record` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `pm_drive_ads_sources` (
	`id` text PRIMARY KEY NOT NULL,
	`record` text NOT NULL
);
