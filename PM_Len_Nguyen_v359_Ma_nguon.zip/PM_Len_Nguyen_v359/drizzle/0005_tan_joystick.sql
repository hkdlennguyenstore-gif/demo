CREATE TABLE `pm_a4_live` (
	`id` text PRIMARY KEY NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`record` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `pm_a4_plans` (
	`id` text PRIMARY KEY NOT NULL,
	`lot` text NOT NULL,
	`date` text NOT NULL,
	`status` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`record` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `pm_a4_requests` (
	`id` text PRIMARY KEY NOT NULL,
	`actor` text NOT NULL,
	`record` text NOT NULL
);
