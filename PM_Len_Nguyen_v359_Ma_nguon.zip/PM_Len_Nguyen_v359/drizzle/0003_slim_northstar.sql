CREATE TABLE `pm_ads_months` (
	`id` text PRIMARY KEY NOT NULL,
	`record` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `pm_ads_reviews` (
	`id` text PRIMARY KEY NOT NULL,
	`record` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `pm_ads_sync` (
	`id` text PRIMARY KEY NOT NULL,
	`record` text NOT NULL,
	`lease_until` integer DEFAULT 0 NOT NULL,
	`token` text DEFAULT '' NOT NULL
);
