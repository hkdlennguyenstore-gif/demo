CREATE TABLE `pm_finance_audit` (
	`id` text PRIMARY KEY NOT NULL,
	`time` text NOT NULL,
	`actor` text NOT NULL,
	`action` text NOT NULL,
	`record` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `pm_finance_docs` (
	`id` text PRIMARY KEY NOT NULL,
	`kind` text NOT NULL,
	`date` text NOT NULL,
	`end_date` text NOT NULL,
	`channel` text NOT NULL,
	`status` text NOT NULL,
	`record` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`fingerprint` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pm_finance_docs_fingerprint_unique` ON `pm_finance_docs` (`fingerprint`);--> statement-breakpoint
CREATE TABLE `pm_finance_requests` (
	`id` text PRIMARY KEY NOT NULL,
	`base_version` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pm_finance_requests_base_version_unique` ON `pm_finance_requests` (`base_version`);