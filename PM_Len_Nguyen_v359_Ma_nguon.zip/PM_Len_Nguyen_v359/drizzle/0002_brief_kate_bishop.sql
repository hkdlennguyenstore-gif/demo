CREATE TABLE `pm_payroll_cost_reviews` (
	`id` text PRIMARY KEY NOT NULL,
	`record` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL
);
