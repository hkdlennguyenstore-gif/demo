const sizes=[27,28,29,30,31,32,33,34,35],sum=values=>values.reduce((n,v)=>n+v,0);
const cutDisplayDate=value=>value?value.split('-').reverse().join('/'):'—';
const cutColorLines=row=>row.colors;
let shopLogo,preparing;
async function prepare(){
 if(!preparing)preparing=(async()=>{
  const faces=await Promise.all([new FontFace('LNCutPDF','url(/a4/LNCutPDF.ttf)',{weight:'400'}).load(),new FontFace('LNCutPDF','url(/a4/LNCutPDF-Bold.ttf)',{weight:'700'}).load()]);faces.forEach(face=>document.fonts.add(face));
  shopLogo=new Image();shopLogo.src='/a4/len-nguyen-logo.png';await shopLogo.decode();
 })().catch(e=>{preparing=null;throw e});
 await preparing;
}
function cutPdfBytes(canvases){
 const encoder=new TextEncoder(),chunks=[],offsets=[0];let length=0;
 const add=data=>{const bytes=typeof data==='string'?encoder.encode(data):data;chunks.push(bytes);length+=bytes.length};
 const object=(id,body)=>{offsets[id]=length;add(id+' 0 obj\n');add(body);add('\nendobj\n')};
 add('%PDF-1.4\n');
 object(1,'<< /Type /Catalog /Pages 2 0 R >>');
 object(2,'<< /Type /Pages /Count '+canvases.length+' /Kids ['+canvases.map((_,i)=>(3+i*3)+' 0 R').join(' ')+'] >>');
 canvases.forEach((canvas,i)=>{
  const pageId=3+i*3,imageId=pageId+1,contentId=pageId+2;
  const jpeg=Uint8Array.from(atob(canvas.toDataURL('image/jpeg',0.95).split(',')[1]),c=>c.charCodeAt(0));
  object(pageId,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im0 '+imageId+' 0 R >> >> /Contents '+contentId+' 0 R >>');
  offsets[imageId]=length;add(imageId+' 0 obj\n<< /Type /XObject /Subtype /Image /Width '+canvas.width+' /Height '+canvas.height+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+jpeg.length+' >>\nstream\n');add(jpeg);add('\nendstream\nendobj\n');
  const content='q\n595.28 0 0 841.89 0 0 cm\n/Im0 Do\nQ\n';
  object(contentId,'<< /Length '+encoder.encode(content).length+' >>\nstream\n'+content+'endstream');
 });
 const start=length,count=3+canvases.length*3;
 add('xref\n0 '+count+'\n0000000000 65535 f \n');
 for(let i=1;i<count;i++)add(String(offsets[i]).padStart(10,'0')+' 00000 n \n');
 add('trailer\n<< /Size '+count+' /Root 1 0 R >>\nstartxref\n'+start+'\n%%EOF\n');
 const result=new Uint8Array(length);let cursor=0;chunks.forEach(chunk=>{result.set(chunk,cursor);cursor+=chunk.length});return result;
}
function cutPlanPdf(row){
 const pages=[],W=620,H=877,M=44,bottom=805;let ctx,y;
 const text=(value,x,top,size=12,bold=false,color='#163c38')=>{ctx.font=(bold?'700 ':'400 ')+size+'px LNCutPDF, Arial, sans-serif';ctx.fillStyle=color;ctx.fillText(String(value),x,top)};
 const line=(top)=>{ctx.strokeStyle='#d5dfd9';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(M,top);ctx.lineTo(W-M,top);ctx.stroke()};
 const newPage=()=>{
  const canvas=document.createElement('canvas');canvas.width=W*2;canvas.height=H*2;ctx=canvas.getContext('2d');ctx.scale(2,2);ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);pages.push(canvas);
  ctx.drawImage(shopLogo,M,22,190,95);
  text('PHIẾU CẮT HÀNG',255,56,24,true);
  text('LÊN NGUYỄN STORE',255,80,14,true);text('ĐƠN VỊ ĐẶT HÀNG',255,99,9,false,'#5f7067');
  const lot='LÔ SỐ: '+row.lot;let lotSize=27;
  ctx.font='700 '+lotSize+'px LNCutPDF, Arial, sans-serif';
  while(ctx.measureText(lot).width>W-M*2-28&&lotSize>12){lotSize--;ctx.font='700 '+lotSize+'px LNCutPDF, Arial, sans-serif'}
  ctx.fillStyle='#e8f1fb';ctx.fillRect(M,132,W-M*2,50);ctx.strokeStyle='#94b4d8';ctx.lineWidth=1;ctx.strokeRect(M,132,W-M*2,50);y=216;
  text(lot,M+14,166,lotSize,true,'#124e89');
 };
 const ensure=height=>{if(y+height>bottom)newPage()};
 const wrap=(value,width,size=12,bold=false)=>{
  ctx.font=(bold?'700 ':'400 ')+size+'px LNCutPDF, Arial, sans-serif';const lines=[];
  String(value).replace(/\r\n?/g,'\n').split('\n').forEach(paragraph=>{let current='';for(const ch of paragraph){if(current&&ctx.measureText(current+ch).width>width){lines.push(current);current=''}current+=ch}lines.push(current)});return lines;
 };
 const field=(label,value)=>{const lines=wrap(value||'—',W-M*2-136);lines.forEach((part,i)=>{ensure(22);if(i===0)text(label,M,y,11,false,'#5f7067');text(part,M+136,y,12,true);y+=22});y+=3};
 newPage();
 field('Ngày kế hoạch',cutDisplayDate(row.date));field('Nhà cung cấp',row.supplier);field('Loại hàng',row.type||'Chưa xác định');field('Mã hàng của shop',row.code);field('Số màu trong lô',cutColorLines(row).length+' màu');field('Ngày hẹn giao',cutDisplayDate(row.due));
 y+=12;ensure(112);text('SỐ LƯỢNG YÊU CẦU THEO MÀU VÀ SIZE',M,y,12,true);y+=15;
 const colorWidth=116,totalWidth=70,cell=(W-M*2-colorWidth-totalWidth)/9;
 const center=(value,x,width,top,size=10,bold=false)=>{const string=String(value);ctx.font=(bold?'700 ':'400 ')+size+'px LNCutPDF, Arial, sans-serif';while(ctx.measureText(string).width>width-6&&size>7){size-=0.5;ctx.font=(bold?'700 ':'400 ')+size+'px LNCutPDF, Arial, sans-serif'}text(string,x+(width-ctx.measureText(string).width)/2,top,size,bold)};
 const gridLines=height=>{
  ctx.strokeStyle='#879bad';ctx.lineWidth=0.8;ctx.strokeRect(M,y,W-2*M,height);
  ctx.beginPath();
  for(let i=0;i<=sizes.length;i++){const x=M+colorWidth+i*cell;ctx.moveTo(x,y);ctx.lineTo(x,y+height);}
  ctx.stroke();
 };
 const tableHeader=()=>{ctx.fillStyle='#e8f1ec';ctx.fillRect(M,y,W-M*2,30);text('Màu sắc',M+6,y+20,10,true);sizes.forEach((size,i)=>center(size,M+colorWidth+i*cell,cell,y+20,10,true));center('Tổng',W-M-totalWidth,totalWidth,y+20,10,true);gridLines(30);y+=30};
 const tableRow=(label,qty,bold=false)=>{
  const lines=wrap(label,colorWidth-12,10,bold),height=Math.max(34,lines.length*15+14);
  if(y+height>bottom){newPage();text('Lô '+row.lot+' · '+row.code,M,y,10,true);y+=20;tableHeader()}
  lines.forEach((part,i)=>text(part,M+6,y+21+i*15,10,bold));sizes.forEach((_,i)=>center(qty[i]||'',M+colorWidth+i*cell,cell,y+22,10,bold));center(sum(qty),W-M-totalWidth,totalWidth,y+22,11,true);gridLines(height);y+=height;
 };
 tableHeader();cutColorLines(row).forEach(color=>tableRow(color.color,color.qty));tableRow('TỔNG LÔ',row.qty,true);y+=31;
 ensure(55);
 text('GHI CHÚ / YÊU CẦU CHO XƯỞNG',M,y,12,true);y+=24;
 wrap(row.note||'Không có ghi chú.',W-M*2).forEach(part=>{ensure(21);text(part,M,y,12);y+=21});
 y+=26;ensure(70);line(y);y+=25;text('Tổng số lượng yêu cầu: '+sum(row.qty)+' sản phẩm',M,y,14,true);y+=23;text('Đối chiếu mẫu và yêu cầu với shop trước khi cắt.',M,y,10,false,'#5f7067');
 pages.forEach((canvas,i)=>{ctx=canvas.getContext('2d');line(835);text('Lên Nguyễn Store · Phiếu cắt hàng',M,853,9,false,'#758079');text('Trang '+(i+1)+' / '+pages.length,W-M-70,853,9,false,'#758079')});
 return cutPdfBytes(pages);
}
export async function createCutPdf(row){await prepare();return cutPlanPdf(row);}
export async function downloadCutPdf(row){
 const bytes=await createCutPdf(row),url=URL.createObjectURL(new Blob([bytes],{type:'application/pdf'}));
 const safe=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').replace(/[^a-zA-Z0-9_-]+/g,'-').slice(0,60);
 const a=document.createElement('a');a.href=url;a.download='Phieu-cat-hang_Lo-'+safe(row.lot)+'_'+safe(row.code)+'.pdf';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
}
