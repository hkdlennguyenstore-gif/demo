import {expenseRows} from './expense.mjs';
import {headerField} from '../document-reader/labels.mjs';
import {unzipSync} from './zip.mjs';
function unpack(bytes, accept) {
  let total = 0, count = 0;
  return unzipSync(bytes, {filter(entry) {
    if (entry.name.endsWith('/')) return false;
    if (!accept(entry.name)) return false;
    total += entry.originalSize;
    if (++count > 500 || total > 48 * 1024 * 1024) throw Error('Tệp giải nén quá lớn');
    return true;
  }});
}
function workbook(bytes) {
  const parts = unpack(bytes, name => /^xl\/(sharedStrings\.xml|worksheets\/sheet\d+\.xml)$/.test(name));
  function xml(part) {
    const doc = new DOMParser().parseFromString(new TextDecoder().decode(part), 'application/xml');
    if (doc.querySelector('parsererror')) throw Error('Excel lỗi cấu trúc');
    return doc;
  }
  const strings = parts['xl/sharedStrings.xml'] ? [...xml(parts['xl/sharedStrings.xml']).querySelectorAll('si')].map(e=>e.textContent) : [];
  const records=[];
  for(const [name,part] of Object.entries(parts)){
    if(!name.includes('/worksheets/')) continue;
    const rows=[...xml(part).querySelectorAll('row')].map(row=>{
      const cells={};
      for(const cell of row.querySelectorAll('c')){
        const value=cell.querySelector('v')?.textContent ?? cell.querySelector('is')?.textContent ?? '';
        cells[cell.getAttribute('r').replace(/\d/g,'')]=cell.getAttribute('t')==='s'?strings[Number(value)]:value;
      }
      return cells;
    });
    const header=rows.shift()||{};
    const fields=Object.values(header).map(headerField);
    if(!['transactionId','accountId','direction','zone','type','invoice'].every(key=>fields.includes(key)))continue;
    for(const row of rows){
      if(!Object.values(row).some(Boolean)) continue;
      const keys={transactionId:'ID giao dịch',accountId:'ID tài khoản',invoice:'Chứng từ',currency:'Tiền tệ',amount:'Số tiền',date:'Thời gian giao dịch',type:'Loại giao dịch phụ',status:'Trạng thái',zone:'Múi giờ',direction:'Loại tiền',description:'Mô tả'};const r=Object.fromEntries(Object.entries(header).map(([col,key])=>[keys[headerField(key)]||key,row[col]||'']));
      if(r['Tiền tệ']!=='VND'||!/^[-+]?\d+$/.test(r['Số tiền'])) throw Error('Tiền tệ hoặc số tiền chưa hỗ trợ');
      records.push({kind:'transaction',number:r['ID giao dịch'],account:r['ID tài khoản'],ref:r['Chứng từ'],date:String(r['Thời gian giao dịch']||'').replaceAll('/','-').replace(/年|月/g,'-').replace('日',''),type:r['Loại giao dịch phụ'],amount:Number(r['Số tiền']),status:r['Trạng thái'],zone:r['Múi giờ'],direction:r['Loại tiền'],method:String(r['Mô tả']||'').split('\n').at(-1)?.trim()||''});
    }
  }
  if(!records.length) throw Error('Cần Excel giao dịch TikTok Ads có cột ID giao dịch / Transaction ID / 交易编号');
  return records;
}
async function invoice(bytes){
  const {getDocument,GlobalWorkerOptions}=await import('./pdf.min.mjs');
  GlobalWorkerOptions.workerSrc=new URL('./pdf.worker.min.mjs',import.meta.url).href;
  const pdf=await getDocument({data:bytes,useSystemFonts:true,isEvalSupported:false}).promise;
  try{
    let content='';
    for(let page=1;page<=pdf.numPages;page++){
      const tokens=(await(await pdf.getPage(page)).getTextContent()).items;
      content+=' '+tokens.map(t=>t.str).join(' ').replace(/\s+/g,' ');
    }
    return invoiceFields(content);
  }finally{await pdf.destroy();}
}
export async function parseFile(file){
  const bytes=new Uint8Array(await file.arrayBuffer());
  if(/\.xlsx$/i.test(file.name)){
    try{return workbook(bytes);}catch(e){if(!e.message.startsWith('Cần Excel giao dịch'))throw e;return expenseRows(file);}
  }
  if(/\.pdf$/i.test(file.name)){
    try{return [await invoice(bytes)];}catch{return expenseRows(file);}
  }
  if(!/\.zip$/i.test(file.name))throw Error('Chọn ZIP, PDF hoặc XLSX');
  const files=unpack(bytes,name=>/\.(pdf|xlsx)$/i.test(name)&&!name.startsWith('__MACOSX/'));
  const rows=[];
  for(const [name,data] of Object.entries(files)){
    const entries=await parseFile(new File([data],name));
    for(const row of entries){if(row.kind==='evidence'){row.number=String(rows.length+1);row.member=name.slice(0,180);}rows.push(row);}
  }
  if(!rows.length)throw Error('ZIP không có PDF hoặc Excel');
  return rows;
}

export function invoiceFields(content){
    function field(re){const m=content.match(re);if(!m)throw Error('Thiếu trường hóa đơn '+re.source);return m[1];}
    if(!/TIKTOK PTE\. LTD/i.test(content)||!content.includes('Amount in VND')) throw Error('Cần hóa đơn TikTok Ads bằng VND');
    const ref=field(/Invoice No\.\s*(VNTT\d+)/);
    const money=re=>Number(field(re).replaceAll(',',''));
    const day=field(/Invoice Date\s*(\d{1,2},\s*[A-Za-z]+,\s*\d{4})/);
    const date=new Date(day+' 00:00:00 GMT').toISOString().slice(0,10);
    return {kind:'invoice',number:ref,ref,account:'',date,type:field(/Advertising Fees\s*(Prepayment On Account|Autopay On Account)/i),net:money(/Subtotal \(excluding Tax\)\s*([\d,]+)/),tax:money(/Total Tax\s*@[\d.]+%\s*([\d,]+)/),amount:money(/Total Amount Due\s*([\d,]+)/)};
}
