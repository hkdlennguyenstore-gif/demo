import {readDocument} from '../document-reader/read.mjs';
import {headerField} from '../document-reader/labels.mjs';
const channel=text=>/shopee|虾皮|蝦皮/i.test(text)?'shopee':/facebook|meta platforms/i.test(text)?'facebook':'';
function category(s){
 for(const [key,re] of [['platform',/phí sàn|commission|platform fee|佣金|平台费/i],['shipping',/vận chuyển|shipping|freight|运费/i],['packing',/bao bì|packaging|包装/i],['rent',/mặt bằng|rental|房租/i],['ads',/quảng cáo|advertising|ad spend|广告/i]])if(re.test(s))return key;
 return 'other';
}
export async function expenseRows(file){
 let doc;
 try{doc=await readDocument(file);}catch(e){if(!String(e.message).includes('Cần OCR'))throw e;doc={text:'PDF scan · cần bổ sung dữ liệu từ bản gốc',tables:[]};}
 return rowsFromDocument(doc,file);
}
export function rowsFromDocument(doc,file){
 const result=[];
 function row(fields,context){
  const raw=String(fields.spend||fields.amount||'').trim(),currency=String(fields.currency||'').trim();
  const valid=/^(?:VND|VNĐ|₫)$/i.test(currency)&&/^\+?\d+$/.test(raw)&&Number.isSafeInteger(Number(raw));
  const date=String(fields.date||'').replaceAll('/','-').match(/^\d{4}-\d\d-\d\d\b/)?.[0]||'';
  const ref=String(fields.invoice||fields.transactionId||'').slice(0,120);
  result.push({kind:'evidence',number:String(result.length+1),ref,date,account:String(fields.accountId||''),type:(fields.description||fields.type||file.name).slice(0,200),amount:valid?Number(raw):0,channel:channel(context),category:fields.spend?'ads':category(context),spend:Boolean(fields.spend),supplier:String(fields.supplier||'').slice(0,160),excerpt:context.slice(0,600)});
 }
 for(const table of doc.tables){
  const start=table.rows.findIndex(r=>r.some(h=>['amount','spend','invoice','transactionId'].includes(headerField(h))));
  if(start<0)continue;
  const keys=table.rows[start].map(headerField);
  for(const cells of table.rows.slice(start+1)){
   const fields=Object.fromEntries(keys.map((k,i)=>[k,cells[i]||'']));
   row(fields,[table.name,...cells].join(' '));
  }
 }
 if(!result.length){const content=doc.text;const amount=content.match(/(?:total amount due|grand total|tổng thanh toán|tong thanh toan|tổng cộng|tong cong|价税合计|总金额)\s*[:：]?\s*(?:VND\s*)?([\d.,]+)(?=\s|$)/i)?.[1];row({amount:amount&&/^(?:\d+|\d{1,3}(?:,\d{3})+|\d{1,3}(?:\.\d{3})+)$/.test(amount)?amount.replace(/[.,]/g,''):'',currency:/\bVND\b|VNĐ|₫/i.test(content)&&!/\b(?:USD|CNY|EUR)\b/i.test(content)?'VND':'',invoice:content.match(/(?:invoice (?:no\.?|number)|số hóa đơn|发票号码)\s*[:：]?\s*([\w/-]+)/i)?.[1],date:content.match(/\b20\d\d-\d\d-\d\d\b/)?.[0]},content);}
 return result;
}
