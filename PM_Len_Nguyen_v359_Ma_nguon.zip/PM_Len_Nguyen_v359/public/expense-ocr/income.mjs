// TikTok settlement exports include the same totals again on the report sheet.
const fees = ['Phí giao dịch','Phí hoa hồng của TikTok Shop','Phí xử lý đơn hàng'];
export function settlementFees(doc){
 const table=doc.tables.find(t=>t.name==='Chi tiết đơn hàng');
 if(!table)return null;
 const [headers,...records]=table.rows;
 if(!headers?.includes('ID đơn hàng/điều chỉnh'))return null;
 const order=headers.indexOf('ID đơn hàng/điều chỉnh'),currency=headers.indexOf('Đơn vị tiền tệ');
 const date=headers.indexOf('Thời gian quyết toán đơn hàng'),columns=fees.map(f=>headers.indexOf(f));
 if(currency<0||date<0||columns.some(c=>c<0))throw Error('Báo cáo thiếu cột phí, ngày quyết toán hoặc đơn vị tiền tệ.');
 const rows=[];
 for(const [index,record] of records.entries()){
   for(const col of columns){
     const raw=String(record[col]??'').trim();
     if(!raw||Number(raw)===0)continue;
     if(record[currency]!=='VND'||!/^[-+]?\d+$/.test(raw)||!Number.isSafeInteger(Number(raw)))throw Error('Cần kiểm tra tiền tệ hoặc số phí tại dòng '+(index+2));
     const charge=-Number(raw),ref=String(record[order]||''),day=String(record[date]||'').replaceAll('/','-');
     rows.push({signedFee:charge,amount:charge>0?charge:0,type:headers[col],ref,date:day,identity:table.name+'|'+(index+2)+'|'+col,meta:{'Mã đơn gốc':ref,'Loại phí':headers[col]},excerpt:[ref,day,headers[col],raw+' VND',charge<0?'Hoàn phí · chỉ đối chiếu':''].filter(Boolean).join(' · ')});
   }
 }
 return {rows,text:records.length+' dòng quyết toán · '+rows.length+' dòng phí giao dịch, hoa hồng TikTok Shop và xử lý đơn có giá trị.'};
}
