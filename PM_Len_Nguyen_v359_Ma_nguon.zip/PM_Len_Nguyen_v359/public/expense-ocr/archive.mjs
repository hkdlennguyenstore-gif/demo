import {unzipSync} from '../ads-import/zip.mjs';
import {invoiceFields} from '../ads-import/read.mjs';

export function extract(text){
 const s=text.replace(/\s+/g,' ').trim();
 try{return {...invoiceFields(s),supplier:'TIKTOK PTE. LTD.',description:'Advertising Fees'};}catch{}
 const field=re=>s.match(re)?.[1]?.trim()||'';
 const value=re=>{const raw=field(re);return raw&&/^(?:\d+|\d{1,3}(?:,\d{3})+)$/.test(raw)?Number(raw.replaceAll(',','')):null};
 return {kind:'evidence',type:/top.?up|tiền nạp|充值/i.test(s)?'Tiền nạp':/invoice|hóa đơn|发票/i.test(s)?'Hóa đơn':/actual spend|chi tiêu thực tế|实际消耗/i.test(s)?'Chi tiêu thực tế':'Chờ phân loại',ref:field(/(?:invoice (?:no\.?|number)|số hóa đơn|发票号码)\s*[:：]?\s*([\w/-]+)/i),account:field(/(?:advertiser id|account id|mã tài khoản|账户编号)\s*[:：]?\s*(\d+)/i),date:field(/(?:invoice date|ngày hóa đơn|开票日期)\s*[:：]?\s*(\d{4}-\d\d-\d\d)/i),supplier:'',description:'',net:value(/(?:subtotal \(excluding tax\)|tiền trước thuế|不含税金额)\s*[:：]?\s*([\d,.]+)/i),tax:value(/(?:total tax(?: @[\d.]+%)?|tiền thuế|税额)\s*[:：]?\s*([\d,.]+)/i),amount:value(/(?:total amount due|tổng thanh toán|价税合计)\s*[:：]?\s*([\d,.]+)/i)};
}
export async function readArchive(file,read,onProgress){
 if(file.size>48*1024*1024)throw Error('ZIP vượt 48 MB.');
 const bytes=new Uint8Array(await file.arrayBuffer()),files=[];let expanded=0;
 unzipSync(bytes,{filter(entry){if(/\.pdf$/i.test(entry.name)&&!entry.name.startsWith('__MACOSX/')){expanded+=entry.originalSize;files.push(entry);if(files.length>500||expanded>128*1024*1024)throw Error('ZIP vượt 500 PDF hoặc 128 MB sau giải nén.')}return false;}});
 if(!files.length)throw Error('ZIP không có PDF.');
 const results=files.map(e=>({name:e.name}));onProgress([...results]);
 for(const [i,entry] of files.entries()){
  let pdf;
  try{
   if(files.filter(e=>e.name===entry.name).length>1)throw Error('Trùng đường dẫn PDF trong ZIP.');
   if(entry.originalSize>12*1024*1024)throw Error('PDF vượt 12 MB.');
   const part=unzipSync(bytes,{filter:e=>e.name===entry.name})[entry.name];
   pdf=new File([part],entry.name.split('/').at(-1),{type:'application/pdf'});
   const doc=await read(pdf),row=extract(doc.text);
   results[i]={name:entry.name,pdf,row};
  }catch(e){results[i]={name:entry.name,pdf,error:e.message||'Không đọc được PDF.'};}
  onProgress([...results]);
 }
 return results;
}
