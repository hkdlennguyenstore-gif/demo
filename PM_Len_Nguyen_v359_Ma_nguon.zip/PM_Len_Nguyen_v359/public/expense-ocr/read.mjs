import {readDocument} from '../document-reader/read.mjs';
import {rowsFromDocument} from '../ads-import/expense.mjs';
import {settlementFees} from './income.mjs';
import {groupRows} from './fields.mjs';
async function recognize(file, scan, payment=false, retryIfIncomplete) {
  const {default:Tesseract}=await import('./tesseract.esm.min.js');
  const url=name=>new URL(name,import.meta.url).href;
  const worker=await Tesseract.createWorker(payment?['vie','eng']:['eng','vie','chi_sim','chi_tra'],1,{
    workerPath:url('worker.min.js'),corePath:url('tesseract-core-lstm.wasm.js'),
    langPath:url('./'),workerBlobURL:false
  });
  try {
    if (!scan) {
      if(payment)await worker.setParameters({tessedit_pageseg_mode:'6'});
      const original=(await worker.recognize(file)).data.text;
      if(!payment||!retryIfIncomplete?.(original))return original;
      try {
        const image=await createImageBitmap(file);
        try {
          const scale=Math.min(2.5,2400/Math.max(image.width,image.height));
          const canvas=document.createElement('canvas');
          canvas.width=Math.max(1,Math.round(image.width*scale));
          canvas.height=Math.max(1,Math.round(image.height*scale));
          const context=canvas.getContext('2d');
          context.fillStyle='white';context.fillRect(0,0,canvas.width,canvas.height);
          context.filter='grayscale(1) contrast(1.25)';
          context.drawImage(image,0,0,canvas.width,canvas.height);
          await worker.setParameters({tessedit_pageseg_mode:'11'});
          const second=(await worker.recognize(canvas)).data.text;
          return {text:original,second};
        }finally{image.close();}
      }catch{return original;}
    }
    const {getDocument,GlobalWorkerOptions}=await import('../ads-import/pdf.min.mjs');
    GlobalWorkerOptions.workerSrc=url('../ads-import/pdf.worker.min.mjs');
    const pdf=await getDocument({data:await file.arrayBuffer(),isEvalSupported:false}).promise;
    try {
      if(pdf.numPages>100)throw Error('PDF vượt 100 trang.');
      const pages=[];
      for(let i=1;i<=pdf.numPages;i++){
        const page=await pdf.getPage(i),base=page.getViewport({scale:1});
        const viewport=page.getViewport({scale:Math.min(2,2000/Math.max(base.width,base.height))});
        const canvas=document.createElement('canvas');canvas.width=viewport.width;canvas.height=viewport.height;
        await page.render({canvas,viewport}).promise;
        pages.push((await worker.recognize(canvas)).data.text);
        canvas.width=canvas.height=0;
      }
      return pages.join('\n');
    }finally{await pdf.destroy();}
  }finally{await worker.terminate();}
}
export async function readExpense(file,group,retryIfIncomplete){
  if(!file.size||file.size>5*1024*1024)throw Error('Chọn một tệp tối đa 5 MB.');
  let doc;
  if(/\.(jpe?g|webp|png)$/i.test(file.name)||file.type.startsWith('image/')){const value=await recognize(file,false,group==='payment-date',retryIfIncomplete);doc=typeof value==='string'?{text:value,tables:[]}:{...value,tables:[]};}
  else try{doc=await readDocument(file,{expenseWorkbook:group==='platform'&&/\.xlsx$/i.test(file.name)});}catch(e){
    if(!/Cần OCR/.test(e.message))throw e;
    doc={text:await recognize(file,true,group==='payment-date'),tables:[]};
  }
  if(!doc.text.trim()&&!doc.second?.trim())throw Error('Không đọc được chữ. Chụp lại rõ và đủ sáng.');
  if(group==='payment-date')return {text:doc.text,second:doc.second,rows:[]};
  if(group==='platform'){const settlement=settlementFees(doc);if(settlement)return settlement;}
  const specific=groupRows(doc,group);
  return {text:doc.text.slice(0,6000),rows:specific.length?specific:rowsFromDocument(doc,file)};
}
window.pmReadExpense=readExpense;

import {readArchive,extract} from './archive.mjs';
async function readArchivedText(pdf){
 let text;try{text=(await readDocument(pdf)).text;}catch(e){if(!/Cần OCR/.test(e.message))throw e;text=await recognize(pdf,true);}
 if(!text.trim())throw Error('OCR chưa nhận diện được chữ.');
 return {text};
}
window.pmReadArchivedPdf=async pdf=>extract((await readArchivedText(pdf)).text);
window.pmReadExpenseZip=(file,progress)=>readArchive(file,readArchivedText,progress);
