const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/đ/g,'d').trim();
const amountColumns={
 platform:['phí sàn','phí thanh toán','commission fee','transaction fee','platform fee'],
 promotion:['shop chịu','seller discount','seller voucher discount','seller subsidy','khuyến mãi shop chịu'],
 shipping:['phí shop chịu','seller shipping fee','seller shipping cost'],
 returns:['chi phí phát sinh','return shipping fee'],ads:['ad spend','chi tiêu thực chạy','phí dịch vụ'],
 staff:['thù lao bổ sung'],content:['thù lao'],operations:['tổng thanh toán'],software:['phí dịch vụ'],
 administration:['số phí'],equipment:['giá trị'],cogs:['giá vốn'],packing:['thành tiền']
};
const extras={
 'Mã đơn gốc':['order id','order number','mã đơn hàng','mã đơn'], 'Mã quyết toán':['settlement id'],
 'Mã vận đơn':['tracking number','tracking id'],'Hãng vận chuyển':['carrier'],
 'Tài khoản quảng cáo':['account id'],'Nhà cung cấp':['vendor','supplier'],
 'Kỳ thanh toán':['billing period'],'Loại phí':['fee type'],'Voucher / chương trình':['voucher code'],
 'Nhân viên':['employee'],'Kỳ lương':['payroll month'],'Buổi livestream / nội dung':['livestream'],
 'Người hoặc đơn vị thực hiện':['performer'],'Thời gian sử dụng':['useful life']
};
export function groupRows(doc,group){
 const rows=[],moneyKeys=(amountColumns[group]||[]).map(norm);
 for(const t of doc.tables){
  if(t.rows.length<2)continue;
  const headers=t.rows[0].map(norm);
  const matches=headers.map((h,i)=>moneyKeys.includes(h.replace(/\s*\(?(?:vnd|vnđ|đ|₫)\)?$/i,'').trim())?i:-1).filter(i=>i>=0);
  if(!matches.length)continue;
  for(const [idx,cells] of t.rows.slice(1).entries()){
   function get(...names){const i=headers.findIndex(h=>names.map(norm).includes(h));return i<0?'':String(cells[i]??'').trim();}
   for(const col of matches){
    const currency=get('Tiền tệ','Currency')||(/vnd|vnđ|₫/i.test(t.rows[0][col])?'VND':'');
    const raw=String(cells[col]??'').trim(),amount=/^(vnd|vnđ|₫)$/i.test(currency)&&/^\d+$/.test(raw)?Number(raw):0;
    const meta=Object.fromEntries(Object.entries(extras).map(([k,a])=>[k,get(k,...a)]).filter(([,v])=>v));
    if(group==='platform')meta['Loại phí']||=t.rows[0][col];
    if(group==='ads')meta['Loại khoản']=headers[col]===norm('Phí dịch vụ')?'Phí dịch vụ':'Chi tiêu thực chạy';
    rows.push({amount:Number.isSafeInteger(amount)?amount:0,type:get('Nội dung','Description')||t.rows[0][col],ref:get('Mã chứng từ','Invoice Number'),supplier:get('Nhà cung cấp','Supplier'),date:get('Ngày','Date').match(/^20\d\d-\d\d-\d\d$/)?.[0]||'',spend:group==='ads',meta,identity:t.name+'|'+(idx+2)+'|'+col,excerpt:[t.name,'Dòng '+(idx+2),...cells].join(' · ')});
   }
  }
 }
 return rows;
}
