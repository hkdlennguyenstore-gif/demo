// Online-only shell: do not cache authenticated pages, API responses or documents.
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  if(event.request.mode!=='navigate'||event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
  event.respondWith(fetch(event.request).catch(()=>new Response(`<!doctype html><html lang="vi"><head><meta name="viewport" content="width=device-width,initial-scale=1"><meta charset="utf-8"><title>PM · Chưa có kết nối</title></head><body style="font-family:system-ui;background:#f7f8f5;color:#214c43;padding:32px;max-width:500px;margin:auto"><h1>Chưa có kết nối Internet</h1><p>Kết nối lại để mở PM và xem dữ liệu mới nhất.</p><p>Các thao tác chưa được máy chủ xác nhận cần kiểm tra lại sau khi có mạng.</p><button style="font:inherit;padding:12px 20px" onclick="location.reload()">Thử lại</button></body></html>`,{status:503,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}})));
});
