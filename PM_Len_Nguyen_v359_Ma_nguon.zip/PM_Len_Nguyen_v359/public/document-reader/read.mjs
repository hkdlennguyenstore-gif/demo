import {unzipSync} from '../ads-import/zip.mjs';
import {decodeText,parseDelimited,detectLanguages,textGlossary,labelVN} from './labels.mjs';
function unpack(bytes,accept){let total=0,count=0;return unzipSync(bytes,{filter(e){if(!accept(e.name))return false;total+=e.originalSize;if(++count>200||total>24*1024*1024)throw Error('Nội dung giải nén quá lớn');return true;}});}
const xml=b=>{const d=new DOMParser().parseFromString(new TextDecoder('utf-8',{fatal:true}).decode(b),'application/xml');if(d.querySelector('parsererror'))throw Error('Tệp XML lỗi cấu trúc');return d;};
const elements=(d,name)=>[...d.getElementsByTagNameNS('*',name)];
async function* worksheetRows(bytes,chunked){
 if(chunked){
   const source=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
   const data=source.match(/<sheetData>([\s\S]*?)<\/sheetData>/);
   if(data){
     const pattern=/<row\b[^>]*?(?:\/>|>[\s\S]*?<\/row>)/gy;
     let offset=0,chunk=[];
     while(offset<data[1].length){
       pattern.lastIndex=offset;
       const match=pattern.exec(data[1]);
       if(!match)throw Error('Chưa đọc đủ dòng trong trang tính.');
       offset=pattern.lastIndex;chunk.push(match[0]);
       while(/\s/.test(data[1][offset]||'!'))offset++;
       if(chunk.length===128||offset===data[1].length){
         const root=source.match(/<worksheet\b[^>]*>/)?.[0];
         if(!root)throw Error('Thiếu cấu trúc trang tính.');
         yield* elements(xml(new TextEncoder().encode(root+chunk.join('')+'</worksheet>')),'row');
         chunk=[];await new Promise(resolve=>setTimeout(resolve,0));
       }
       while(/\s/.test(data[1][offset]||'!'))offset++;
     }
     return;
   }
 }
 yield* elements(xml(bytes),'row');
}
export async function readDocument(file,{encoding='auto',expenseWorkbook=false}={}){if(!file.size||file.size>12*1024*1024)throw Error('Chọn tệp tối đa 12 MB');const bytes=new Uint8Array(await file.arrayBuffer()),tables=[],warnings=[];let text='',cells=0;const ext=file.name.split('.').pop().toLowerCase();
if(['txt','csv','tsv'].includes(ext)){text=decodeText(bytes,encoding).replace(/^\uFEFF/,'');if(ext!=='txt'){const delimiter=ext==='tsv'?'\t':[',',';','\t'].map(d=>({d,n:parseDelimited(text.split(/\r?\n/)[0],d)[0]?.length||0})).sort((a,b)=>b.n-a.n)[0].d;tables.push({name:file.name,rows:parseDelimited(text,delimiter)});}}
else if(ext==='xlsx'){const parts=unpack(bytes,n=>/^xl\/(sharedStrings\.xml|workbook\.xml|_rels\/workbook\.xml\.rels|worksheets\/sheet\d+\.xml)$/.test(n));const strings=parts['xl/sharedStrings.xml']?elements(xml(parts['xl/sharedStrings.xml']),'si').map(e=>elements(e,'t').map(t=>t.textContent).join('')):[],names={};if(parts['xl/workbook.xml']&&parts['xl/_rels/workbook.xml.rels']){const rel=elements(xml(parts['xl/_rels/workbook.xml.rels']),'Relationship');for(const sheet of elements(xml(parts['xl/workbook.xml']),'sheet')){const target=rel.find(r=>r.getAttribute('Id')===sheet.getAttribute('r:id'))?.getAttribute('Target');if(target)names[target.startsWith('/')?target.slice(1):'xl/'+target.replace(/^\.\//,'')]=sheet.getAttribute('name');}}
for(const [name,b] of Object.entries(parts)){if(!name.includes('/worksheets/'))continue;const rows=[];for await(const row of worksheetRows(b,expenseWorkbook&&b.length>2000000)){const values=[];for(const cell of elements(row,'c')){const ref=cell.getAttribute('r')||'',col=ref.replace(/\d/g,'');let index=0;for(const c of col)index=index*26+c.charCodeAt(0)-64;if(index<1||index>200)throw Error('Bảng vượt 200 cột');const raw=elements(cell,'v')[0]?.textContent??elements(cell,'t').map(t=>t.textContent).join('');values[index-1]=cell.getAttribute('t')==='s'?strings[Number(raw)]??'':raw;if(elements(cell,'f').length)warnings.push('Excel có công thức: chỉ đọc kết quả đã lưu, không tính lại.');}if(values.some(v=>v!==''&&v!=null))rows.push(Array.from({length:values.length},(_,i)=>values[i]??''));}tables.push({name:names[name]||name,rows});}warnings.push('Giữ nguyên số và ID trong tệp. Ngày Excel dạng số cần đối chiếu định dạng gốc; không tự quy đổi tiền tệ.');}
else if(ext==='docx'){const parts=unpack(bytes,n=>n==='word/document.xml');if(!parts['word/document.xml'])throw Error('Không thấy nội dung Word');text=elements(xml(parts['word/document.xml']),'p').map(p=>elements(p,'t').map(t=>t.textContent).join('')).join('\n');}
else if(ext==='pdf'){const {getDocument,GlobalWorkerOptions}=await import('../ads-import/pdf.min.mjs');GlobalWorkerOptions.workerSrc=new URL('../ads-import/pdf.worker.min.mjs',import.meta.url).href;const pdf=await getDocument({data:bytes,isEvalSupported:false,useSystemFonts:true}).promise;try{if(pdf.numPages>100)throw Error('PDF vượt 100 trang; tách tệp trước khi đọc');for(let n=1;n<=pdf.numPages;n++){const content=await(await pdf.getPage(n)).getTextContent();let pageText='',line='',y=null;for(const t of content.items){if(!('str'in t))continue;if(y!==null&&Math.abs(y-t.transform[5])>3){pageText+=line+'\n';line='';}line+=t.str+(t.hasEOL?'\n':' ');y=t.transform[5];}text+=`\n[Trang ${n}]\n`+pageText+line+'\n';if(text.length>500000)throw Error('Nội dung vượt giới hạn; tách tệp trước khi đọc');}if(text.replace(/\[Trang \d+\]/g,'').trim().length<5)throw Error('PDF không có lớp chữ đọc được. Cần OCR cho bản scan; PM chưa trích được nội dung tệp này.');}finally{await pdf.destroy();}}
else throw Error('Hỗ trợ PDF có lớp chữ, XLSX, CSV, TSV, DOCX và TXT. Ảnh/scan cần OCR riêng.');
for(const t of tables){cells+=t.rows.reduce((n,r)=>n+r.length,0);if(cells>(expenseWorkbook?1200000:50000)||t.rows.length>(expenseWorkbook?50000:10000))throw Error('Bảng quá lớn; chia tệp trước khi đọc, không cắt ngầm dữ liệu');t.headers=(t.rows[0]||[]).map(original=>({original,label:labelVN(original)}));}if(expenseWorkbook&&ext==='xlsx')text=tables.map(t=>t.name+' · '+t.rows.length+' dòng').join('\n');else if(tables.length)text=tables.map(t=>t.name+'\n'+t.rows.map(r=>r.join('\t')).join('\n')).join('\n\n');if(text.length>500000)throw Error('Nội dung vượt 500.000 ký tự; chia tệp trước khi đọc');if(!text.trim())throw Error('Tệp không có nội dung đọc được');return {name:file.name,text,tables,languages:detectLanguages(text),glossary:textGlossary(text),warnings:[...new Set(warnings)]};}
